import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DoughnutChartTicketComponent } from './doughnut-chart-ticket.component';

describe('DoughnutChartTicketComponent', () => {
  let component: DoughnutChartTicketComponent;
  let fixture: ComponentFixture<DoughnutChartTicketComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DoughnutChartTicketComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DoughnutChartTicketComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
