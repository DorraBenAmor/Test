import { Component, OnInit, Input, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';
import { ChartType } from 'chart.js';
import { FicheModel } from '../models/fiche.model';
import { User } from '../models/user.model';
import { Entreprise } from '../models/entreprise.model';
import { DashboardService } from '../services/dashboard.service';
import { Connection } from '../models/connection.model';
import { ConnexionService } from '../services/connexion.service';
import { TypeObjetModel } from '../models/typeObjet.model';
import { EtatModel } from '../models/etat.model';
import { ModuleModel } from '../models/module.model';
import { OrdrePrioriteModel } from '../models/ordrePriorite.model';
import { URLModel } from '../models/url.model';
import { DataLoadingService } from '../services/dataLoading.service';
import { StatistiquesTicketsService } from '../services/statistiques_tickets.service';
import { yearsPerPage } from '@angular/material/datepicker';
import { TransitionCheckState } from '@angular/material/checkbox';

@Component({
  selector: 'app-doughnut-chart-ticket',
  templateUrl: './doughnut-chart-ticket.component.html',
  styleUrls: ['./doughnut-chart-ticket.component.css']
})
export class DoughnutChartTicketComponent implements OnInit, OnDestroy {
  @Input() selected: string;
  @Input() selected2: string;
  @Input() periode: string;
  @Input() selectedEntreprise: string;
  @Input() selectedBase: string;

  // DECLARATION DES VARIABLES

  // Données du user connecté
  currentUser: Connection;
  private subscription: Subscription;

  // Loading Data
  private subscriptionLoadData: Subscription
  listSubscription = <Subscription[]>[];

  // Données de la BDD
  fiches: FicheModel[] = [];
  fichesPeriode: FicheModel[] = [];
  typesObjet: TypeObjetModel[] = [];
  etats: EtatModel[] = [];
  modules: ModuleModel[] = [];
  ordresPriorite: OrdrePrioriteModel[] = [];
  urls: URLModel[] = [];
  resposDossier: User[] = [];
  entreprises: Entreprise[] = [];
  dashboardComponents: any[] = [];

  // Paramètres DoughnutChart Tickets
  doughnutChartReadyTickets: boolean = false;
  doughnutChartLabelsTickets: any[] = [];
  doughnutChartDataTickets: any[] = [];
  doughnutChartLegendTickets: boolean = true;
  doughnutChartType: ChartType;
  doughnutChartOptions: any = {};
  colors:any []= [];
  legendeTickets: string = "";
   doughnutChartColors: Array<any>

  // Data
  CategorieObjetCount: any[] = [];
  total : number ;
  quantite : number;
  
  // Chemin de la page
  href: string;


  constructor(private dataLoadingService: DataLoadingService,public stats: StatistiquesTicketsService, private cdRef: ChangeDetectorRef, private router: Router, private connexionService: ConnexionService, private dashboardService: DashboardService) { }
  
    

  getRandomColor() {
  var x = Math.floor(Math.random() * 256);
  var y = Math.floor(Math.random() * 256);
  var z = Math.floor(Math.random() * 256);
  var bgColor = "rgb(" + x + "," + y + "," + z + ")";
  return bgColor;
    }
  
  
  ngOnInit(): void {
    this.stats.entreprise= '';
    this.stats.base='';

 let date= new Date()
this.stats.jour=""+date.getFullYear();
this.stats.mois=""+(date.getMonth()+1)
this.stats.filtre=this.selected;


   console.log("Je suis selectionnée",this.selected)

    // Initialisation des variables
    this.href = this.router.url;
    //Paramétrage DoughnutChart
    this.doughnutChartOptions = {
      responsive: true,
      legend: {position: 'right'}
    }
    this.doughnutChartType = 'doughnut';
    this.doughnutChartLegendTickets = true;
    console.log(this.getRandomColor());

    // on le definit toujours à vide
    this.fichesPeriode = []
    
    
    // Mise à jour du tableau des graphes ouverts
    this.dataLoadingService.chartOpened.doughnutChartTicket = 1

    // Récupération des données du user connecté
    this.subscription = this.connexionService.connexionSubject.subscribe(datas => {
      this.currentUser = datas;
    })
    this.connexionService.emitConnection();

    // Récupération des données de la BDD
    this.subscriptionLoadData = this.dataLoadingService.DoughnutChartTicketloadDataCalled.subscribe(() => {
      this.dashboardComponents = this.dataLoadingService.dashboardComponents
      this.entreprises = this.dataLoadingService.entreprises
      this.resposDossier = this.dataLoadingService.resposDossier
      this.urls = this.dataLoadingService.urls
      this.ordresPriorite = this.dataLoadingService.ordresPriorite
      this.modules = this.dataLoadingService.modules
      this.etats = this.dataLoadingService.etats
      this.typesObjet = this.dataLoadingService.typesObjet
      this.fiches = this.dataLoadingService.fiches

    
    });
    //Initialisation
    this.stats.entreprise = this.selectedEntreprise
    this.stats.base = this.selectedBase
    
    console.log(this.selected + " " + this.periode + " " + this.selectedEntreprise + " " + this.selectedBase + " " + this.selected2 + " ", "Testing")
    if(this.selected!=='Entreprise' && this.selected!=='Base - Entreprise' )    {
    this.handleClick(this.selected, this.periode, [])}
    else
    {
    this.stats.filtre=this.selected2;
    this.handleClickCritère(this.selected2, this.periode, [])
    }// Chargement des données de la BDD
   // this.chargementDonneesBDD()
  }

  ngOnDestroy(): void {
    this.listSubscription.map((elem) => elem.unsubscribe());
    this.subscription.unsubscribe();
    this.subscriptionLoadData.unsubscribe()
  }

  chartHovered(event: Event){}
  chartClicked(event: Event){}

  activeLegend() {
    this.doughnutChartLegendTickets = !this.doughnutChartLegendTickets
  }

  handleClickCritère(value: string, periode: string, fichesPeriode: FicheModel[])
  {
    this.selected2=value;
    this.periode = periode
    this.stats.entreprise=this.selectedEntreprise;
    this.stats.base=this.selectedBase;
    
 
    this.doughnutChartReadyTickets = false;
    //Calcul en pourcentage & Paramétrage DoughnutChart Nombre de tickets
    this.doughnutChartLabelsTickets = [];
    this.doughnutChartDataTickets = [];
 

    if(this.selected==='Entreprise')
    {
      switch(periode)
      {
        case 'Année':
          this.legendeTickets = "Pourcentage de tickets par "+this.selected2.toLowerCase()+" de l\'année pour l'entreprise "+this.selectedEntreprise;
       

          this.doughnutChartType = 'doughnut';
          this.stats.filtre=this.selected2;
          console.log(this.selected);
          //On récupère les catégories selon le filtre.
          const variable = this.stats.getCategorieStats().subscribe((response:any) => {
            //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
            this.CategorieObjetCount = response.data; 
     
  
            this.stats.filtre=this.selected2;
            this.stats.entreprise = this.selectedEntreprise
            this.stats.base = this.selectedBase
          const variable2 = this.stats.gettotalStatsbyEntreprise().subscribe((response) => {
            //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
            this.total = JSON.parse(JSON.stringify(response)).data[0].total; 
            console.log(this.total)
        
            });
            //Détruire la souscription
            this.listSubscription.push(variable2);
            console.log(this.CategorieObjetCount);
            for(let item of this.CategorieObjetCount){
              this.colors.push(this.getRandomColor());
              this.stats.categorie=item.category;
              this.stats.filtre=this.selected2;
              console.log(this.CategorieObjetCount);
              console.log(this.stats.categorie)
             
              const variable3 = this.stats.getQuantityStatsbyEntreprise().subscribe((response) => {
                //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
                  console.log(response);
                this.quantite = JSON.parse(JSON.stringify(response)).data[0].sum; 
                console.log("categorie ",item.category," quantite ",this.quantite );
          
                this.doughnutChartLabelsTickets.push(" " + item.category);
                this.doughnutChartDataTickets.push(Number(this.quantite/this.total*100).toFixed(2));
              this.doughnutChartReadyTickets = true;
          });
          //Détruire la souscription
          this.listSubscription.push(variable3);
          }
          this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
          this.colors=[]
          });
          //Détruire la souscription
          this.listSubscription.push(variable);
          
          
          
          // this.sortFiches(value, fichesPeriode)
          console.log(value);
          console.log(periode);
          console.log(fichesPeriode);
      
          break;

        case 'Mois':
          this.legendeTickets = "Pourcentage de tickets par "+this.selected2.toLowerCase()+" du mois pour l'entreprise "+this.selectedEntreprise;
        
     
      
  
          this.doughnutChartType = 'doughnut';
          
          console.log(this.selected);
          //On récupère les catégories selon le filtre.
          const variable4 = this.stats.getCategorieStats().subscribe((response:any) => {
            //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
            this.CategorieObjetCount = response.data; 
  
     
            this.stats.filtre=this.selected2;
            this.stats.entreprise = this.selectedEntreprise
            this.stats.base = this.selectedBase
  
          const variable2 = this.stats.gettotalStatsByMonthbyEntreprise().subscribe((response) => {
            //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
            this.total = JSON.parse(JSON.stringify(response)).data[0].total; 
            console.log(this.total)
        
            });
            //Détruire la souscription
            this.listSubscription.push(variable2);
            console.log(this.CategorieObjetCount);
            for(let item of this.CategorieObjetCount){
              this.colors.push(this.getRandomColor());
              this.stats.categorie=item.category;
              this.stats.filtre=this.selected2;

              console.log(this.CategorieObjetCount);
              console.log(this.stats.categorie)
              
              const variable3 = this.stats.getQuantityStatsByMonthbyEntreprise().subscribe((response) => {
                //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
                  console.log(response);
                this.quantite = JSON.parse(JSON.stringify(response)).data[0].sum; 
                console.log("categorie ",item.category," quantite ",this.quantite );
              
                  this.doughnutChartLabelsTickets.push(" " + item.category);
                  this.doughnutChartDataTickets.push(Number(this.quantite/this.total*100).toFixed(2));
              
                this.doughnutChartReadyTickets = true;
              });
              //Détruire la souscription
              this.listSubscription.push(variable3);
    
              }
              this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
              this.colors=[]
              });
              //Détruire la souscription
              this.listSubscription.push(variable4);
    
              // this.sortFiches(value, fichesPeriode)
                console.log(value);
                console.log(periode);
                console.log(fichesPeriode);
  
          break;
        case 'Semaine':
          this.legendeTickets = "Pourcentage de tickets par "+this.selected2.toLowerCase()+" de la semaine pour l'entreprise "+this.selectedEntreprise;
       
     
      
  
          this.doughnutChartType = 'doughnut';
          this.stats.filtre=this.selected2;
          console.log(this.selected);
          //On récupère les catégories selon le filtre.
          const variable5 = this.stats.getCategorieStats().subscribe((response:any) => {
            //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
            this.CategorieObjetCount = response.data; 
           
       
            this.stats.filtre=this.selected2;
            this.stats.entreprise = this.selectedEntreprise
            this.stats.base = this.selectedBase
    
          const variable2 = this.stats.gettotalStatsByWeekbyEntreprise().subscribe((response) => {
            //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
            this.total = JSON.parse(JSON.stringify(response)).data[0].total; 
            console.log(this.total)
        
          });
          //Détruire la souscription
          this.listSubscription.push(variable2);
          console.log(this.CategorieObjetCount);
          for(let item of this.CategorieObjetCount){
            this.colors.push(this.getRandomColor());
            this.stats.categorie=item.category;
            this.stats.filtre=this.selected2;
            console.log(this.CategorieObjetCount);
            console.log(this.stats.categorie)
            
            const variable3 = this.stats.getQuantityStatsByWeekbyEntreprise().subscribe((response) => {
              //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
                console.log(response);
              this.quantite = JSON.parse(JSON.stringify(response)).data[0].sum; 
              console.log("categorie ",item.category," quantite ",this.quantite );
            
                this.doughnutChartLabelsTickets.push(" " + item.category);
                this.doughnutChartDataTickets.push(Number(this.quantite/this.total*100).toFixed(2));
            
              this.doughnutChartReadyTickets = true;
            });
            //Détruire la souscription
            this.listSubscription.push(variable3);
    
    
            }
            this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
            this.colors=[]
          });
          //Détruire la souscription
          this.listSubscription.push(variable5);
  
    
    
          // this.sortFiches(value, fichesPeriode)
          console.log(value);
          console.log(periode);
          console.log(fichesPeriode);
      
          break;
        case 'Tout':
          this.legendeTickets = "Pourcentage de tickets "+this.selected2.toLowerCase() + "pour l'entreprise "+this.selectedEntreprise;
       
     
      
  
          this.doughnutChartType = 'doughnut';
          this.stats.filtre=this.selected2;
          console.log(this.selected);
          //On récupère les catégories selon le filtre.
          const variable6 = this.stats.getCategorieStats().subscribe((response:any) => {
            //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
            this.CategorieObjetCount = response.data; 
        
     
  
            this.stats.filtre=this.selected2;
            this.stats.entreprise = this.selectedEntreprise
            this.stats.base = this.selectedBase
          const variable2 = this.stats.getAlltotalStatsbyEntreprise().subscribe((response) => {
            //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
            this.total = JSON.parse(JSON.stringify(response)).data[0].total; 
            console.log(this.total)
        
            });
          //Détruire la souscription
          this.listSubscription.push(variable2);
          console.log(this.CategorieObjetCount);
          for(let item of this.CategorieObjetCount){
            this.colors.push(this.getRandomColor());
            this.stats.categorie=item.category;
            this.stats.filtre=this.selected2;
            console.log(this.CategorieObjetCount);
            console.log(this.stats.categorie)
           

            const variable3 = this.stats.getAllQuantityStatsbyEntreprise().subscribe((response) => {
              //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
                console.log(response);
              this.quantite = JSON.parse(JSON.stringify(response)).data[0].sum; 
              console.log("categorie ",item.category," quantite ",this.quantite );
         
                this.doughnutChartLabelsTickets.push(" " + item.category);
                this.doughnutChartDataTickets.push(Number(this.quantite/this.total*100).toFixed(2));
            
              this.doughnutChartReadyTickets = true;
            });
            //Détruire la souscription
            this.listSubscription.push(variable3);
  
  
          }
          this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
          this.colors=[]
          });
          //Détruire la souscription
          this.listSubscription.push(variable6);
  
  
  
          // this.sortFiches(value, fichesPeriode)
          console.log(value);
          console.log(periode);
          console.log(fichesPeriode);
      
          break;
        case 'Periode':
          this.legendeTickets = "Pourcentage de tickets par "+this.selected2.toLowerCase()+" de la période pour l'entreprise "+this.selectedEntreprise;
       
     
      
  
          this.doughnutChartType = 'doughnut';
          this.stats.filtre=this.selected2;
          console.log(this.selected);
          //On récupère les catégories selon le filtre.
          const variable7 = this.stats.getCategorieStats().subscribe((response:any) => {
            //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
            this.CategorieObjetCount = response.data; 
       
       
            this.stats.filtre=this.selected2;
            this.stats.entreprise = this.selectedEntreprise
            this.stats.base = this.selectedBase
      
          const variable2 = this.stats.getPeriodetotalStatsbyEntreprise().subscribe((response) => {
            //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
            this.total = JSON.parse(JSON.stringify(response)).data[0].total; 
            console.log(this.total)
      
          });
          //Détruire la souscription
          this.listSubscription.push(variable2);
          console.log(this.CategorieObjetCount);
          for(let item of this.CategorieObjetCount){
            this.colors.push(this.getRandomColor());
            this.stats.categorie=item.category;
            this.stats.filtre=this.selected2;
            console.log(this.CategorieObjetCount);
            console.log(this.stats.categorie)
       
            const variable3 = this.stats.getPeriodeQuantityStatsbyEntreprise().subscribe((response) => {
              //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
                console.log(response);
              this.quantite = JSON.parse(JSON.stringify(response)).data[0].sum; 
              console.log("categorie ",item.category," quantite ",this.quantite );
            
                this.doughnutChartLabelsTickets.push(" " + item.category);
                this.doughnutChartDataTickets.push(Number(this.quantite/this.total*100).toFixed(2));
            
              this.doughnutChartReadyTickets = true;
            });
            //Détruire la souscription
            this.listSubscription.push(variable3);
    
    
            }
            this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
            this.colors=[]
            });
            //Détruire la souscription
            this.listSubscription.push(variable7);
            
    
    
            // this.sortFiches(value, fichesPeriode)
            console.log(this.stats);
            console.log(value);
            console.log(periode);
            console.log(fichesPeriode);
        
            break;
  
  
      }
    }
    else {
      switch(periode) {
        case 'Année':
          this.legendeTickets = "Pourcentage de tickets par "+this.selected2.toLowerCase()+" de l\'année de la base "+this.selectedBase+" de l'entreprise "+this.selectedEntreprise;
       
          console.log(this.selected, 'Test base')
      
  
          this.doughnutChartType = 'doughnut';
          this.stats.filtre=this.selected2;
          console.log(this.selected);
          //On récupère les catégories selon le filtre.
          const variable = this.stats.getCategorieStats().subscribe((response:any) => {
            //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
            this.CategorieObjetCount = response.data; 
    
     
            this.stats.filtre=this.selected2;
            this.stats.entreprise = this.selectedEntreprise
            this.stats.base = this.selectedBase
  
            const variable2 = this.stats.gettotalStatsbyEntrepriseAndBase().subscribe((response) => {
              //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
              this.total = JSON.parse(JSON.stringify(response)).data[0].total; 
              console.log(this.total)
    
            });
            //Détruire la souscription
            this.listSubscription.push(variable2);
          console.log(this.CategorieObjetCount);
          for(let item of this.CategorieObjetCount){
            this.colors.push(this.getRandomColor());
            this.stats.categorie=item.category;
            this.stats.filtre=this.selected2;
            console.log(this.CategorieObjetCount);
            console.log(this.stats.categorie)
  

            const variable3 = this.stats.getQuantityStatsbyEntrepriseAndBase().subscribe((response) => {
              //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
              console.log(response);
            this.quantite = JSON.parse(JSON.stringify(response)).data[0].sum; 
            console.log("categorie ",item.category," quantite ",this.quantite );
          
              this.doughnutChartLabelsTickets.push(" " + item.category);
              this.doughnutChartDataTickets.push(Number(this.quantite/this.total*100).toFixed(2));
          
            this.doughnutChartReadyTickets = true;
          });
          //Détruire la souscription
          this.listSubscription.push(variable3);
  
  
          }
          this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
          this.colors=[]
          });
          //Détruire la souscription
          this.listSubscription.push(variable);
  
  
  
          // this.sortFiches(value, fichesPeriode)
          console.log(value);
          console.log(periode);
          console.log(fichesPeriode);
  
          break;
        case 'Mois':
          this.legendeTickets = "Pourcentage de tickets par "+this.selected2.toLowerCase()+" du mois de la base "+this.selectedBase+" de l'entreprise "+this.selectedEntreprise;
       
     
      
  
      this.doughnutChartType = 'doughnut';
      this.stats.filtre=this.selected2;
      console.log(this.selected);
      //On récupère les catégories selon le filtre.
      const variable4 = this.stats.getCategorieStats().subscribe((response:any) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
         this.CategorieObjetCount = response.data; 
       
     
         this.stats.filtre=this.selected2;
         this.stats.entreprise = this.selectedEntreprise
         this.stats.base = this.selectedBase
  
      const variable2 = this.stats.gettotalStatsByMonthbyEntrepriseAndBase().subscribe((response) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
        this.total = JSON.parse(JSON.stringify(response)).data[0].total; 
        console.log(this.total)
    
        });
        //Détruire la souscription
        this.listSubscription.push(variable2);
      console.log(this.CategorieObjetCount);
      for(let item of this.CategorieObjetCount){
        this.colors.push(this.getRandomColor());
        this.stats.categorie=item.category;
        this.stats.filtre=this.selected2;
        console.log(this.CategorieObjetCount);
       

        const variable3 = this.stats.getQuantityStatsByMonthbyEntrepriseAndBase().subscribe((response) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
            console.log(response);
          this.quantite = JSON.parse(JSON.stringify(response)).data[0].sum; 
          console.log("categorie ",item.category," quantite ",this.quantite );
         
            this.doughnutChartLabelsTickets.push(" " + item.category);
            this.doughnutChartDataTickets.push(Number(this.quantite/this.total*100).toFixed(2));
         
          this.doughnutChartReadyTickets = true;
        });
        //Détruire la souscription
        this.listSubscription.push(variable3);
  
  
  }
  this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
  this.colors=[]
  });
  //Détruire la souscription
  this.listSubscription.push(variable4);
  
  
  
     // this.sortFiches(value, fichesPeriode)
      console.log(value);
      console.log(periode);
      console.log(fichesPeriode);
  
      break;
      case 'Semaine':
        this.legendeTickets = "Pourcentage de tickets par "+this.selected2.toLowerCase()+" de la semaine de la base "+this.selectedBase+" de l'entreprise "+this.selectedEntreprise;
       
     
      
  
        this.doughnutChartType = 'doughnut';
        this.stats.filtre=this.selected2;
        console.log(this.selected);
        //On récupère les catégories selon le filtre.
        const variable5 = this.stats.getCategorieStats().subscribe((response:any) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
           this.CategorieObjetCount = response.data; 
           this.stats.filtre=this.selected2;
           this.stats.entreprise = this.selectedEntreprise
           this.stats.base = this.selectedBase
    
    
        const variable2 = this.stats.gettotalStatsByWeekbyEntrepriseAndBase().subscribe((response) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
          this.total = JSON.parse(JSON.stringify(response)).data[0].total; 
          console.log(this.total)
      
          });
          //Détruire la souscription
          this.listSubscription.push(variable2);
        console.log(this.CategorieObjetCount);
        for(let item of this.CategorieObjetCount){
          this.colors.push(this.getRandomColor());
          this.stats.categorie=item.category;
          this.stats.filtre=this.selected2;
          console.log(this.CategorieObjetCount);
          console.log(this.stats.categorie)

          const variable3 = this.stats.getQuantityStatsByWeekbyEntrepriseAndBase().subscribe((response) => {
            //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
              console.log(response);
            this.quantite = JSON.parse(JSON.stringify(response)).data[0].sum; 
            console.log("categorie ",item.category," quantite ",this.quantite );
           
              this.doughnutChartLabelsTickets.push(" " + item.category);
              this.doughnutChartDataTickets.push(Number(this.quantite/this.total*100).toFixed(2));
           
            this.doughnutChartReadyTickets = true;
          });
          //Détruire la souscription
          this.listSubscription.push(variable3);
    
    
    }
    this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
    this.colors=[]
    });
    //Détruire la souscription
    this.listSubscription.push(variable5);
    
    
    
       // this.sortFiches(value, fichesPeriode)
        console.log(value);
        console.log(periode);
        console.log(fichesPeriode);
    
        break;
        case 'Tout':
          this.legendeTickets = "Pourcentage de tickets par "+this.selected2.toLowerCase()  +" de la base "+this.selectedBase+" de l'entreprise "+this.selectedEntreprise;
       
     
      
  
      this.doughnutChartType = 'doughnut';
      this.stats.filtre=this.selected2;
      console.log(this.selected);
      //On récupère les catégories selon le filtre.
      const variable6 = this.stats.getCategorieStats().subscribe((response:any) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
         this.CategorieObjetCount = response.data; 
         this.stats.filtre=this.selected2;
         this.stats.entreprise = this.selectedEntreprise
         this.stats.base = this.selectedBase
  
  
      const variable2 = this.stats.getAlltotalStatsbyEntrepriseAndBase().subscribe((response) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
        this.total = JSON.parse(JSON.stringify(response)).data[0].total; 
        console.log(this.total)
    
        });
        //Détruire la souscription
        this.listSubscription.push(variable2);
      console.log(this.CategorieObjetCount);
      for(let item of this.CategorieObjetCount){
        this.colors.push(this.getRandomColor());
        this.stats.categorie=item.category;
        this.stats.filtre=this.selected2;
        console.log(this.CategorieObjetCount);
        console.log(this.stats.categorie)

        const variable3 = this.stats.getAllQuantityStatsbyEntrepriseAndBase().subscribe((response) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
            console.log(response);
          this.quantite = JSON.parse(JSON.stringify(response)).data[0].sum; 
          console.log("categorie ",item.category," quantite ",this.quantite );
         
            this.doughnutChartLabelsTickets.push(" " + item.category);
            this.doughnutChartDataTickets.push(Number(this.quantite/this.total*100).toFixed(2));
         
          this.doughnutChartReadyTickets = true;
        });
        //Détruire la souscription
        this.listSubscription.push(variable3);
  
  
  }
  this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
  this.colors=[]
  });
  //Détruire la souscription
  this.listSubscription.push(variable6);
  
  
  
     // this.sortFiches(value, fichesPeriode)
      console.log(value);
      console.log(periode);
      console.log(fichesPeriode);
  
      break;
      case 'Periode':
        this.legendeTickets = "Pourcentage de tickets par "+this.selected2.toLowerCase()+" de la période  de la base "+this.selectedBase+" de l'entreprise "+this.selectedEntreprise;
       
     
      
  
        this.doughnutChartType = 'doughnut';
        this.stats.filtre=this.selected2;
        console.log(this.selected);
        //On récupère les catégories selon le filtre.
        const variable7 = this.stats.getCategorieStats().subscribe((response:any) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
           this.CategorieObjetCount = response.data; 
       
           this.stats.filtre=this.selected2;
           this.stats.entreprise = this.selectedEntreprise
           this.stats.base = this.selectedBase
    
        const variable2 = this.stats.getPeriodetotalStatsbyEntrepriseAndBase().subscribe((response) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
          this.total = JSON.parse(JSON.stringify(response)).data[0].total; 
          console.log(this.total)
      
          });
          //Détruire la souscription
          this.listSubscription.push(variable2);
        console.log(this.CategorieObjetCount);
        for(let item of this.CategorieObjetCount){
          this.colors.push(this.getRandomColor());
          this.stats.categorie=item.category;
          this.stats.filtre=this.selected2;
          console.log(this.CategorieObjetCount);
          console.log(this.stats.categorie)

          const variable3 = this.stats.getPeriodeQuantityStatsbyEntrepriseAndBase().subscribe((response) => {
            //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
              console.log(response);
            this.quantite = JSON.parse(JSON.stringify(response)).data[0].sum; 
            console.log("categorie ",item.category," quantite ",this.quantite );
           
              this.doughnutChartLabelsTickets.push(" " + item.category);
              this.doughnutChartDataTickets.push(Number(this.quantite/this.total*100).toFixed(2));
           
            this.doughnutChartReadyTickets = true;
          });
          //Détruire la souscription
          this.listSubscription.push(variable3);
    
    
    }
    this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
    this.colors=[]
    });
    //Détruire la souscription
    this.listSubscription.push(variable7);
    
    
    
       // this.sortFiches(value, fichesPeriode)
        console.log(this.stats);
        console.log(value);
        console.log(periode);
        console.log(fichesPeriode);
    
        break;
  



    }
  

  


  }
  this.cdRef.detectChanges();


  }




  handleClick(value: string, periode: string, fichesPeriode: FicheModel[]){

    this.selected=value;
    this.periode = periode
    console.log(this.selected, 'TEST selected')
    console.log(this.periode, 'TEST periode')
    
 
    
    //Calcul en pourcentage & Paramétrage DoughnutChart Nombre de tickets
    this.doughnutChartLabelsTickets = [];
    this.doughnutChartDataTickets = [];
    if(this.selected!=='Entreprise' && this.selected!=='Base - Entreprise' )
    {
    switch(periode)
    {
      case 'Année':
        this.legendeTickets = "Pourcentage de tickets par "+this.selected.toLowerCase()+" de l\'année";
     
        console.log('TEST inside')

        this.doughnutChartReadyTickets = false;
    
        this.stats.filtre=this.selected
        console.log(this.selected, 'selected')
        //On récupère toutes les catégories selon le filtre.
        const variable = this.stats.getCategorieStats().subscribe((response:any) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
          this.CategorieObjetCount = response.data;
          console.log(this.CategorieObjetCount, 'CategorieObjetCount result')
          this.selected=value;
          this.stats.filtre = this.selected

          const variable2 = this.stats.gettotalStats().subscribe((response) => {
            this.total = JSON.parse(JSON.stringify(response)).data[0].total; 
            console.log(this.total, 'total')
          

            for(let item of this.CategorieObjetCount){
              this.colors.push(this.getRandomColor());
              this.stats.categorie=item.category;
              console.log(this.stats.filtre, 'TEST filtre')
              console.log(this.stats.categorie, 'TEST categorie')
              console.log(this.stats.jour, 'TEST jour')
              this.stats.filtre = this.selected

              const variable3 = this.stats.getQuantityStats().subscribe((response:any) => {
                //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
                console.log(response, 'getQuantityStats result');
                console.log(this.stats.categorie);
                console.log(this.selected);
          
                this.quantite = response.data[0].sum; 
                console.log("categorie ",item.category," quantite ",this.quantite );
          
                this.doughnutChartLabelsTickets.push(" " + item.category);
                this.doughnutChartDataTickets.push(Number(this.quantite/this.total*100).toFixed(2));

                console.log(this.quantite, 'TEST selection')
                console.log(this.doughnutChartDataTickets, 'TEST data')
                
                this.doughnutChartReadyTickets = true;
              });
              //Détruire la souscription
              this.listSubscription.push(variable3);
            }
            this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
            this.colors=[]
          });
          //Détruire la souscription
          this.listSubscription.push(variable2);
        });
        //Détruire la souscription
        this.listSubscription.push(variable);

        // this.sortFiches(value, fichesPeriode)
        console.log(value);
        console.log(periode);
        console.log(fichesPeriode);

        

        break;
      case 'Mois':
        this.legendeTickets = "Pourcentage de tickets par"+this.selected.toLowerCase()+ "du mois";
     
   
    

    this.doughnutChartType = 'doughnut';
    this.stats.filtre=this.selected;
    console.log(this.selected);
    //On récupère les catégories selon le filtre.
    const variable4 = this.stats.getCategorieStats().subscribe((response:any) => {
      //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
       this.CategorieObjetCount = response.data; 
       this.selected=value;
   

       this.stats.filtre = this.selected

    const variable2 = this.stats.gettotalStatsByMonth().subscribe((response) => {
      //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
      this.total = JSON.parse(JSON.stringify(response)).data[0].total; 
      console.log(this.total)
  
      });
      //Détruire la souscription
      this.listSubscription.push(variable2);
    console.log(this.CategorieObjetCount);
    for(let item of this.CategorieObjetCount){
      this.colors.push(this.getRandomColor());
      this.stats.categorie=item.category;
      this.stats.filtre = this.selected
      console.log(this.CategorieObjetCount);
      console.log(this.stats.categorie)
      this.stats.filtre = this.selected

      const variable3 = this.stats.getQuantityStatsByMonth().subscribe((response) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
          console.log(response);
        this.quantite = JSON.parse(JSON.stringify(response)).data[0].sum; 
        console.log("categorie ",item.category," quantite ",this.quantite );
       
          this.doughnutChartLabelsTickets.push(" " + item.category);
          this.doughnutChartDataTickets.push(Number(this.quantite/this.total*100).toFixed(2));
       
        this.doughnutChartReadyTickets = true;
      });
      //Détruire la souscription
      this.listSubscription.push(variable3);


}
this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
this.colors=[]
});
//Détruire la souscription
this.listSubscription.push(variable4);



   // this.sortFiches(value, fichesPeriode)
    console.log(value);
    console.log(periode);
    console.log(fichesPeriode);

    break;
    case 'Semaine':
      this.legendeTickets = "Pourcentage de tickets par "+this.selected.toLowerCase()+" de la semaine";
     
   
    

      this.doughnutChartType = 'doughnut';
      this.stats.filtre=this.selected;
      console.log(this.selected);
      //On récupère les catégories selon le filtre.
      const variable5 = this.stats.getCategorieStats().subscribe((response:any) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
         this.CategorieObjetCount = response.data; 
         this.selected=value;
     
  
         this.stats.filtre = this.selected

      const variable2 = this.stats.gettotalStatsByWeek().subscribe((response) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
        this.total = JSON.parse(JSON.stringify(response)).data[0].total; 
        console.log(this.total)
    
        });
        //Détruire la souscription
        this.listSubscription.push(variable2);
      console.log(this.CategorieObjetCount);
      for(let item of this.CategorieObjetCount){
        this.colors.push(this.getRandomColor());
        this.stats.categorie=item.category;
        this.stats.filtre = this.selected
        console.log(this.CategorieObjetCount);
        console.log(this.stats.categorie)
        this.stats.filtre = this.selected

        const variable3 = this.stats.getQuantityStatsByWeek().subscribe((response) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
            console.log(response);
          this.quantite = JSON.parse(JSON.stringify(response)).data[0].sum; 
          console.log("categorie ",item.category," quantite ",this.quantite );
         
            this.doughnutChartLabelsTickets.push(" " + item.category);
            this.doughnutChartDataTickets.push(Number(this.quantite/this.total*100).toFixed(2));
         
          this.doughnutChartReadyTickets = true;
        });
        //Détruire la souscription
        this.listSubscription.push(variable3);
  
  
  }
  this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
  this.colors=[]
  });
  //Détruire la souscription
  this.listSubscription.push(variable5);
  
  
  
     // this.sortFiches(value, fichesPeriode)
      console.log(value);
      console.log(periode);
      console.log(fichesPeriode);
  
      break;
      case 'Tout':
        this.legendeTickets = "Pourcentage de tickets par "+this.selected.toLowerCase();
     
   
    

    this.doughnutChartType = 'doughnut';
    this.stats.filtre=this.selected;
    console.log(this.selected);
    //On récupère les catégories selon le filtre.
    const variable6 = this.stats.getCategorieStats().subscribe((response:any) => {
      //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
       this.CategorieObjetCount = response.data; 
       this.selected=value;
   
       this.stats.filtre = this.selected

    const variable2 = this.stats.getAlltotalStats().subscribe((response) => {
      //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
      this.total = JSON.parse(JSON.stringify(response)).data[0].total; 
      console.log(this.total)
  
      });
      //Détruire la souscription
      this.listSubscription.push(variable2);
    console.log(this.CategorieObjetCount);
    for(let item of this.CategorieObjetCount){
      this.colors.push(this.getRandomColor());
      this.stats.categorie=item.category;
      this.stats.filtre = this.selected
      console.log(this.CategorieObjetCount);
      console.log(this.stats.categorie)
      this.stats.filtre = this.selected

      const variable3 = this.stats.getAllQuantityStats().subscribe((response) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
          console.log(response);
        this.quantite = JSON.parse(JSON.stringify(response)).data[0].sum; 
        console.log("categorie ",item.category," quantite ",this.quantite );
       
          this.doughnutChartLabelsTickets.push(" " + item.category);
          this.doughnutChartDataTickets.push(Number(this.quantite/this.total*100).toFixed(2));
       
        this.doughnutChartReadyTickets = true;
      });
      //Détruire la souscription
      this.listSubscription.push(variable3);


}
this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
this.colors=[]
});
//Détruire la souscription
this.listSubscription.push(variable6);



   // this.sortFiches(value, fichesPeriode)
    console.log(value);
    console.log(periode);
    console.log(fichesPeriode);

    break;
    case 'Periode':
      this.legendeTickets = "Pourcentage de tickets par "+this.selected.toLowerCase()+" de la période ";
     
   
    

      this.doughnutChartType = 'doughnut';
      this.stats.filtre=this.selected;
      console.log(this.selected);
      //On récupère les catégories selon le filtre.
      const variable7 = this.stats.getCategorieStats().subscribe((response:any) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
         this.CategorieObjetCount = response.data; 
         this.selected=value;
     
  
         this.stats.filtre = this.selected

      const variable2 = this.stats.getPeriodetotalStats().subscribe((response) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
        this.total = JSON.parse(JSON.stringify(response)).data[0].total; 
        console.log(this.total)
    
        });
        //Détruire la souscription
        this.listSubscription.push(variable2);
      console.log(this.CategorieObjetCount);
      for(let item of this.CategorieObjetCount){
        this.colors.push(this.getRandomColor());
        this.stats.categorie=item.category;
        this.stats.filtre = this.selected
        console.log(this.CategorieObjetCount);
        console.log(this.stats.categorie)
    
        const variable3 = this.stats.getPeriodeQuantityStats().subscribe((response) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
            console.log(response);
          this.quantite = JSON.parse(JSON.stringify(response)).data[0].sum; 
          console.log("categorie ",item.category," quantite ",this.quantite );
         
            this.doughnutChartLabelsTickets.push(" " + item.category);
            this.doughnutChartDataTickets.push(Number(this.quantite/this.total*100).toFixed(2));
         
          this.doughnutChartReadyTickets = true;
        });
        //Détruire la souscription
        this.listSubscription.push(variable3);
  
  
  }
  this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
  this.colors=[]
  });
  //Détruire la souscription
  this.listSubscription.push(variable7);
  
  
  
     // this.sortFiches(value, fichesPeriode)
      console.log(this.stats);
      console.log(value);
      console.log(periode);
      console.log(fichesPeriode);
  
      break;


      }
    }
    else
    {
      
      
      this.doughnutChartReadyTickets = false;
      //Calcul en pourcentage & Paramétrage DoughnutChart Nombre de tickets
      this.doughnutChartLabelsTickets = [];
      this.doughnutChartDataTickets = [];
    }


    this.cdRef.detectChanges();
    
  }
  /** FIN Doughnut Chart Nombre de tickets */

  // Affichage du graphe sur le dashboard
  checkCmpInDashboard(){
    let alreadyInDashboard = false;
    for(let cmp of this.dashboardComponents){
      // Vérification si le component est associé au user connecté et s'il s'agit du bon graphe
      if(cmp.userId == Number(this.currentUser.id) && cmp.titreComponent == "DoughnutChartTicket"){
        if(cmp.donnees[0] == this.selected && cmp.donnees[1] == this.periode)  alreadyInDashboard = true;
      }
    }
    return alreadyInDashboard;
  }

  addToDashboard(){
    if(this.periode != 'Periode'){
      this.dashboardService.dataToAdd = []
      if(this.selected !== 'Entreprise' && this.selected !== 'Base - Entreprise')  this.dashboardService.dataToAdd.push({id: 0, userId: Number(this.currentUser.id), titreComponent: "DoughnutChartTicket", titreDashboard: "Statistiques", donnees: "/" + this.selected + "*" + "/" + this.periode + "*"});
      if(this.selected === 'Entreprise')  this.dashboardService.dataToAdd.push({id: 0, userId: Number(this.currentUser.id), titreComponent: "DoughnutChartTicket", titreDashboard: "Statistiques", donnees: "/" + this.selected + "*" + "/" + this.periode + "*" + "/" + this.stats.entreprise + "*"+ "/" + this.selected2 + "*"});
      if(this.selected === 'Base - Entreprise')  this.dashboardService.dataToAdd.push({id: 0, userId: Number(this.currentUser.id), titreComponent: "DoughnutChartTicket", titreDashboard: "Statistiques", donnees: "/" + this.selected + "*" + "/" + this.periode + "*" + "/" + this.stats.entreprise + "*"+ "/" + this.stats.base + "*"+ "/" + this.selected2 + "*"});

      const variable = this.dashboardService.postAddDashboardComponentToServer().subscribe(
        () => {
        console.log('Component du dashboard sauvegardé !');
        },
        (error) => {
        console.log('Erreur ! : ' + error);
        }
      );
      this.listSubscription.push(variable);
    }
  }

  removeFromDashboard(){
    for(let component of this.dashboardComponents){
      if(component.userId == Number(this.currentUser.id) && component.titreComponent == "DoughnutChartTicket")  this.dashboardService.idOfDataToDelete = component.id;
    }
    const variable = this.dashboardService.postDeleteDashboardComponentFromServer().subscribe(
      () => {
        console.log('Component du dashboard supprimé !');
      },
      (error) => {
        console.log('Erreur ! : ' + error);
      }
    );
    this.listSubscription.push(variable);
  }
  /* FIN Affichage du graphe sur le dashboard */

  // Quelques fonctions simples nécessaires
  getWeek(date: Date) {
    // Create a copy of this date object  
    var target  = new Date(date.valueOf());  
    // ISO week date weeks start on monday so correct the day number  
    var dayNr   = (date.getDay() + 6) % 7;  
    // Set the target to the thursday of this week so the target date is in the right year  
    target.setDate(target.getDate() - dayNr + 3);  
    // ISO 8601 states that week 1 is the week with january 4th in it  
    var jan4    = new Date(target.getFullYear(), 0, 4);  
    // Number of days between target date and january 4th  
    var diff = Math.abs(target.getTime() - jan4.getTime());
    var dayDiff = Math.ceil(diff / (1000 * 3600 * 24)); 
    // Calculate week number: Week 1 (january 4th) plus the number of weeks between target date and january 4th    
    var weekNr = 1 + Math.ceil(dayDiff / 7);    
  
    return weekNr;
  }
}
