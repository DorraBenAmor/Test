import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, AbstractControl } from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { is } from 'date-fns/locale';
import { Subscription } from 'rxjs';
import { InscriptionCheckService } from 'src/app/services/inscription-check.service';
import { Variable } from '@angular/compiler/src/render3/r3_ast';
import { ThrowStmt, Identifiers } from '@angular/compiler';
import { ConnexionService } from 'src/app/services/connexion.service';
import { ModuleList } from '../services/module-list.service';
import { FAQService } from '../services/faq.service';
import { stringify } from 'querystring';
import { BaseService } from '../services/base.service';
import { MessagerieTicketsService } from '../services/messagerie_tickets.service';
import { UserList } from '../services/user-list.service';
import { updateSousModuleService } from '../services/update-sousmodule.service';
import { TimelineData } from '../services/timeline-data.service';
import { updatesousmodule } from '../models/update_sous_module.model';
@Component({
  selector: 'app-update-base',
  templateUrl: './update-base.component.html',
  styleUrls: ['./update-base.component.css']
})
export class UpdateBaseComponent implements OnInit {



  nom:string;
  modules:any[];
  sous_modules:any[];
  bases:any[];
  updates:any[];
  client_ID:number;
  charge_dossier_ID:number;
  showModal1:boolean=false;
  showModal:boolean=false;
  id:number;
  listuser:any[];
  timelines:any[];
  listSubscription = <Subscription[]>[];
  submitted:boolean=false;
  registerForm: FormGroup;
  date_prod:Date;
  newId:number=0;
  toutclient:boolean=false;
 
  date_preprod:Date;
  module:string;
  charge_dossier:string;

  sous_module:string;
  modified:boolean=false;
  update_ID: any;
  exist: boolean;
  constructor(private titleService: Title, private users:UserList,private base: BaseService, private modulelist:ModuleList, private updateSousModule: updateSousModuleService, private inscriptionCheckService: InscriptionCheckService, private formBuilder: FormBuilder, private connexion: ConnexionService, private timeline: TimelineData, private router: Router) { }
  get f() { return this.registerForm.controls; }

  ngOnInit(): void {
    this.id=this.connexion.userID;
    this.registerForm = this.formBuilder.group({

      date_prod:['', Validators.required],
      module:['', Validators.required],
      sous_module:['', Validators.required],
      date_preprod:['', Validators.required],
      client_ID:['', Validators.required],
    
    
    
            });
            const variable5  =this.updateSousModule.getupdatefromServer().subscribe((response) => {

    
              this.updates = JSON.parse(JSON.stringify(response)).data;
              console.log(this.updates)
              console.log(JSON.parse(JSON.stringify(response)).data)
             
                     
            });
            this.listSubscription.push(variable5);
            console.log(this.updates)
            this.charge_dossier=this.connexion.userNom+" "+this.connexion.userPrenom;
            console.log(this.charge_dossier);

            const variable4 = this.users.getUserFromServer().subscribe((response:any) => {
              //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
              this.updateSousModule.charge_dossier_ID=(response.data.filter(x=>this.charge_dossier=== x.nom+" "+x.prenom))[0].id;
 
              
              console.log( this.updateSousModule.charge_dossier_ID)
                
                });
                this.listSubscription.push(variable4);
                this.charge_dossier_ID=this.updateSousModule.charge_dossier_ID;
          


            
            //Les modules et leurs sous-modules
            this.modules=this.modulelist.moduleSample;
            const variable= this.modulelist.getModuleFromServer().subscribe((response) => {
              //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
            
              
                this.modules = JSON.parse(JSON.stringify(response)).data; 
                console.log(this.modules);
            
            });
            //Détruire la souscription
            this.listSubscription.push(variable);
           
    
            //les bases prod et preprod pour recuperer les chargé de dossier et leurs clients
            const variable2= this.base.getcharges().subscribe((response:any) => {
              //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
              this.bases=response.data.filter(x=> x.nomDemandeur===this.charge_dossier)
              console.log(this.bases);

            });
            //Détruire la souscription
            this.listSubscription.push(variable2);
          
  

  }  
  


  getNomClient(value:number)
  {

    var nom;
    const variable4 = this.users.getUserFromServer().subscribe((response:any) => {
      //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
      nom=(response.data.filter(x=>x.id===value))[0].nom+" "+(response.data.filter(x=>x.id===value))[0].prenom;
      return nom; 
        });
        this.listSubscription.push(variable4);
    




  }
  


  ngOnDestroy(){
    this.listSubscription.map((elem) => elem.unsubscribe());
  }



update()
{
  this.submitted = true;

  // stop here if form is invalid
 if(this.registerForm.invalid)

 { 
  console.log("Il y a une erreur de form");
  return;

 }
 else{
  
 
 
 const var9= this.updateSousModule.getupdatefromServer().subscribe((response:any) => {
  console.log(response.data.filter(x=> x.module===this.updateSousModule.module && x.sous_module===this.updateSousModule.sous_module && x.charge_dossier_ID==this.updateSousModule.charge_dossier_ID  && x.client_ID==this.updateSousModule.client_ID  ))
if(response.data.filter(x=> x.module===this.updateSousModule.module && x.sous_module===this.updateSousModule.sous_module && x.charge_dossier_ID==this.updateSousModule.charge_dossier_ID  && x.client_ID==this.updateSousModule.client_ID  ).length>0)
{

this.exist=true;
}
else
{
  this.exist=false;


  if(this.toutclient===false)
 {
  console.log(this.updateSousModule.dataToAdd);
  this.updateSousModule.dataToAdd.push({id:this.updateSousModule.id, module:this.updateSousModule.module,sous_module:this.updateSousModule.sous_module,date_prod:this.updateSousModule.date_prod,date_preprod:this.updateSousModule.date_preprod,charge_dossier_ID:this.updateSousModule.charge_dossier_ID,client_ID:this.updateSousModule.client_ID});
console.log(this.updateSousModule)  
  const variable3 = this.updateSousModule.postupdateToServer().subscribe(
    () => {
        console.log('Données sauvegardées !');
    },
    (error) => {
        console.log('Erreur ! : ' + error);
    }
);
console.log(this.updateSousModule.dataToAdd);
//Détruite la souscription
this.listSubscription.push(variable3);


const variable10= this.updateSousModule.getLastId().subscribe((response:any) => {
this.updateSousModule.id=response.data[0].maxim;
    console.log(this.updateSousModule.id);
  this.update_ID=this.updateSousModule.id;
  
  const variable4  =this.updateSousModule.getupdatefromServer().subscribe((response) => {
  
      
    this.updates = JSON.parse(JSON.stringify(response)).data;
   
           
  });
  this.listSubscription.push(variable4);
  this.modified=true;
   //recevoir la taille de la table timeline
   console.log(this.updateSousModule.dataToAdd);
   const variable8 = this.timeline.getEvtFromServer().subscribe((response) => {
    //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
  
    
      this.timelines = JSON.parse(JSON.stringify(response)).data; 
  
  });
  //Détruire la souscription
  this.listSubscription.push(variable8);
   var dateObj =new Date();   
   if(dateObj.getHours()<10)
   {if(dateObj.getMinutes()<10)
     {var date="0"+dateObj.getHours()+":"+"0"+dateObj.getMinutes();}
     else{
      var date="0"+dateObj.getHours()+":"+dateObj.getMinutes();
     }
    
    
    }
  else{
    if(dateObj.getMinutes()<10)
    {var date=dateObj.getHours()+":"+"0"+dateObj.getMinutes();}
    else{
     var date=dateObj.getHours()+":"+dateObj.getMinutes();
    }
  
  }
  this.timeline.dataToAdd=[];
      this.timeline.dataToAdd.push({id:0,eventID:0, update_ID: this.updateSousModule.id,base_ID:null,date: this.date_prod, heure: date, motif:"mise à jour du sous_module: "+this.sous_module+" pour la base prod" , userID: this.updateSousModule.charge_dossier_ID, isUserConcerned: true })
      console.log(  this.timeline.dataToAdd);
      var variable2  = this.timeline.postEvtToServer().subscribe(
        () => {
            console.log('Données sauvegardées !');
        },
        (error) => {
            console.log('Erreur ! : ' + error);
        }
    );
    this.listSubscription.push(variable2);
    this.timeline.dataToAdd=[];
      this.timeline.dataToAdd.push({id:0,eventID:0, update_ID: this.updateSousModule.id,base_ID:null,date: this.date_preprod, heure: date, motif:"mise à jour du sous_module: "+this.sous_module+" pour la base preprod" , userID: this.updateSousModule.charge_dossier_ID, isUserConcerned: true })
  
      var variable2  = this.timeline.postEvtToServer().subscribe(
        () => {
            console.log('Données sauvegardées !');
        },
        (error) => {
            console.log('Erreur ! : ' + error);
        }
    );
    this.listSubscription.push(variable2);
    this.timeline.dataToAdd=[];
    this.timeline.dataToAdd.push({id:0,eventID:0, update_ID: this.updateSousModule.id,base_ID:null,date: this.date_prod, heure: date, motif:"mise à jour du sous_module: "+this.sous_module+" pour la base prod" , userID: this.updateSousModule.client_ID, isUserConcerned: true })
  
    var variable2  = this.timeline.postEvtToServer().subscribe(
      () => {
          console.log('Données sauvegardées !');
      },
      (error) => {
          console.log('Erreur ! : ' + error);
      }
  );
  this.listSubscription.push(variable2);
  this.timeline.dataToAdd=[];
  this.timeline.dataToAdd.push({id:0,eventID:0,date: this.date_preprod, update_ID: this.updateSousModule.id,base_ID:null, heure: date, motif:"mise à jour du sous_module: "+this.sous_module+" pour la base preprod" , userID: this.updateSousModule.client_ID, isUserConcerned: true })
  
  var variable2  = this.timeline.postEvtToServer().subscribe(
    () => {
        console.log('Données sauvegardées !');
    },
    (error) => {
        console.log('Erreur ! : ' + error);
    }
  );
  this.listSubscription.push(variable2);
  
      
    });
    this.listSubscription.push(variable10);
    this.updateSousModule.dataToAdd=[];
  }
else{



for(let client of this.bases)
{ 
  const variable = this.users.getUserFromServer().subscribe((response:any) => {
    //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
    this.client_ID=(response.data.filter(x=> client.responsable===x.nom+" "+x.prenom))[0].id;
   


      
this.updateSousModule.client_ID=this.client_ID
console.log(this.updateSousModule.dataToAdd);
this.updateSousModule.dataToAdd=[];
this.updateSousModule.dataToAdd.push({id:this.updateSousModule.id, module:this.updateSousModule.module,sous_module:this.updateSousModule.sous_module,date_prod:this.updateSousModule.date_prod,date_preprod:this.updateSousModule.date_preprod,charge_dossier_ID:this.updateSousModule.charge_dossier_ID,client_ID:this.updateSousModule.client_ID});
console.log(this.updateSousModule)  
const variable3 = this.updateSousModule.postupdateToServer().subscribe(
  () => {
      console.log('Données sauvegardées !');
  },
  (error) => {
      console.log('Erreur ! : ' + error);
  }
);
console.log(this.updateSousModule.dataToAdd);
//Détruite la souscription
this.listSubscription.push(variable3);



const variable10= this.updateSousModule.getLastId().subscribe((response:any) => {
this.updateSousModule.id=response.data[0].maxim;

  console.log(this.updateSousModule.id);
this.update_ID=this.updateSousModule.id;

const variable4  =this.updateSousModule.getupdatefromServer().subscribe((response) => {

    
  this.updates = JSON.parse(JSON.stringify(response)).data;
 
         
});
this.listSubscription.push(variable4);
this.modified=true;
 //recevoir la taille de la table timeline
 console.log(this.updateSousModule.dataToAdd);
 const variable8 = this.timeline.getEvtFromServer().subscribe((response) => {
  //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template

  
    this.timelines = JSON.parse(JSON.stringify(response)).data; 

});
//Détruire la souscription
this.listSubscription.push(variable8);
 var dateObj =new Date();   
 if(dateObj.getHours()<10)
 {if(dateObj.getMinutes()<10)
   {var date="0"+dateObj.getHours()+":"+"0"+dateObj.getMinutes();}
   else{
    var date="0"+dateObj.getHours()+":"+dateObj.getMinutes();
   }
  
  
  }
else{
  if(dateObj.getMinutes()<10)
  {var date=dateObj.getHours()+":"+"0"+dateObj.getMinutes();}
  else{
   var date=dateObj.getHours()+":"+dateObj.getMinutes();
  }

}
this.timeline.dataToAdd=[];
    this.timeline.dataToAdd.push({id:0,eventID:0, update_ID: this.updateSousModule.id,base_ID:null,date: this.date_prod, heure: date, motif:"mise à jour du sous_module: "+this.sous_module+" pour la base prod" , userID: this.updateSousModule.charge_dossier_ID, isUserConcerned: true })
    console.log(  this.timeline.dataToAdd);
    var variable2  = this.timeline.postEvtToServer().subscribe(
      () => {
          console.log('Données sauvegardées !');
      },
      (error) => {
          console.log('Erreur ! : ' + error);
      }
  );
  this.listSubscription.push(variable2);
  this.timeline.dataToAdd=[];
    this.timeline.dataToAdd.push({id:0,eventID:0, update_ID: this.updateSousModule.id,base_ID:null,date: this.date_preprod, heure: date, motif:"mise à jour du sous_module: "+this.sous_module+" pour la base preprod" , userID: this.updateSousModule.charge_dossier_ID, isUserConcerned: true })

    var variable2  = this.timeline.postEvtToServer().subscribe(
      () => {
          console.log('Données sauvegardées !');
      },
      (error) => {
          console.log('Erreur ! : ' + error);
      }
  );
  this.listSubscription.push(variable2);
  console.log(this.updateSousModule.client_ID)

  this.timeline.dataToAdd=[];
  this.updateSousModule.client_ID=this.client_ID
  
  this.timeline.dataToAdd.push({id:0,eventID:0, update_ID: this.updateSousModule.id,base_ID:null,date: this.date_prod, heure: date, motif:"mise à jour du sous_module: "+this.sous_module+" pour la base prod" , userID: this.updateSousModule.client_ID, isUserConcerned: true })

  var variable2  = this.timeline.postEvtToServer().subscribe(
    () => {
        console.log('Données sauvegardées !');
    },
    (error) => {
        console.log('Erreur ! : ' + error);
    }
);
this.listSubscription.push(variable2);
this.timeline.dataToAdd=[];
this.updateSousModule.client_ID=this.client_ID
this.timeline.dataToAdd.push({id:0,eventID:0,date: this.date_preprod, update_ID: this.updateSousModule.id,base_ID:null, heure: date, motif:"mise à jour du sous_module: "+this.sous_module+" pour la base preprod" , userID: this.updateSousModule.client_ID, isUserConcerned: true })

var variable2  = this.timeline.postEvtToServer().subscribe(
  () => {
      console.log('Données sauvegardées !');
  },
  (error) => {
      console.log('Erreur ! : ' + error);
  }
);
this.listSubscription.push(variable2);

    
  });
  this.listSubscription.push(variable10);
});
this.listSubscription.push(variable);
  this.updateSousModule.dataToAdd=[];



    }
}



  }

}
);
this.listSubscription.push(var9);


    
    }

 


 

}
handleClient(value:string)
{


  if(value==='Tous les clients')
  {this.toutclient=true}
  else{

  const variable = this.users.getUserFromServer().subscribe((response:any) => {
    //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
    this.updateSousModule.client_ID=(response.data.filter(x=> value===x.nom+" "+x.prenom))[0].id;
   
    console.log( this.updateSousModule.client_ID)


      
      });
      this.listSubscription.push(variable);
this.client_ID=this.updateSousModule.client_ID
}
}



handleModule(value:string)
{this.module=value;
  this.modulelist.module=value;
  this.updateSousModule.module=value;
  const variable6 = this.modulelist.getSousModuleByModuleFromServer().subscribe((response) => {
    //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template


     this.sous_modules = JSON.parse(JSON.stringify(response)).data;

       console.log(this.sous_modules);
      console.log(JSON.parse(JSON.stringify(response)).data);
      });
      this.listSubscription.push(variable6);
      console.log( this.updateSousModule.module)

}
handleSousModule(value:string)
{this.sous_module=value;
  this.updateSousModule.sous_module=value;
  console.log( this.updateSousModule.sous_module)

}
handleDateProd(value:Date)
{
  this.date_prod=value;
  this.updateSousModule.date_prod=value;
  console.log( this.updateSousModule.date_prod)

}
handleDatePreProd(value:Date)
{
  this.date_preprod=value;
this.updateSousModule.date_preprod=value;
console.log( this.updateSousModule.date_preprod)
}

affect(value:string,value2:string)
{
this.module=value;
this.sous_module=value2;


}


delete(update: updatesousmodule)
{


this.updateSousModule.id=update.id;

  const variable3 = this.updateSousModule.deleteupdate().subscribe(
    () => {
        console.log('Données supprimées !');
    },
    (error) => {
        console.log('Erreur ! : ' + error);
    }
);
//Détruite la souscription
this.listSubscription.push(variable3);

  
const variable4  =this.updateSousModule.getupdatefromServer().subscribe((response) => {

    
  this.updates = JSON.parse(JSON.stringify(response)).data;
 
         
});
this.listSubscription.push(variable4);






var dateObj =new Date();   
if(dateObj.getHours()<10)
{if(dateObj.getMinutes()<10)
  {var date="0"+dateObj.getHours()+":"+"0"+dateObj.getMinutes();}
  else{
   var date="0"+dateObj.getHours()+":"+dateObj.getMinutes();
  }
 
 
 }
else{
 if(dateObj.getMinutes()<10)
 {var date=dateObj.getHours()+":"+"0"+dateObj.getMinutes();}
 else{
  var date=dateObj.getHours()+":"+dateObj.getMinutes();
 }

}



this.timeline.dataToAdd=[];
this.timeline.dataToAdd.push({id:0,eventID:0,date: update.date_preprod, update_ID: update.id,base_ID:null, heure: date, motif:" Annulation de la mise à jour du sous module: "+update.sous_module+" pour la base preprod" , userID: update.client_ID, isUserConcerned: true })

var variable2  = this.timeline.postEvtToServer().subscribe(
  () => {
      console.log('Données sauvegardées !');
  },
  (error) => {
      console.log('Erreur ! : ' + error);
  }
);
this.listSubscription.push(variable2);
this.timeline.dataToAdd=[];

this.timeline.dataToAdd.push({id:0,eventID:0,date: update.date_prod, update_ID: update.id,base_ID:null, heure: date, motif:" Annulation de la mise à jour du sous module: "+update.sous_module+" pour la base prod" , userID: update.client_ID, isUserConcerned: true })

var variable2  = this.timeline.postEvtToServer().subscribe(
  () => {
      console.log('Données sauvegardées !');
  },
  (error) => {
      console.log('Erreur ! : ' + error);
  }
);
this.listSubscription.push(variable2);



this.timeline.dataToAdd=[];
this.timeline.dataToAdd.push({id:0,eventID:0,date: update.date_preprod, update_ID: update.id,base_ID:null, heure: date, motif:" Annulation de la mise à jour du sous module: "+update.sous_module+" pour la base preprod" , userID: update.charge_dossier_ID, isUserConcerned: true })

var variable2  = this.timeline.postEvtToServer().subscribe(
  () => {
      console.log('Données sauvegardées !');
  },
  (error) => {
      console.log('Erreur ! : ' + error);
  }
);
this.listSubscription.push(variable2);
this.timeline.dataToAdd=[];

this.timeline.dataToAdd.push({id:0,eventID:0,date: update.date_prod, update_ID: update.id,base_ID:null, heure: date, motif:" Annulation de la mise à jour du sous module: "+update.sous_module+" pour la base prod" , userID: update.charge_dossier_ID, isUserConcerned: true })

var variable2  = this.timeline.postEvtToServer().subscribe(
  () => {
      console.log('Données sauvegardées !');
  },
  (error) => {
      console.log('Erreur ! : ' + error);
  }
);
this.listSubscription.push(variable2);



}









close()
{

this.submitted=false
this.showModal=false;
this.modified=false;
this.newId=0;
this.f.module.reset();
this.f.client_ID.reset();
this.f.sous_module.reset();
this.f.date_preprod.reset();
this.f.date_prod.reset();
this.toutclient=false;


}



}
