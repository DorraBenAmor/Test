import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateBaseComponent } from './update-base.component';

describe('UpdateBaseComponent', () => {
  let component: UpdateBaseComponent;
  let fixture: ComponentFixture<UpdateBaseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateBaseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateBaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
