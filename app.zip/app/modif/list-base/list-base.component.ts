import { Component, OnInit, OnDestroy } from '@angular/core';
import { base } from '../models/base.model';
import { Subscription } from 'rxjs';
import { BaseService } from '../services/base.service';
import { ConnexionService } from '../services/connexion.service'; 
import { UserList } from '../services/user-list.service';
import { Title } from '@angular/platform-browser'




@Component({
  selector: 'app-list-base',
  templateUrl: './list-base.component.html',
  styleUrls: ['./list-base.component.css']
})
export class ListBaseComponent implements OnInit, OnDestroy {
  bases : base[]; 
  baseSubscription= <Subscription[]>[];; 
  nomDemandeur : string; 
  baseFiltrer : any[] = [];
  statue: number;  
  listSubscription = <Subscription[]>[];
  searchText;
  ConnectedUserFonction : string ; 
  Questions: any[];
  



  constructor(private baseService: BaseService, private connexion: ConnexionService , private  userService: UserList, private titleService: Title) {
   
   }

  ngOnInit() {
    this.bases=this.baseService.dataToAdd;
    this.statue=this.baseService.statue; 
    this.ConnectedUserFonction= this.connexion.userFonction; 
    this.titleService.setTitle('base');
  
  
const variable = this.baseService. getBaseFromServer().subscribe((response) => {
  //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template

  
    this.bases = JSON.parse(JSON.stringify(response)).data; 
    console.log(this.bases);
    this.baseFiltrer=this.bases;

});

//Détruire la souscription
this.baseSubscription.push(variable);
  
  }
  
ngOnDestroy() {
  this.listSubscription.map((elem) => elem.unsubscribe());


}
radioChangeHandler (event : any){

}
handleClick(selectedElt: string) {
  switch (selectedElt) {
    case 'Interne':
      this.baseFiltrer = [];
      for(let base of this.bases) {
        if (base.typeBase=0)
          { 
            this.baseFiltrer.push(base)
        } 
      }
      break;
    case 'prod':
      this.baseFiltrer = [];
        for(let base of this.bases) {
          if (base.typeBase=1)
            { 
              this.baseFiltrer.push(base)
            } 
          }
    break; 
    case 'proprod':
      this.baseFiltrer = [];
          for(let base of this.bases) {
            if (base.typeBase=2)
              { 
                this.baseFiltrer.push(base)
              } 
              
   break;
         
    }
  
    
}



}
Search(){
  console.log("just trying"); 
  
  this.bases=this.bases.filter(res=> {
    return res.nomDemandeur.toLocaleLowerCase().match(this.nomDemandeur.toLocaleLowerCase());

  }) ; 
  


}
onConfirmer(baseId: number ){
  
   for(let base of this.bases){
     if (base.Id==baseId){
       base.statue=1 ; 
       this.baseService.AppdatStatue = [] ; 
       this.baseService.AppdatStatue.push({Id : baseId , coordonneesSociete: this.baseService.coordonnees, responsable: this.baseService.responsable, effectifs: this.baseService.effectifs, utilisation: this.baseService.utilisationPrev, urlBase: this.baseService.url, dateLivraison: this.baseService.dateLivraison, adresseMail: this.baseService.adresseMail, coordinateurProjet: this.baseService.coordinateur, chefProjet: this.baseService.chef, typeBase: this.baseService.type, copieBase: this.baseService.copiebase, autres: this.baseService.siAutres,  lieeGlobal: this.baseService.lieeBase,lieeGl:this.baseService.siOui, lieeCDF: this.baseService.lieeCDF, lieeC: this.baseService.siOuiCDF, nettoyage: this.baseService.nettoyage, sitePro: this.baseService.sitePro, siteP: this.baseService.siOuiSiteP, siteCl: this.baseService.siteCl, siteC: this.baseService.siOuiSiteC, dateCreation: this.baseService.dateCreation, statue: 1,
        nomDemandeur: this.baseService.nomDemandeur, dateConfirmation: this.baseService.dateConfirmation});
        console.log(this.baseService.AppdatStatue, "test");
        const variable  = this.baseService.postUpdateStatueToServer().subscribe(
          (res) => {
          console.log('statue mise à jour !');
          },
          (error) => {
          console.log('Erreur ! : ' + error);
          }
        );
        //Destruction de la souscription
        this.listSubscription.push(variable);
     }
   }
  }

  update()
{
 
  const variable2=this.baseService.getBaseFromServer().subscribe((response)=>
  
  {
  for(let i=0; i<(JSON.parse(JSON.stringify(response)).data.length); i++)
  {

  this.bases[i]=JSON.parse(JSON.stringify(response)).data[i];

  }
  }
  
  
  );
  this.listSubscription.push(variable2);
 






  }

  

  onSupprimer(baseId: number){
   
  const variable  = this.baseService.deleteTable(baseId).subscribe(
  () => {
   
      console.log('deleted !');
  },
  (error) => {
      console.log('Erreur ! : ' + error);
  }
);

this.listSubscription.push(variable);

this.update();

}



  }




