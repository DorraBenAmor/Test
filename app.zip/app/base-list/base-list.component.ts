import { Component, OnInit, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { base } from '../models/base.model';
import { Subscription } from 'rxjs';
import { BaseService } from '../services/base.service';
import * as jsPDF from 'jspdf';
import { EntrepriseList } from '../services/entreprise-list.service';
import { UserList } from '../services/user-list.service';

@Component({
  selector: 'app-base-list',
  templateUrl: './base-list.component.html',
  styleUrls: ['./base-list.component.css']
})
export class BaseListComponent implements OnInit, OnDestroy {
  bases : base[]; 
  baseSubscription = <Subscription[]>[];
  listSubscription1=<Subscription[]>[];
  entreprises: any[] = [];
   base64="";
   mailCharge:string;
   mailRespo:string;

  constructor(private baseService: BaseService, private entrepriseList: EntrepriseList, private userList: UserList) { }

  ngOnInit() {



    const variable2 = this.userList.getUserFromServer().subscribe((response:any) => {
      //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
    
      this.baseService.mailCharge=response.data.filter(x=> this.baseService.nomDemandeur=== x.nom+" "+x.prenom)[0].emailPerso;
     console.log( this.baseService.mailCharge);
      
    });
    //Détruire la souscription
    this.listSubscription1.push(variable2);
  
    const variable3 = this.userList.getUserFromServer().subscribe((response:any) => {
      //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
    
      this.baseService.mailResponsable=response.data.filter(x=> this.baseService.responsable=== x.nom+" "+x.prenom)[0].emailPerso;
     console.log( this.baseService.mailCharge);
      
    });
    //Détruire la souscription
    this.listSubscription1.push(variable3);
    


    
    this.entreprises = this.entrepriseList.entrepriseSample;
    this.bases=this.baseService.dataToAdd;
    console.log(this.baseService.dataToAdd);
    const variable = this.entrepriseList.getEntrepriseFromServer().subscribe((response) => {
      //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
    
        
      this.entreprises = JSON.parse(JSON.stringify(response)).data;
     
     
             
  });
  

  //Détruire la souscription
  this.listSubscription1.push(variable);
  this.baseService.clear();

  
  }
  
ngOnDestroy() {   this.baseSubscription.map((elem) => elem.unsubscribe());
  this.listSubscription1.map((elem) => elem.unsubscribe());
}
radioChangeHandler (event : any){

}
@ViewChild('content') content : ElementRef;
downloadPDF()
{
  
const doc = new jsPDF();
var imgData = new Image();
var logo=new Image();
for(let m=0;m<this.entreprises.length;m++)
  {
    if(this.entreprises[m].nom==this.bases[0].coordonneesSociete)
    {
      logo.src=this.entreprises[m].logo;
    }
  }
  console.log(logo.src);

imgData.src="assets/images/logo3.png"
    const specialElementHandlers = {
      '#editor': function (element, renderer) {
        return true;
      }
    };

    const content = this.content.nativeElement;
    doc.text(40,30,"Récapitulatif de demande de création de base");
    doc.setFont("Times");
    doc.setFontType("bold");
    doc.setTextColor("gray");
    setTimeout(function(){ 
    doc.addImage(imgData, 'PNG',10,10,40,10);
    doc.addImage(logo, 'JPEG',160,10,30,10);
  
    doc.rect(30, 40, 150, 200);
    
    doc.fromHTML(content.innerHTML, 60, 40, {
      
      'elementHandlers': specialElementHandlers
    },
      function (bla) { /*doc.save('Recapitulatif.pdf'); */
    
     this.base64=doc.output('datauristring')
      console.log(doc.output('datauristring'))
 this.sendmail();
    }.bind(this),

      0);
   

    }.bind(this), 5000);

   console.log(this.base64);


}




sendmail()
{
 this.baseService.myfile=this.base64;
 console.log("je suis dans l'envoi",this.baseService.myfile);
 
  var variable2  = this.baseService.postmail().subscribe(
    () => {
        console.log('données ajoutées ! !');
    },
    (error) => {
        console.log('Erreur ! : ' + error);
    }
);
this.baseSubscription.push(variable2);
console.log(this.baseService.myfile);

}

}