import { Component, OnInit, OnDestroy, ViewChild, ChangeDetectorRef, AfterViewInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Subscription } from 'rxjs';
import { Connection } from '../models/connection.model';
import { ConnexionService } from '../services/connexion.service';
import { GrapheEvolutifGlobalComponent } from '../graphe-evolutif-global/graphe-evolutif-global.component'
import { GrapheEvolutifFiltreComponent } from '../graphe-evolutif-filtre/graphe-evolutif-filtre.component'
import { StatService } from '../services/statistique.service';

@Component({
  selector: 'app-grouppement-graphe-evolutif',
  templateUrl: './grouppement-graphe-evolutif.component.html',
  styleUrls: ['./grouppement-graphe-evolutif.component.css']
})
export class GrouppementGrapheEvolutifComponent implements OnInit, OnDestroy, AfterViewInit {

  /**Declaration des variables**/
  @ViewChild(GrapheEvolutifGlobalComponent) grapheEvolutifGlobal:GrapheEvolutifGlobalComponent;
  @ViewChild(GrapheEvolutifFiltreComponent) grapheEvolutifFiltre:GrapheEvolutifFiltreComponent;

  // Données du user connecté
  currentUser: Connection;
  private subscription: Subscription;
 
  // Données de la BDD
  listeEntreprises: any[] = []
  listeEntreprisesBases: any[] = []

  //Choix de periode
  periode: string;
  debut: Date;
  fin: Date;
  erreurPeriodeManquante: boolean;
  erreurPeriodeIncorrect: boolean;

  //Choix de menu
  selectedCourbe: string
  selected: string
  selectedEntreprises = new FormControl()
  selectedBases = new FormControl()
  listeEntrepriseBase: any[] = []
  selectedFiltre: string
  checkedGlobal: boolean
  selectionErreur: boolean

  listSubscription = <Subscription[]>[]

  constructor(private statService: StatService, private connexionService: ConnexionService,) { }

  ngOnInit(): void {
    // Initialisation des variables
    this.selectedCourbe = "Nombre de tickets"
    this.selected = "Type d\'objet"
    this.selectedFiltre = ""
    this.periode = "Tout"
    this.checkedGlobal = false
    this.erreurPeriodeManquante = false
    this.erreurPeriodeIncorrect = false

    // Récupération des données du user connecté
    this.subscription = this.connexionService.connexionSubject.subscribe(datas => {
      this.currentUser = datas
      if(this.currentUser.statut === 'Externe') this.selected = 'Choix Entreprise'
    })
    this.connexionService.emitConnection()

    const variable = this.statService.getEntreprisesFromFiches().subscribe((res) => {
      this.listeEntreprises = JSON.parse(JSON.stringify(res)).data
    });
    this.listSubscription.push(variable)

    const variable2 = this.statService.getEntreprisesBasesFromFiches().subscribe((res) => {
      this.listeEntreprisesBases = JSON.parse(JSON.stringify(res)).data
    });
    this.listSubscription.push(variable2)

    this.handleClickPeriode(this.periode)
  }

  ngOnDestroy(): void {
    this.listSubscription.map((elem) => elem.unsubscribe())
    this.subscription.unsubscribe()
  }

  ngAfterViewInit() {
    this.handleClickPeriode(this.periode)
  }

  /** Choix de période */
  handleDebutInput(value: Date) {
    this.debut = value;
  }

  handleFinInput(value: Date) {
    this.fin = value;
  }

  toggle(checked: boolean) {
    console.log(checked, 'checked')
    this.checkedGlobal = checked
    this.handleClickPeriode(this.periode)
  }

  checkPeriode(){
    this.erreurPeriodeManquante = false;
    this.erreurPeriodeIncorrect = false;
    if(this.debut == undefined || this.fin == undefined){
      this.erreurPeriodeManquante = true;
    }
    if(this.debut > this.fin){
      this.erreurPeriodeIncorrect = true;
    }
    if(this.erreurPeriodeManquante == false && this.erreurPeriodeIncorrect == false){

      this.handleClickPeriode('Periode');
    }
  }

  handleClickPeriode(value: string){
    let canLaunch = true
    if (this.selected === 'Choix Entreprise' && (this.selectedEntreprises.value === null || this.selectedBases.value === null || this.selectedEntreprises.value.length === 0 || this.selectedBases.value.length === 0 || this.selectedFiltre === null)) canLaunch = false
    console.log(canLaunch, 'canLaunch')
    
    if (canLaunch === true) {
      this.listeEntrepriseBase = []
      if(this.selected === 'Choix Entreprise')  this.listeEntrepriseBase = this.getListEntrepriseBaseSelected()
      this.periode = value;
      if(this.periode != "Periode") {
        this.grapheEvolutifFiltre.chargementDonnees(this.selectedCourbe, this.selected, this.listeEntrepriseBase, this.selectedFiltre, this.checkedGlobal, this.periode);
        this.grapheEvolutifGlobal.chargementDonnees(this.selectedCourbe, this.periode);
      }
      else {
        this.grapheEvolutifFiltre.chargementPeriodeDonnees(this.selectedCourbe, this.selected, this.listeEntrepriseBase, this.selectedFiltre, this.checkedGlobal, this.periode, this.debut, this.fin);
        this.grapheEvolutifGlobal.chargementPeriodeDonnees(this.selectedCourbe, this.periode, this.debut, this.fin);
      }
    }
  }

  getUserEntreprise() {
    for (let item of this.listeEntreprises) {
      if (item.entreprise === this.currentUser.entreprise)  return item.entreprise
    }
  }

  getBaseOfEntreprise(entreprise: string) {
    let listBases = []
    for(let item of this.listeEntreprisesBases) {
      if (entreprise === item.entreprise)  listBases.push(item.url)
    }
    return listBases
  }

  getBaseOfEntrepriseUser(entreprise: string) {
    let listBases = []
    for(let item of this.listeEntreprisesBases) {
      if (entreprise === item.entreprise && this.currentUser.base === item.url)  listBases.push(item.url)
    }
    return listBases
  }

  getListEntrepriseBaseSelected() {
    let listEB = []
    for(let item of this.listeEntreprisesBases) {
      for(let ese of this.selectedEntreprises.value) {
        for(let base of this.selectedBases.value) {
          if(item.entreprise === ese && item.url === base)  listEB.push(item)
        }
      }
    }
    return listEB
  }

}
