import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GrouppementGrapheEvolutifComponent } from './grouppement-graphe-evolutif.component';

describe('GrouppementGrapheEvolutifComponent', () => {
  let component: GrouppementGrapheEvolutifComponent;
  let fixture: ComponentFixture<GrouppementGrapheEvolutifComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GrouppementGrapheEvolutifComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GrouppementGrapheEvolutifComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
