import { Component, OnInit, OnDestroy, Input, ChangeDetectorRef } from '@angular/core';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';
import { FicheModel } from '../models/fiche.model';
import { User } from '../models/user.model';
import { Entreprise } from '../models/entreprise.model';
import { MessageModel } from '../models/message.model';
import { DashboardService } from '../services/dashboard.service';
import { Connection } from '../models/connection.model';
import { ConnexionService } from '../services/connexion.service';
import { TypeObjetModel } from '../models/typeObjet.model';
import { EtatModel } from '../models/etat.model';
import { ModuleModel } from '../models/module.model';
import { OrdrePrioriteModel } from '../models/ordrePriorite.model';
import { URLModel } from '../models/url.model';
import { DataLoadingService } from '../services/dataLoading.service';
import { StatistiquesTicketsService } from '../services/statistiques_tickets.service';

@Component({
  selector: 'app-doughnutchart-reponse',
  templateUrl: './doughnutchart-reponse.component.html',
  styleUrls: ['./doughnutchart-reponse.component.css']
})
export class DoughnutchartReponseComponent implements OnInit, OnDestroy {
  @Input() selected: string;
  @Input() selected2: string;
  @Input() periode: string;
  @Input() selectedEntreprise: string;
  @Input() selectedBase: string;
  // DECLARATION DES VARIABLES

  // Données du user connecté
  currentUser: Connection;
  private subscription: Subscription;

  // Loading Data
  private subscriptionLoadData: Subscription

  //Données de la BDD
  fiches: FicheModel[] = [];
  fichesPeriode: FicheModel[] = [];
  messages: MessageModel[] = [];
  resposDossier: User[] = [];
  typesObjet: TypeObjetModel[] = [];
  etats: EtatModel[] = [];
  modules: ModuleModel[] = [];
  ordresPriorite: OrdrePrioriteModel[] = [];
  urls: URLModel[] = [];
  entreprises: Entreprise[] = [];
  dashboardComponents: any[] = [];

  //Paramètres DoughnutChart
  //Chart Reponse
  doughnutChartReadyReponse: boolean;
  doughnutChartLabelsReponse = [];
  doughnutChartDataReponse = [];
  doughnutChartLegendReponse: boolean;
  doughnutChartType = '';
  doughnutChartOptions: any = {};
  legendeReponse: string = "";
  unite: string

  //Data
  typeObjetCount: any[] = [];
  etatCount: any[] = [];
  moduleCount: any[] = [];
  prioriteCount: any[] = [];
  urlCount: any[] = [];
  respCount: any[] = [];
  entrepriseCount: any[] = [];
  colors:any []= [];
  doughnutChartColors: Array<any>


  // Temps de réponse (en h)
  allFichesMessages: any[] = [];

  CategorieObjetCount: any[] = [];

  tempsReponse : number;
  nbTicketsConcerned: number

  //Chemin de la page
  href: string;

  listSubscription = <Subscription[]>[];

  constructor(private router: Router, private dataLoadingService: DataLoadingService,public stats: StatistiquesTicketsService, private cdRef: ChangeDetectorRef, private connexionService: ConnexionService, private dashboardService: DashboardService) { }
 
  getRandomColor() {
    var x = Math.floor(Math.random() * 256);
    var y = Math.floor(Math.random() * 256);
    var z = Math.floor(Math.random() * 256);
    var bgColor = "rgb(" + x + "," + y + "," + z + ")";
    return bgColor;
      }
    
    



  ngOnInit(): void {
    // Initialisation des variables
    this.href = this.router.url;
    // Paramétrage DoughnutChart
    this.doughnutChartType = 'doughnut';
    this.doughnutChartLegendReponse = true;
    this.doughnutChartOptions = {
      legend: {position: 'right'}
    }
    this.doughnutChartReadyReponse = false
    // Mise à jour du tableau des graphes ouverts
    this.dataLoadingService.chartOpened.doughnutChartReponse = 1

    // Récupération des données du user connecté
    this.subscription = this.connexionService.connexionSubject.subscribe(datas => {
      this.currentUser = datas;
    })
    this.connexionService.emitConnection();

    // Chargement des données
 

    this.subscriptionLoadData = this.dataLoadingService.DoughnutChartReponseloadDataCalled.subscribe(() => {
      this.dashboardComponents = this.dataLoadingService.dashboardComponents
      this.entreprises = this.dataLoadingService.entreprises
      this.resposDossier = this.dataLoadingService.resposDossier
      this.urls = this.dataLoadingService.urls
      this.ordresPriorite = this.dataLoadingService.ordresPriorite
      this.modules = this.dataLoadingService.modules
      this.etats = this.dataLoadingService.etats
      this.typesObjet = this.dataLoadingService.typesObjet
      this.fiches = this.dataLoadingService.fiches
      this.messages = this.dataLoadingService.messages

      //Chargement des données
     
    });
   
    this.stats.entreprise = this.selectedEntreprise
    this.stats.base = this.selectedBase
    
    console.log(this.selected + " " + this.periode + " " + this.selectedEntreprise + " " + this.selectedBase + " " + this.selected2 + " ", "Testing")
    if(this.selected!=='Entreprise' && this.selected!=='Base - Entreprise' )    {
    this.handleClick(this.selected, this.periode, [])}
    else
    {
    this.stats.filtre=this.selected2;
    this.handleClickCritère(this.selected2, this.periode, [])
    }// Chargement des données de la BDD
  }

  ngOnDestroy(): void {
    this.listSubscription.map((elem) => elem.unsubscribe());
    this.subscription.unsubscribe();
    this.subscriptionLoadData.unsubscribe()
  }

  chartHovered(event: Event){}
  chartClicked(event: Event){}

  activeLegend() {
    this.doughnutChartLegendReponse = !this.doughnutChartLegendReponse
  }

  
  chargementDonneesBDD(){
    // Chargement des données
    // Verfication chargement des données des types d'objet
    if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.typesObjet) == true) {
      if(this.dataLoadingService.loadingLaunched.typesObjet === 0) this.dataLoadingService.loadDataTypesObjet()
      console.log('I am loading types objet data')
    }
    else this.typesObjet = this.dataLoadingService.typesObjet
    
    // Verfication chargement des données des etats
    if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.etats) == true) {
      if(this.dataLoadingService.loadingLaunched.etats === 0)this.dataLoadingService.loadDataEtats()
      console.log('I am loading etats data')
    }
    else this.etats = this.dataLoadingService.etats
    

    // Verfication chargement des données des modules
    if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.modules) == true) {
      if(this.dataLoadingService.loadingLaunched.modules === 0)this.dataLoadingService.loadDataModules()
      console.log('I am loading modules data')
    }
    else this.modules = this.dataLoadingService.modules

    // Verfication chargement des données des ordres de priorité
    if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.ordresPriorite) == true) {
      if(this.dataLoadingService.loadingLaunched.ordresPriorite === 0)this.dataLoadingService.loadDataOrdresPriorite()
      console.log('I am loading ordres de priorité data')
    }
    else this.ordresPriorite = this.dataLoadingService.ordresPriorite

    // Verfication chargement des données des urls
    if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.urls) == true) {
      if(this.dataLoadingService.loadingLaunched.urls === 0)this.dataLoadingService.loadDataUrls()
      console.log('I am loading urls data')
    }
    else this.urls = this.dataLoadingService.urls

    // Verfication chargement des données des resposDossier
    if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.resposDossier) == true) {
      if(this.dataLoadingService.loadingLaunched.resposDossier === 0)this.dataLoadingService.loadDataResposDossier()
      console.log('I am loading resposDossier data')
    }
    else this.resposDossier = this.dataLoadingService.resposDossier

    // Verfication chargement des données des entreprises
    if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.entreprises) == true) {
      if(this.dataLoadingService.loadingLaunched.entreprises === 0)this.dataLoadingService.loadDataEntreprises()
      console.log('I am loading entreprises data')
    }
    else this.entreprises = this.dataLoadingService.entreprises



    // On demande à récupérer les données du user connecté
    this.dataLoadingService.mesFicheUserId = Number(this.currentUser.id)

    // Verfication chargement des données des dashboard components
    if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.dashboardComponents) == true) {
      if(this.dataLoadingService.loadingLaunched.dashboardComponents === 0)  this.dataLoadingService.loadDataDashboardComponents()
      console.log('I am loading dasboard componenents data')
    }
    else this.dashboardComponents = this.dataLoadingService.dashboardComponents

    // Verfication chargement des données des fiches
    if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.fiches) == true) {
      if(this.dataLoadingService.loadingLaunched.fiches === 0)  this.dataLoadingService.loadDataFiches()
      console.log('I am loading fiches data')

      // Verfication chargement des données des messages
      if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.messages) == true) {
        if(this.dataLoadingService.loadingLaunched.messages === 0)  {
          this.dataLoadingService.loadDataMessages()
        }
        console.log('I am loading messages data')
      }
      else {
        // Initialisation Messages
        this.messages = this.dataLoadingService.messages
      }
    }
    else {
      // Initialisation Fiches
      this.fiches = this.dataLoadingService.fiches

      // Verfication chargement des données des messages
      if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.messages) == true) {
        if(this.dataLoadingService.loadingLaunched.messages === 0)  {
          this.dataLoadingService.loadDataMessages()
        }
        console.log('I am loading messages data')
      }
      else {
        // Initialisation Messages
        this.messages = this.dataLoadingService.messages

        //Chargement des données
        this.chargementDonnees(this.selected, this.periode);
      }
    }
  }

  chargementPeriode(selected: string, periode: string, start: Date, end: Date){
    let debut = new Date(start);
    let fin = new Date(end);

    this.fichesPeriode = [];
    for(let fiche of this.fiches){
      if(new Date(fiche.date_ouverture) >= debut && new Date(fiche.date_ouverture) <= fin) this.fichesPeriode.push(fiche);
    }

    // Reinitialisation des données pour le graphe du temps de réponse
    this.allFichesMessages = [];
    for(let fiche of this.fichesPeriode){
      this.allFichesMessages.push({ficheID: fiche.id, numero_ticket: fiche.numero_ticket, date_ouverture: new Date(fiche.date_ouverture), usersID: fiche.usersID, etat: fiche.etat, type_objet: fiche.type_objet, module: fiche.module, url: fiche.url, respo_dossier_ID: fiche.respo_dossier_ID, ordre_priorite: fiche.ordre_priorite, entreprise: fiche.numero_ticket.substring(0, fiche.numero_ticket.lastIndexOf("_")), messages: []})
    }
    this.allFichesMessages.sort((a, b) => a.date_ouverture - b.date_ouverture);
    for(let fiche of this.allFichesMessages){
      for(let message of this.messages){
        if(fiche.ficheID == message.ficheID) fiche.messages.push({userID: message.userID, userStatut: message.userStatut, date_envoie: new Date(message.date_envoie)});
      }
    }
    for(let fiche of this.allFichesMessages){
      fiche.messages.sort((a, b) => a.date_envoie - b.date_envoie);
    }

    this.handleClick(selected, periode, this.allFichesMessages);
  }

  chargementDonnees(selected: string, value: string){
    this.periode = value;
    let todayDate = new Date();
    switch(value){
      case "Tout":
        // Reinitialisation des données pour le graphe du nombre de tickets
        this.fichesPeriode = this.fiches;
        // Reinitialisation des données pour le graphe du temps de réponse
        this.allFichesMessages = [];
        for(let fiche of this.fichesPeriode){
          this.allFichesMessages.push({ficheID: fiche.id, numero_ticket: fiche.numero_ticket, date_ouverture: new Date(fiche.date_ouverture), usersID: fiche.usersID, etat: fiche.etat, type_objet: fiche.type_objet, module: fiche.module, url: fiche.url, respo_dossier_ID: fiche.respo_dossier_ID, ordre_priorite: fiche.ordre_priorite, entreprise: fiche.numero_ticket.substring(0, fiche.numero_ticket.lastIndexOf("_")), messages: []})
        }
        this.allFichesMessages.sort((a, b) => a.date_ouverture - b.date_ouverture);
        for(let fiche of this.allFichesMessages){
          for(let message of this.messages){
            if(fiche.ficheID == message.ficheID) fiche.messages.push({userID: message.userID, userStatut: message.userStatut, date_envoie: new Date(message.date_envoie)});
          }
        }
        for(let fiche of this.allFichesMessages){
          fiche.messages.sort((a, b) => a.date_envoie - b.date_envoie);
        }
        this.handleClick(selected, value, this.allFichesMessages);
        break;
      case "Année":
        // Reinitialisation des données pour le graphe du nombre de tickets
        this.fichesPeriode = [];
        for(let fiche of this.fiches){
          if(todayDate.getFullYear() == (new Date(fiche.date_ouverture)).getFullYear()) this.fichesPeriode.push(fiche);
        }
        // Reinitialisation des données pour le graphe du temps de réponse
        this.allFichesMessages = [];
        for(let fiche of this.fichesPeriode){
          this.allFichesMessages.push({ficheID: fiche.id, numero_ticket: fiche.numero_ticket, date_ouverture: new Date(fiche.date_ouverture), usersID: fiche.usersID, etat: fiche.etat, type_objet: fiche.type_objet, module: fiche.module, url: fiche.url, respo_dossier_ID: fiche.respo_dossier_ID, ordre_priorite: fiche.ordre_priorite, entreprise: fiche.numero_ticket.substring(0, fiche.numero_ticket.lastIndexOf("_")), messages: []})
        }
        this.allFichesMessages.sort((a, b) => a.date_ouverture - b.date_ouverture);
        for(let fiche of this.allFichesMessages){
          for(let message of this.messages){
            if(fiche.ficheID == message.ficheID) fiche.messages.push({userID: message.userID, userStatut: message.userStatut, date_envoie: new Date(message.date_envoie)});
          }
        }
        for(let fiche of this.allFichesMessages){
          fiche.messages.sort((a, b) => a.date_envoie - b.date_envoie);
        }
        this.handleClick(selected, value, this.allFichesMessages);
        break;
      case "Mois":
        // Reinitialisation des données pour le graphe du nombre de tickets
        this.fichesPeriode = [];
        for(let fiche of this.fiches){
          if((todayDate.getMonth() + 1) == ((new Date(fiche.date_ouverture)).getMonth() + 1) && todayDate.getFullYear() == (new Date(fiche.date_ouverture)).getFullYear()) this.fichesPeriode.push(fiche);
        }
        // Reinitialisation des données pour le graphe du temps de réponse
        this.allFichesMessages = [];
        for(let fiche of this.fichesPeriode){
          this.allFichesMessages.push({ficheID: fiche.id, numero_ticket: fiche.numero_ticket, date_ouverture: new Date(fiche.date_ouverture), usersID: fiche.usersID, etat: fiche.etat, type_objet: fiche.type_objet, module: fiche.module, url: fiche.url, respo_dossier_ID: fiche.respo_dossier_ID, ordre_priorite: fiche.ordre_priorite, entreprise: fiche.numero_ticket.substring(0, fiche.numero_ticket.lastIndexOf("_")), messages: []})
        }
        this.allFichesMessages.sort((a, b) => a.date_ouverture - b.date_ouverture);
        for(let fiche of this.allFichesMessages){
          for(let message of this.messages){
            if(fiche.ficheID == message.ficheID) fiche.messages.push({userID: message.userID, userStatut: message.userStatut, date_envoie: new Date(message.date_envoie)});
          }
        }
        for(let fiche of this.allFichesMessages){
          fiche.messages.sort((a, b) => a.date_envoie - b.date_envoie);
        }
        this.handleClick(selected, value, this.allFichesMessages);
        break;
      case "Semaine":
        // Reinitialisation des données pour le graphe du nombre de tickets
        this.fichesPeriode = [];
        for(let fiche of this.fiches){
          if(this.getWeek(new Date(todayDate)) == this.getWeek(new Date(fiche.date_ouverture)) && (todayDate.getMonth() + 1) == ((new Date(fiche.date_ouverture)).getMonth() + 1) && todayDate.getFullYear() == (new Date(fiche.date_ouverture)).getFullYear()) this.fichesPeriode.push(fiche);
        }
        // Reinitialisation des données pour le graphe du temps de réponse
        this.allFichesMessages = [];
        for(let fiche of this.fichesPeriode){
          this.allFichesMessages.push({ficheID: fiche.id, numero_ticket: fiche.numero_ticket, date_ouverture: new Date(fiche.date_ouverture), usersID: fiche.usersID, etat: fiche.etat, type_objet: fiche.type_objet, module: fiche.module, url: fiche.url, respo_dossier_ID: fiche.respo_dossier_ID, ordre_priorite: fiche.ordre_priorite, entreprise: fiche.numero_ticket.substring(0, fiche.numero_ticket.lastIndexOf("_")), messages: []})
        }
        this.allFichesMessages.sort((a, b) => a.date_ouverture - b.date_ouverture);
        for(let fiche of this.allFichesMessages){
          for(let message of this.messages){
            if(fiche.ficheID == message.ficheID) fiche.messages.push({userID: message.userID, userStatut: message.userStatut, date_envoie: new Date(message.date_envoie)});
          }
        }
        for(let fiche of this.allFichesMessages){
          fiche.messages.sort((a, b) => a.date_envoie - b.date_envoie);
        }
        this.handleClick(selected, value, this.allFichesMessages);
        break;
      case "Periode":
        this.handleClick(selected, value, this.allFichesMessages);
        break;
    }
  }

  
  /** Doughnut Chart Temps de réponse */
  recuperationTempsReponse(selected: string, allFichesMessages: any[]){
    this.allFichesMessages = allFichesMessages;
    this.tempsReponse = 0;
    this.nbTicketsConcerned = 0
    let dateDernierMsgCLient;
    let datePremierMsgBugtracker;
    let msgIndex;
    let clientExist;

    //Décompte de chaque colonne
    for(let fiche of this.allFichesMessages){
      if(fiche.messages.length != 0){
        switch(selected){
          case "Type d'objet":
            for(let item of this.typeObjetCount){
              if(fiche.type_objet == item.type_objet){
                // On parcourt les messages de la conversation
                msgIndex = 0;
                while((msgIndex + 1) != fiche.messages.length){
                  clientExist = false;
                  if(fiche.messages[msgIndex].userStatut == "Externe") {
                    clientExist = true;
                  }
                  if(clientExist == true){
                    if(fiche.messages[msgIndex + 1].userStatut == "Interne") {
                      dateDernierMsgCLient = fiche.messages[msgIndex].date_envoie;
                      datePremierMsgBugtracker = fiche.messages[msgIndex + 1].date_envoie;
      
                      item.tempsReponse = item.tempsReponse + this.getHoursGap(new Date(dateDernierMsgCLient), new Date(datePremierMsgBugtracker))
                    }
                  }
                  msgIndex++;
                }
              }
            }
            break;

          case "Etat":
            for(let item of this.etatCount){
              if(fiche.etat == item.etat){
                // On parcourt les messages de la conversation
                msgIndex = 0; 
                while((msgIndex + 1) != fiche.messages.length){
                  clientExist = false;
                  if(fiche.messages[msgIndex].userStatut == "Externe") {
                    clientExist = true;
                  }
                  if(clientExist == true){
                    if(fiche.messages[msgIndex + 1].userStatut == "Interne") {
                      dateDernierMsgCLient = fiche.messages[msgIndex].date_envoie;
                      datePremierMsgBugtracker = fiche.messages[msgIndex + 1].date_envoie;
      
                      item.tempsReponse = item.tempsReponse + this.getHoursGap(new Date(dateDernierMsgCLient), new Date(datePremierMsgBugtracker))
                    }
                  }
                  msgIndex++;
                }
              }
            }
            break;

          case "Module":
            for(let item of this.moduleCount){
              if(fiche.module == item.module) {
                // On parcourt les messages de la conversation
                msgIndex = 0; 
                while((msgIndex + 1) != fiche.messages.length){
                  clientExist = false;
                  if(fiche.messages[msgIndex].userStatut == "Externe") {
                    clientExist = true;
                  }
                  if(clientExist == true){
                    if(fiche.messages[msgIndex + 1].userStatut == "Interne") {
                      dateDernierMsgCLient = fiche.messages[msgIndex].date_envoie;
                      datePremierMsgBugtracker = fiche.messages[msgIndex + 1].date_envoie;
      
                      item.tempsReponse = item.tempsReponse + this.getHoursGap(new Date(dateDernierMsgCLient), new Date(datePremierMsgBugtracker))
                    }
                  }
                  msgIndex++;
                }
              }
            }
            break;

          case "Ordre de priorité":
            for(let item of this.prioriteCount){
              if(fiche.ordre_priorite == item.ordre_priorite) {
                // On parcourt les messages de la conversation
                msgIndex = 0; 
                while((msgIndex + 1) != fiche.messages.length){
                  clientExist = false;
                  if(fiche.messages[msgIndex].userStatut == "Externe") {
                    clientExist = true;
                  }
                  if(clientExist == true){
                    if(fiche.messages[msgIndex + 1].userStatut == "Interne") {
                      dateDernierMsgCLient = fiche.messages[msgIndex].date_envoie;
                      datePremierMsgBugtracker = fiche.messages[msgIndex + 1].date_envoie;
      
                      item.tempsReponse = item.tempsReponse + this.getHoursGap(new Date(dateDernierMsgCLient), new Date(datePremierMsgBugtracker))
                    }
                  }
                  msgIndex++;
                }
              }
            }
            break;
          
          case "URL":
            for(let item of this.urlCount){
              if(fiche.url == item.url) {
                // On parcourt les messages de la conversation
                msgIndex = 0; 
                while((msgIndex + 1) != fiche.messages.length){
                  clientExist = false;
                  if(fiche.messages[msgIndex].userStatut == "Externe") {
                    clientExist = true;
                  }
                  if(clientExist == true){
                    if(fiche.messages[msgIndex + 1].userStatut == "Interne") {
                      dateDernierMsgCLient = fiche.messages[msgIndex].date_envoie;
                      datePremierMsgBugtracker = fiche.messages[msgIndex + 1].date_envoie;
      
                      item.tempsReponse = item.tempsReponse + this.getHoursGap(new Date(dateDernierMsgCLient), new Date(datePremierMsgBugtracker))
                    }
                  }
                  msgIndex++;
                }
              }
            }
            break;

          case "Entreprise":
            for(let i=0; i < this.entrepriseCount.length; i++){
              if(fiche.numero_ticket.includes(this.entrepriseCount[i].entreprise)) {
                // On parcourt les messages de la conversation
                msgIndex = 0; 
                while((msgIndex + 1) != fiche.messages.length){
                  clientExist = false;
                  if(fiche.messages[msgIndex].userStatut == "Externe") {
                    clientExist = true;
                  }
                  if(clientExist == true){
                    if(fiche.messages[msgIndex + 1].userStatut == "Interne") {
                      dateDernierMsgCLient = fiche.messages[msgIndex].date_envoie;
                      datePremierMsgBugtracker = fiche.messages[msgIndex + 1].date_envoie;
      
                      this.entrepriseCount[i].tempsReponse = this.entrepriseCount[i].tempsReponse + this.getHoursGap(new Date(dateDernierMsgCLient), new Date(datePremierMsgBugtracker))
                    }
                  }
                  msgIndex++;
                }
              }
            }
            break;

          case "Responsable de dossier":
            for(let item of this.respCount){
              if(fiche.respo_dossier_ID == item.respo) {
                // On parcourt les messages de la conversation
                msgIndex = 0; 
                while((msgIndex + 1) != fiche.messages.length){
                  clientExist = false;
                  if(fiche.messages[msgIndex].userStatut == "Externe") {
                    clientExist = true;
                  }
                  if(clientExist == true){
                    if(fiche.messages[msgIndex + 1].userStatut == "Interne") {
                      dateDernierMsgCLient = fiche.messages[msgIndex].date_envoie;
                      datePremierMsgBugtracker = fiche.messages[msgIndex + 1].date_envoie;
      
                      item.tempsReponse = item.tempsReponse + this.getHoursGap(new Date(dateDernierMsgCLient), new Date(datePremierMsgBugtracker))
                    }
                  }
                  msgIndex++;
                }
              }
            }
            break;
        }
      }
    }
  }
  /** FIN Doughnut Chart Temps de réponse */
  handleClickCritère(value: string, periode: string, fichesPeriode: any[])
  {
    this.selected2=value;
    this.periode = periode
    
 
    this.doughnutChartReadyReponse = false;
    //Calcul en pourcentage & Paramétrage DoughnutChart Nombre de Reponse
    this.doughnutChartLabelsReponse = [];
    this.doughnutChartDataReponse = [];
 

    if(this.selected==='Entreprise')
    {

      switch(periode)
      {
        case 'Année':
          this.legendeReponse = "Moyenne de temps de réponse par "+this.selected2.toLowerCase()+" de l\'année de l'entreprise "+this.selectedEntreprise;
          this.unite = '(en heure/mois)'
     
      console.log("critère ")
  
      this.doughnutChartType = 'doughnut';
      this.stats.filtre=this.selected2;
      console.log(this.selected);
      //On récupère les catégories selon le filtre.
      const variable = this.stats.getCategorieStats().subscribe((response:any) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
         this.CategorieObjetCount = response.data; 
     
  
  
      console.log(this.CategorieObjetCount);
      for(let item of this.CategorieObjetCount){
        this.colors.push(this.getRandomColor());
        this.stats.filtre=this.selected2;
        this.stats.categorie=item.category;
        console.log(this.CategorieObjetCount);
        console.log(this.stats.categorie)
        this.stats.entreprise = this.selectedEntreprise
        this.stats.base = this.selectedBase
        this.stats.filtre=this.selected2;
        const variable3 = this.stats.getReponseQuantityStatsbyEntreprise().subscribe((response) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
            console.log(response);
          this.tempsReponse = JSON.parse(JSON.stringify(response)).data[0].sum; 
          this.nbTicketsConcerned = JSON.parse(JSON.stringify(response)).data[0].nbTicketsConcernes; 
          console.log("categorie ",item.category," tempsReponse ",this.tempsReponse );
         
            this.doughnutChartLabelsReponse.push(" " + item.category);
            this.doughnutChartDataReponse.push(Number(this.tempsReponse/this.nbTicketsConcerned).toFixed(2));
          this.doughnutChartReadyReponse = true;
        });
        //Détruire la souscription
        this.listSubscription.push(variable3);
  
  
  }
  this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
  this.colors=[]
  });
  //Détruire la souscription
  this.listSubscription.push(variable);
  
  
  
     // this.sortFiches(value, fichesPeriode)
      console.log(value);
      console.log(periode);
      console.log(fichesPeriode);
  
      break;
      case 'Mois':
        this.legendeReponse = "Moyenne de temps de réponse par "+this.selected2.toLowerCase()+" du mois de l'entreprise "+this.selectedEntreprise;
        this.unite = '(en heure/semaine)'
     
      
  
      this.doughnutChartType = 'doughnut';
      this.stats.filtre=this.selected2;
      console.log(this.selected);
      //On récupère les catégories selon le filtre.
      const variable4 = this.stats.getCategorieStats().subscribe((response:any) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
         this.CategorieObjetCount = response.data; 
  
     
  
  
     
      console.log(this.CategorieObjetCount);
      for(let item of this.CategorieObjetCount){
        this.colors.push(this.getRandomColor());
        this.stats.filtre=this.selected2;
        this.stats.categorie=item.category;
        console.log(this.CategorieObjetCount);
        console.log(this.stats.categorie)
        this.stats.entreprise = this.selectedEntreprise
        this.stats.base = this.selectedBase
        this.stats.filtre=this.selected2;
        const variable3 = this.stats.getReponseQuantityStatsByMonthbyEntreprise().subscribe((response) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
            console.log(response);
          this.tempsReponse = JSON.parse(JSON.stringify(response)).data[0].sum; 
          this.nbTicketsConcerned = JSON.parse(JSON.stringify(response)).data[0].nbTicketsConcernes; 
          console.log("categorie ",item.category," tempsReponse ",this.tempsReponse );
         
            this.doughnutChartLabelsReponse.push(" " + item.category);
            this.doughnutChartDataReponse.push(Number(this.tempsReponse/this.nbTicketsConcerned).toFixed(2) );
         
          this.doughnutChartReadyReponse = true;
        });
        //Détruire la souscription
        this.listSubscription.push(variable3);
  
  
  }
  this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
  this.colors=[]
  });
  //Détruire la souscription
  this.listSubscription.push(variable4);
  
  
  
     // this.sortFiches(value, fichesPeriode)
      console.log(value);
      console.log(periode);
      console.log(fichesPeriode);
  
      break;
      case 'Semaine':
        this.legendeReponse = "Moyenne de temps de réponse par "+this.selected2.toLowerCase()+" de la semaine de l'entreprise "+this.selectedEntreprise;
        this.unite = '(en heure/jour)'
     
      
  
        this.doughnutChartType = 'doughnut';
        this.stats.filtre=this.selected2;
        console.log(this.selected);
        //On récupère les catégories selon le filtre.
        const variable5 = this.stats.getCategorieStats().subscribe((response:any) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
           this.CategorieObjetCount = response.data; 
           
       
        console.log(this.CategorieObjetCount);
        for(let item of this.CategorieObjetCount){
          this.colors.push(this.getRandomColor());
          this.stats.filtre=this.selected2;
          this.stats.categorie=item.category;
          console.log(this.CategorieObjetCount);
          console.log(this.stats.categorie)
          this.stats.entreprise = this.selectedEntreprise
          this.stats.base = this.selectedBase
          this.stats.filtre=this.selected2;
          const variable3 = this.stats.getReponseQuantityStatsByWeekbyEntreprise().subscribe((response) => {
            //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
              console.log(response);
            this.tempsReponse = JSON.parse(JSON.stringify(response)).data[0].sum; 
            this.nbTicketsConcerned = JSON.parse(JSON.stringify(response)).data[0].nbTicketsConcernes; 
            console.log("categorie ",item.category," tempsReponse ",this.tempsReponse );
           
              this.doughnutChartLabelsReponse.push(" " + item.category);
              this.doughnutChartDataReponse.push(Number(this.tempsReponse/this.nbTicketsConcerned).toFixed(2));
           
            this.doughnutChartReadyReponse = true;
          });
          //Détruire la souscription
          this.listSubscription.push(variable3);
    
    
    }
    this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
    this.colors=[]
    });
    //Détruire la souscription
    this.listSubscription.push(variable5);
    
    
    
       // this.sortFiches(value, fichesPeriode)
        console.log(value);
        console.log(periode);
        console.log(fichesPeriode);
    
        break;
        case 'Tout':
          this.legendeReponse = "Moyenne de temps de réponse par "+this.selected2.toLowerCase()+ " de l'entreprise "+this.selectedEntreprise;
          this.unite = '(en heure/mois)'
          
          // Le nombre de mois total pour la periode 'Tout'
          let nbMonths = 0
          const variable0 = this.stats.getNbMoisDeMessagerie().subscribe((response:any) => {
            nbMonths = response.data[0].months
          
            this.doughnutChartType = 'doughnut';
            this.stats.filtre=this.selected2;
            console.log(this.selected);
            //On récupère les catégories selon le filtre.
            const variable6 = this.stats.getCategorieStats().subscribe((response:any) => {
              //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
              this.CategorieObjetCount = response.data; 
              console.log(this.CategorieObjetCount);
              for(let item of this.CategorieObjetCount){
                this.colors.push(this.getRandomColor());
                this.stats.filtre=this.selected2;
                this.stats.categorie=item.category;
                console.log(this.CategorieObjetCount);
                console.log(this.stats.categorie)
                this.stats.entreprise = this.selectedEntreprise
                this.stats.base = this.selectedBase
                this.stats.filtre=this.selected2;
                const variable3 = this.stats.getReponseAllQuantityStatsbyEntreprise().subscribe((response) => {
                  //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
                    console.log(response);
                  this.tempsReponse = JSON.parse(JSON.stringify(response)).data[0].sum; 
                  this.nbTicketsConcerned = JSON.parse(JSON.stringify(response)).data[0].nbTicketsConcernes; 
                  console.log("categorie ",item.category," tempsReponse ",this.tempsReponse );
                
                    this.doughnutChartLabelsReponse.push(" " + item.category);
                    console.log(nbMonths, 'TEST nbMonths')
                    this.doughnutChartDataReponse.push(Number(this.tempsReponse/this.nbTicketsConcerned).toFixed(2)  );
                
                  this.doughnutChartReadyReponse = true;
                });
                //Détruire la souscription
                this.listSubscription.push(variable3);
              }
              this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
              this.colors=[]
            });
            //Détruire la souscription
            this.listSubscription.push(variable6);
          });
          //Détruire la souscription
          this.listSubscription.push(variable0);

          // this.sortFiches(value, fichesPeriode)
          console.log(value);
          console.log(periode);
          console.log(fichesPeriode);
      
          break;
      case 'Periode':
        this.legendeReponse = "Moyenne de temps de réponse par "+this.selected2.toLowerCase()+" de la période  de l'entreprise "+this.selectedEntreprise;
        this.unite = '(en heure/mois)'
     
      
  
        this.doughnutChartType = 'doughnut';
        this.stats.filtre=this.selected2;
        console.log(this.selected);

        // Le nombre de mois total pour la periode saisie
        let nbMois = 0
        const variable1 = this.stats.getNbMoisBetween2Dates().subscribe((response:any) => {
           nbMois = response.data[0].months + 1

        //On récupère les catégories selon le filtre.
        const variable7 = this.stats.getCategorieStats().subscribe((response:any) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
           this.CategorieObjetCount = response.data; 
       
       
    
    
        console.log(this.CategorieObjetCount);
        for(let item of this.CategorieObjetCount){
          this.colors.push(this.getRandomColor());
          this.stats.filtre=this.selected2;
          this.stats.categorie=item.category;
          console.log(this.CategorieObjetCount);
          console.log(this.stats.categorie)
          this.stats.entreprise = this.selectedEntreprise
          this.stats.base = this.selectedBase
          this.stats.filtre=this.selected2;
          const variable3 = this.stats.getReponsePeriodeQuantityStatsbyEntreprise().subscribe((response) => {
            //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
            console.log(response);
            this.tempsReponse = JSON.parse(JSON.stringify(response)).data[0].sum; 
            this.nbTicketsConcerned = JSON.parse(JSON.stringify(response)).data[0].nbTicketsConcernes; 
            console.log("categorie ",item.category," tempsReponse ",this.tempsReponse );
           
              this.doughnutChartLabelsReponse.push(" " + item.category);
              console.log(nbMois, 'nbMois')
              if(nbMois != 0) this.doughnutChartDataReponse.push(Number(this.tempsReponse/this.nbTicketsConcerned).toFixed(2));
              else  this.doughnutChartDataReponse.push(Number(this.tempsReponse/this.nbTicketsConcerned).toFixed(2));

            this.doughnutChartReadyReponse = true;
          });
          //Détruire la souscription
          this.listSubscription.push(variable3);
    
    
              }
              this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
              this.colors=[]
              });
              //Détruire la souscription
              this.listSubscription.push(variable7);
            });
            //Détruire la souscription
            this.listSubscription.push(variable1);

    
    
    
       // this.sortFiches(value, fichesPeriode)
        console.log(this.stats);
        console.log(value);
        console.log(periode);
        console.log(fichesPeriode);
    
        break;
  
  
    }



    }
    else
    {
     
      switch(periode)
      {
        
        case 'Année':
          this.legendeReponse = "Moyenne de temps de réponse par "+this.selected2.toLowerCase()+" de l\'année de la période  de la base "+this.selectedBase+" de l'entreprise "+this.selectedEntreprise;
          this.unite = '(en heure/mois)'
     
      
  
      this.doughnutChartType = 'doughnut';
      this.stats.filtre=this.selected2;
      console.log(this.selected);
      //On récupère les catégories selon le filtre.
      const variable = this.stats.getCategorieStats().subscribe((response:any) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
         this.CategorieObjetCount = response.data; 
    

      console.log(this.CategorieObjetCount);
      for(let item of this.CategorieObjetCount){
        this.colors.push(this.getRandomColor());
        this.stats.filtre=this.selected2;
        this.stats.categorie=item.category;
        console.log(this.CategorieObjetCount);
        console.log(this.stats.categorie)
        this.stats.entreprise = this.selectedEntreprise
        this.stats.base = this.selectedBase
        this.stats.filtre=this.selected2;
        const variable3 = this.stats.getReponseQuantityStatsbyEntrepriseAndBase().subscribe((response) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
            console.log(response);
          this.tempsReponse = JSON.parse(JSON.stringify(response)).data[0].sum; 
          this.nbTicketsConcerned = JSON.parse(JSON.stringify(response)).data[0].nbTicketsConcernes; 
          console.log("categorie ",item.category," tempsReponse ",this.tempsReponse );
         
            this.doughnutChartLabelsReponse.push(" " + item.category);
            this.doughnutChartDataReponse.push(Number(this.tempsReponse/this.nbTicketsConcerned).toFixed(2) );
         
          this.doughnutChartReadyReponse = true;
        });
        //Détruire la souscription
        this.listSubscription.push(variable3);
  
  
  }
  this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
  this.colors=[]
  });
  //Détruire la souscription
  this.listSubscription.push(variable);
  
  
  
     // this.sortFiches(value, fichesPeriode)
      console.log(value);
      console.log(periode);
      console.log(fichesPeriode);
  
      break;
      case 'Mois':
        this.legendeReponse = "Moyenne de temps de réponse par "+this.selected2.toLowerCase()+" du mois de la base "+this.selectedBase+" de l'entreprise "+this.selectedEntreprise;
        this.unite = '(en heure/semaine)'
     
      
  
      this.doughnutChartType = 'doughnut';
      this.stats.filtre=this.selected2;
      console.log(this.selected);
      //On récupère les catégories selon le filtre.
      const variable4 = this.stats.getCategorieStats().subscribe((response:any) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
         this.CategorieObjetCount = response.data; 
       
     
  
  
    
      console.log(this.CategorieObjetCount);
      for(let item of this.CategorieObjetCount){
        this.colors.push(this.getRandomColor());
        this.stats.filtre=this.selected2;
        this.stats.categorie=item.category;
        console.log(this.CategorieObjetCount);
        console.log(this.stats.categorie)
        this.stats.entreprise = this.selectedEntreprise
        this.stats.base = this.selectedBase
        this.stats.filtre=this.selected2;
        const variable3 = this.stats.getReponseQuantityStatsByMonthbyEntrepriseAndBase().subscribe((response) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
            console.log(response);
          this.tempsReponse = JSON.parse(JSON.stringify(response)).data[0].sum; 
          this.nbTicketsConcerned = JSON.parse(JSON.stringify(response)).data[0].nbTicketsConcernes; 
          console.log("categorie ",item.category," tempsReponse ",this.tempsReponse );
         
            this.doughnutChartLabelsReponse.push(" " + item.category);
            this.doughnutChartDataReponse.push(Number(this.tempsReponse/this.nbTicketsConcerned).toFixed(2) );
         
          this.doughnutChartReadyReponse = true;
        });
        //Détruire la souscription
        this.listSubscription.push(variable3);
  
  
  }
  this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
  this.colors=[]
  });
  //Détruire la souscription
  this.listSubscription.push(variable4);
  
  
  
     // this.sortFiches(value, fichesPeriode)
      console.log(value);
      console.log(periode);
      console.log(fichesPeriode);
  
      break;
      case 'Semaine':
        this.legendeReponse = "Moyenne de temps de réponse par "+this.selected2.toLowerCase()+" de la semaine de la base "+this.selectedBase+" de l'entreprise "+this.selectedEntreprise;
        this.unite = '(en heure/jour)'
     
      
  
        this.doughnutChartType = 'doughnut';
        this.stats.filtre=this.selected2;
        console.log(this.selected);
        //On récupère les catégories selon le filtre.
        const variable5 = this.stats.getCategorieStats().subscribe((response:any) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
           this.CategorieObjetCount = response.data; 
       
    
    
      
        console.log(this.CategorieObjetCount);
        for(let item of this.CategorieObjetCount){
          this.colors.push(this.getRandomColor());
          this.stats.filtre=this.selected2;
          this.stats.categorie=item.category;
          console.log(this.CategorieObjetCount);
          console.log(this.stats.categorie)
          this.stats.entreprise = this.selectedEntreprise
          this.stats.base = this.selectedBase
          this.stats.filtre=this.selected2;
          const variable3 = this.stats.getReponseQuantityStatsByWeekbyEntrepriseAndBase().subscribe((response) => {
            //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
              console.log(response);
            this.tempsReponse = JSON.parse(JSON.stringify(response)).data[0].sum; 
            this.nbTicketsConcerned = JSON.parse(JSON.stringify(response)).data[0].nbTicketsConcernes; 
            console.log("categorie ",item.category," tempsReponse ",this.tempsReponse );
           
              this.doughnutChartLabelsReponse.push(" " + item.category);
              this.doughnutChartDataReponse.push(Number(this.tempsReponse/this.nbTicketsConcerned).toFixed(2));
           
            this.doughnutChartReadyReponse = true;
          });
          //Détruire la souscription
          this.listSubscription.push(variable3);
    
    
    }
    this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
    this.colors=[]
    });
    //Détruire la souscription
    this.listSubscription.push(variable5);
    
    
    
       // this.sortFiches(value, fichesPeriode)
        console.log(value);
        console.log(periode);
        console.log(fichesPeriode);
    
        break;
        case 'Tout':
          this.legendeReponse = "Moyenne de temps de réponse par "+this.selected2.toLowerCase()+" de la base "+this.selectedBase+" de l'entreprise "+this.selectedEntreprise;;
          this.unite = '(en heure/mois)'
      // Le nombre de mois total pour la periode 'Tout'
      let nbMonths = 0
      const variable0 = this.stats.getNbMoisDeMessagerie().subscribe((response:any) => {
        nbMonths = response.data[0].months
      
  
      this.doughnutChartType = 'doughnut';
      this.stats.filtre=this.selected2;
      console.log(this.selected);
      //On récupère les catégories selon le filtre.
      const variable6 = this.stats.getCategorieStats().subscribe((response:any) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
         this.CategorieObjetCount = response.data; 
     
  
  
     
      console.log(this.CategorieObjetCount);
      for(let item of this.CategorieObjetCount){
        this.colors.push(this.getRandomColor());
        this.stats.filtre=this.selected2;
        this.stats.categorie=item.category;
        console.log(this.CategorieObjetCount);
        console.log(this.stats.categorie)
        this.stats.entreprise = this.selectedEntreprise
        this.stats.base = this.selectedBase
        this.stats.filtre=this.selected2;
        const variable3 = this.stats.getReponseAllQuantityStatsbyEntrepriseAndBase().subscribe((response) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
            console.log(response);
          this.tempsReponse = JSON.parse(JSON.stringify(response)).data[0].sum; 
          this.nbTicketsConcerned = JSON.parse(JSON.stringify(response)).data[0].nbTicketsConcernes; 
          console.log("categorie ",item.category," tempsReponse ",this.tempsReponse );
         
            this.doughnutChartLabelsReponse.push(" " + item.category);
            this.doughnutChartDataReponse.push(Number(this.tempsReponse/this.nbTicketsConcerned).toFixed(2)  );
         
          this.doughnutChartReadyReponse = true;
        });
        //Détruire la souscription
        this.listSubscription.push(variable3);
  
  
  }
  this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
  this.colors=[]
  });
  //Détruire la souscription
  this.listSubscription.push(variable6);
});
//Détruire la souscription
this.listSubscription.push(variable0);
  
  
  
     // this.sortFiches(value, fichesPeriode)
      console.log(value);
      console.log(periode);
      console.log(fichesPeriode);
  
      break;
      case 'Periode':
        this.legendeReponse = "Moyenne de temps de réponse par "+this.selected2.toLowerCase()+" de la période de la base "+this.selectedBase+" de l'entreprise "+this.selectedEntreprise;;
        this.unite = '(en heure/mois)'
     
      
  
        this.doughnutChartType = 'doughnut';
        this.stats.filtre=this.selected2;
        console.log(this.selected);

        // Le nombre de mois total pour la periode saisie
        let nbMois = 0
        const variable1 = this.stats.getNbMoisBetween2Dates().subscribe((response:any) => {
           nbMois = response.data[0].months + 1

        //On récupère les catégories selon le filtre.
        const variable7 = this.stats.getCategorieStats().subscribe((response:any) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
           this.CategorieObjetCount = response.data; 
       
    
        console.log(this.CategorieObjetCount);
        for(let item of this.CategorieObjetCount){
          this.colors.push(this.getRandomColor());
          this.stats.filtre=this.selected2;
          this.stats.categorie=item.category;
          console.log(this.CategorieObjetCount);
          console.log(this.stats.categorie)
          this.stats.entreprise = this.selectedEntreprise
          this.stats.base = this.selectedBase
          this.stats.filtre=this.selected2;
          const variable3 = this.stats.getReponsePeriodeQuantityStatsbyEntrepriseAndBase().subscribe((response) => {
            //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
              console.log(response);
            this.tempsReponse = JSON.parse(JSON.stringify(response)).data[0].sum; 
            this.nbTicketsConcerned = JSON.parse(JSON.stringify(response)).data[0].nbTicketsConcernes; 
            console.log("categorie ",item.category," tempsReponse ",this.tempsReponse );
           
              this.doughnutChartLabelsReponse.push(" " + item.category);
              this.doughnutChartDataReponse.push(Number(this.tempsReponse/this.nbTicketsConcerned).toFixed(2));
           
            this.doughnutChartReadyReponse = true;
          });
          //Détruire la souscription
          this.listSubscription.push(variable3);
    
    
    }
    this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
    this.colors=[]
    });
    //Détruire la souscription
    this.listSubscription.push(variable7);

  });
  //Détruire la souscription
  this.listSubscription.push(variable1);
    
    
    
       // this.sortFiches(value, fichesPeriode)
        console.log(this.stats);
        console.log(value);
        console.log(periode);
        console.log(fichesPeriode);
    
        break;
  



    }
 

  }
  this.cdRef.detectChanges();


  }


  handleClick(value: string, periode: string, fichesPeriode: any[]){
    this.selected=value;
    this.periode = periode
    console.log(this.selected)
    
 
    this.doughnutChartReadyReponse = false;
    //Calcul en pourcentage & Paramétrage DoughnutChart Nombre de Reponse
    this.doughnutChartLabelsReponse = [];
    this.doughnutChartDataReponse = [];
    if(this.selected!=='Entreprise' && this.selected!=='Base - Entreprise' )
    {
    switch(periode)
    {
      case 'Année':
        this.legendeReponse = "Moyenne de temps de réponse par "+this.selected.toLowerCase()+" de l\'année";
        this.unite = '(en heure/mois)'
   
    

    this.doughnutChartType = 'doughnut';
    this.stats.filtre=this.selected;
    console.log(this.selected);
    //On récupère les catégories selon le filtre.
    const variable = this.stats.getCategorieStats().subscribe((response:any) => {
      //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
       this.CategorieObjetCount = response.data; 
       this.selected=value;
   


    console.log(this.CategorieObjetCount);
    for(let item of this.CategorieObjetCount){
      this.colors.push(this.getRandomColor());
      this.stats.filtre=this.selected;
      this.stats.categorie=item.category;
      console.log(this.CategorieObjetCount);
      console.log(this.stats.categorie)
      const variable3 = this.stats.getReponseQuantityStats().subscribe((response) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
          console.log(response);
        this.tempsReponse = JSON.parse(JSON.stringify(response)).data[0].sum; 
        this.nbTicketsConcerned = JSON.parse(JSON.stringify(response)).data[0].nbTicketsConcernes; 
        console.log("categorie ",item.category," tempsReponse ",this.tempsReponse );
       
          this.doughnutChartLabelsReponse.push(" " + item.category);
          this.doughnutChartDataReponse.push(Number(this.tempsReponse/this.nbTicketsConcerned).toFixed(2) );
       
        this.doughnutChartReadyReponse = true;
      });
      //Détruire la souscription
      this.listSubscription.push(variable3);


}
this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
this.colors=[]
});
//Détruire la souscription
this.listSubscription.push(variable);



   // this.sortFiches(value, fichesPeriode)
    console.log(value);
    console.log(periode);
    console.log(fichesPeriode);

    break;
    case 'Mois':
      this.legendeReponse = "Moyenne de temps de réponse par "+this.selected.toLowerCase()+" du mois";
      this.unite = '(en heure/semaine)'
   
    

    this.doughnutChartType = 'doughnut';
    this.stats.filtre=this.selected;
    console.log(this.selected);
    //On récupère les catégories selon le filtre.
    const variable4 = this.stats.getCategorieStats().subscribe((response:any) => {
      //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
       this.CategorieObjetCount = response.data; 
       this.selected=value;
   


  
    console.log(this.CategorieObjetCount);
    for(let item of this.CategorieObjetCount){
      this.colors.push(this.getRandomColor());
      this.stats.filtre=this.selected;
      this.stats.categorie=item.category;
      console.log(this.CategorieObjetCount);
      console.log(this.stats.categorie)
      const variable3 = this.stats.getReponseQuantityStatsByMonth().subscribe((response) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
          console.log(response);
        this.tempsReponse = JSON.parse(JSON.stringify(response)).data[0].sum; 
        this.nbTicketsConcerned = JSON.parse(JSON.stringify(response)).data[0].nbTicketsConcernes; 
        console.log("categorie ",item.category," tempsReponse ",this.tempsReponse );
       
          this.doughnutChartLabelsReponse.push(" " + item.category);
          this.doughnutChartDataReponse.push(Number(this.tempsReponse/this.nbTicketsConcerned).toFixed(2) );
       
        this.doughnutChartReadyReponse = true;
      });
      //Détruire la souscription
      this.listSubscription.push(variable3);


}
this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
this.colors=[]
});
//Détruire la souscription
this.listSubscription.push(variable4);



   // this.sortFiches(value, fichesPeriode)
    console.log(value);
    console.log(periode);
    console.log(fichesPeriode);

    break;
    case 'Semaine':
      this.legendeReponse = "Moyenne de temps de réponse par "+this.selected.toLowerCase()+" de la semaine";
      this.unite = '(en heure/jour)'
   
    

      this.doughnutChartType = 'doughnut';
      this.stats.filtre=this.selected;
      console.log(this.selected);
      //On récupère les catégories selon le filtre.
      const variable5 = this.stats.getCategorieStats().subscribe((response:any) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
         this.CategorieObjetCount = response.data; 
         this.selected=value;
     
  
  
    
      console.log(this.CategorieObjetCount);
      for(let item of this.CategorieObjetCount){
        this.colors.push(this.getRandomColor());
        this.stats.filtre=this.selected;
        this.stats.categorie=item.category;
        console.log(this.CategorieObjetCount);
        console.log(this.stats.categorie)
        const variable3 = this.stats.getReponseQuantityStatsByWeek().subscribe((response) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
            console.log(response);
          this.tempsReponse = JSON.parse(JSON.stringify(response)).data[0].sum; 
          this.nbTicketsConcerned = JSON.parse(JSON.stringify(response)).data[0].nbTicketsConcernes; 
          console.log("categorie ",item.category," tempsReponse ",this.tempsReponse );
         
            this.doughnutChartLabelsReponse.push(" " + item.category);
            this.doughnutChartDataReponse.push(Number(this.tempsReponse/this.nbTicketsConcerned).toFixed(2) );
         
          this.doughnutChartReadyReponse = true;
        });
        //Détruire la souscription
        this.listSubscription.push(variable3);
  
  
  }
  this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
  this.colors=[]
  });
  //Détruire la souscription
  this.listSubscription.push(variable5);
  
  
  
     // this.sortFiches(value, fichesPeriode)
      console.log(value);
      console.log(periode);
      console.log(fichesPeriode);
  
      break;
      case 'Tout':
        this.legendeReponse = "Moyenne de temps de réponse par "+this.selected.toLowerCase();
        this.unite = '(en heure/mois)'
   
    // Le nombre de mois total pour la periode 'Tout'
    let nbMonths = 0
    const variable0 = this.stats.getNbMoisDeMessagerie().subscribe((response:any) => {
      nbMonths = response.data[0].months

    this.doughnutChartType = 'doughnut';
    this.stats.filtre=this.selected;
    console.log(this.selected);
    //On récupère les catégories selon le filtre.
    const variable6 = this.stats.getCategorieStats().subscribe((response:any) => {
      //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
       this.CategorieObjetCount = response.data; 
       this.selected=value;
   

    console.log(this.CategorieObjetCount);
    for(let item of this.CategorieObjetCount){
      this.colors.push(this.getRandomColor());
      this.stats.filtre=this.selected;
      this.stats.categorie=item.category;
      console.log(this.CategorieObjetCount);
      console.log(this.stats.categorie)
      const variable3 = this.stats.getReponseAllQuantityStats().subscribe((response) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
          console.log(response);
        this.tempsReponse = JSON.parse(JSON.stringify(response)).data[0].sum; 
        this.nbTicketsConcerned = JSON.parse(JSON.stringify(response)).data[0].nbTicketsConcernes; 
        console.log("categorie ",item.category," tempsReponse ",this.tempsReponse );
       
          this.doughnutChartLabelsReponse.push(" " + item.category);
          this.doughnutChartDataReponse.push(Number(this.tempsReponse/this.nbTicketsConcerned).toFixed(2));
       
        this.doughnutChartReadyReponse = true;
      });
      //Détruire la souscription
      this.listSubscription.push(variable3);


}
this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
this.colors=[]
});
//Détruire la souscription
this.listSubscription.push(variable6);
});
//Détruire la souscription
this.listSubscription.push(variable0);


   // this.sortFiches(value, fichesPeriode)
    console.log(value);
    console.log(periode);
    console.log(fichesPeriode);

    break;
    case 'Periode':
      this.legendeReponse = "Moyenne de temps de réponse par "+this.selected.toLowerCase()+" de la période ";
      this.unite = '(en heure/mois)'
   
    // Le nombre de mois total pour la periode saisie
    let nbMois = 0
    const variable1 = this.stats.getNbMoisBetween2Dates().subscribe((response:any) => {
       nbMois = response.data[0].months + 1

      this.doughnutChartType = 'doughnut';
      this.stats.filtre=this.selected;
      console.log(this.selected);
      //On récupère les catégories selon le filtre.
      const variable7 = this.stats.getCategorieStats().subscribe((response:any) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
         this.CategorieObjetCount = response.data; 
         this.selected=value;
     
  
  
      console.log(this.CategorieObjetCount);
      for(let item of this.CategorieObjetCount){
        this.colors.push(this.getRandomColor());
        this.stats.filtre=this.selected;
        this.stats.categorie=item.category;
        console.log(this.CategorieObjetCount);
        console.log(this.stats.categorie)
        const variable3 = this.stats.getReponsePeriodeQuantityStats().subscribe((response) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
            console.log(response);
          this.tempsReponse = JSON.parse(JSON.stringify(response)).data[0].sum; 
          this.nbTicketsConcerned = JSON.parse(JSON.stringify(response)).data[0].nbTicketsConcernes; 
          console.log("categorie ",item.category," tempsReponse ",this.tempsReponse );
         
            this.doughnutChartLabelsReponse.push(" " + item.category);
            this.doughnutChartDataReponse.push(Number(this.tempsReponse/this.nbTicketsConcerned).toFixed(2));
         
          this.doughnutChartReadyReponse = true;
        });
        //Détruire la souscription
        this.listSubscription.push(variable3);
  
  
  }
  this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
  this.colors=[]
  });
  //Détruire la souscription
  this.listSubscription.push(variable7);
  });
  //Détruire la souscription
  this.listSubscription.push(variable1);
  
  
  
     // this.sortFiches(value, fichesPeriode)
      console.log(this.stats);
      console.log(value);
      console.log(periode);
      console.log(fichesPeriode);
  
      break;


  }
}
else
{ 
  this.doughnutChartReadyReponse = false;
  //Calcul en pourcentage & Paramétrage DoughnutChart Nombre de Reponse
  this.doughnutChartLabelsReponse = [];
  this.doughnutChartDataReponse = [];}


    this.cdRef.detectChanges();
  }
  /** FIN Doughnut Chart Nombre de tickets */

  // Affichage du graphe sur le dashboard
  checkCmpInDashboard(){
    let alreadyInDashboard = false;
    for(let cmp of this.dashboardComponents){
      // Vérification si le component est associé au user connecté et s'il s'agit du bon graphe
      if(cmp.userId == Number(this.currentUser.id) && cmp.titreComponent == "DoughnutChartReponse"){
        if(cmp.donnees[0] == this.selected && cmp.donnees[1] == this.periode)  alreadyInDashboard = true;
      }
    }
    return alreadyInDashboard;
  }

  addToDashboard(){
    if(this.periode != 'Periode'){
      this.dashboardService.dataToAdd = []
      if(this.selected !== 'Entreprise' && this.selected !== 'Base - Entreprise')  this.dashboardService.dataToAdd.push({id: 0, userId: Number(this.currentUser.id), titreComponent: "DoughnutChartReponse", titreDashboard: "Statistiques", donnees: "/" + this.selected + "*" + "/" + this.periode + "*"});
      if(this.selected === 'Entreprise')  this.dashboardService.dataToAdd.push({id: 0, userId: Number(this.currentUser.id), titreComponent: "DoughnutChartReponse", titreDashboard: "Statistiques", donnees: "/" + this.selected + "*" + "/" + this.periode + "*" + "/" + this.stats.entreprise + "*"+ "/" + this.selected2 + "*"});
      if(this.selected === 'Base - Entreprise')  this.dashboardService.dataToAdd.push({id: 0, userId: Number(this.currentUser.id), titreComponent: "DoughnutChartReponse", titreDashboard: "Statistiques", donnees: "/" + this.selected + "*" + "/" + this.periode + "*" + "/" + this.stats.entreprise + "*"+ "/" + this.stats.base + "*"+ "/" + this.selected2 + "*"});

      const variable = this.dashboardService.postAddDashboardComponentToServer().subscribe(
        () => {
        console.log('Component du dashboard sauvegardé !');
        },
        (error) => {
        console.log('Erreur ! : ' + error);
        }
      );
      this.listSubscription.push(variable);
    }
  }

  removeFromDashboard(){
    for(let component of this.dashboardComponents){
      if(component.userId == Number(this.currentUser.id) && component.titreComponent == "DoughnutChartReponse") {
        if(component.donnees[0] == this.selected && component.donnees[1] == this.periode) this.dashboardService.idOfDataToDelete = component.id;
      }
    }
    const variable = this.dashboardService.postDeleteDashboardComponentFromServer().subscribe(
      () => {
        console.log('Component du dashboard supprimé !');
      },
      (error) => {
        console.log('Erreur ! : ' + error);
      }
    );
    this.listSubscription.push(variable);
  }
  /* FIN Affichage du graphe sur le dashboard */

  // Quelques méthodes basiques qui sont utiles pour les algorithmes au-dessus
  getWeek(date: Date ) { 
    // Create a copy of this date object  
    var target  = new Date(date.valueOf());  
    // ISO week date weeks start on monday so correct the day number  
    var dayNr   = (date.getDay() + 6) % 7;  
    // Set the target to the thursday of this week so the target date is in the right year  
    target.setDate(target.getDate() - dayNr + 3);  
    // ISO 8601 states that week 1 is the week with january 4th in it  
    var jan4    = new Date(target.getFullYear(), 0, 4);  
    // Number of days between target date and january 4th  
    var diff = Math.abs(target.getTime() - jan4.getTime());
    var dayDiff = Math.ceil(diff / (1000 * 3600 * 24)); 
    // Calculate week number: Week 1 (january 4th) plus the number of weeks between target date and january 4th    
    var weekNr = 1 + Math.ceil(dayDiff / 7);    
  
    return weekNr;
  }

  getHoursGap(start: Date, end: Date){
    let debut = new Date(start)
    let fin = new Date(end)

    // Si le msg du client a été envoyé en semaine en dehors des heures d'ouverture
    if(debut.getDay() == 1 || debut.getDay() == 2 || debut.getDay() == 3 || debut.getDay() == 4){
      if(debut.getHours() < 9) debut.setHours(9);
      if(debut.getHours() > 17) {
        debut.setDate(debut.getDate() + 1)
        debut.setHours(9);
        debut.setMinutes(0);
        debut.setSeconds(0);
      }
    }
    // Si le msg du bug tracker a été envoyé en semaine en dehors des heures d'ouverture
    if(fin.getDay() == 1 || fin.getDay() == 2 || fin.getDay() == 3 || fin.getDay() == 4){
      if(fin.getHours() < 9) fin.setHours(9);
      if(fin.getHours() > 17) {
        fin.setDate(fin.getDate() + 1)
        fin.setHours(9);
        debut.setMinutes(0);
        debut.setSeconds(0);
      }
    }
    
    // Si le msg du client a été envoyé vendredi hors heures d'ouverture
    if(debut.getDay() == 5){
      if(debut.getHours() < 9) debut.setHours(9);
      if(debut.getHours() > 17){
        debut.setDate(debut.getDate() + 3)
        debut.setHours(9);
        debut.setMinutes(0);
        debut.setSeconds(0);
      }
    }
    // Si le msg du bug tracker a été envoyé vendredi hors heures d'ouverture
    if(fin.getDay() == 5){
      if(fin.getHours() < 9) fin.setHours(9);
      if(fin.getHours() > 17){
        fin.setDate(fin.getDate() + 3)
        fin.setHours(9);
        debut.setMinutes(0);
        debut.setSeconds(0);
      }
    }

    // Si le msg du client a été envoyé le weekend
    if(debut.getDay() == 6 || debut.getDay() == 0){
      if(debut.getDay() == 6) debut.setDate(debut.getDate() + 2)
      if(debut.getDay() == 0) debut.setDate(debut.getDate() + 1)
      debut.setHours(9);
      debut.setMinutes(0);
      debut.setSeconds(0);
    }
    // Si le msg du bug tracker a été envoyé le weekend
    if(fin.getDay() == 6 || fin.getDay() == 0){
      if(fin.getDay() == 6) fin.setDate(fin.getDate() + 2)
      if(fin.getDay() == 0) fin.setDate(fin.getDate() + 1)
      fin.setHours(9);
      fin.setMinutes(0);
      fin.setSeconds(0);
    }
    
    // Calculer en respectant les horaires d'ouverture
    let gapMilliseconds = new Date(fin).getTime() - new Date(debut).getTime();
    let gapHours = gapMilliseconds/(3600 * 1000);
    let gapHoursCalculated = gapMilliseconds/(3600 * 1000);
    let extraHour = 0;
    
    // S'il il s'agit de 2 dates différentes
    if(debut.getDate() != fin.getDate() || debut.getMonth() != fin.getMonth() || debut.getFullYear() != fin.getFullYear()){
      //S'il y a qu'un jour d'écart, on retire lécart en millisecondes entre 17h et 9h du lendemain
      if(gapHours < 24) gapMilliseconds = gapMilliseconds - (16 * 3600 * 1000)
      // S'il y a plus d'un jour de différence
      if(gapHours >= 24){
        // On retire les horaires du weekend entre 9h et 17h (gap de 8h)
        if(this.countSpecificDayBetweenDates(new Date(debut), new Date(fin),'Sun') > 0){
          gapHoursCalculated = gapHoursCalculated - (this.countSpecificDayBetweenDates(new Date(debut), new Date(fin),'Sun') * 2 * 24)
        }
        // On retire les horaires après 17h et avant 9h tous les jour (gap de 16h entre la fermeture à 17h et l'ouverture le lendemine à 9h)
        if(fin.getHours() < debut.getHours()){
          extraHour = 1;
        }
        gapHoursCalculated = gapHoursCalculated - ((Math.floor(gapHours/24) + extraHour - (2 * this.countSpecificDayBetweenDates(new Date(debut), new Date(fin),'Sun'))) * 16)
      }
    }

    return gapHoursCalculated;
  }

  countSpecificDayBetweenDates(start, end, dayName) {
    var result = [];
    var days = {sun:0,mon:1,tue:2,wed:3,thu:4,fri:5,sat:6};
    var day = days[dayName.toLowerCase().substr(0,3)];
    // Copy start date
    var current = new Date(start);
    // Shift to next of required days
    current.setDate(current.getDate() + (day - current.getDay() + 7) % 7);
    // While less than end date, add dates to result array
    while (current < end) {
      result.push(new Date(+current));
      current.setDate(current.getDate() + 7);
    }
    return result.length;  
  }

  monthDiff(d1: Date, d2: Date) {
    var months;
    months = (d2.getFullYear() - d1.getFullYear()) * 12;
    months -= d1.getMonth();
    months += d2.getMonth();
    return months <= 0 ? 0 : months;
  }

  weeksBetween(date1: Date, date2: Date) {
    let start = new Date(date1);
    let end = new Date(date2);
    // The number of milliseconds in one week
    var ONE_WEEK = 1000 * 60 * 60 * 24 * 7;
    // Convert both dates to milliseconds
    var date1_ms = start.getTime();
    var date2_ms = end.getTime();
    // Calculate the difference in milliseconds
    var difference_ms = Math.abs(date1_ms - date2_ms);
    // Convert back to weeks and return hole weeks
    return Math.floor(difference_ms / ONE_WEEK);
  }

  daysBetween(date1: Date, date2: Date){
    var diff = Math.abs(date1.getTime() - date2.getTime());
    var diffDays = Math.ceil(diff / (1000 * 3600 * 24));  
    return diffDays;
  }

  getMonday(d: Date) {
    d = new Date(d);
    var day = d.getDay(),
        diff = d.getDate() - day + (day == 0 ? -6:1); // adjust when day is sunday
    return new Date(d.setDate(diff));
  }

}
