import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DoughnutchartReponseComponent } from './doughnutchart-reponse.component';

describe('DoughnutchartReponseComponent', () => {
  let component: DoughnutchartReponseComponent;
  let fixture: ComponentFixture<DoughnutchartReponseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DoughnutchartReponseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DoughnutchartReponseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
