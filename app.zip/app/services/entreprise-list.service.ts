import { Entreprise } from '../models/entreprise.model';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class EntrepriseList {

    //DECLARATION DES VARIABLES

    entrepriseSample: Entreprise[] = [];
    dataToAdd: Entreprise[] = [];
    dataEntrepriseNom: any[] = []

    constructor(private httpClient: HttpClient) { }

    //METHODES
    
    postEntrepriseToServer() {
        return this.httpClient.post('/api/addCompany', {data: this.dataToAdd});
    }
    
    getEntrepriseFromServer() {
        return this.httpClient.get<any[]>('/api/fetchCompany',{
            headers: {
              'Content-Type': 'application/json',
            },
          }); 
    }

    getEntrepriseSpecifique() {
      return this.httpClient.post('/api/fetchCompanyWanted', {data: this.dataEntrepriseNom});
    }
}