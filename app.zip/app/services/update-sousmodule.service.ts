import { HttpClient } from '@angular/common/http';
import { updatesousmodule } from '../models/update_sous_module.model';
import { Injectable } from '@angular/core';

@Injectable()
export class updateSousModuleService{


id:number;
module:string;
sous_module:string;
date_prod:Date;
date_preprod:Date;
charge_dossier_ID:number;
client_ID:number;


    //DECLARATION VARIABLES

    updateSousModuleSample: updatesousmodule[] = [];

    dataToAdd: updatesousmodule[] = [];

    constructor(private httpClient: HttpClient) { }

    getLastId() {
        return this.httpClient.get<any[]>('/api/maxIdupdate',{
            headers: {
              'Content-Type': 'application/json',
            },
          }); 
    }
    postupdateToServer() {
        console.log("je suis dans le service");
        return this.httpClient.post('/api/addupdate', {data: this.dataToAdd});
        
    }
    getupdatefromServer()
    {
        return this.httpClient.get<any[]>('/api/getupdate',{
            headers: {
              'Content-Type': 'application/json',
            },
          }); 


    }
    
    updateupdates() {
        console.log("je suis dans le service");
        return this.httpClient.post('/api/updateupdates', {date_prod: this.date_prod,date_preprod: this.date_preprod,id:this.id});
        
    }



    deleteupdate()
    {
        console.log("je suis dans le service");
        return this.httpClient.post('/api/deleteupdate', {id:this.id});

    }

    clear(){

        this.updateSousModuleSample = [];

        this.dataToAdd= [];
    }


}