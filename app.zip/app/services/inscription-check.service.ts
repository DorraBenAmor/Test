export class InscriptionCheckService {
    
    //DECLARATION DES VARIABLES
    
    //Variables nécessaires pour créer un user
    userNom = "";
    userPrenom = "";
    userImage = "";
    userEntreprise = "";
    userBase = ""
    userFonction = "";
    userStatut = "";
    userModule = "";
    userProjet = "";
    userEmailPerso = "";
    userEmailPro = "";
    userMdpPro = "";
    userReferant = "";
    userDomaineTravail = "";
    userAdresse = "";
    userAdresse2 = "";
    userCodePostal: number;
    userVille = "";
    userPays = "";
    userTel: string;
    userFax: string;

    //METHODES

    
}