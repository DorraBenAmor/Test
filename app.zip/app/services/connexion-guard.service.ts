import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { ConnexionService } from './connexion.service';
import { Observable } from 'rxjs';
import { Subject } from 'rxjs';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable() //nécessaire lors d'un ajout d'un service dans un autre
export class ConnexionGuardService {

    // Déclaration des variables
    //loggedIn: Subject<boolean>;
    checkLoggedIn: boolean = false;
    
    // Constructeur
    constructor(private httpClient: HttpClient, private connexionService: ConnexionService, private router: Router){
        //this.loggedIn = new Subject();
        //this.getLogin();
    }

    // // Méthodes
    // canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    //   //console.log(this.loggedIn, "LOGGEDIN")

    //   /*
    //     if(this.loggedIn){
    //         //si l'utilisateur est authentifié, on lui laisse l'accès
    //         return true;
    //     }
    //     else{
    //         this.router.navigate(['/']);
    //     }
    //     */
    // }

    // Session
    getLogin() {
      //   return this.httpClient.get<any[]>('/api/retrieveLogin', {
      //     withCredentials: true // <=========== important!
      //   }).subscribe((resp: any) => {
      //     this.checkLoggedIn = resp.loggedIn
      //     console.log(this.checkLoggedIn, "loggin recupéré")
      //     if(this.checkLoggedIn){
      //       //si l'utilisateur est authentifié, on lui laisse l'accès
      //       this.router.navigate(['/dashboard']);
      //     }
      //     else{
      //         this.router.navigate(['/']);
      //     }
      //   }, (errorResp) => {
      //     console.log('Oops, something went wrong getting the logged in status')
      // })
    }

    doLogin(userid: string) {
      console.log('I am in !')
        return this.httpClient.post('/api/doLogin', {id: userid}, {
          withCredentials: true
        }).subscribe((resp: any) => {
          this.checkLoggedIn = true
          console.log('doLogin: Logged in!');
        }, (errorResp) => {
          this.checkLoggedIn = false
          console.log('doLogin: An unknown error has occured.');
        });
    }

    doLogout() {
        return this.httpClient.post('/api/doLogout', {}, {
          withCredentials: true
        }).subscribe(() => {
          this.checkLoggedIn = false
        });
    }
}