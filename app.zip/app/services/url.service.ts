import { URLModel } from '../models/url.model';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
    providedIn: 'root'
})
export class URLService {

    constructor(private httpClient: HttpClient) { }

    dataToAdd: URLModel[] = [];

    //METHODES
    
    getUrlsFromServer() {
        return this.httpClient.get<any[]>('/api/fetchUrls',{
            headers: {
              'Content-Type': 'application/json',
            },
        }); 
    }

}