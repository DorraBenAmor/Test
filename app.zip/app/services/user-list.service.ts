import { User } from '../models/user.model';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class UserList {
  
    //DECLARATION VARIABLES

    userSample: User[] = [];

    dataToAdd: User[] = [];

    dataConnexionUpdate: User[] = [];

    dataUserId: number = 0;

    dataUsersOfEntrepriseBase: any[] = []

    constructor(private httpClient: HttpClient) { }

    //METHODES
    /*
    addUser(nom: string, prenom: string, image: string, entreprise: string, fonction: string, statut: string, module: string, projet: string, emailPerso: string, emailPro: string, mdpPro: string, referant: string){
        this.users.push({id: (this.users.length + 1), nom: nom, prenom: prenom, image: image, entreprise: entreprise, fonction: fonction, statut: statut, module: module, projet: projet, connected: false, emailPerso: emailPerso, emailPro:  emailPro, mdpPro: mdpPro, isReferant: false, referantNom: referant});
        console.log(this.users);
    }*/

    postUserToServer() {
        return this.httpClient.post('/api/addUser', {data: this.dataToAdd});
    }

    updateUserConnexionToServer() {
        return this.httpClient.post('/api/updateUserConnexion', {data: this.dataConnexionUpdate});
    }
    
    getUserFromServer() {
        return this.httpClient.get<any[]>('/api/fetchUser',{
            headers: {
              'Content-Type': 'application/json',
            },
          }); 
    }

    getResposDossierFromServer() {
        return this.httpClient.get<any[]>('/api/fetchResposDossier',{
            headers: {
              'Content-Type': 'application/json',
            },
          }); 
    }

    getUsersCreatedLast7DaysFromServer() {
        return this.httpClient.get<any[]>('/api/fetchUserCreatedLast7Days',{
            headers: {
              'Content-Type': 'application/json',
            },
          }); 
    }

    getUserWithHisIdFromServer() {
        return this.httpClient.post('/api/fetchUserWithHisId', {data: this.dataUserId});
    }

    getUsersOfEntrepriseBase() {
      return this.httpClient.post('/api/fetchUsersOfEntrepriseBase', {data: this.dataUsersOfEntrepriseBase});
    }

    getUsersOfEntrepriseBaseCreatedLast7Days() {
      return this.httpClient.post('/api/fetchUsersOfEntrepriseBaseCreatedLast7Days', {data: this.dataUsersOfEntrepriseBase});
    }

    getInternesHorsHotliners() {
      return this.httpClient.get<any[]>('/api/fetchInternesHorsHotliners',{
          headers: {
            'Content-Type': 'application/json',
          },
        }); 
    }

  getReferents() {
    return this.httpClient.get<any[]>('/api/fetchReferents',{
        headers: {
          'Content-Type': 'application/json',
        },
      }); 
  }

  getNbInternes() {
    return this.httpClient.get<any[]>('/api/fetchNbInternes',{
        headers: {
          'Content-Type': 'application/json',
        },
    }); 
  }

  getNbExternes() {
    return this.httpClient.get<any[]>('/api/fetchNbExternes',{
        headers: {
          'Content-Type': 'application/json',
        },
    }); 
  }
    
}