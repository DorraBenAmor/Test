import { StatTempsResolutionModel } from '../models/statTempsResolution.model';
import { StatTempsReponseModel } from '../models/statTempsReponse.model';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
    providedIn: 'root'
})
export class StatService {

    constructor(private httpClient: HttpClient) { }

    dataToAdd: StatTempsResolutionModel[] = [];
    data: StatTempsReponseModel[] = [];
    filtre: string = ""
    filtreEntreprise: any[] = []
    filtrePeriode: any[] = []

    //METHODES

    // Récupération de la liste des entreprises qui ont déjà signalé un bug
    getEntreprisesFromFiches() {
        return this.httpClient.get<any[]>('/api/fetchEntreprisesFromFiches',{
            headers: {
              'Content-Type': 'application/json',
            },
        }); 
    }

    // Récupération de la liste des entreprises et base qui ont déjà signalé un bug
    getEntreprisesBasesFromFiches() {
        return this.httpClient.get<any[]>('/api/fetchEntreprisesBasesFromFiches',{
            headers: {
              'Content-Type': 'application/json',
            },
        }); 
    }

    /* GRAPHE D'EVOLUTION */
    // Periode : Tout
    getStatNombreTicketsTout() {
        return this.httpClient.post('/api/fetchStatNbTicketsTout', {data: this.filtre});
    }
    
    getStatTempsReponseTout() {
        return this.httpClient.post('/api/fetchStatReponseTout', {data: this.filtre});
    }

    getStatTempsResolutionTout() {
        return this.httpClient.post('/api/fetchTempsResolutionTout', {data: this.filtre});
    }

    // Periode : Année
    getStatNombreTicketsAnnee() {
        return this.httpClient.post('/api/fetchStatNbTicketsAnnee', {data: this.filtre});
    }
    
    getStatTempsReponseAnnee() {
        return this.httpClient.post('/api/fetchStatReponseAnnee', {data: this.filtre});
    }

    getStatTempsResolutionAnnee() {
        return this.httpClient.post('/api/fetchTempsResolutionAnnee', {data: this.filtre});
    }

    // Periode : Mois
    getStatNombreTicketsMois() {
        return this.httpClient.post('/api/fetchStatNbTicketsMois', {data: this.filtre});
    }
    
    getStatTempsReponseMois() {
        return this.httpClient.post('/api/fetchStatReponseMois', {data: this.filtre});
    }

    getStatTempsResolutionMois() {
        return this.httpClient.post('/api/fetchTempsResolutionMois', {data: this.filtre});
    }

    // Periode : Semaine
    getStatNombreTicketsSemaine() {
        return this.httpClient.post('/api/fetchStatNbTicketsSemaine', {data: this.filtre});
    }
    
    getStatTempsReponseSemaine() {
        return this.httpClient.post('/api/fetchStatReponseSemaine', {data: this.filtre});
    }

    getStatTempsResolutionSemaine() {
        return this.httpClient.post('/api/fetchTempsResolutionSemaine', {data: this.filtre});
    }

    // Periode : Periode saisie
    getStatNombreTicketsPeriodeSaisie() {
        return this.httpClient.post('/api/fetchStatNbTicketsPeriodeSaisie', {data: this.filtrePeriode});
    }
    
    getStatTempsReponsePeriodeSaisie() {
        return this.httpClient.post('/api/fetchStatReponsePeriodeSaisie', {data: this.filtrePeriode});
    }

    getStatTempsResolutionPeriodeSaisie() {
        return this.httpClient.post('/api/fetchTempsResolutionPeriodeSaisie', {data: this.filtrePeriode});
    }

    /* Si option Choix Entreprise choisie avec FILTRE*/
    // Periode : Tout
    getStatNombreTicketsToutChoixEntreprise() {
        return this.httpClient.post('/api/fetchStatNbTicketsToutChoixEntreprise', {data: this.filtreEntreprise});
    }
    
    getStatTempsReponseToutChoixEntreprise() {
        return this.httpClient.post('/api/fetchStatReponseToutChoixEntreprise', {data: this.filtreEntreprise});
    }

    getStatTempsResolutionToutChoixEntreprise() {
        return this.httpClient.post('/api/fetchTempsResolutionToutChoixEntreprise', {data: this.filtreEntreprise});
    }

    // Periode : Année
    getStatNombreTicketsAnneeChoixEntreprise() {
        return this.httpClient.post('/api/fetchStatNbTicketsAnneeChoixEntreprise', {data: this.filtreEntreprise});
    }
    
    getStatTempsReponseAnneeChoixEntreprise() {
        return this.httpClient.post('/api/fetchStatReponseAnneeChoixEntreprise', {data: this.filtreEntreprise});
    }

    getStatTempsResolutionAnneeChoixEntreprise() {
        return this.httpClient.post('/api/fetchTempsResolutionAnneeChoixEntreprise', {data: this.filtreEntreprise});
    }

    // Periode : Mois
    getStatNombreTicketsMoisChoixEntreprise() {
        return this.httpClient.post('/api/fetchStatNbTicketsMoisChoixEntreprise', {data: this.filtreEntreprise});
    }
    
    getStatTempsReponseMoisChoixEntreprise() {
        return this.httpClient.post('/api/fetchStatReponseMoisChoixEntreprise', {data: this.filtreEntreprise});
    }

    getStatTempsResolutionMoisChoixEntreprise() {
        return this.httpClient.post('/api/fetchTempsResolutionMoisChoixEntreprise', {data: this.filtreEntreprise});
    }

    // Periode : Semaine
    getStatNombreTicketsSemaineChoixEntreprise() {
        return this.httpClient.post('/api/fetchStatNbTicketsSemaineChoixEntreprise', {data: this.filtreEntreprise});
    }
    
    getStatTempsReponseSemaineChoixEntreprise() {
        return this.httpClient.post('/api/fetchStatReponseSemaineChoixEntreprise', {data: this.filtreEntreprise});
    }

    getStatTempsResolutionSemaineChoixEntreprise() {
        return this.httpClient.post('/api/fetchTempsResolutionSemaineChoixEntreprise', {data: this.filtreEntreprise});
    }

    // Periode : Periode saisie
    getStatNombreTicketsPeriodeSaisieChoixEntreprise() {
        return this.httpClient.post('/api/fetchStatNbTicketsPeriodeSaisieChoixEntreprise', {data: this.filtreEntreprise});
    }
    
    getStatTempsReponsePeriodeSaisieChoixEntreprise() {
        return this.httpClient.post('/api/fetchStatReponsePeriodeSaisieChoixEntreprise', {data: this.filtreEntreprise});
    }

    getStatTempsResolutionPeriodeSaisieChoixEntreprise() {
        return this.httpClient.post('/api/fetchTempsResolutionPeriodeSaisieChoixEntreprise', {data: this.filtreEntreprise});
    }


    /* GRAPHE A 2 FILTRES */
    // Tout
    getStatNbTicketsToutEntrepriseBaseFiltre() {
        return this.httpClient.post('/api/fetchStatNbTicketsToutEntrepriseBaseFiltre', {data: this.filtreEntreprise});
    }

    getStatNbTicketsToutEntrepriseFiltre() {
        return this.httpClient.post('/api/fetchStatNbTicketsToutEntrepriseFiltre', {data: this.filtreEntreprise});
    }

    getStatNbTicketsToutEntrepriseBase() {
        return this.httpClient.post('/api/fetchStatNbTicketsToutEntrepriseBase', {data: this.filtreEntreprise});
    }
    
    getStatNbTicketsToutDoubleFiltre() {
        return this.httpClient.post('/api/fetchStatNbTicketsToutDoubleFiltre', {data: this.filtreEntreprise});
    }
    
    // Année
    getStatNbTicketsAnneeEntrepriseBaseFiltre() {
        return this.httpClient.post('/api/fetchStatNbTicketsAnneeEntrepriseBaseFiltre', {data: this.filtreEntreprise});
    }

    getStatNbTicketsAnneeEntrepriseFiltre() {
        return this.httpClient.post('/api/fetchStatNbTicketsAnneeEntrepriseFiltre', {data: this.filtreEntreprise});
    }

    getStatNbTicketsAnneeEntrepriseBase() {
        return this.httpClient.post('/api/fetchStatNbTicketsAnneeEntrepriseBase', {data: this.filtreEntreprise});
    }
    
    getStatNbTicketsAnneeDoubleFiltre() {
        return this.httpClient.post('/api/fetchStatNbTicketsAnneeDoubleFiltre', {data: this.filtreEntreprise});
    }

    // Mois
    getStatNbTicketsMoisEntrepriseBaseFiltre() {
        return this.httpClient.post('/api/fetchStatNbTicketsMoisEntrepriseBaseFiltre', {data: this.filtreEntreprise});
    }

    getStatNbTicketsMoisEntrepriseFiltre() {
        return this.httpClient.post('/api/fetchStatNbTicketsMoisEntrepriseFiltre', {data: this.filtreEntreprise});
    }

    getStatNbTicketsMoisEntrepriseBase() {
        return this.httpClient.post('/api/fetchStatNbTicketsMoisEntrepriseBase', {data: this.filtreEntreprise});
    }
    
    getStatNbTicketsMoisDoubleFiltre() {
        return this.httpClient.post('/api/fetchStatNbTicketsMoisDoubleFiltre', {data: this.filtreEntreprise});
    }

    // Semaine
    getStatNbTicketsSemaineEntrepriseBaseFiltre() {
        return this.httpClient.post('/api/fetchStatNbTicketsSemaineEntrepriseBaseFiltre', {data: this.filtreEntreprise});
    }

    getStatNbTicketsSemaineEntrepriseFiltre() {
        return this.httpClient.post('/api/fetchStatNbTicketsSemaineEntrepriseFiltre', {data: this.filtreEntreprise});
    }

    getStatNbTicketsSemaineEntrepriseBase() {
        return this.httpClient.post('/api/fetchStatNbTicketsSemaineEntrepriseBase', {data: this.filtreEntreprise});
    }
    
    getStatNbTicketsSemaineDoubleFiltre() {
        return this.httpClient.post('/api/fetchStatNbTicketsSemaineDoubleFiltre', {data: this.filtreEntreprise});
    }

    // Periode Saisie
    getStatNbTicketsPeriodeSaisieEntrepriseBaseFiltre() {
        return this.httpClient.post('/api/fetchStatNbTicketsPeriodeSaisieEntrepriseBaseFiltre', {data: this.filtreEntreprise});
    }

    getStatNbTicketsPeriodeSaisieEntrepriseFiltre() {
        return this.httpClient.post('/api/fetchStatNbTicketsPeriodeSaisieEntrepriseFiltre', {data: this.filtreEntreprise});
    }

    getStatNbTicketsPeriodeSaisieEntrepriseBase() {
        return this.httpClient.post('/api/fetchStatNbTicketsPeriodeSaisieEntrepriseBase', {data: this.filtreEntreprise});
    }
    
    getStatNbTicketsPeriodeSaisieDoubleFiltre() {
        return this.httpClient.post('/api/fetchStatNbTicketsPeriodeSaisieDoubleFiltre', {data: this.filtreEntreprise});
    }

    // Autres routes
    getTempsRep() {
        return this.httpClient.get<any[]>('/api/fetchTempsRep',{
            headers: {
              'Content-Type': 'application/json',
            },
        }); 
    }

    postAddStatTempsRep() {
        return this.httpClient.post('/api/insertStatRep', {data: this.data});
    }

}