import { EventModel } from '../models/event.model';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class CalendarService {
  
    //DECLARATION VARIABLES
    eventsSampple: EventModel[] = [];


    dataToAdd: EventModel[] = [];
    dataToDelete: EventModel[] = [];
    dataToUpdate: EventModel[] = [];

    constructor(private httpClient: HttpClient) { }

    //METHODES
     
    postNewEventToServer() {
        return this.httpClient.post('/api/addNewEvent', {data: this.dataToAdd});
    }

    postDeleteEventInServer() {
        return this.httpClient.post('/api/deleteEvent', {data: this.dataToDelete});
    }

    postUpdateEventInServer() {
        return this.httpClient.post('/api/updateEvent', {data: this.dataToUpdate});
    }
    
    getEventsFromServer() {
        return this.httpClient.get<any[]>('/api/fetchAllEvents',{
            headers: {
              'Content-Type': 'application/json',
            },
          }); 
    }
    

}