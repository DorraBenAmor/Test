import { Injectable, OnDestroy, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Subscription, Subject } from 'rxjs';
import { User } from '../models/user.model';
import { UserList } from '../services/user-list.service';
import { Entreprise } from '../models/entreprise.model';
import { EntrepriseList } from '../services/entreprise-list.service';
import { TimelineElement } from '../models/timeline-element.model';
import { TimelineData } from '../services/timeline-data.service';
import { TypeObjetService } from '../services/typeObjet.service';
import { TypeObjetModel } from '../models/typeObjet.model';
import { EtatService } from '../services/etat.service';
import { EtatModel } from '../models/etat.model';
import { ImpactModel } from '../models/impact.model';
import { ImpactService } from '../services/impact.service';
import { ModuleModel } from '../models/module.model';
import { ModuleService } from '../services/module.service';
import { OrdrePrioriteModel } from '../models/ordrePriorite.model';
import { OrdrePrioriteService } from '../services/ordrePriorite.service';
import { URLModel } from '../models/url.model';
import { URLService } from '../services/url.service';
import { FicheModel } from '../models/fiche.model';
import { FicheUserModel } from '../models/fiche_user.model';
import { MessageModel } from '../models/message.model';
import { MessagerieTicketsService } from '../services/messagerie_tickets.service';
import { FiltreModel } from '../models/filtre.model';
import { faq } from '../models/faq.model';
import { FAQService } from '../services/faq.service';
import { DashboardService } from './dashboard.service';

@Injectable({
    providedIn: 'root'
})
export class DataLoadingService implements OnInit, OnDestroy {

    // Observable Load Data in component sources
    private LinearChartFiltreTicketloadDataSource = new Subject<any>();
    private LinearChartFiltreTicketPersoloadDataSource = new Subject<any>();
    private LinearChartGlobalTicketloadDataSource = new Subject<any>();
    private LinearChartGlobalTicketPersoloadDataSource = new Subject<any>();
    private DoughnutChartTicketloadDataSource = new Subject<any>();
    private DoughnutChartTicketPersoloadDataSource = new Subject<any>();
    private DoughnutChartReponseloadDataSource = new Subject<any>();
    private DoughnutChartReponsePersoloadDataSource = new Subject<any>();
    private DoughnutChartResolutionloadDataSource = new Subject<any>();
    private DoughnutChartResolutionPersoloadDataSource = new Subject<any>();
    private MessagerieTicketloadDataSource = new Subject<any>();
    private DashboardCollaborateursloadDataSource = new Subject<any>();
    private CollaborateursloadDataSource = new Subject<any>();
    private GrapheNiveau2TicketloadDataSource = new Subject<any>();
    private GrapheNiveau2TicketPersoloadDataSource = new Subject<any>();

    // Observable Load Data called in component
    LinearChartFiltreTicketloadDataCalled = this.LinearChartFiltreTicketloadDataSource.asObservable();
    LinearChartFiltreTicketPersoloadDataCalled = this.LinearChartFiltreTicketPersoloadDataSource.asObservable();
    LinearChartGlobalTicketloadDataCalled = this.LinearChartGlobalTicketloadDataSource.asObservable();
    LinearChartGlobalTicketPersoloadDataCalled = this.LinearChartGlobalTicketPersoloadDataSource.asObservable();
    DoughnutChartTicketloadDataCalled = this.DoughnutChartTicketloadDataSource.asObservable();
    DoughnutChartTicketPersoloadDataCalled = this.DoughnutChartTicketPersoloadDataSource.asObservable();
    DoughnutChartReponseloadDataCalled = this.DoughnutChartReponseloadDataSource.asObservable();
    DoughnutChartReponsePersoloadDataCalled = this.DoughnutChartReponsePersoloadDataSource.asObservable();
    DoughnutChartResolutionloadDataCalled = this.DoughnutChartResolutionloadDataSource.asObservable();
    DoughnutChartResolutionPersoloadDataCalled = this.DoughnutChartResolutionPersoloadDataSource.asObservable();
    MessagerieTicketloadDataCalled = this.MessagerieTicketloadDataSource.asObservable();
    DashboardCollaborateursloadDataCalled = this.DashboardCollaborateursloadDataSource.asObservable();
    CollaborateursloadDataCalled = this.CollaborateursloadDataSource.asObservable();
    GrapheNiveau2TicketloadDataCalled = this.GrapheNiveau2TicketloadDataSource.asObservable();
    GrapheNiveau2TicketPersoloadDataCalled = this.GrapheNiveau2TicketPersoloadDataSource.asObservable();

    users: User[] = [];
    usersCreatedLast7Days: User[] = []  // User créés les 7 derniers jours
    resposDossier: User[] = []
    entreprises: Entreprise[] = [];
    timeline: TimelineElement[] = []
    typesObjet: TypeObjetModel[] = [];
    etats: EtatModel[] = [];
    impacts: ImpactModel[] = [];
    modules: ModuleModel[] = [];    // [id, module, sous_module]
    onlyModules: any[] = [];        // Modules
    ordresPriorite: OrdrePrioriteModel[] = [];
    urls: URLModel[] = [];
    fiches: FicheModel[] = [];
    fichesUser: FicheUserModel[] = [];
    messages: MessageModel[] = [];
    lastInterneMessagesOfFicheCloturee: MessageModel[] = []
    filtres: FiltreModel[] = [];
    faqs: faq[] = []
    dashboardComponents: any[] = [];

    // Data du user connecté (récupéré à partir de toutes les données récupérées)
    mesFicheUserId: number = 0
    mesFiches: FicheModel[] = []
    mesFichesUser: FicheUserModel[] = []
    messagesDeMesFiches: MessageModel[] = []
    mesFiltres: FiltreModel[] = []

    // Data du user connecté (récupéré directement depuis la BDD)
    myFiches: FicheModel[] = []
    myFichesUser: FicheUserModel[] = []
    myMessagesOfMyFiches: MessageModel[] = []
    myLastInterneMessagesOfFicheCloturee: MessageModel[] = []
    myFiltres: FiltreModel[] = []

    loadingLaunched = {
        users: 0,
        usersCreatedLast7Days: 0,
        resposDossier: 0,
        entreprises: 0,
        timeline: 0,
        typesObjet: 0,
        etats: 0,
        impacts: 0,
        modules: 0,
        ordresPriorite: 0,
        urls: 0,
        fiches: 0,
        myFiches: 0,
        fichesUser: 0,
        myFichesUser: 0,
        messages: 0,
        myMessages: 0,
        lastInterneMessagesOfFicheCloturee: 0,
        myLastInterneMessagesOfFicheCloturee: 0,
        filtres: 0,
        myFiltres: 0,
        faqs: 0,
        dashboardComponents: 0
    }

    loading = {
        users: 0,
        usersCreatedLast7Days: 0,
        resposDossier: 0,
        entreprises: 0,
        timeline: 0,
        typesObjet: 0,
        etats: 0,
        impacts: 0,
        modules: 0,
        ordresPriorite: 0,
        urls: 0,
        fiches: 0,
        myFiches: 0,
        fichesUser: 0,
        myFichesUser: 0,
        messages: 0,
        myMessages: 0,
        lastInterneMessagesOfFicheCloturee: 0,
        myLastInterneMessagesOfFicheCloturee: 0,
        filtres: 0,
        myFiltres: 0,
        faqs: 0,
        dashboardComponents: 0
    }

    // Tableau des components ouverts
    chartOpened = {
        linearChartFiltreTicket: 0,
        linearChartFiltreTicketPerso: 0,
        linearChartGlobalTicket: 0,
        linearChartGlobalTicketPerso: 0,
        doughnutChartTicket: 0,
        doughnutChartTicketPerso: 0,
        doughnutChartReponse: 0,
        doughnutChartReponsePerso: 0,
        doughnutChartResolution: 0,
        doughnutChartResolutionPerso: 0,
        messagerieTicket: 0,
        dashboardCollaborateurs: 0,
        collaborateurs: 0,
        grapheNiveau2Ticket: 0,
        grapheNiveau2TicketPerso: 0
    }
    

    listSubscription = <Subscription[]>[];

    constructor(private httpClient: HttpClient, private dashboardService: DashboardService, private messagerieTicketsSerivice: MessagerieTicketsService, private faqService: FAQService, private impactService: ImpactService, private urlService: URLService, private ordrePrioriteService: OrdrePrioriteService, private moduleService: ModuleService, private etatService: EtatService, private typeObjetService: TypeObjetService, private userService: UserList, private entrepriseService: EntrepriseList, private timelineData: TimelineData) { }

    //METHODES
    ngOnInit(): void { 
    }

    ngOnDestroy(): void {
        this.listSubscription.map((elem) => elem.unsubscribe());
    }

    // Chargement de données
    loadDataUsers(){
        this.loadingLaunched.users = 1
        //Récupération du data des users de la BDD
        const variable3 = this.userService.getUserFromServer().subscribe((res3) => {
            this.loading.users = 1
            this.users = JSON.parse(JSON.stringify(res3)).data
            this.verifyLoading()
        });
        this.listSubscription.push(variable3);
    }

    // Chargement de données
    loadDataUsersCreatedLast7Days(){
        this.loadingLaunched.usersCreatedLast7Days = 1
        //Récupération du data des users de la BDD
        const variable3 = this.userService.getUsersCreatedLast7DaysFromServer().subscribe((res3) => {
            this.loading.usersCreatedLast7Days = 1
            this.usersCreatedLast7Days = JSON.parse(JSON.stringify(res3)).data;
            this.verifyLoading()
        });
        this.listSubscription.push(variable3);
    }

    loadDataResposDossier(){
        this.loadingLaunched.resposDossier = 1
        //Récupération du data des responsables de dossier de la BDD (contiennent le tag 'bug')
        const variable3 = this.userService.getResposDossierFromServer().subscribe((res3) => {
            this.loading.resposDossier = 1
            this.resposDossier = JSON.parse(JSON.stringify(res3)).data;
            this.verifyLoading()
        });
        this.listSubscription.push(variable3);
    }

    loadDataEntreprises(){
        this.loadingLaunched.entreprises = 1
        //Récupération du data des entreprises de la BDD
        const variable4 = this.entrepriseService.getEntrepriseFromServer().subscribe((res) => {
            this.loading.entreprises = 1
            this.entreprises = JSON.parse(JSON.stringify(res)).data;
            this.verifyLoading()
        });
        this.listSubscription.push(variable4);
    }

    loadDataTimeline(){
        this.loadingLaunched.timeline = 1
        //Récupération du data de la timeline de la BDD
        const variable = this.timelineData.getEvtFromServer().subscribe((response) => {
            this.loading.timeline = 1
            this.timeline =  JSON.parse(JSON.stringify(response)).data
            this.verifyLoading()
          });
          //Détruire la souscription
          this.listSubscription.push(variable);
    }

    loadDataTypesObjet(){
        this.loadingLaunched.typesObjet = 1
        //Récupération du data des types d'objet de la BDD
        const variable8 = this.typeObjetService.getTypesObjetFromServer().subscribe((res) => {
            this.loading.typesObjet = 1
            this.typesObjet = JSON.parse(JSON.stringify(res)).data;
            this.verifyLoading()
        });
        this.listSubscription.push(variable8);
    }

    loadDataEtats(){
        this.loadingLaunched.etats = 1
        //Récupération du data des états de la BDD
        const variable9 = this.etatService.getEtatFromServer().subscribe((res) => {
            this.loading.etats = 1
            this.etats = JSON.parse(JSON.stringify(res)).data;
            this.verifyLoading()
        });
        this.listSubscription.push(variable9);
    }

    loadDataImpacts(){
        this.loadingLaunched.impacts = 1
        //Récupération du data des états de la BDD
        const variable13 = this.impactService.getImpactFromServer().subscribe((res) => {
            this.loading.impacts = 1
            this.impacts = JSON.parse(JSON.stringify(res)).data;
            this.verifyLoading()
        });
        this.listSubscription.push(variable13);
    }

    loadDataModules(){
        this.loadingLaunched.modules = 1
        //Récupération du data des modules de la BDD
        const variable10 = this.moduleService.getAllModulesFromServer().subscribe((res) => {
            this.loading.modules = 1
            this.modules = JSON.parse(JSON.stringify(res)).data;
            for(let item of this.modules){
            if(!(this.onlyModules.includes(item.module))) this.onlyModules.push(item.module)
            }
            this.verifyLoading()
        });
        this.listSubscription.push(variable10);
    }

    loadDataOrdresPriorite(){
        this.loadingLaunched.ordresPriorite = 1
        //Récupération du data des ordres de priorité de la BDD
        const variable11 = this.ordrePrioriteService.getOrdresPrioriteFromServer().subscribe((res) => {
            this.loading.ordresPriorite = 1
            this.ordresPriorite = JSON.parse(JSON.stringify(res)).data;
            this.verifyLoading()
        });
        this.listSubscription.push(variable11);
    }

    loadDataUrls(){
        this.loadingLaunched.urls = 1
        //Récupération du data des urls de la BDD
        const variable12 = this.urlService.getUrlsFromServer().subscribe((res) => {
            this.loading.urls = 1
            this.urls = JSON.parse(JSON.stringify(res)).data;
            this.verifyLoading()
        });
        this.listSubscription.push(variable12);
    }

    loadDataFiches(){
        this.loadingLaunched.fiches = 1
        //Récupération du data des fiches de la BDD
        const variable = this.messagerieTicketsSerivice.getFichesFromServer().subscribe((res) => {
            this.loading.fiches = 1
            this.fiches = JSON.parse(JSON.stringify(res)).data;
            this.verifyLoading()
        });
        this.listSubscription.push(variable);
    }

    loadDataMyFiches(){
        this.loadingLaunched.myFiches = 1
        //Récupération du data des fiches de la BDD
        const variable = this.messagerieTicketsSerivice.getFichesOfConnectedUserFromServer().subscribe((res) => {
            this.loading.myFiches = 1
            this.myFiches = JSON.parse(JSON.stringify(res)).data;
            console.log(this.myFiches, 'my fiches service')
            this.verifyLoading()
        });
        this.listSubscription.push(variable);
    }

    loadDataFichesUser(){
        this.loadingLaunched.fichesUser = 1
        //Récupération du data des fichesUser de la BDD
        const variable5 = this.messagerieTicketsSerivice.getFichesUserFromServer().subscribe((res) => {
            this.loading.fichesUser = 1
            this.fichesUser = JSON.parse(JSON.stringify(res)).data;
            this.verifyLoading()
        });
        //Détruire la souscription
        this.listSubscription.push(variable5);
    }

    loadDataMyFichesUser(){
        this.loadingLaunched.myFichesUser = 1
        //Récupération du data des fichesUser de la BDD
        const variable5 = this.messagerieTicketsSerivice.getFichesUserOfConnectedUserFromServer().subscribe((res) => {
            this.loading.myFichesUser = 1
            this.myFichesUser = JSON.parse(JSON.stringify(res)).data
            this.verifyLoading()
        });
        //Détruire la souscription
        this.listSubscription.push(variable5);
    }

    loadDataMessages(){
        this.loadingLaunched.messages = 1
        //Récupération du data des messages de la BDD
        const variable1 = this.messagerieTicketsSerivice.getMessagesFromServer().subscribe((response) => {
            this.loading.messages = 1
            this.messages = JSON.parse(JSON.stringify(response)).data;
            this.verifyLoading()
        });
        //Détruire la souscription
        this.listSubscription.push(variable1);
    }
    loadDataMyMessages(){
        this.loadingLaunched.myMessages = 1
        //Récupération du data des messages de la BDD
        const variable1 = this.messagerieTicketsSerivice.getMessagesOfFichesOfConnectedUserFromServer().subscribe((response) => {
            this.loading.myMessages = 1
            this.myMessagesOfMyFiches = JSON.parse(JSON.stringify(response)).data
            console.log(this.myMessagesOfMyFiches, 'my msg service')
            this.verifyLoading()
        });
        //Détruire la souscription
        this.listSubscription.push(variable1);
    }
    loadDataLastInterneMessagesOfFicheCloturee(){
        this.loadingLaunched.lastInterneMessagesOfFicheCloturee = 1
        //Récupération du data des messages de la BDD
        const variable1 = this.messagerieTicketsSerivice.getAllLastInterneMessagesOfFicheClotureeFromServer().subscribe((response) => {
            this.loading.lastInterneMessagesOfFicheCloturee = 1
            this.lastInterneMessagesOfFicheCloturee = JSON.parse(JSON.stringify(response)).data
            console.log(JSON.parse(JSON.stringify(response)).data, 'LastInterneMessages')
            this.verifyLoading()
        });
        //Détruire la souscription
        this.listSubscription.push(variable1);
    }
    loadDataMyLastInterneMessagesOfFicheCloturee(){
        this.loadingLaunched.myLastInterneMessagesOfFicheCloturee = 1
        //Récupération du data des messages de la BDD
        const variable1 = this.messagerieTicketsSerivice.getMyAllLastInterneMessagesOfFicheClotureeFromServer().subscribe((response) => {
            this.loading.myLastInterneMessagesOfFicheCloturee = 1
            this.myLastInterneMessagesOfFicheCloturee = JSON.parse(JSON.stringify(response)).data
            console.log(JSON.parse(JSON.stringify(response)).data, 'MyLastInterneMessages')
            this.verifyLoading()
        });
        //Détruire la souscription
        this.listSubscription.push(variable1);
    }

    loadDataFiltres(){
        this.loadingLaunched.filtres = 1
        //Récupération du data des filtres de la BDD
        const variable3 = this.messagerieTicketsSerivice.getFiltresFromServer().subscribe((response) => {
            this.loading.filtres = 1
            this.filtres = JSON.parse(JSON.stringify(response)).data;
            this.verifyLoading()
        });
        //Détruire la souscription
        this.listSubscription.push(variable3);
    }

    loadDataMyFiltres(){
        this.loadingLaunched.myFiltres = 1
        //Récupération du data des filtres de la BDD
        const variable3 = this.messagerieTicketsSerivice.getFiltresOfConnectedUserFromServer().subscribe((response) => {
            this.loading.myFiltres = 1
            this.myFiltres = JSON.parse(JSON.stringify(response)).data;
            this.verifyLoading()
        });
        //Détruire la souscription
        this.listSubscription.push(variable3);
    }


    loadDataFaqs(){
        this.loadingLaunched.faqs = 1
        //Récupération du data des filtres de la BDD
        const variable7 = this.faqService.getQuestionBySousModule().subscribe((response) => {
            this.loading.faqs = 1
            this.faqs = JSON.parse(JSON.stringify(response)).data;
            this.verifyLoading()
        });
        //Détruire la souscription
        this.listSubscription.push(variable7);
    }

    loadDataDashboardComponents(){
        this.loadingLaunched.dashboardComponents = 1
        // Récupération des components du dashboard de la BDD
        this.dashboardService.dataUserId = this.mesFicheUserId
        const variable = this.dashboardService.getUserDashboardComponentsFromServer().subscribe((res) => {
            this.loading.dashboardComponents = 1
            if(this.mesFicheUserId != 0){
                let donneesTab;
                console.log(JSON.parse(JSON.stringify(res)).data, "dashCmp Service")
                for(let cmp of JSON.parse(JSON.stringify(res)).data){
                    donneesTab = cmp.donnees.split(/[/*]/);
                    for(let i=0; i<donneesTab.length; i++){
                        if(donneesTab[i] == "") donneesTab.splice(i, 1);
                    }
                    this.dashboardComponents.push({id: cmp.id, userId: cmp.userId, titreComponent: cmp.titreComponent, titreDashboard: cmp.titreDashboard, donnees: donneesTab});
                }
            }
            this.verifyLoading()
        });
        this.listSubscription.push(variable);
    }

    verifyArrayEmpty(dataTab: any[]){
        if(dataTab.length == 0) return true
        else return false
    }

    verifyLoading(){
        console.log('Je suis ici !')
        if(this.chartOpened.messagerieTicket === 1){
            if(this.loading.users === 1 && this.loading.typesObjet === 1 && this.loading.etats === 1 && this.loading.impacts === 1 && this.loading.modules === 1 && this.loading.ordresPriorite === 1 && this.loading.urls === 1 && this.loading.myFiches === 1 && this.loading.myFichesUser === 1 && this.loading.myMessages === 1 && this.loading.myFiltres === 1 && this.loading.faqs === 1){
                this.MessagerieTicketloadDataSource.next();
            }
        }
        if(this.chartOpened.dashboardCollaborateurs === 1){
            if(this.loading.entreprises === 1 && this.loading.usersCreatedLast7Days === 1){
                this.DashboardCollaborateursloadDataSource.next();
            }
        }
        if(this.chartOpened.collaborateurs === 1){
            if(this.loading.entreprises === 1 && this.loading.users === 1){
                this.CollaborateursloadDataSource.next();
            }
        }
        if(this.chartOpened.linearChartFiltreTicket === 1){
            if(this.loading.dashboardComponents === 1 && this.loading.entreprises === 1 && this.loading.resposDossier === 1 && this.loading.typesObjet === 1 && this.loading.etats === 1 && this.loading.modules === 1 && this.loading.ordresPriorite === 1 && this.loading.urls === 1 && this.loading.fiches === 1 && this.loading.messages === 1){
                this.LinearChartFiltreTicketloadDataSource.next();
            }
        }
        if(this.chartOpened.linearChartFiltreTicketPerso === 1){
            if(this.loading.dashboardComponents === 1 && this.loading.entreprises === 1 && this.loading.resposDossier === 1 && this.loading.typesObjet === 1 && this.loading.etats === 1 && this.loading.modules === 1 && this.loading.ordresPriorite === 1 && this.loading.urls === 1 && this.loading.myFiches === 1 && this.loading.myMessages === 1){
                this.LinearChartFiltreTicketPersoloadDataSource.next();
            }
        }
        if(this.chartOpened.linearChartGlobalTicket === 1){
            if(this.loading.dashboardComponents === 1 && this.loading.entreprises === 1 && this.loading.resposDossier === 1 && this.loading.fiches === 1 && this.loading.messages === 1){
                this.LinearChartGlobalTicketloadDataSource.next();
            }
        }
        if(this.chartOpened.linearChartGlobalTicketPerso === 1){
            if(this.loading.dashboardComponents === 1 && this.loading.entreprises === 1 && this.loading.resposDossier === 1 && this.loading.myFiches === 1 && this.loading.myMessages === 1){
                this.LinearChartGlobalTicketPersoloadDataSource.next();
            }
        }
        if(this.chartOpened.doughnutChartTicket === 1){
            if(this.loading.dashboardComponents === 1 && this.loading.entreprises === 1 && this.loading.resposDossier === 1 && this.loading.typesObjet === 1 && this.loading.etats === 1 && this.loading.modules === 1 && this.loading.ordresPriorite === 1 && this.loading.urls === 1 && this.loading.fiches === 1){
                this.DoughnutChartTicketloadDataSource.next();
            }
        }
        if(this.chartOpened.doughnutChartTicketPerso === 1){
            if(this.loading.dashboardComponents === 1 && this.loading.entreprises === 1 && this.loading.resposDossier === 1 && this.loading.typesObjet === 1 && this.loading.etats === 1 && this.loading.modules === 1 && this.loading.ordresPriorite === 1 && this.loading.urls === 1 && this.loading.myFiches === 1){
                this.DoughnutChartTicketPersoloadDataSource.next();
            }
        }

        if(this.chartOpened.doughnutChartReponse === 1){
            if(this.loading.dashboardComponents === 1 && this.loading.entreprises === 1 && this.loading.resposDossier === 1 && this.loading.typesObjet === 1 && this.loading.etats === 1 && this.loading.modules === 1 && this.loading.ordresPriorite === 1 && this.loading.urls === 1 && this.loading.fiches === 1 && this.loading.messages === 1){
                this.DoughnutChartReponseloadDataSource.next();
            }
        }

        if(this.chartOpened.doughnutChartReponsePerso === 1){
            if(this.loading.dashboardComponents === 1 && this.loading.entreprises === 1 && this.loading.resposDossier === 1 && this.loading.typesObjet === 1 && this.loading.etats === 1 && this.loading.modules === 1 && this.loading.ordresPriorite === 1 && this.loading.urls === 1 && this.loading.myFiches === 1 && this.loading.myMessages === 1){
                this.DoughnutChartReponsePersoloadDataSource.next();
            }
        }

        if(this.chartOpened.doughnutChartResolution === 1){
            if(this.loading.dashboardComponents === 1 && this.loading.entreprises === 1 && this.loading.resposDossier === 1 && this.loading.typesObjet === 1 && this.loading.etats === 1 && this.loading.modules === 1 && this.loading.ordresPriorite === 1 && this.loading.urls === 1 && this.loading.fiches === 1 && this.loading.lastInterneMessagesOfFicheCloturee === 1){
                this.DoughnutChartResolutionloadDataSource.next();
            }
        }

        if(this.chartOpened.doughnutChartResolutionPerso === 1){
            if(this.loading.dashboardComponents === 1 && this.loading.entreprises === 1 && this.loading.resposDossier === 1 && this.loading.typesObjet === 1 && this.loading.etats === 1 && this.loading.modules === 1 && this.loading.ordresPriorite === 1 && this.loading.urls === 1 && this.loading.myFiches === 1 && this.loading.myLastInterneMessagesOfFicheCloturee === 1){
                this.DoughnutChartResolutionPersoloadDataSource.next();
            }
        }

        if(this.chartOpened.grapheNiveau2Ticket === 1){
            if(this.loading.dashboardComponents === 1 && this.loading.entreprises === 1 && this.loading.resposDossier === 1 && this.loading.typesObjet === 1 && this.loading.etats === 1 && this.loading.modules === 1 && this.loading.ordresPriorite === 1 && this.loading.urls === 1 && this.loading.fiches === 1){
                this.GrapheNiveau2TicketloadDataSource.next();
            }
        }

        if(this.chartOpened.grapheNiveau2TicketPerso === 1){
            if(this.loading.dashboardComponents === 1 && this.loading.entreprises === 1 && this.loading.users === 1 && this.loading.typesObjet === 1 && this.loading.etats === 1 && this.loading.modules === 1 && this.loading.ordresPriorite === 1 && this.loading.urls === 1 && this.loading.myFiches === 1){
                this.GrapheNiveau2TicketPersoloadDataSource.next();
            }
        }
    }

    reset(){
        this.users = [];
        this.usersCreatedLast7Days = []  // User créés les 7 derniers jours
        this.resposDossier = []
        this.entreprises = [];
        this.timeline = []
        this.typesObjet = [];
        this.etats = [];
        this.impacts = [];
        this.modules = [];    // [id, module, sous_module]
        this.onlyModules = [];        // Modules
        this.ordresPriorite = [];
        this.urls = [];
        this.fiches = [];
        this.fichesUser = [];
        this.messages = [];
        this.lastInterneMessagesOfFicheCloturee = []
        this.filtres = [];
        this.faqs = []
        this.dashboardComponents = [];
    
        // Data du user connecté (récupéré à partir de toutes les données récupérées)
        this.mesFicheUserId = 0
        this.mesFiches = []
        this.mesFichesUser = []
        this.messagesDeMesFiches = []
        this.mesFiltres = []
    
        // Data du user connecté (récupéré directement depuis la BDD)
        this.myFiches = []
        this.myFichesUser = []
        this.myMessagesOfMyFiches = []
        this.myLastInterneMessagesOfFicheCloturee = []
        this.myFiltres = []
    
        this.loadingLaunched = {
            users: 0,
            usersCreatedLast7Days: 0,
            resposDossier: 0,
            entreprises: 0,
            timeline: 0,
            typesObjet: 0,
            etats: 0,
            impacts: 0,
            modules: 0,
            ordresPriorite: 0,
            urls: 0,
            fiches: 0,
            myFiches: 0,
            fichesUser: 0,
            myFichesUser: 0,
            messages: 0,
            myMessages: 0,
            lastInterneMessagesOfFicheCloturee: 0,
            myLastInterneMessagesOfFicheCloturee: 0,
            filtres: 0,
            myFiltres: 0,
            faqs: 0,
            dashboardComponents: 0
        }
    
        this.loading = {
            users: 0,
            usersCreatedLast7Days: 0,
            resposDossier: 0,
            entreprises: 0,
            timeline: 0,
            typesObjet: 0,
            etats: 0,
            impacts: 0,
            modules: 0,
            ordresPriorite: 0,
            urls: 0,
            fiches: 0,
            myFiches: 0,
            fichesUser: 0,
            myFichesUser: 0,
            messages: 0,
            myMessages: 0,
            lastInterneMessagesOfFicheCloturee: 0,
            myLastInterneMessagesOfFicheCloturee: 0,
            filtres: 0,
            myFiltres: 0,
            faqs: 0,
            dashboardComponents: 0
        }
    
        // Tableau des components ouverts
        this.chartOpened = {
            linearChartFiltreTicket: 0,
            linearChartFiltreTicketPerso: 0,
            linearChartGlobalTicket: 0,
            linearChartGlobalTicketPerso: 0,
            doughnutChartTicket: 0,
            doughnutChartTicketPerso: 0,
            doughnutChartReponse: 0,
            doughnutChartReponsePerso: 0,
            doughnutChartResolution: 0,
            doughnutChartResolutionPerso: 0,
            messagerieTicket: 0,
            dashboardCollaborateurs: 0,
            collaborateurs: 0,
            grapheNiveau2Ticket: 0,
            grapheNiveau2TicketPerso: 0
        }
    }

}