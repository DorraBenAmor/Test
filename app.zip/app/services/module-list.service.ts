import { HttpClient } from '@angular/common/http';
import { ModuleModel } from '../models/module.model';
import { Injectable } from '@angular/core';

@Injectable()
export class ModuleList{

//DECLARATION DES VARIABLES
    
//Variables nécessaires pour créer le module


    //DECLARATION VARIABLES

    moduleSample: ModuleModel[] = [];
    module: string;
    sous_module:string;


    constructor(private httpClient: HttpClient) { }    
    

    getSousModuleByModuleFromServer() {
        return this.httpClient.post('/api/fetchSousModule', {module: this.module});
    }
    
    getModuleFromServer() {
        return this.httpClient.get<any[]>('/api/fetchModule',{
            headers: {
              'Content-Type': 'application/json',
            },
          }); 
    }
   
    getTableModuleFromServer() {
        return this.httpClient.get<any[]>('/api/fetchModuleAndSousModule',{
            headers: {
              'Content-Type': 'application/json',
            },
          }); 
    }
    deleteFromServer()
    {

        return this.httpClient.post('/api/deleteSousModule', {module: this.module, sous_module:this.sous_module});



    }
   
    clear()
    {
        this.moduleSample =[];
    }
}