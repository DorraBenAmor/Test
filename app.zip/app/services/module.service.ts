import { ModuleModel } from '../models/module.model';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
    providedIn: 'root'
})
export class ModuleService {

    constructor(private httpClient: HttpClient) { }

    dataToAdd: ModuleModel[] = [];

    //METHODES
    
    getModulesFromServer() {
        return this.httpClient.get<any[]>('/api/fetchModule',{
            headers: {
              'Content-Type': 'application/json',
            },
        }); 
    }

    getAllModulesFromServer() {
        return this.httpClient.get<any[]>('/api/fetchAllModules',{
            headers: {
              'Content-Type': 'application/json',
            },
        }); 
    }

}