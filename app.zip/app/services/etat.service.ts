import { EtatModel } from '../models/etat.model';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
    providedIn: 'root'
})
export class EtatService {

    constructor(private httpClient: HttpClient) { }

    dataToAdd: EtatModel[] = [];

    //METHODES
    
    getEtatFromServer() {
        return this.httpClient.get<any[]>('/api/fetchEtat',{
            headers: {
              'Content-Type': 'application/json',
            },
        }); 
    }

    getPageViewsFromServer() {
        return this.httpClient.get<any[]>('/api/views',{
            headers: {
              'Content-Type': 'application/json',
            },
        }); 
    }

}