import { TypeObjetModel } from '../models/typeObjet.model';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
    providedIn: 'root'
})
export class TypeObjetService {

    constructor(private httpClient: HttpClient) { }

    dataToAdd: TypeObjetModel[] = [];

    //METHODES
    
    getTypesObjetFromServer() {
        return this.httpClient.get<any[]>('/api/fetchTypesObjet',{
            headers: {
              'Content-Type': 'application/json',
            },
        }); 
    }

}