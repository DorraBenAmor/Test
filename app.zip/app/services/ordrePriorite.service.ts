import { OrdrePrioriteModel } from '../models/ordrePriorite.model';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
    providedIn: 'root'
})
export class OrdrePrioriteService {

    constructor(private httpClient: HttpClient) { }

    dataToAdd: OrdrePrioriteModel[] = [];

    //METHODES
    
    getOrdresPrioriteFromServer() {
        return this.httpClient.get<any[]>('/api/fetchOrdresPriorite',{
            headers: {
              'Content-Type': 'application/json',
            },
        }); 
    }

}