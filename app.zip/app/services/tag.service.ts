import { TagModel } from '../models/tag.model';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class TagService {

    //DECLARATION DES VARIABLES


    constructor(private httpClient: HttpClient) { }

    //METHODES
    
    getTagsFromServer() {
        return this.httpClient.get<any[]>('/api/fetchTags',{
            headers: {
              'Content-Type': 'application/json',
            },
        }); 
    }
}