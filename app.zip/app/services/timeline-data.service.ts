import { TimelineElement } from '../models/timeline-element.model';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class TimelineData {
  
    //DECLARATION VARIABLES

    timelineSampple: TimelineElement[] = [];

    dataToAdd: TimelineElement[] = [];
    dataToUpdate: TimelineElement[] = [];
    update_ID:number;
    base_ID:number;


    constructor(private httpClient: HttpClient) { }

    //METHODES
    
    postEvtToServer() {
        return this.httpClient.post('/api/addEvent', {data: this.dataToAdd});
    }

    postUpdateEventTimelineInServer() {
      return this.httpClient.post('/api/updateEventTimeline', {data: this.dataToUpdate});
  }
    
  getEvtFromServer() {
      return this.httpClient.get<any[]>('/api/fetchEvent',{
          headers: {
            'Content-Type': 'application/json',
          },
        }); 
  }

  postDeleteUpdates() {
    return this.httpClient.post('/api/deleteTimelineByUpdate', {update_ID: this.update_ID});
  }

  postUpdateBase()
    {
      return this.httpClient.post('/api/deleteTimelineByUpdate', {data: this.dataToUpdate});
    }
    
    postDeleteBase()
    {
      return this.httpClient.post('/api/DeleteBaseInTimeline', {base_ID: this.base_ID});
    }
  

}