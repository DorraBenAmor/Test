import { ImpactModel } from '../models/impact.model';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
    providedIn: 'root'
})
export class ImpactService {

    constructor(private httpClient: HttpClient) { }

    dataToAdd: ImpactModel[] = [];

    //METHODES
    
    getImpactFromServer() {
        return this.httpClient.get<any[]>('/api/fetchImpact',{
            headers: {
              'Content-Type': 'application/json',
            },
        }); 
    }

}