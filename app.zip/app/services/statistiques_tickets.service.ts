import { Injectable, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { FicheModel } from '../models/fiche.model';
import { User } from '../models/user.model';
import { Entreprise } from '../models/entreprise.model';
import { MessageModel } from '../models/message.model';
import { MessagerieTicketsService } from '../services/messagerie_tickets.service';
import { UserList } from '../services/user-list.service';
import { EntrepriseList } from '../services/entreprise-list.service';
import { DashboardService } from '../services/dashboard.service';
import { TypeObjetService } from '../services/typeObjet.service';
import { TypeObjetModel } from '../models/typeObjet.model';
import { EtatService } from '../services/etat.service';
import { EtatModel } from '../models/etat.model';
import { ModuleModel } from '../models/module.model';
import { ModuleService } from '../services/module.service';
import { OrdrePrioriteModel } from '../models/ordrePriorite.model';
import { OrdrePrioriteService } from '../services/ordrePriorite.service';
import { URLModel } from '../models/url.model';
import { URLService } from '../services/url.service';
import { HttpClient } from '@angular/common/http';



@Injectable({
    providedIn: 'root'
})
export class StatistiquesTicketsService implements OnInit, OnDestroy {
  
    // DECLARATION VARIABLES
    // Données de la BDD
    fiches: FicheModel[] = [];
    messages: MessageModel[] = [];
    users: User[] = [];
    typesObjet: TypeObjetModel[] = [];
    etats: EtatModel[] = [];
    modules: ModuleModel[] = [];
    ordresPriorite: OrdrePrioriteModel[] = [];
    urls: URLModel[] = [];
    entreprises: Entreprise[] = [];
    dashboardComponents: any[] = [];

    entreprise: string = "";
    base:string = "";
    filtre:string = "";
    categorie:string = "";
    jour:string = "";
    mois:string = "";
    debut: Date;
    fin: Date;

    listSubscription = <Subscription[]>[];

    // CONSTRUCTEUR
    constructor(private httpClient: HttpClient, private urlService: URLService, private ordrePrioriteService: OrdrePrioriteService, private moduleService: ModuleService, private etatService: EtatService, private typeObjetService: TypeObjetService, private dashboardService: DashboardService, private messagerieTicketsService: MessagerieTicketsService, private userService: UserList, private entrepriseService: EntrepriseList) { }

    // METHODES
    ngOnInit(): void { 
    }
    ngOnDestroy(): void {
        this.listSubscription.map((elem) => elem.unsubscribe());
    }

    loadData(){
        //Récupération du data des tickets de la BDD
        const variable1 = this.messagerieTicketsService.getFichesFromServer().subscribe((res) => {
            this.fiches = JSON.parse(JSON.stringify(res)).data;
        });
        this.listSubscription.push(variable1);

        //Récupération du data des messages de la BDD
        const variable2 = this.messagerieTicketsService.getMessagesFromServer().subscribe((res2) => {
            this.messages = JSON.parse(JSON.stringify(res2)).data;
        });
        this.listSubscription.push(variable2);

        //Récupération du data des types d'objet de la BDD
        const variable0 = this.typeObjetService.getTypesObjetFromServer().subscribe((res) => {
            this.typesObjet = JSON.parse(JSON.stringify(res)).data;
        });
        this.listSubscription.push(variable0);
    
        //Récupération du data des états de la BDD
        const variable8 = this.etatService.getEtatFromServer().subscribe((res) => {
            this.etats = JSON.parse(JSON.stringify(res)).data;
        });
        this.listSubscription.push(variable8);
    
        //Récupération du data des modules de la BDD
        const variable5 = this.moduleService.getModulesFromServer().subscribe((res) => {
            this.modules = JSON.parse(JSON.stringify(res)).data;
        });
        this.listSubscription.push(variable5);
    
        //Récupération du data des ordres de priorité de la BDD
        const variable6 = this.ordrePrioriteService.getOrdresPrioriteFromServer().subscribe((res) => {
            this.ordresPriorite = JSON.parse(JSON.stringify(res)).data;
        });
        this.listSubscription.push(variable6);
    
        //Récupération du data des urls de la BDD
        const variable7 = this.urlService.getUrlsFromServer().subscribe((res) => {
            this.urls = JSON.parse(JSON.stringify(res)).data;
        });
        this.listSubscription.push(variable7);
    
        //Récupération du data des users de la BDD
        const variable3 = this.userService.getUserFromServer().subscribe((res3) => {
            this.users = JSON.parse(JSON.stringify(res3)).data;
        });
        this.listSubscription.push(variable3);
    
        //Récupération du data des entreprises de la BDD
        const variable4 = this.entrepriseService.getEntrepriseFromServer().subscribe((res) => {
            this.entreprises = JSON.parse(JSON.stringify(res)).data;
        });
        this.listSubscription.push(variable4);
    
        // Récupération des components du dashboard de la BDD
        const variable = this.dashboardService.getDashboardComponentsFromServer().subscribe((res) => {
            let donneesTab;
            for(let cmp of JSON.parse(JSON.stringify(res)).data){
                donneesTab = cmp.donnees.split(/[/*]/);
                for(let i=0; i<donneesTab.length; i++){
                    if(donneesTab[i] == "") donneesTab.splice(i, 1);
                }
                this.dashboardComponents.push({id: cmp.id, userId: cmp.userId, titreComponent: cmp.titreComponent, titreDashboard: cmp.titreDashboard, donnees: donneesTab});
            }
        });
        this.listSubscription.push(variable);
    }

    verifyArrayEmpty(dataTab: any[]){
        if(dataTab.length == 0) return true
        else return false
    }




    
    // Routes pour récupérer les statistiques pour les graphes en doughnut
    getCategorieStats()
    {
        return this.httpClient.post('/api/fetchCategorieStats',{filtre: this.filtre}); 
 
    }
    getAllFilter() {
        return this.httpClient.get<any[]>('/api/fetchAllFilter',{
            headers: {
              'Content-Type': 'application/json',
            },
          }); 
    }
    getAllFilter2() {
        return this.httpClient.get<any[]>('/api/fetchAllFilter2',{
            headers: {
              'Content-Type': 'application/json',
            },
          }); 
    }
    getAllEntreprises() {
        return this.httpClient.get<any[]>('/api/fetchFicheEntreprises',{
            headers: {
              'Content-Type': 'application/json',
            },
          }); 
    }
    getAllBases()
    {
        return this.httpClient.post('/api/fetchFicheBase',{entreprise: this.entreprise}); 
 
    }



    gettotalStats()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchtotalStats',{filtre: this.filtre, jour:this.jour}); 
 
    }
    getQuantityStats()
    {
        // console.log(this);
        return this.httpClient.post('/api/fetchQuantityStats',{filtre: this.filtre, categorie:this.categorie, jour:this.jour}); 
 
    }
    getAverageStats()
    {
        return this.httpClient.post('/api/fetchAverageStats',{filtre: this.filtre, categorie:this.categorie, jour:this.jour}); 
 
    }
   
    gettotalStatsByMonth()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchtotalStatsByMonth',{filtre: this.filtre, mois:this.mois}); 
 
    }
    getQuantityStatsByMonth()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchQuantityStatsByMonth',{filtre: this.filtre, categorie:this.categorie, mois:this.mois}); 
 
    }
    getAverageStatsByMonth()
    {
        return this.httpClient.post('/api/fetchAverageStatsByMonth',{filtre: this.filtre, categorie:this.categorie, mois:this.mois}); 
 
    }
    gettotalStatsByWeek()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchtotalStatsByWeek',{filtre: this.filtre, jour:this.jour}); 
 
    }
    getQuantityStatsByWeek()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchQuantityStatsByWeek',{filtre: this.filtre, categorie:this.categorie, jour:this.jour}); 
 
    }
    getAverageStatsByWeek()
    {
        return this.httpClient.post('/api/fetchAverageStatsByWeek',{filtre: this.filtre, categorie:this.categorie, jour:this.jour}); 
 
    }

    getAlltotalStats()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchAlltotalStats',{filtre: this.filtre}); 
 
    }
    getAllQuantityStats()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchAllQuantityStats',{filtre: this.filtre, categorie:this.categorie}); 
 
    }
    getAllAverageStats()
    {
        return this.httpClient.post('/api/fetchAllAverageStats',{filtre: this.filtre, categorie:this.categorie}); 
 
    }

    getPeriodetotalStats()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchPeriodetotalStats',{filtre: this.filtre, debut: this.debut, fin: this.fin}); 
 
    }
    getPeriodeQuantityStats()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchPeriodeQuantityStats',{filtre: this.filtre, categorie:this.categorie, debut: this.debut, fin: this.fin}); 
 
    }
    getPeriodeAverageStats()
    {
        return this.httpClient.post('/api/fetchPeriodeAverageStats',{filtre: this.filtre, categorie:this.categorie, debut: this.debut, fin: this.fin}); 
 
    }




    // Par entreprise 
    gettotalStatsbyEntreprise()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchtotalStatsbyEntreprise',{filtre: this.filtre, jour:this.jour, entreprise:this.entreprise}); 
 
    }
    getQuantityStatsbyEntreprise()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchQuantityStatsbyEntreprise',{filtre: this.filtre, categorie:this.categorie, jour:this.jour, entreprise:this.entreprise}); 
 
    }
    getAverageStatsbyEntreprise()
    {
        return this.httpClient.post('/api/fetchAverageStatsbyEntreprise',{filtre: this.filtre, categorie:this.categorie, jour:this.jour, entreprise:this.entreprise}); 
 
    }


    gettotalStatsByMonthbyEntreprise()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchtotalStatsByMonthbyEntreprise',{filtre: this.filtre, mois:this.mois, entreprise:this.entreprise}); 
 
    }
    getQuantityStatsByMonthbyEntreprise()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchQuantityStatsByMonthbyEntreprise',{filtre: this.filtre, categorie:this.categorie, mois:this.mois, entreprise:this.entreprise}); 
 
    }
    getAverageStatsByMonthbyEntreprise()
    {
        return this.httpClient.post('/api/fetchAverageStatsByMonthbyEntreprise',{filtre: this.filtre, categorie:this.categorie, mois:this.mois, entreprise:this.entreprise}); 
 
    }
    gettotalStatsByWeekbyEntreprise()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchtotalStatsByWeekbyEntreprise',{filtre: this.filtre, jour:this.jour, entreprise:this.entreprise}); 
 
    }
    getQuantityStatsByWeekbyEntreprise()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchQuantityStatsByWeekbyEntreprise',{filtre: this.filtre, categorie:this.categorie, jour:this.jour, entreprise:this.entreprise}); 
 
    }
    getAverageStatsByWeekbyEntreprise()
    {
        return this.httpClient.post('/api/fetchAverageStatsByWeekbyEntreprise',{filtre: this.filtre, categorie:this.categorie, jour:this.jour, entreprise:this.entreprise}); 
 
    }

    getAlltotalStatsbyEntreprise()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchAlltotalStatsbyEntreprise',{filtre: this.filtre, entreprise:this.entreprise}); 
 
    }
    getAllQuantityStatsbyEntreprise()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchAllQuantityStatsbyEntreprise',{filtre: this.filtre, categorie:this.categorie, entreprise:this.entreprise}); 
 
    }
    getAllAverageStatsbyEntreprise()
    {
        return this.httpClient.post('/api/fetchAllAverageStatsbyEntreprise',{filtre: this.filtre, categorie:this.categorie, entreprise:this.entreprise}); 
 
    }

    getPeriodetotalStatsbyEntreprise()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchPeriodetotalStatsbyEntreprise',{filtre: this.filtre, debut: this.debut, fin: this.fin, entreprise:this.entreprise}); 
 
    }
    getPeriodeQuantityStatsbyEntreprise()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchPeriodeQuantityStatsbyEntreprise',{filtre: this.filtre, categorie:this.categorie, debut: this.debut, fin: this.fin, entreprise:this.entreprise}); 
 
    }
    getPeriodeAverageStatsbyEntreprise()
    {
        return this.httpClient.post('/api/fetchPeriodeAverageStatsbyEntreprise',{filtre: this.filtre, categorie:this.categorie, debut: this.debut, fin: this.fin, entreprise:this.entreprise}); 
 
    }

    //by entreprise and base 



    gettotalStatsbyEntrepriseAndBase()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchtotalStatsbyEntrepriseAndBase',{filtre: this.filtre, jour:this.jour, entreprise:this.entreprise,base:this.base}); 
 
    }
    getQuantityStatsbyEntrepriseAndBase()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchQuantityStatsbyEntrepriseAndBase',{filtre: this.filtre, categorie:this.categorie, jour:this.jour, entreprise:this.entreprise,base:this.base}); 
 
    }
    getAverageStatsbyEntrepriseAndBase()
    {
        return this.httpClient.post('/api/fetchAverageStatsbyEntrepriseAndBase',{filtre: this.filtre, categorie:this.categorie, jour:this.jour, entreprise:this.entreprise,base:this.base}); 
 
    }

    gettotalStatsByMonthbyEntrepriseAndBase()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchtotalStatsByMonthbyEntrepriseAndBase',{filtre: this.filtre, mois:this.mois, entreprise:this.entreprise,base:this.base}); 
 
    }
    getQuantityStatsByMonthbyEntrepriseAndBase()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchQuantityStatsByMonthbyEntrepriseAndBase',{filtre: this.filtre, categorie:this.categorie, mois:this.mois, entreprise:this.entreprise,base:this.base}); 
 
    }
    getAverageStatsByMonthbyEntrepriseAndBase()
    {
        return this.httpClient.post('/api/fetchAverageStatsByMonthbyEntrepriseAndBase',{filtre: this.filtre, categorie:this.categorie, mois:this.mois, entreprise:this.entreprise,base:this.base}); 
 
    }
    gettotalStatsByWeekbyEntrepriseAndBase()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchtotalStatsByWeekbyEntrepriseAndBase',{filtre: this.filtre, jour:this.jour, entreprise:this.entreprise,base:this.base}); 
 
    }
    getQuantityStatsByWeekbyEntrepriseAndBase()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchQuantityStatsByWeekbyEntrepriseAndBase',{filtre: this.filtre, categorie:this.categorie, jour:this.jour, entreprise:this.entreprise,base:this.base}); 
 
    }
    getAverageStatsByWeekbyEntrepriseAndBase()
    {
        return this.httpClient.post('/api/fetchAverageStatsByWeekbyEntrepriseAndBase',{filtre: this.filtre, categorie:this.categorie, jour:this.jour, entreprise:this.entreprise,base:this.base}); 
 
    }

    getAlltotalStatsbyEntrepriseAndBase()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchAlltotalStatsbyEntrepriseAndBase',{filtre: this.filtre, entreprise:this.entreprise,base:this.base}); 
 
    }
    getAllQuantityStatsbyEntrepriseAndBase()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchAllQuantityStatsbyEntrepriseAndBase',{filtre: this.filtre, categorie:this.categorie, entreprise:this.entreprise,base:this.base}); 
 
    }
    getAllAverageStatsbyEntrepriseAndBase()
    {
        return this.httpClient.post('/api/fetchAllAverageStatsbyEntrepriseAndBase',{filtre: this.filtre, categorie:this.categorie, entreprise:this.entreprise,base:this.base}); 
 
    }

    getPeriodetotalStatsbyEntrepriseAndBase()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchPeriodetotalStatsbyEntrepriseAndBase',{filtre: this.filtre, debut: this.debut, fin: this.fin, entreprise:this.entreprise,base:this.base}); 
 
    }
    getPeriodeQuantityStatsbyEntrepriseAndBase()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchPeriodeQuantityStatsbyEntrepriseAndBase',{filtre: this.filtre, categorie:this.categorie, debut: this.debut, fin: this.fin, entreprise:this.entreprise,base:this.base}); 
 
    }
    getPeriodeAverageStatsbyEntrepriseAndBase()
    {
        return this.httpClient.post('/api/fetchPeriodeAverageStatsbyEntrepriseAndBase',{filtre: this.filtre, categorie:this.categorie, debut: this.debut, fin: this.fin, entreprise:this.entreprise,base:this.base}); 
 
    }


    // Moyenne de resolution 

    getReponsetotalStats()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResponsetotalStats',{filtre: this.filtre, jour:this.jour}); 

    }
    getReponseQuantityStats()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResponseQuantityStats',{filtre: this.filtre, categorie:this.categorie, jour:this.jour}); 

    }
    getReponseAverageStats()
    {
        return this.httpClient.post('/api/fetchResponseAverageStats',{filtre: this.filtre, categorie:this.categorie, jour:this.jour}); 

    }

    getReponsetotalStatsByMonth()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResponsetotalStatsByMonth',{filtre: this.filtre, mois:this.mois}); 

    }
    getReponseQuantityStatsByMonth()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResponseQuantityStatsByMonth',{filtre: this.filtre, categorie:this.categorie, mois:this.mois}); 

    }
    getReponseAverageStatsByMonth()
    {
        return this.httpClient.post('/api/fetchResponseAverageStatsByMonth',{filtre: this.filtre, categorie:this.categorie, mois:this.mois}); 

    }
    getReponsetotalStatsByWeek()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResponsetotalStatsByWeek',{filtre: this.filtre, jour:this.jour}); 

    }
    getReponseQuantityStatsByWeek()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResponseQuantityStatsByWeek',{filtre: this.filtre, categorie:this.categorie, jour:this.jour}); 

    }
    getReponseAverageStatsByWeek()
    {
        return this.httpClient.post('/api/fetchResponseAverageStatsByWeek',{filtre: this.filtre, categorie:this.categorie, jour:this.jour}); 

    }

    getReponseAlltotalStats()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResponseAlltotalStats',{filtre: this.filtre}); 

    }
    getReponseAllQuantityStats()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResponseAllQuantityStats',{filtre: this.filtre, categorie:this.categorie}); 

    }
    getReponseAllAverageStats()
    {
        return this.httpClient.post('/api/fetchResponseAllAverageStats',{filtre: this.filtre, categorie:this.categorie}); 

    }

    getReponsePeriodetotalStats()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResponsePeriodetotalStats',{filtre: this.filtre, debut: this.debut, fin: this.fin}); 

    }
    getReponsePeriodeQuantityStats()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResponsePeriodeQuantityStats',{filtre: this.filtre, categorie:this.categorie, debut: this.debut, fin: this.fin}); 

    }
    getReponsePeriodeAverageStats()
    {
        return this.httpClient.post('/api/fetchResponsePeriodeAverageStats',{filtre: this.filtre, categorie:this.categorie, debut: this.debut, fin: this.fin}); 

    }




    // Par entreprise 
    getReponsetotalStatsbyEntreprise()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResponsetotalStatsbyEntreprise',{filtre: this.filtre, jour:this.jour, entreprise:this.entreprise}); 

    }
    getReponseQuantityStatsbyEntreprise()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResponseQuantityStatsbyEntreprise',{filtre: this.filtre, categorie:this.categorie, jour:this.jour, entreprise:this.entreprise}); 

    }
    getReponseAverageStatsbyEntreprise()
    {
        return this.httpClient.post('/api/fetchResponseAverageStatsbyEntreprise',{filtre: this.filtre, categorie:this.categorie, jour:this.jour, entreprise:this.entreprise}); 

    }


    getReponsetotalStatsByMonthbyEntreprise()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResponsetotalStatsByMonthbyEntreprise',{filtre: this.filtre, mois:this.mois, entreprise:this.entreprise}); 

    }
    getReponseQuantityStatsByMonthbyEntreprise()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResponseQuantityStatsByMonthbyEntreprise',{filtre: this.filtre, categorie:this.categorie, mois:this.mois, entreprise:this.entreprise}); 

    }
    getReponseAverageStatsByMonthbyEntreprise()
    {
        return this.httpClient.post('/api/fetchResponseAverageStatsByMonthbyEntreprise',{filtre: this.filtre, categorie:this.categorie, mois:this.mois, entreprise:this.entreprise}); 

    }
    getReponsetotalStatsByWeekbyEntreprise()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResponsetotalStatsByWeekbyEntreprise',{filtre: this.filtre, jour:this.jour, entreprise:this.entreprise}); 

    }
    getReponseQuantityStatsByWeekbyEntreprise()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResponseQuantityStatsByWeekbyEntreprise',{filtre: this.filtre, categorie:this.categorie, jour:this.jour, entreprise:this.entreprise}); 

    }
    getReponseAverageStatsByWeekbyEntreprise()
    {
        return this.httpClient.post('/api/fetchResponseAverageStatsByWeekbyEntreprise',{filtre: this.filtre, categorie:this.categorie, jour:this.jour, entreprise:this.entreprise}); 

    }

    getReponseAlltotalStatsbyEntreprise()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResponseAlltotalStatsbyEntreprise',{filtre: this.filtre, entreprise:this.entreprise}); 

    }
    getReponseAllQuantityStatsbyEntreprise()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResponseAllQuantityStatsbyEntreprise',{filtre: this.filtre, categorie:this.categorie, entreprise:this.entreprise}); 

    }
    getReponseAllAverageStatsbyEntreprise()
    {
        return this.httpClient.post('/api/fetchResponseAllAverageStatsbyEntreprise',{filtre: this.filtre, categorie:this.categorie, entreprise:this.entreprise}); 

    }

    getReponsePeriodetotalStatsbyEntreprise()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResponsePeriodetotalStatsbyEntreprise',{filtre: this.filtre, debut: this.debut, fin: this.fin, entreprise:this.entreprise}); 

    }
    getReponsePeriodeQuantityStatsbyEntreprise()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResponsePeriodeQuantityStatsbyEntreprise',{filtre: this.filtre, categorie:this.categorie, debut: this.debut, fin: this.fin, entreprise:this.entreprise}); 

    }
    getReponsePeriodeAverageStatsbyEntreprise()
    {
        return this.httpClient.post('/api/fetchResponsePeriodeAverageStatsbyEntreprise',{filtre: this.filtre, categorie:this.categorie, debut: this.debut, fin: this.fin, entreprise:this.entreprise}); 

    }

    //by entreprise and base 



    getReponsetotalStatsbyEntrepriseAndBase()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResponsetotalStatsbyEntrepriseAndBase',{filtre: this.filtre, jour:this.jour, entreprise:this.entreprise,base:this.base}); 

    }
    getReponseQuantityStatsbyEntrepriseAndBase()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResponseQuantityStatsbyEntrepriseAndBase',{filtre: this.filtre, categorie:this.categorie, jour:this.jour, entreprise:this.entreprise,base:this.base}); 

    }
    getReponseAverageStatsbyEntrepriseAndBase()
    {
        return this.httpClient.post('/api/fetchResponseAverageStatsbyEntrepriseAndBase',{filtre: this.filtre, categorie:this.categorie, jour:this.jour, entreprise:this.entreprise,base:this.base}); 

    }

    getReponsetotalStatsByMonthbyEntrepriseAndBase()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResponsetotalStatsByMonthbyEntrepriseAndBase',{filtre: this.filtre, mois:this.mois, entreprise:this.entreprise,base:this.base}); 

    }
    getReponseQuantityStatsByMonthbyEntrepriseAndBase()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResponseQuantityStatsByMonthbyEntrepriseAndBase',{filtre: this.filtre, categorie:this.categorie, mois:this.mois, entreprise:this.entreprise,base:this.base}); 

    }
    getReponseAverageStatsByMonthbyEntrepriseAndBase()
    {
        return this.httpClient.post('/api/fetchResponseAverageStatsByMonthbyEntrepriseAndBase',{filtre: this.filtre, categorie:this.categorie, mois:this.mois, entreprise:this.entreprise,base:this.base}); 

    }
    getReponsetotalStatsByWeekbyEntrepriseAndBase()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResponsetotalStatsByWeekbyEntrepriseAndBase',{filtre: this.filtre, jour:this.jour, entreprise:this.entreprise,base:this.base}); 

    }
    getReponseQuantityStatsByWeekbyEntrepriseAndBase()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResponseQuantityStatsByWeekbyEntrepriseAndBase',{filtre: this.filtre, categorie:this.categorie, jour:this.jour, entreprise:this.entreprise,base:this.base}); 

    }
    getReponseAverageStatsByWeekbyEntrepriseAndBase()
    {
        return this.httpClient.post('/api/fetchResponseAverageStatsByWeekbyEntrepriseAndBase',{filtre: this.filtre, categorie:this.categorie, jour:this.jour, entreprise:this.entreprise,base:this.base}); 

    }

    getReponseAlltotalStatsbyEntrepriseAndBase()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResponseAlltotalStatsbyEntrepriseAndBase',{filtre: this.filtre, entreprise:this.entreprise,base:this.base}); 

    }
    getReponseAllQuantityStatsbyEntrepriseAndBase()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResponseAllQuantityStatsbyEntrepriseAndBase',{filtre: this.filtre, categorie:this.categorie, entreprise:this.entreprise,base:this.base}); 

    }
    getReponseAllAverageStatsbyEntrepriseAndBase()
    {
        return this.httpClient.post('/api/fetchResponseAllAverageStatsbyEntrepriseAndBase',{filtre: this.filtre, categorie:this.categorie, entreprise:this.entreprise,base:this.base}); 

    }

    getReponsePeriodetotalStatsbyEntrepriseAndBase()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResponsePeriodetotalStatsbyEntrepriseAndBase',{filtre: this.filtre, debut: this.debut, fin: this.fin, entreprise:this.entreprise,base:this.base}); 

    }
    getReponsePeriodeQuantityStatsbyEntrepriseAndBase()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResponsePeriodeQuantityStatsbyEntrepriseAndBase',{filtre: this.filtre, categorie:this.categorie, debut: this.debut, fin: this.fin, entreprise:this.entreprise,base:this.base}); 

    }
    getReponsePeriodeAverageStatsbyEntrepriseAndBase()
    {
        return this.httpClient.post('/api/fetchResponsePeriodeAverageStatsbyEntrepriseAndBase',{filtre: this.filtre, categorie:this.categorie, debut: this.debut, fin: this.fin, entreprise:this.entreprise,base:this.base}); 

    }


    getResolutiontotalStats()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResolutiontotalStats',{filtre: this.filtre, jour:this.jour}); 

    }
    getResolutionQuantityStats()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResolutionQuantityStats',{filtre: this.filtre, categorie:this.categorie, jour:this.jour}); 

    }
    getResolutionAverageStats()
    {
        return this.httpClient.post('/api/fetchResolutionAverageStats',{filtre: this.filtre, categorie:this.categorie, jour:this.jour}); 

    }

    getResolutiontotalStatsByMonth()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResolutiontotalStatsByMonth',{filtre: this.filtre, mois:this.mois}); 

    }
    getResolutionQuantityStatsByMonth()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResolutionQuantityStatsByMonth',{filtre: this.filtre, categorie:this.categorie, mois:this.mois}); 

    }
    getResolutionAverageStatsByMonth()
    {
        return this.httpClient.post('/api/fetchResolutionAverageStatsByMonth',{filtre: this.filtre, categorie:this.categorie, mois:this.mois}); 

    }
    getResolutiontotalStatsByWeek()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResolutiontotalStatsByWeek',{filtre: this.filtre, jour:this.jour}); 

    }
    getResolutionQuantityStatsByWeek()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResolutionQuantityStatsByWeek',{filtre: this.filtre, categorie:this.categorie, jour:this.jour}); 

    }
    getResolutionAverageStatsByWeek()
    {
        return this.httpClient.post('/api/fetchResolutionAverageStatsByWeek',{filtre: this.filtre, categorie:this.categorie, jour:this.jour}); 

    }

    getResolutionAlltotalStats()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResolutionAlltotalStats',{filtre: this.filtre}); 

    }
    getResolutionAllQuantityStats()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResolutionAllQuantityStats',{filtre: this.filtre, categorie:this.categorie}); 

    }
    getResolutionAllAverageStats()
    {
        return this.httpClient.post('/api/fetchResolutionAllAverageStats',{filtre: this.filtre, categorie:this.categorie}); 

    }

    getResolutionPeriodetotalStats()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResolutionPeriodetotalStats',{filtre: this.filtre, debut: this.debut, fin: this.fin}); 

    }
    getResolutionPeriodeQuantityStats()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResolutionPeriodeQuantityStats',{filtre: this.filtre, categorie:this.categorie, debut: this.debut, fin: this.fin}); 

    }
    getResolutionPeriodeAverageStats()
    {
        return this.httpClient.post('/api/fetchResolutionPeriodeAverageStats',{filtre: this.filtre, categorie:this.categorie, debut: this.debut, fin: this.fin}); 

    }




    // Par entreprise 
    getResolutiontotalStatsbyEntreprise()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResolutiontotalStatsbyEntreprise',{filtre: this.filtre, jour:this.jour, entreprise:this.entreprise}); 

    }
    getResolutionQuantityStatsbyEntreprise()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResolutionQuantityStatsbyEntreprise',{filtre: this.filtre, categorie:this.categorie, jour:this.jour, entreprise:this.entreprise}); 

    }
    getResolutionAverageStatsbyEntreprise()
    {
        return this.httpClient.post('/api/fetchResolutionAverageStatsbyEntreprise',{filtre: this.filtre, categorie:this.categorie, jour:this.jour, entreprise:this.entreprise}); 

    }


    getResolutiontotalStatsByMonthbyEntreprise()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResolutiontotalStatsByMonthbyEntreprise',{filtre: this.filtre, mois:this.mois, entreprise:this.entreprise}); 

    }
    getResolutionQuantityStatsByMonthbyEntreprise()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResolutionQuantityStatsByMonthbyEntreprise',{filtre: this.filtre, categorie:this.categorie, mois:this.mois, entreprise:this.entreprise}); 

    }
    getResolutionAverageStatsByMonthbyEntreprise()
    {
        return this.httpClient.post('/api/fetchResolutionAverageStatsByMonthbyEntreprise',{filtre: this.filtre, categorie:this.categorie, mois:this.mois, entreprise:this.entreprise}); 

    }
    getResolutiontotalStatsByWeekbyEntreprise()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResolutiontotalStatsByWeekbyEntreprise',{filtre: this.filtre, jour:this.jour, entreprise:this.entreprise}); 

    }
    getResolutionQuantityStatsByWeekbyEntreprise()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResolutionQuantityStatsByWeekbyEntreprise',{filtre: this.filtre, categorie:this.categorie, jour:this.jour, entreprise:this.entreprise}); 

    }
    getResolutionAverageStatsByWeekbyEntreprise()
    {
        return this.httpClient.post('/api/fetchResolutionAverageStatsByWeekbyEntreprise',{filtre: this.filtre, categorie:this.categorie, jour:this.jour, entreprise:this.entreprise}); 

    }

    getResolutionAlltotalStatsbyEntreprise()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResolutionAlltotalStatsbyEntreprise',{filtre: this.filtre, entreprise:this.entreprise}); 

    }
    getResolutionAllQuantityStatsbyEntreprise()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResolutionAllQuantityStatsbyEntreprise',{filtre: this.filtre, categorie:this.categorie, entreprise:this.entreprise}); 

    }
    getResolutionAllAverageStatsbyEntreprise()
    {
        return this.httpClient.post('/api/fetchResolutionAllAverageStatsbyEntreprise',{filtre: this.filtre, categorie:this.categorie, entreprise:this.entreprise}); 

    }

    getResolutionPeriodetotalStatsbyEntreprise()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResolutionPeriodetotalStatsbyEntreprise',{filtre: this.filtre, debut: this.debut, fin: this.fin, entreprise:this.entreprise}); 

    }
    getResolutionPeriodeQuantityStatsbyEntreprise()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResolutionPeriodeQuantityStatsbyEntreprise',{filtre: this.filtre, categorie:this.categorie, debut: this.debut, fin: this.fin, entreprise:this.entreprise}); 

    }
    getResolutionPeriodeAverageStatsbyEntreprise()
    {
        return this.httpClient.post('/api/fetchResolutionPeriodeAverageStatsbyEntreprise',{filtre: this.filtre, categorie:this.categorie, debut: this.debut, fin: this.fin, entreprise:this.entreprise}); 

    }

    //by entreprise and base 



    getResolutiontotalStatsbyEntrepriseAndBase()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResolutiontotalStatsbyEntrepriseAndBase',{filtre: this.filtre, jour:this.jour, entreprise:this.entreprise,base:this.base}); 

    }
    getResolutionQuantityStatsbyEntrepriseAndBase()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResolutionQuantityStatsbyEntrepriseAndBase',{filtre: this.filtre, categorie:this.categorie, jour:this.jour, entreprise:this.entreprise,base:this.base}); 

    }
    getResolutionAverageStatsbyEntrepriseAndBase()
    {
        return this.httpClient.post('/api/fetchResolutionAverageStatsbyEntrepriseAndBase',{filtre: this.filtre, categorie:this.categorie, jour:this.jour, entreprise:this.entreprise,base:this.base}); 

    }

    getResolutiontotalStatsByMonthbyEntrepriseAndBase()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResolutiontotalStatsByMonthbyEntrepriseAndBase',{filtre: this.filtre, mois:this.mois, entreprise:this.entreprise,base:this.base}); 

    }
    getResolutionQuantityStatsByMonthbyEntrepriseAndBase()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResolutionQuantityStatsByMonthbyEntrepriseAndBase',{filtre: this.filtre, categorie:this.categorie, mois:this.mois, entreprise:this.entreprise,base:this.base}); 

    }
    getResolutionAverageStatsByMonthbyEntrepriseAndBase()
    {
        return this.httpClient.post('/api/fetchResolutionAverageStatsByMonthbyEntrepriseAndBase',{filtre: this.filtre, categorie:this.categorie, mois:this.mois, entreprise:this.entreprise,base:this.base}); 

    }
    getResolutiontotalStatsByWeekbyEntrepriseAndBase()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResolutiontotalStatsByWeekbyEntrepriseAndBase',{filtre: this.filtre, jour:this.jour, entreprise:this.entreprise,base:this.base}); 

    }
    getResolutionQuantityStatsByWeekbyEntrepriseAndBase()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResolutionQuantityStatsByWeekbyEntrepriseAndBase',{filtre: this.filtre, categorie:this.categorie, jour:this.jour, entreprise:this.entreprise,base:this.base}); 

    }
    getResolutionAverageStatsByWeekbyEntrepriseAndBase()
    {
        return this.httpClient.post('/api/fetchResolutionAverageStatsByWeekbyEntrepriseAndBase',{filtre: this.filtre, categorie:this.categorie, jour:this.jour, entreprise:this.entreprise,base:this.base}); 

    }

    getResolutionAlltotalStatsbyEntrepriseAndBase()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResolutionAlltotalStatsbyEntrepriseAndBase',{filtre: this.filtre, entreprise:this.entreprise,base:this.base}); 

    }
    getResolutionAllQuantityStatsbyEntrepriseAndBase()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResolutionAllQuantityStatsbyEntrepriseAndBase',{filtre: this.filtre, categorie:this.categorie, entreprise:this.entreprise,base:this.base}); 

    }
    getResolutionAllAverageStatsbyEntrepriseAndBase()
    {
        return this.httpClient.post('/api/fetchResolutionAllAverageStatsbyEntrepriseAndBase',{filtre: this.filtre, categorie:this.categorie, entreprise:this.entreprise,base:this.base}); 

    }

    getResolutionPeriodetotalStatsbyEntrepriseAndBase()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResolutionPeriodetotalStatsbyEntrepriseAndBase',{filtre: this.filtre, debut: this.debut, fin: this.fin, entreprise:this.entreprise,base:this.base}); 

    }
    getResolutionPeriodeQuantityStatsbyEntrepriseAndBase()
    {
        console.log(this);
        return this.httpClient.post('/api/fetchResolutionPeriodeQuantityStatsbyEntrepriseAndBase',{filtre: this.filtre, categorie:this.categorie, debut: this.debut, fin: this.fin, entreprise:this.entreprise,base:this.base}); 

    }
    getResolutionPeriodeAverageStatsbyEntrepriseAndBase()
    {
        return this.httpClient.post('/api/fetchResolutionPeriodeAverageStatsbyEntrepriseAndBase',{filtre: this.filtre, categorie:this.categorie, debut: this.debut, fin: this.fin, entreprise:this.entreprise,base:this.base}); 

    }

    getNbMoisDeMessagerie(){
        return this.httpClient.post('/api/fetchNbMoisDeMessagerie',{}); 
    }

    getNbMoisBetween2Dates(){
        return this.httpClient.post('/api/fetchNbMoisBetween2Dates',{debut: this.debut, fin: this.fin}); 
    }

}