import { Injectable } from '@angular/core';
import { Socket } from 'ngx-socket-io';
import { Connection } from '../models/connection.model';
import { Subject } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ConnexionService {

  // Déclaration des variables

    connexionSubject = new Subject<Connection>();
    connections: Connection[] = []
    allConnectionsSubject = new Subject<Connection[]>();

    //Socket
    currentConnection = this.socket.fromEvent<Connection>('receive_connexion');
    connectionTab = this.socket.fromEvent<Connection[]>('connections');
    
    
    //autres
    connected = false;
    connectedUserEmail = "";
    userID: number = 0;
    userNom: string = "";
    userPrenom: string = "";
    userImage: string = "";
    userTags: string = "";
    userStatut: string = "";
    userFonction: string = "";

    identifiants: string[] = []
    

    constructor(private httpClient: HttpClient, private socket: Socket) { 

        this.socket.on('receive_connexion', (datas:Connection) => {
            this.connections.push(datas);
            this.emitConnection()
            //console.log(datas, 'receive datas from connexion')
        })

        this.socket.on('connect', function () {
            console.log('connect');
        });

        this.socket.on('disconnect', (datas:Connection) => {
            this.connections.slice(this.connections.indexOf(datas), 1);
            console.log('disconnect');
        });

        
    }

    emitConnection() {
        const lastConnection = this.connections[this.connections.length - 1]
        this.connexionSubject.next(lastConnection);
    }
    emitAllConnection() {
        this.allConnectionsSubject.next(this.connections);
    }


    /** METHODES **/
    //Socket
    getConnection(id: string) {
        this.socket.emit('getConnection', id);
    }

    newConnection(userId: number, userNom: string, userPrenom: string, userEmail: string, userStatut: string, userImage: string, userTags: string, userTel: string, userEntreprise: string, userBase: string) {
        console.log(this.newConnection, 'nouvelle connexion')
        this.socket.emit('addConnection', { id: userId.toString(), online: "true", nom: userNom, prenom: userPrenom, email: userEmail, statut: userStatut, image: userImage, tags: userTags, tel:  userTel, entreprise: userEntreprise, base: userBase});
    }

    editConnection(connection: Connection) {
        this.socket.emit('editConnection', connection);
    }

    deleteConnection(connection: Connection) {
        this.socket.emit('deleteConnection', connection);
    }

    //Autres
    signIn(){
        this.connected = true;
    }

    signOut() {
        this.connected = false;
    }

    // Vérification de la connexion
    // Periode Saisie
    getUserConnection() {
        return this.httpClient.post('/api/fetchVerifyConnection', {data: this.identifiants});
    }
    
}