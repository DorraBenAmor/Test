import {Injectable} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ToastrService}  from 'ngx-toastr';
import { environment } from '../../environments/environment';
import { Subject } from 'rxjs';

interface Balance {
  balance: number
}

@Injectable()
export class AuthService {

  loggedIn: Subject<boolean>;
  accountBalance: Subject<Balance | null>;

  constructor(private http: HttpClient,private toastr: ToastrService, private httpClient: HttpClient) {
    this.loggedIn = new Subject();
    this.getLogin();

    this.accountBalance = new Subject();
    this.loggedIn.subscribe(() => {
      this.accountBalance.next(null);
    });
  }

  doLogin(email: string, password: string) {
    return this.httpClient.post('/api/saveLogin', {
      email: email,
      password: password
    }, {
      withCredentials: true
    }).subscribe((resp: any) => {
      this.loggedIn.next(true);
      this.toastr.success(resp && resp.user && resp.user.name ? `Welcome ${resp.user.name}` : 'Logged in!');
    }, (errorResp) => {
      this.loggedIn.next(false);
      errorResp.error ? this.toastr.error(errorResp.error.errorMessage) : this.toastr.error('An unknown error has occured.');
    });
  }

  getLogin() {
    return this.httpClient.get<any[]>('/api/getLogin', {
      withCredentials: true // <=========== important!
    }).subscribe((resp: any) => {
      this.loggedIn.next(resp.loggedIn);
    }, (errorResp) => {
      this.toastr.error('Oops, something went wrong getting the logged in status')
    })
  }

  logout() {
    return this.httpClient.post('/api/logout', {}, {
      withCredentials: true
    }).subscribe(() => {
      this.loggedIn.next(false);
    });
  }

  getPageViewsFromServer() {
    return this.httpClient.get<any[]>('/api/views',{
        headers: {
          'Content-Type': 'application/json',
        },
    }); 
  }

  getAccountBalance() {
    const req = this.httpClient.get('/api/balance', {
      withCredentials: true
    });
    req.subscribe((balance: Balance) => {
      this.accountBalance.next(balance);
    }, errorResp => {
      if (errorResp.status === 403) {
        // TODO: redirect to login
      }
      this.toastr.error(errorResp.error && errorResp.error.errorMessage ?
        errorResp.error.errorMessage :  'Oops, something went wrong.');
    });
  }
}