import { FiltreModel } from '../models/filtre.model';
import { MessageModel } from '../models/message.model';
import { FicheMessageModel } from '../models/fiche_Message.model';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Socket } from 'ngx-socket-io';
import { Message } from '@angular/compiler/src/i18n/i18n_ast';
import { Subject } from 'rxjs';
import { FicheModel } from '../models/fiche.model';
import { FicheUserModel } from '../models/fiche_user.model';

@Injectable({
    providedIn: 'root'
})
export class MessagerieTicketsService {
  
    //DECLARATION VARIABLES
    //Socket
    newMessage = this.socket.fromEvent<MessageModel>('newMessage');
    updatedFicheUser = this.socket.fromEvent<FicheUserModel>('updatedFicheUser');
    newTicket = this.socket.fromEvent<FicheMessageModel>('new_ticket');

    subCategorySubject = new Subject<any[]>();
    private subCategories = [];

    constructor(private socket: Socket, private httpClient: HttpClient) { }

    dataToAdd: FiltreModel[] = [];
    dataFicheToAdd: FicheModel[] = [];
    dataMsgToAdd: MessageModel[] = [];
    dataFicheMsgToAdd: FicheMessageModel[] = [];
    dataFicheUserToAdd: FicheUserModel[] = [];
    dataToDelete: number;
    dataFicheId: number;
    dataUserId: string = "";
    dataToUpdate: any[] = []
    selectedInterneTransfert: string = ""
    commentaireTransfert: string = ""
    
    //METHODES
    getFichesFromServer() {
        return this.httpClient.get<any[]>('/api/fetchFiches',{
            headers: {
              'Content-Type': 'application/json',
            },
        }); 
    }
    getLastFicheFromServer() {
        return this.httpClient.get<any[]>('/api/fetchLastFiche',{
            headers: {
              'Content-Type': 'application/json',
            },
        }); 
    }
    
    getFichesUserFromServer() {
        return this.httpClient.get<any[]>('/api/fetchFichesUser',{
            headers: {
              'Content-Type': 'application/json',
            },
        }); 
    }

    getFichesOfConnectedUserFromServer() {
        return this.httpClient.post('/api/fetchFichesOfUser', {data: this.dataUserId});
    }

    getFichesFantomesOfConnectedUserFromServer() {
        return this.httpClient.post('/api/fetchFichesFantomesOfUser', {data: this.dataUserId});
    }

    getFichesUserOfConnectedUserFromServer() {
        return this.httpClient.post('/api/fetchFichesUserOfUser', {data: Number(this.dataUserId)});
    }
    
    getMessagesOfFichesOfConnectedUserFromServer() {
        return this.httpClient.post('/api/fetchMessagesOfFichesOfUser', {data: this.dataUserId});
    }

    getMessagesOfFichesFantomesOfConnectedUserFromServer() {
        return this.httpClient.post('/api/fetchMessagesOfFichesFantomesOfUser', {data: this.dataUserId});
    }

    getAllLastInterneMessagesOfFicheClotureeFromServer() {
        return this.httpClient.get<any[]>('/api/fetchAllLastInterneMessagesOfFicheCloturee',{
            headers: {
              'Content-Type': 'application/json',
            },
        }); 
    }

    getMyAllLastInterneMessagesOfFicheClotureeFromServer() {
        return this.httpClient.post('/api/fetchMyAllLastInterneMessagesOfFicheClotureeOfUser', {id: this.dataUserId});
    }

    getFiltresOfConnectedUserFromServer() {
        return this.httpClient.post('/api/fetchFiltresOfUser', {data: this.dataUserId});
    }


    getFichesUserOfLastFicheFromServer() {
        return this.httpClient.post('/api/fetchFichesUserOfLastFiche', {data: this.dataFicheId});
    }

    getFiltresFromServer() {
        return this.httpClient.get<any[]>('/api/fetchFiltres',{
            headers: {
              'Content-Type': 'application/json',
            },
        }); 
    }

    getMessagesFromServer() {
        return this.httpClient.get<any[]>('/api/fetchMessages',{
            headers: {
              'Content-Type': 'application/json',
            },
        }); 
    }

    getLastMessageFromServer() {
        return this.httpClient.get<any[]>('/api/fetchLastMessage',{
            headers: {
              'Content-Type': 'application/json',
            },
        }); 
    }

    getNbTicketsFermes() {
        return this.httpClient.get<any[]>('/api/fetchNbTicketsFermes',{
            headers: {
              'Content-Type': 'application/json',
            },
        }); 
    }

    getNbTicketsOuverts() {
        return this.httpClient.get<any[]>('/api/fetchNbTicketsOuverts',{
            headers: {
              'Content-Type': 'application/json',
            },
        }); 
    }

    postAddFicheMessageToServer() {
        return this.httpClient.post('/api/addFicheMessage', {data: this.dataFicheMsgToAdd});
    }

    postAddMessageToServer() {
        return this.httpClient.post('/api/addMessage', {data: this.dataMsgToAdd});
    }

    postAddFiltreToServer() {
        return this.httpClient.post('/api/addFiltre', {data: this.dataToAdd});
    }

    postUpdateFicheToServer() {
        console.log(this.dataFicheToAdd, "In service")
        return this.httpClient.post('/api/updateFiche', {data: this.dataFicheToAdd});
    }

    postUpdateFicheUserToServer() {
        return this.httpClient.post('/api/updateFicheUser', {data: this.dataFicheUserToAdd});
    }

    postAddFicheUserToServer() {
        return this.httpClient.post('/api/addFicheUser', {data: this.dataFicheUserToAdd});
    }


    postDeleteFiltretInServer() {
        return this.httpClient.post('/api/deleteFiltre', {data: this.dataToDelete});
    }

    updateTicketRespo() {
        return this.httpClient.post('/api/updateTicketRespo', {data: this.dataToUpdate});
    }

    updateAccesVisuelUser() {
        return this.httpClient.post('/api/updateAccesVisuelUser', {data: this.dataToUpdate});
    }
    
    //Socket
    addMessage(id: number, ficheId: number, userID: number, userStatut: string, invisibleAuClient: number, date_envoie: Date, message: string, non_lu: number, envoyé: number, listUsers: string[], listAccesUsers: string[] ) {
        console.log("Lancement ajout d'un nouveau message")
        this.socket.emit('addMessage', { id: id, ficheID: ficheId, userID: userID, userStatut, invisibleAuClient, date_envoie: date_envoie, message: message, non_lu: non_lu, envoyé: envoyé, listUsers: listUsers, listAccesUsers: listAccesUsers});
    }

    addNewTicket(numero_ticket: string, libelle: string, respo_dossier_ID: number, usersID: string, accesVisuelPourUsers: string, url: string, module: string, sous_module: string, ordre_priorite: string, type_objet: string, etat: string, impact: string, numTelephoneClient: string, archivé: number, ficheID: number, userID: number, userStatut: string, invisibleAuClient	: number, date_envoie: Date, message: string, non_lu: number, envoyé: number) {
        console.log("Lancement ajout d'un nouveau ticket")
        this.socket.emit('addTicket', { numero_ticket: numero_ticket, libelle: libelle, respo_dossier_ID: respo_dossier_ID, usersID: usersID, accesVisuelPourUsers: accesVisuelPourUsers, url: url, module: module, sous_module: sous_module, ordre_priorite: ordre_priorite, type_objet: type_objet, etat: etat, impact: impact, numTelephoneClient: numTelephoneClient, archivé: archivé, ficheID: ficheID, userID: userID.toString(), userStatut: userStatut, invisibleAuClient: invisibleAuClient, date_envoie: date_envoie, message: message, non_lu: non_lu, envoyé: envoyé});
    }

    updateFicheUser(id: number, ficheId: number, userID: number, non_lu: number, archive: number, accesFicheRefuse: number) {
        console.log("Lancement mise à jour de la fiche_user")
        this.socket.emit('updateFicheUser', { id: id, ficheID: ficheId, userID: userID.toString(), non_lu: non_lu, archive: archive, accesFicheRefuse: accesFicheRefuse});
    }

    emitSubCategorySubject() {
        this.subCategorySubject.next(this.subCategories.slice());
    }

    addSubCategory(value: string) {
        this.subCategories.push(value)
        this.emitSubCategorySubject();
        console.log(this.subCategories, "Sub Categories")
    }

}