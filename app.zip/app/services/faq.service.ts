import { HttpClient } from '@angular/common/http';
import { faq } from '../models/faq.model';
import { Injectable } from '@angular/core';
@Injectable()
export class FAQService{

    faqSample: faq[]=[];
    dataToAdd: faq[] = [];
    module:string;
    sous_module:string;
    question:string;
    reponse:string;
    is_prived:number;
    date:Date;
    responsable:string;
    nb_like:number;
    nb_dislike:number;
    id:number;
    reactions: string;
    id_connected:number;
   

    dataConnexionUpdate: faq[] = [];

    constructor(private httpClient: HttpClient) { }    
    

    
    getfaqFromServer() {
        return this.httpClient.get<any[]>('/api/getFAQ',{
            headers: {
              'Content-Type': 'application/json',
            },
          }); 
    }

    postfaqToServer() {
        console.log("je suis dans le service");
        return this.httpClient.post('/api/addFAQ', {data: this.dataToAdd});
        
    }
    getQuestionBySousModule()
    {

        return this.httpClient.post('/api/fetchQuestion', {sous_module: this.sous_module, module:this.module});


    }
   updateLikes()
    {

        return this.httpClient.post('/api/updatelikes', {id_connected:this.id_connected,id: this.id});


    }
    updateLikes2()
    {

        return this.httpClient.post('/api/updatelikes2', {id_connected:this.id_connected,id: this.id});


    }
    deleteTable()
    {console.log(this.id);


        return this.httpClient.post('/api/deletetablefaq', {id: this.id});
        

    }
    updateDislikes()
    {

        return this.httpClient.post('/api/updatedislikes', {id_connected:this.id_connected,id: this.id });


    }
   
    modifyTable()
    {
        return this.httpClient.post('/api/modifytable', {reponse:this.reponse,id: this.id,is_prived:this.is_prived });


    }

    clear()
    {
        this.faqSample =[];
        this.dataToAdd=[];
        this.dataConnexionUpdate=[];
    }




}