import { HttpClient } from '@angular/common/http';
import { base } from '../models/base.model';
import { Injectable } from '@angular/core';
import * as jsPDF from 'jspdf';

@Injectable()
export class BaseService{

//DECLARATION DES VARIABLES
    
//Variables nécessaires pour créer la base
Id:number;
coordonnees="";
responsable="";
effectifs=0;
utilisationPrev= new Date();
url="";
dateLivraison=new Date();
adresseMail="";
coordinateur="";
chef="";
type=0;
copiebase=0;
siAutres="";
lieeBase=0;
siOui="";
lieeCDF=0;
siOuiCDF="";
nettoyage=0;
sitePro=0;
siOuiSiteP="";
siteCl=0;
siOuiSiteC="";
dateCreation:Date;
statue: number;
nomDemandeur:string;
dateConfirmation:Date;
forModif:boolean=false;
codeConfirmation:string;
myfile:any;
mailCharge:string;
mailResponsable:string;


    //DECLARATION VARIABLES

    baseSample: base[] = [];

    dataToAdd: base[] = [];

    dataConnexionUpdate: base[] = [];

    AppdatStatue: base[] = []; 

 

    constructor(private httpClient: HttpClient) { }


    


    postBaseToServer() {
        console.log("je suis dans le service");
        return this.httpClient.post('/api/addBase', {data: this.dataToAdd});
        
    }
    getBaseFromServer() {
        return this.httpClient.get<any[]>('/api/fetchBase',{
            headers: {
              'Content-Type': 'application/json',
            },
          }); 
    }

    getBaseFromServerByCompany()
    {
        return this.httpClient.post('/api/fetchBaseByCompany',{coordonnees: this.coordonnees}); 

    }
    getGlobalBaseFromServerByCompany()
    {
        return this.httpClient.post('/api/fetchGlobalBaseByCompany',{coordonnees: this.coordonnees}); 

    }
    getCDFBaseFromServerByCompany()
    {
        return this.httpClient.post('/api/fetchCDFBaseByCompany',{coordonnees: this.coordonnees}); 

    }
    getPersonalVersionFromServerByCompany()
    {
        return this.httpClient.post('/api/fetchPersonalByCompany',{coordonnees: this.coordonnees}); 

    }
    getClientVersionFromServerByCompany()
    {
        return this.httpClient.post('/api/fetchClientByCompany',{coordonnees: this.coordonnees}); 

    }
    postUpdateStatueToServer() {
        return this.httpClient.post('/api/updateStatueBase', {data: this.AppdatStatue});
    }


    updateBaseConnexionToServer() {
        return this.httpClient.post('/api/updateBaseConnexion', {data: this.dataConnexionUpdate});
    }
    updateBaseDate()
    {

        return this.httpClient.post('/api/updateDateBase', {dateConfirmation:this.dateConfirmation, Id:this.Id});
    }
    deleteTable(Id)
    {
 
    return this.httpClient.post('/api/deletetable', {Id: Id});
 
    }

    getcharges()
    {
        return this.httpClient.get<any[]>('/api/fetchcharge',{
            headers: {
              'Content-Type': 'application/json',
            },
          }); 
    }
    getmaxid()
    {

        return this.httpClient.get<any[]>('/api/maxId',{
            headers: {
              'Content-Type': 'application/json',
            },
          }); 


    }
    
    postupdateBaseToServer() {
        console.log("je suis dans le service");
        return this.httpClient.post('/api/updateBase', {data: this.dataToAdd});
        
    }
    
    postmail()
    { console.log("je suis dans le service",this.myfile)
         return this.httpClient.post('/api/send', {codeConfirmation:this.codeConfirmation,mailCharge: this.mailCharge,mailResponsable: this.mailResponsable,myfile:this.myfile})}

    confirmBase()
    {
        console.log("je suis dans le service")
        return this.httpClient.post('/api/confirmBase', {codeConfirmation: this.codeConfirmation})


    }

    getEntreprisesFromServer() {
        return this.httpClient.get<any[]>('/api/fetchEntreprise',{
            headers: {
              'Content-Type': 'application/json',
            },
        }); 

    }
    
   
    clear()
    {

        this.dataToAdd = [];

        this.dataConnexionUpdate= [];

        this.baseSample =[];
    }
}