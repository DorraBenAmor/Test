import { NotificationModel } from '../models/notification.model';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Socket } from 'ngx-socket-io';


@Injectable({
    providedIn: 'root'
})
export class NotificationService {

    //DECLARATION DES VARIABLES
    newNotification = this.socket.fromEvent<NotificationModel>('new_notification');

    constructor(private socket: Socket, private httpClient: HttpClient) { }

    dataToAdd: NotificationModel[] = [];
    dataUserId: number = 0

    //METHODES
    
    getNotifsFromServer() {
        return this.httpClient.get<any[]>('/api/fetchNotifs',{
            headers: {
              'Content-Type': 'application/json',
            },
        }); 
    }

    getNumberNotifOfUserFromServer() {
        return this.httpClient.post('/api/fetchNombreNotifs', {data: this.dataUserId});
    }

    postAddNotifToServer() {
        return this.httpClient.post('/api/addNotif', {data: this.dataToAdd});
    }

    //SOCKET
    addNotification(envoyéA: string, id: number, userID: number, date: Date, notification: string) {
        console.log("Lancement ajout d'une nouvelle notification")
        if(envoyéA == "Interne")  this.socket.emit('addNotificationInternes', { id: id, userID: userID, date: date, notification: notification});
        if(envoyéA == "Externe")  this.socket.emit('addNotificationExternes', { id: id, userID: userID, date: date, notification: notification});
    }

}