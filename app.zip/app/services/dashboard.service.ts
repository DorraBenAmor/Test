import { DashboardComponentModel } from '../models/dashboardComponent.model';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Socket } from 'ngx-socket-io';


@Injectable({
    providedIn: 'root'
})
export class DashboardService {

    //DECLARATION DES VARIABLES

    constructor(private socket: Socket, private httpClient: HttpClient) { }


    dataToAdd: DashboardComponentModel[] = [];
    idOfDataToDelete: number;
    dataUserId: number = 0;

    //METHODES
    
    getDashboardComponentsFromServer() {
        return this.httpClient.get<any[]>('/api/fetchDashboardComponents',{
            headers: {
              'Content-Type': 'application/json',
            },
        }); 
    }

    getUserDashboardComponentsFromServer() {
        return this.httpClient.post('/api/fetchUserDashboardComponents', {data: this.dataUserId});
    }


    postAddDashboardComponentToServer() {
        return this.httpClient.post('/api/addDashboardComponent', {data: this.dataToAdd});
    }

    
    postDeleteDashboardComponentFromServer() {
        return this.httpClient.post('/api/deleteDashboardComponent', {data: this.idOfDataToDelete});
    }

}