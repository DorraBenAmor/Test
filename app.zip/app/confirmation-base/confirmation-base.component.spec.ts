import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmationBaseComponent } from './confirmation-base.component';

describe('ConfirmationBaseComponent', () => {
  let component: ConfirmationBaseComponent;
  let fixture: ComponentFixture<ConfirmationBaseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfirmationBaseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmationBaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
