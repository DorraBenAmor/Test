import { Component, OnInit, OnDestroy } from '@angular/core';
import {  FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { ConnexionService } from '../services/connexion.service';
import { UserList } from '../services/user-list.service';
import { Observable, Subscription } from 'rxjs';
import { BaseService } from '../services/base.service';
import { base } from '../models/base.model';
import { TimelineData } from '../services/timeline-data.service';

@Component({
  selector: 'app-confirmation-base',
  templateUrl: './confirmation-base.component.html',
  styleUrls: ['./confirmation-base.component.css']
})
export class ConfirmationBaseComponent implements OnInit {
 //socket
 currentConnection: any;
 private subscription: Subscription;

 //autres
 connected: boolean;
 registerForm: FormGroup;
 submitted = false;
 verified =false;
   
 codeConfirmation: string = "";
 codeexistance:boolean;


 listSubscription = <Subscription[]>[];
 bases: any[] = [];
  users: any[] =[];
  responsable: any;
  coordinateurProjet: any;
  chefProjet: any;
  constructor(private titleService: Title, private timeline: TimelineData, private user: UserList,private connexionService: ConnexionService, private base: BaseService, private formBuilder: FormBuilder, private router: Router) { }
  get f() { return this.registerForm.controls; }
  ngOnInit(): void {
    this.verified=false;
    this.registerForm = this.formBuilder.group({
      codeConfirmation: ['', [Validators.required]],
  });
  
  }


  ngOnDestroy(){
    this.listSubscription.map((elem) => elem.unsubscribe());
    this.subscription.unsubscribe();
  }
  handleCode(value: string)
  {
    this.codeConfirmation=value;
   
      
    
  }
  
  

  verifConcerned(id:number)
  {
    var ConnectedName;
    for(let i=0; i<this.users.length;i++)
      {
        if(this.users[i].id==id)
        {

          ConnectedName=this.users[i].nom+" "+this.users[i].prenom;

        }
      }

      if(ConnectedName==this.responsable || ConnectedName==this.coordinateurProjet || ConnectedName== this.chefProjet)
      {

        return true;

      }
      else return false;



  }
  onSubmit()
  { 
    this.submitted = true;
    const variable2 = this.base.getBaseFromServer().subscribe((response:any) => {
      //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
    
        
      this.bases = response.data.filter(x=> x.codeConfirmation===this.codeConfirmation)
      console.log(this.bases);
     if(this.bases.length===0)
     {
       this.codeexistance=false;
     }
     else
     this.codeexistance=true;





    if(this.registerForm.invalid || this.bases.length===0)

    { 
     console.log("Il y a une erreur de form");
     return;
   
    }else {
      this.responsable=this.bases[0].responsable;
      this.chefProjet=this.bases[0].chefProjet;
      this.coordinateurProjet=this.bases[0].coordinateurProjet;
      const variable2 = this.user.getUserFromServer().subscribe((response:any) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
      
      this.users=response.data.filter(x=> x.entreprise===this.bases[0].coordonneesSociete)
        
         console.log(this.users);
         console.log(response);
       
      
        
      });
     
      this.listSubscription.push(variable2);
      
     this.verified=true;
      this.base.codeConfirmation=this.codeConfirmation;
      this.base.Id=this.bases[0].Id;
      
      console.log(this.base)
      const variable  = this.base.confirmBase().subscribe(
        (response:any) => {
            console.log('Données confirmées !');
           
        },
        (error) => {
            console.log('Erreur ! : ' + error);
        }
    );
    this.listSubscription.push(variable)
    var dateObj =new Date();   
    if(dateObj.getHours()<10)
    {if(dateObj.getMinutes()<10)
      {var date="0"+dateObj.getHours()+":"+"0"+dateObj.getMinutes();}
      else{
       var date="0"+dateObj.getHours()+":"+dateObj.getMinutes();
      }
     
     
     }
   else{
     if(dateObj.getMinutes()<10)
     {var date=dateObj.getHours()+":"+"0"+dateObj.getMinutes();}
     else{
      var date=dateObj.getHours()+":"+dateObj.getMinutes();
     }
   
   }
    for(let i=0;i<this.users.length;i++)
    {
        console.log(this.users[i].id);
        let identity=this.users[i].id;
        console.log(this.users);
        console.log(identity, "identity");
        this.timeline.dataToAdd=[];
        this.timeline.dataToAdd.push({id:0,eventID:0, update_ID: null, base_ID:this.base.Id,date: new Date(), heure: date, motif:"Création de base confirmée de Mr/Mme "+this.base.responsable, userID: identity, isUserConcerned:this.verifConcerned(identity) })
        console.log(identity);
        console.log(this.timeline.dataToAdd);
    
        var variable3  = this.timeline.postEvtToServer().subscribe(
          () => {
              console.log('donnée ajoutés ! !');
          },
          (error) => {
              console.log('Erreur ! : ' + error);
          }
      );
      this.listSubscription.push(variable3);





    }
  }
    
                 
  });
  

  //Détruire la souscription
  this.listSubscription.push(variable2);
  


  }

}
