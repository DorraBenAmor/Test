import { Component, OnInit, OnDestroy, Input, ChangeDetectorRef } from '@angular/core';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';
import { FicheModel } from '../models/fiche.model';
import { User } from '../models/user.model';
import { Entreprise } from '../models/entreprise.model';
import { MessageModel } from '../models/message.model';
import { DashboardService } from '../services/dashboard.service';
import { Connection } from '../models/connection.model';
import { ConnexionService } from '../services/connexion.service';
import { TypeObjetModel } from '../models/typeObjet.model';
import { EtatModel } from '../models/etat.model';
import { ModuleModel } from '../models/module.model';
import { OrdrePrioriteModel } from '../models/ordrePriorite.model';
import { URLModel } from '../models/url.model';
import { DataLoadingService } from '../services/dataLoading.service';
import { StatistiquesTicketsService } from '../services/statistiques_tickets.service';

@Component({
  selector: 'app-doughnutchart-resolution',
  templateUrl: './doughnutchart-resolution.component.html',
  styleUrls: ['./doughnutchart-resolution.component.css']
})
export class DoughnutchartResolutionComponent implements OnInit, OnDestroy {
  @Input() selected: string;
  @Input() selected2: string;
  @Input() periode: string;
  @Input() selectedEntreprise: string;
  @Input() selectedBase: string;

  // DECLARATION DES VARIABLES

  // Données du user connecté
  currentUser: Connection;
  private subscription: Subscription;

  // Loading Data
  private subscriptionLoadData: Subscription

  //Données de la BDD
  fiches: FicheModel[] = [];
  fichesPeriode: FicheModel[] = [];
  messages: MessageModel[] = [];
  typesObjet: TypeObjetModel[] = [];
  etats: EtatModel[] = [];
  modules: ModuleModel[] = [];
  ordresPriorite: OrdrePrioriteModel[] = [];
  urls: URLModel[] = [];
  resposDossier: User[] = [];
  entreprises: Entreprise[] = [];
  dashboardComponents: any[] = [];

  //Paramètres DoughnutChart
  //Chart Resolution
  doughnutChartReadyResolution: boolean = false;
  doughnutChartLabelsResolution = [];
  doughnutChartDataResolution = [];
  doughnutChartLegendResolution: boolean;
  doughnutChartType;
  doughnutChartOptions: any;
  legendeResolution: string = "";
  unite: string

  //Data
  typeObjetCount: any[] = [];
  etatCount: any[] = [];
  moduleCount: any[] = [];
  prioriteCount: any[] = [];
  urlCount: any[] = [];
  respCount: any[] = [];
  entrepriseCount: any[] = [];
  colors:any []= [];
  doughnutChartColors: Array<any>
  CategorieObjetCount: any[] = [];
  //Temps de résolutions (en jour)
  fichesResolues: any[] = [];
  resolutionLegende;
  tempsResolution:number;
  nbTicketsConcernes:number;

  //Chemin de la page
  href: string;

  listSubscription = <Subscription[]>[];

  constructor(private router: Router, private dataLoadingService: DataLoadingService,public stats: StatistiquesTicketsService,  private cdRef: ChangeDetectorRef, private connexionService: ConnexionService, private dashboardService: DashboardService) { }
  getRandomColor() {
    var x = Math.floor(Math.random() * 256);
    var y = Math.floor(Math.random() * 256);
    var z = Math.floor(Math.random() * 256);
    var bgColor = "rgb(" + x + "," + y + "," + z + ")";
    return bgColor;
      }
    
  ngOnInit(): void {
    // Initialisation des variables
    this.href = this.router.url;
    this.unite = '(en jour)'
    // Paramétrage DoughnutChart
    this.doughnutChartType = 'doughnut';
    this.doughnutChartLegendResolution = true;
    this.doughnutChartOptions = {
      legend: {position: 'right'}
    }
    // Mise à jour du tableau des graphes ouverts
    this.dataLoadingService.chartOpened.doughnutChartResolution = 1

    // Récupération des données du user connecté
    this.subscription = this.connexionService.connexionSubject.subscribe(datas => {
      this.currentUser = datas;
    })
    this.connexionService.emitConnection();

    // Chargement des données

    this.subscriptionLoadData = this.dataLoadingService.DoughnutChartResolutionloadDataCalled.subscribe(() => {
      this.dashboardComponents = this.dataLoadingService.dashboardComponents
      this.entreprises = this.dataLoadingService.entreprises
      this.resposDossier = this.dataLoadingService.resposDossier
      this.urls = this.dataLoadingService.urls
      this.ordresPriorite = this.dataLoadingService.ordresPriorite
      this.modules = this.dataLoadingService.modules
      this.etats = this.dataLoadingService.etats
      this.typesObjet = this.dataLoadingService.typesObjet
      this.messages = this.dataLoadingService.lastInterneMessagesOfFicheCloturee

      for(let fiche of this.dataLoadingService.fiches){
        if(fiche.etat == "Demande terminée" || fiche.etat == "Demande cloturée")  this.fiches.push(fiche)
      }
    });
    
    //Chargement des données
    console.log(this.selected + ' ' + this.periode,'ICI')
    this.stats.entreprise = this.selectedEntreprise
    this.stats.base = this.selectedBase
    
    console.log(this.selected + " " + this.periode + " " + this.selectedEntreprise + " " + this.selectedBase + " " + this.selected2 + " ", "Testing")
    if(this.selected!=='Entreprise' && this.selected!=='Base - Entreprise' )    {
    this.handleClick(this.selected, this.periode, [])}
    else
    {
    this.stats.filtre=this.selected2;
    this.handleClickCritère(this.selected2, this.periode, [])
    }// Chargement des données de la BDD
  }

  ngOnDestroy(): void {
    this.listSubscription.map((elem) => elem.unsubscribe());
    this.subscription.unsubscribe();
    this.subscriptionLoadData.unsubscribe()
  }

  chartHovered(event: Event){}
  chartClicked(event: Event){}

  activeLegend() {
    this.doughnutChartLegendResolution = !this.doughnutChartLegendResolution
  }

  chargementDonneesBDD(){
    // Chargement des données
    // Verfication chargement des données des types d'objet
    if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.typesObjet) == true) {
      if(this.dataLoadingService.loadingLaunched.typesObjet === 0) this.dataLoadingService.loadDataTypesObjet()
      console.log('I am loading types objet data')
    }
    else this.typesObjet = this.dataLoadingService.typesObjet
    
    // Verfication chargement des données des etats
    if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.etats) == true) {
      if(this.dataLoadingService.loadingLaunched.etats === 0)this.dataLoadingService.loadDataEtats()
      console.log('I am loading etats data')
    }
    else this.etats = this.dataLoadingService.etats
    

    // Verfication chargement des données des modules
    if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.modules) == true) {
      if(this.dataLoadingService.loadingLaunched.modules === 0)this.dataLoadingService.loadDataModules()
      console.log('I am loading modules data')
    }
    else this.modules = this.dataLoadingService.modules

    // Verfication chargement des données des ordres de priorité
    if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.ordresPriorite) == true) {
      if(this.dataLoadingService.loadingLaunched.ordresPriorite === 0)this.dataLoadingService.loadDataOrdresPriorite()
      console.log('I am loading ordres de priorité data')
    }
    else this.ordresPriorite = this.dataLoadingService.ordresPriorite

    // Verfication chargement des données des urls
    if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.urls) == true) {
      if(this.dataLoadingService.loadingLaunched.urls === 0)this.dataLoadingService.loadDataUrls()
      console.log('I am loading urls data')
    }
    else this.urls = this.dataLoadingService.urls

    // Verfication chargement des données des resposDossier
    if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.resposDossier) == true) {
      if(this.dataLoadingService.loadingLaunched.resposDossier === 0)this.dataLoadingService.loadDataResposDossier()
      console.log('I am loading resposDossier data')
    }
    else this.resposDossier = this.dataLoadingService.resposDossier

    // Verfication chargement des données des users
    if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.entreprises) == true) {
      if(this.dataLoadingService.loadingLaunched.entreprises === 0)this.dataLoadingService.loadDataEntreprises()
      console.log('I am loading entreprises data')
    }
    else this.entreprises = this.dataLoadingService.entreprises



    // On demande à récupérer les données du user connecté
    this.dataLoadingService.mesFicheUserId = Number(this.currentUser.id)

    // Verfication chargement des données des dashboard components
    if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.dashboardComponents) == true) {
      if(this.dataLoadingService.loadingLaunched.dashboardComponents === 0)  this.dataLoadingService.loadDataDashboardComponents()
      console.log('I am loading dasboard componenents data')
    }
    else this.dashboardComponents = this.dataLoadingService.dashboardComponents

    // Verfication chargement des données des fiches
    if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.fiches) == true) {
      if(this.dataLoadingService.loadingLaunched.fiches === 0)  this.dataLoadingService.loadDataFiches()
      console.log('I am loading fiches data')

      // Verfication chargement des données des derniers messages de l'interne
      if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.lastInterneMessagesOfFicheCloturee) == true) {
        if(this.dataLoadingService.loadingLaunched.lastInterneMessagesOfFicheCloturee === 0)  {
          this.dataLoadingService.loadDataLastInterneMessagesOfFicheCloturee()
        }
        console.log('I am loading derniers messages de l\'interne data')
      }
      else {
        // Initialisation Messages
        this.messages = this.dataLoadingService.lastInterneMessagesOfFicheCloturee
      }
    }
    else {
      // Initialisation Fiches
      for(let fiche of this.dataLoadingService.fiches){
        if(fiche.etat == "Demande terminée" || fiche.etat == "Demande cloturée")  this.fiches.push(fiche)
      }

      // Verfication chargement des données des derniers messages de l'interne
      if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.lastInterneMessagesOfFicheCloturee) == true) {
        if(this.dataLoadingService.loadingLaunched.lastInterneMessagesOfFicheCloturee === 0)  {
          this.dataLoadingService.loadDataLastInterneMessagesOfFicheCloturee()
        }
        console.log('I am loading derniers messages de l\'interne data')
      }
      else {
        // Initialisation Messages
        this.messages = this.dataLoadingService.lastInterneMessagesOfFicheCloturee

        //Chargement des données
        this.chargementDonnees(this.selected, this.periode);
      }
    }
  }

  chargementPeriode(selected: string, periode: string, start: Date, end: Date){
    let debut = new Date(start);
    let fin = new Date(end);

    this.fichesPeriode = [];
    this.fichesResolues = [];
    for(let fiche of this.fiches){
      if(new Date(fiche.date_ouverture) >= debut && new Date(fiche.date_ouverture) <= fin){
        this.fichesPeriode.push(fiche);
        for(let message of this.messages){
          if(fiche.id == message.ficheID)  this.fichesResolues.push({ficheID: fiche.id, numero_ticket: fiche.numero_ticket, date_ouverture: new Date(fiche.date_ouverture), usersID: fiche.usersID, etat: fiche.etat, type_objet: fiche.type_objet, module: fiche.module, url: fiche.url, respo_dossier_ID: fiche.respo_dossier_ID, ordre_priorite: fiche.ordre_priorite, entreprise: fiche.numero_ticket.substring(0, fiche.numero_ticket.lastIndexOf("_")), messages: [{userID: message.userID, userStatut: message.userStatut, date_envoie: new Date(message.date_envoie)}]})
        }
      }
    }
    this.handleClick(selected, periode, this.fichesResolues);
  }

  chargementDonnees(selected: string, value: string){
    this.selected = selected;
    this.periode = value;
    let todayDate = new Date();
    switch(value){
      case "Tout":
        // Reinitialisation des données pour le graphe du nombre de tickets
        this.fichesPeriode = this.fiches;
        // Récupération de tous les tickets pour le temps de résolution
        this.fichesResolues = [];
        for(let fiche of this.fichesPeriode){
          for(let message of this.messages){
            if(fiche.id == message.ficheID)  this.fichesResolues.push({ficheID: fiche.id, numero_ticket: fiche.numero_ticket, date_ouverture: new Date(fiche.date_ouverture), usersID: fiche.usersID, etat: fiche.etat, type_objet: fiche.type_objet, module: fiche.module, url: fiche.url, respo_dossier_ID: fiche.respo_dossier_ID, ordre_priorite: fiche.ordre_priorite, entreprise: fiche.numero_ticket.substring(0, fiche.numero_ticket.lastIndexOf("_")), messages: [{userID: message.userID, userStatut: message.userStatut, date_envoie: new Date(message.date_envoie)}]})
          }
        }
        this.handleClick(this.selected, this.periode, this.fichesResolues);
        break;
      case "Année":
        // Reinitialisation des données pour le graphe du nombre de tickets
        this.fichesPeriode = [];
        this.fichesResolues = [];
        for(let fiche of this.fiches){
          if(todayDate.getFullYear() == (new Date(fiche.date_ouverture)).getFullYear()) {
            this.fichesPeriode.push(fiche);
            for(let message of this.messages){
              if(fiche.id == message.ficheID)  this.fichesResolues.push({ficheID: fiche.id, numero_ticket: fiche.numero_ticket, date_ouverture: new Date(fiche.date_ouverture), usersID: fiche.usersID, etat: fiche.etat, type_objet: fiche.type_objet, module: fiche.module, url: fiche.url, respo_dossier_ID: fiche.respo_dossier_ID, ordre_priorite: fiche.ordre_priorite, entreprise: fiche.numero_ticket.substring(0, fiche.numero_ticket.lastIndexOf("_")), messages: [{userID: message.userID, userStatut: message.userStatut, date_envoie: new Date(message.date_envoie)}]})
            }
          }
        }
        this.handleClick(this.selected, this.periode, this.fichesResolues);
        break;
      case "Mois":
        // Reinitialisation des données pour le graphe du nombre de tickets
        this.fichesPeriode = [];
        this.fichesResolues = [];
        for(let fiche of this.fiches){
          if((todayDate.getMonth() + 1) == ((new Date(fiche.date_ouverture)).getMonth() + 1) && todayDate.getFullYear() == (new Date(fiche.date_ouverture)).getFullYear()) {
            this.fichesPeriode.push(fiche);
            for(let message of this.messages){
              if(fiche.id == message.ficheID)  this.fichesResolues.push({ficheID: fiche.id, numero_ticket: fiche.numero_ticket, date_ouverture: new Date(fiche.date_ouverture), usersID: fiche.usersID, etat: fiche.etat, type_objet: fiche.type_objet, module: fiche.module, url: fiche.url, respo_dossier_ID: fiche.respo_dossier_ID, ordre_priorite: fiche.ordre_priorite, entreprise: fiche.numero_ticket.substring(0, fiche.numero_ticket.lastIndexOf("_")), messages: [{userID: message.userID, userStatut: message.userStatut, date_envoie: new Date(message.date_envoie)}]})
            }
          }
        }
        this.handleClick(this.selected, this.periode, this.fichesResolues);
        break;
      case "Semaine":
        // Reinitialisation des données pour le graphe du nombre de tickets
        this.fichesPeriode = [];
        this.fichesResolues = [];
        for(let fiche of this.fiches){
          if(this.getWeek(new Date(todayDate)) == this.getWeek(new Date(fiche.date_ouverture)) && (todayDate.getMonth() + 1) == ((new Date(fiche.date_ouverture)).getMonth() + 1) && todayDate.getFullYear() == (new Date(fiche.date_ouverture)).getFullYear()) {
            this.fichesPeriode.push(fiche);
            for(let message of this.messages){
              if(fiche.id == message.ficheID)  this.fichesResolues.push({ficheID: fiche.id, numero_ticket: fiche.numero_ticket, date_ouverture: new Date(fiche.date_ouverture), usersID: fiche.usersID, etat: fiche.etat, type_objet: fiche.type_objet, module: fiche.module, url: fiche.url, respo_dossier_ID: fiche.respo_dossier_ID, ordre_priorite: fiche.ordre_priorite, entreprise: fiche.numero_ticket.substring(0, fiche.numero_ticket.lastIndexOf("_")), messages: [{userID: message.userID, userStatut: message.userStatut, date_envoie: new Date(message.date_envoie)}]})
            }              
          }
        }
        this.handleClick(this.selected, this.periode, this.fichesResolues);
        break;
      case "Periode":
        // Reinitialisation des données pour le graphe du nombre de tickets
        this.fichesPeriode = [];
        this.fichesResolues = [];
        for(let fiche of this.fiches){
          if(this.getWeek(new Date(todayDate)) == this.getWeek(new Date(fiche.date_ouverture)) && (todayDate.getMonth() + 1) == ((new Date(fiche.date_ouverture)).getMonth() + 1) && todayDate.getFullYear() == (new Date(fiche.date_ouverture)).getFullYear()) {
            this.fichesPeriode.push(fiche);
            for(let message of this.messages){
              if(fiche.id == message.ficheID)  this.fichesResolues.push({ficheID: fiche.id, numero_ticket: fiche.numero_ticket, date_ouverture: new Date(fiche.date_ouverture), usersID: fiche.usersID, etat: fiche.etat, type_objet: fiche.type_objet, module: fiche.module, url: fiche.url, respo_dossier_ID: fiche.respo_dossier_ID, ordre_priorite: fiche.ordre_priorite, entreprise: fiche.numero_ticket.substring(0, fiche.numero_ticket.lastIndexOf("_")), messages: [{userID: message.userID, userStatut: message.userStatut, date_envoie: new Date(message.date_envoie)}]})
            }
          }
        }
        this.handleClick(this.selected, this.periode, this.fichesResolues);
        break;
    }
  }

  initialisationDonnees(selected: string){
    
    switch(selected){
      case "Type d'objet":
        this.typeObjetCount = [];
        for(let item of this.typesObjet){
          this.typeObjetCount.push({type_objet: item.typeObjet, tempsResolution: 0, nbFicheResolution: 0});
        }
        break;
      case "Etat":
        this.etatCount = [];
        for(let item of this.etats){
          this.etatCount.push({etat: item.etat, tempsResolution: 0, nbFicheResolution: 0});
        }
        break;
      case "Module":
        this.moduleCount = [];
        for(let item of this.modules){
          this.moduleCount.push({module: item.module, tempsResolution: 0, nbFicheResolution: 0});
        }
        break;
      case "Ordre de priorité":
        this.prioriteCount = [];
        for(let item of this.ordresPriorite){
          this.prioriteCount.push({ordre_priorite: item.ordrePriorite, tempsResolution: 0, nbFicheResolution: 0});
        }
        break;
      case "URL":
        this.urlCount = [];
        for(let item of this.urls){
          this.urlCount.push({url: item.url, tempsResolution: 0, nbFicheResolution: 0});
        }
        break;
      case "Entreprise":
        this.entrepriseCount = [];
        for(let ese of this.entreprises){
          if(ese.nom != "GTP-Conseil") this.entrepriseCount.push({entreprise: ese.nom, tempsResolution: 0, nbFicheResolution: 0});
        }
        break;
      case "Responsable de dossier":
        this.respCount = [];
        for(let user of this.resposDossier){
          if(user.tags.includes("bug/")) this.respCount.push({respo: user.id, tempsResolution: 0, nbFicheResolution: 0});
        }
        break;
    }
  }


  /** Doughnut Chart Temps de résolution */
  recuperationTempsResolution(selected: string, fichesResolues: any[]){
    this.fichesResolues = fichesResolues;
    let dateDernierMsgBugtracker;
    let msgIndex;

    //Décompte de chaque colonne
    for(let fiche of this.fichesResolues){
      dateDernierMsgBugtracker = "" 
      switch(selected){
        case "Type d'objet":
          for(let item of this.typeObjetCount){
            if(fiche.type_objet == item.type_objet){
              // On parcourt les messages de la conversation
              msgIndex = fiche.messages.length -1; 
              while(dateDernierMsgBugtracker == "" && msgIndex > -1){
                if(fiche.messages[msgIndex].userStatut == "Interne") {
                  dateDernierMsgBugtracker = fiche.messages[msgIndex].date_envoie;
                }
                msgIndex--;
              }
              if(dateDernierMsgBugtracker != ""){
                item.tempsResolution = item.tempsResolution + this.getDaysGap(fiche.date_ouverture, new Date(dateDernierMsgBugtracker));
                item.nbFicheResolution++;
              }
            }
          }
          break;
        case "Etat":
          for(let item of this.etatCount){
            if(fiche.etat == item.etat){
              // On parcourt les messages de la conversation
              msgIndex = fiche.messages.length -1; 
              while(dateDernierMsgBugtracker == "" && msgIndex > -1){
                if(fiche.messages[msgIndex].userStatut == "Interne") {
                  dateDernierMsgBugtracker = fiche.messages[msgIndex].date_envoie;
                }
                msgIndex--;
              }
              if(dateDernierMsgBugtracker != ""){
                item.tempsResolution = item.tempsResolution + this.getDaysGap(fiche.date_ouverture, new Date(dateDernierMsgBugtracker));
                item.nbFicheResolution++;
              }
            }
          }
          break;
        case "Module":
          for(let item of this.moduleCount){
            if(fiche.module == item.module) {
              // On parcourt les messages de la conversation
              msgIndex = fiche.messages.length -1; 
              while(dateDernierMsgBugtracker == "" && msgIndex > -1){
                if(fiche.messages[msgIndex].userStatut == "Interne") {
                  dateDernierMsgBugtracker = fiche.messages[msgIndex].date_envoie;
                }
                msgIndex--;
              }
              if(dateDernierMsgBugtracker != ""){
                item.tempsResolution = item.tempsResolution + this.getDaysGap(fiche.date_ouverture, new Date(dateDernierMsgBugtracker));
                item.nbFicheResolution++;
              }
            }
          }
          break;
        case "Ordre de priorité":
          for(let item of this.prioriteCount){
            if(fiche.ordre_priorite == item.ordre_priorite) {
              // On parcourt les messages de la conversation
              msgIndex = fiche.messages.length -1; 
              while(dateDernierMsgBugtracker == "" && msgIndex > -1){
                if(fiche.messages[msgIndex].userStatut == "Interne") {
                  dateDernierMsgBugtracker = fiche.messages[msgIndex].date_envoie;
                }
                msgIndex--;
              }
              if(dateDernierMsgBugtracker != ""){
                item.tempsResolution = item.tempsResolution + this.getDaysGap(fiche.date_ouverture, new Date(dateDernierMsgBugtracker));
                item.nbFicheResolution++;
              }
            }
          }
          break;
        case "URL":
          for(let item of this.urlCount){
            if(fiche.url == item.url) {
              // On parcourt les messages de la conversation
              msgIndex = fiche.messages.length -1; 
              while(dateDernierMsgBugtracker == "" && msgIndex > -1){
                if(fiche.messages[msgIndex].userStatut == "Interne") {
                  dateDernierMsgBugtracker = fiche.messages[msgIndex].date_envoie;
                }
                msgIndex--;
              }
              if(dateDernierMsgBugtracker != ""){
                item.tempsResolution = item.tempsResolution + this.getDaysGap(fiche.date_ouverture, new Date(dateDernierMsgBugtracker));
                item.nbFicheResolution++;
              }
            }
          }
          break;
        case "Entreprise":
          for(let i=0; i < this.entrepriseCount.length; i++){
            if(fiche.usersID != null){
              if(fiche.numero_ticket.includes(this.entrepriseCount[i].entreprise)) {
                // On parcourt les messages de la conversation
                msgIndex = fiche.messages.length -1; 
      
                while(dateDernierMsgBugtracker == "" && msgIndex > -1){
                  if(fiche.messages[msgIndex].userStatut == "Interne") {
                    dateDernierMsgBugtracker = fiche.messages[msgIndex].date_envoie;
                  }
                  msgIndex--;
                }
                if(dateDernierMsgBugtracker != ""){
                  this.entrepriseCount[i].tempsResolution =  this.entrepriseCount[i].tempsResolution + this.getDaysGap(fiche.date_ouverture, new Date(dateDernierMsgBugtracker));
                  this.entrepriseCount[i].nbFicheResolution++;
                }
              }
            }
          }
          break;
        case "Responsable de dossier":
          for(let item of this.respCount){
            if(fiche.respo_dossier_ID == item.respo) {
              // On parcourt les messages de la conversation
              msgIndex = fiche.messages.length -1; 
              while(dateDernierMsgBugtracker == "" && msgIndex > -1){
                if(fiche.messages[msgIndex].userStatut == "Interne") {
                  dateDernierMsgBugtracker = fiche.messages[msgIndex].date_envoie;
                }
                msgIndex--;
              }
              if(dateDernierMsgBugtracker != ""){
                item.tempsResolution = item.tempsResolution + this.getDaysGap(fiche.date_ouverture, new Date(dateDernierMsgBugtracker));
                item.nbFicheResolution++;
              }
            }
          }
          break;
      }
    }
  }
  /** FIN Doughnut Chart Temps de résolution */

  handleClickCritère(value: string, periode: string, fichesPeriode: FicheModel[])
  {
    this.selected2=value;
    this.periode = periode
    
 
    this.doughnutChartReadyResolution= false;
    //Calcul en pourcentage & Paramétrage DoughnutChart Nombre de Resolution
    this.doughnutChartLabelsResolution= [];
    this.doughnutChartDataResolution= [];
 

    if(this.selected==='Entreprise')
    {

      switch(periode)
      {
        case 'Année':
          this.legendeResolution= "Moyenne de temps de résolution par "+this.selected2.toLowerCase()+" de l\'année de l'entreprise "+this.selectedEntreprise;
       
     
      console.log("critère ")
  
      this.doughnutChartType = 'doughnut';
      this.stats.filtre=this.selected2;
      console.log(this.selected);
      //On récupère les catégories selon le filtre.
      const variable = this.stats.getCategorieStats().subscribe((response:any) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
         this.CategorieObjetCount = response.data; 
     
  
  
      console.log(this.CategorieObjetCount);
      for(let item of this.CategorieObjetCount){
        this.colors.push(this.getRandomColor());
        this.stats.filtre=this.selected2;
        this.stats.categorie=item.category;
        console.log(this.CategorieObjetCount);
        console.log(this.stats.categorie)
        this.stats.entreprise = this.selectedEntreprise
        this.stats.base = this.selectedBase
        const variable3 = this.stats.getResolutionQuantityStatsbyEntreprise().subscribe((response) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
            console.log(response);

          this.tempsResolution= JSON.parse(JSON.stringify(response)).data[0].sum; this.nbTicketsConcernes=JSON.parse(JSON.stringify(response)).data[0].nbTickets
         
            this.doughnutChartLabelsResolution.push(" " + item.category);
            this.doughnutChartDataResolution.push(Number(this.tempsResolution/this.nbTicketsConcernes).toFixed(2));
         
          this.doughnutChartReadyResolution= true;
        });
        //Détruire la souscription
        this.listSubscription.push(variable3);
  
  
  }
  this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
  this.colors=[]
  });
  //Détruire la souscription
  this.listSubscription.push(variable);
  
  
  
     // this.sortFiches(value, fichesPeriode)
      console.log(value);
      console.log(periode);
      console.log(fichesPeriode);
  
      break;
      case 'Mois':
        this.legendeResolution= "Moyenne de temps de résolution par "+this.selected2.toLowerCase()+" du mois de l'entreprise "+this.selectedEntreprise;
       
     
      
  
      this.doughnutChartType = 'doughnut';
      this.stats.filtre=this.selected2;
      console.log(this.selected);
      //On récupère les catégories selon le filtre.
      const variable4 = this.stats.getCategorieStats().subscribe((response:any) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
         this.CategorieObjetCount = response.data; 
  
     
  
  
     
      console.log(this.CategorieObjetCount);
      for(let item of this.CategorieObjetCount){
        this.colors.push(this.getRandomColor());
        this.stats.filtre=this.selected2;
        this.stats.categorie=item.category;
        console.log(this.CategorieObjetCount);
        console.log(this.stats.categorie)
        this.stats.entreprise = this.selectedEntreprise
        this.stats.base = this.selectedBase
        const variable3 = this.stats.getResolutionQuantityStatsByMonthbyEntreprise().subscribe((response) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
            console.log(response);
          this.tempsResolution= JSON.parse(JSON.stringify(response)).data[0].sum; this.nbTicketsConcernes=JSON.parse(JSON.stringify(response)).data[0].nbTickets
          console.log("categorie ",item.category," tempsResolution",this.tempsResolution);
         
            this.doughnutChartLabelsResolution.push(" " + item.category);
            this.doughnutChartDataResolution.push(Number(this.tempsResolution/this.nbTicketsConcernes).toFixed(2) );
         
          this.doughnutChartReadyResolution= true;
        });
        //Détruire la souscription
        this.listSubscription.push(variable3);
  
  
  }
  this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
  this.colors=[]
  });
  //Détruire la souscription
  this.listSubscription.push(variable4);
  
  
  
     // this.sortFiches(value, fichesPeriode)
      console.log(value);
      console.log(periode);
      console.log(fichesPeriode);
  
      break;
      case 'Semaine':
        this.legendeResolution= "Moyenne de temps de résolution par "+this.selected2.toLowerCase()+" de la semaine de l'entreprise "+this.selectedEntreprise;
       
     
      
  
        this.doughnutChartType = 'doughnut';
        this.stats.filtre=this.selected2;
        console.log(this.selected);
        //On récupère les catégories selon le filtre.
        const variable5 = this.stats.getCategorieStats().subscribe((response:any) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
           this.CategorieObjetCount = response.data; 
           
       
        console.log(this.CategorieObjetCount);
        for(let item of this.CategorieObjetCount){
          this.colors.push(this.getRandomColor());
          this.stats.filtre=this.selected2;
          this.stats.categorie=item.category;
          console.log(this.CategorieObjetCount);
          console.log(this.stats.categorie)
          this.stats.entreprise = this.selectedEntreprise
          this.stats.base = this.selectedBase
          const variable3 = this.stats.getResolutionQuantityStatsByWeekbyEntreprise().subscribe((response) => {
            //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
              console.log(response);
            this.tempsResolution= JSON.parse(JSON.stringify(response)).data[0].sum; this.nbTicketsConcernes=JSON.parse(JSON.stringify(response)).data[0].nbTickets
            console.log("categorie ",item.category," tempsResolution",this.tempsResolution);
           
              this.doughnutChartLabelsResolution.push(" " + item.category);
              this.doughnutChartDataResolution.push(Number(this.tempsResolution/this.nbTicketsConcernes).toFixed(2));
           
            this.doughnutChartReadyResolution= true;
          });
          //Détruire la souscription
          this.listSubscription.push(variable3);
    
    
    }
    this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
    this.colors=[]
    });
    //Détruire la souscription
    this.listSubscription.push(variable5);
    
    
    
       // this.sortFiches(value, fichesPeriode)
        console.log(value);
        console.log(periode);
        console.log(fichesPeriode);
    
        break;
        case 'Tout':
          this.legendeResolution= "Moyenne de temps de résolution par "+this.selected2.toLowerCase()+" de l'entreprise "+this.selectedEntreprise;
       
     
      
  
      this.doughnutChartType = 'doughnut';
      this.stats.filtre=this.selected2;
      console.log(this.selected);
      //On récupère les catégories selon le filtre.
      const variable6 = this.stats.getCategorieStats().subscribe((response:any) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
         this.CategorieObjetCount = response.data; 
        
     
  
  
   
      console.log(this.CategorieObjetCount);
      for(let item of this.CategorieObjetCount){
        this.colors.push(this.getRandomColor());
        this.stats.filtre=this.selected2;
        this.stats.categorie=item.category;
        console.log(this.CategorieObjetCount);
        console.log(this.stats.categorie)
        this.stats.entreprise = this.selectedEntreprise
        this.stats.base = this.selectedBase
        const variable3 = this.stats.getResolutionAllQuantityStatsbyEntreprise().subscribe((response) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
            console.log(response);
          this.tempsResolution= JSON.parse(JSON.stringify(response)).data[0].sum; this.nbTicketsConcernes=JSON.parse(JSON.stringify(response)).data[0].nbTickets
          console.log("categorie ",item.category," tempsResolution",this.tempsResolution);
         
            this.doughnutChartLabelsResolution.push(" " + item.category);
            this.doughnutChartDataResolution.push(Number(this.tempsResolution/this.nbTicketsConcernes).toFixed(2));
         
          this.doughnutChartReadyResolution= true;
        });
        //Détruire la souscription
        this.listSubscription.push(variable3);
  
  
  }
  this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
  this.colors=[]
  });
  //Détruire la souscription
  this.listSubscription.push(variable6);
  
  
  
     // this.sortFiches(value, fichesPeriode)
      console.log(value);
      console.log(periode);
      console.log(fichesPeriode);
  
      break;
      case 'Periode':
        this.legendeResolution= "Moyenne de temps de résolution par "+this.selected2.toLowerCase()+" de la période  de l'entreprise "+this.selectedEntreprise;
       
     
      
  
        this.doughnutChartType = 'doughnut';
        this.stats.filtre=this.selected2;
        console.log(this.selected);
        //On récupère les catégories selon le filtre.
        const variable7 = this.stats.getCategorieStats().subscribe((response:any) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
           this.CategorieObjetCount = response.data; 
       
       
    
    
        console.log(this.CategorieObjetCount);
        for(let item of this.CategorieObjetCount){
          this.colors.push(this.getRandomColor());
          this.stats.filtre=this.selected2;
          this.stats.categorie=item.category;
          console.log(this.CategorieObjetCount);
          console.log(this.stats.categorie)
          this.stats.entreprise = this.selectedEntreprise
          this.stats.base = this.selectedBase
          const variable3 = this.stats.getResolutionPeriodeQuantityStatsbyEntreprise().subscribe((response) => {
            //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
              console.log(response);
            this.tempsResolution= JSON.parse(JSON.stringify(response)).data[0].sum; this.nbTicketsConcernes=JSON.parse(JSON.stringify(response)).data[0].nbTickets
            console.log("categorie ",item.category," tempsResolution",this.tempsResolution);
           
              this.doughnutChartLabelsResolution.push(" " + item.category);
              this.doughnutChartDataResolution.push(Number(this.tempsResolution/this.nbTicketsConcernes).toFixed(2));
           
            this.doughnutChartReadyResolution= true;
          });
          //Détruire la souscription
          this.listSubscription.push(variable3);
    
    
    }
    this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
    this.colors=[]
    });
    //Détruire la souscription
    this.listSubscription.push(variable7);
    
    
    
       // this.sortFiches(value, fichesPeriode)
        console.log(this.stats);
        console.log(value);
        console.log(periode);
        console.log(fichesPeriode);
    
        break;
  
  
    }



    }
    else
    {
     
      switch(periode)
      {
        
        case 'Année':
          this.legendeResolution= "Moyenne de temps de résolution par "+this.selected2.toLowerCase()+" de l\'année de la base "+this.selectedBase+" de l'entreprise "+this.selectedEntreprise ;
       
     
      
  
      this.doughnutChartType = 'doughnut';
      this.stats.filtre=this.selected2;
      console.log(this.selected);
      //On récupère les catégories selon le filtre.
      const variable = this.stats.getCategorieStats().subscribe((response:any) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
         this.CategorieObjetCount = response.data; 
    

      console.log(this.CategorieObjetCount);
      for(let item of this.CategorieObjetCount){
        this.colors.push(this.getRandomColor());
        this.stats.filtre=this.selected2;
        this.stats.categorie=item.category;
        console.log(this.CategorieObjetCount);
        console.log(this.stats.categorie)
        this.stats.entreprise = this.selectedEntreprise
        this.stats.base = this.selectedBase
        const variable3 = this.stats.getResolutionQuantityStatsbyEntrepriseAndBase().subscribe((response) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
            console.log(response);
          this.tempsResolution= JSON.parse(JSON.stringify(response)).data[0].sum; this.nbTicketsConcernes=JSON.parse(JSON.stringify(response)).data[0].nbTickets
          console.log("categorie ",item.category," tempsResolution",this.tempsResolution);
         
            this.doughnutChartLabelsResolution.push(" " + item.category);
            this.doughnutChartDataResolution.push(Number(this.tempsResolution/this.nbTicketsConcernes).toFixed(2));
         
          this.doughnutChartReadyResolution= true;
        });
        //Détruire la souscription
        this.listSubscription.push(variable3);
  
  
  }
  this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
  this.colors=[]
  });
  //Détruire la souscription
  this.listSubscription.push(variable);
  
  
  
     // this.sortFiches(value, fichesPeriode)
      console.log(value);
      console.log(periode);
      console.log(fichesPeriode);
  
      break;
      case 'Mois':
        this.legendeResolution= "Moyenne de temps de résolution par "+this.selected2.toLowerCase()+" du mois de la base "+this.selectedBase+" de l'entreprise "+this.selectedEntreprise;
       
     
      
  
      this.doughnutChartType = 'doughnut';
      this.stats.filtre=this.selected2;
      console.log(this.selected);
      //On récupère les catégories selon le filtre.
      const variable4 = this.stats.getCategorieStats().subscribe((response:any) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
         this.CategorieObjetCount = response.data; 
       
     
  
  
    
      console.log(this.CategorieObjetCount);
      for(let item of this.CategorieObjetCount){
        this.colors.push(this.getRandomColor());
        this.stats.filtre=this.selected2;
        this.stats.categorie=item.category;
        console.log(this.CategorieObjetCount);
        console.log(this.stats.categorie)
        this.stats.entreprise = this.selectedEntreprise
        this.stats.base = this.selectedBase
        const variable3 = this.stats.getResolutionQuantityStatsByMonthbyEntrepriseAndBase().subscribe((response) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
            console.log(response);
          this.tempsResolution= JSON.parse(JSON.stringify(response)).data[0].sum; this.nbTicketsConcernes=JSON.parse(JSON.stringify(response)).data[0].nbTickets
          console.log("categorie ",item.category," tempsResolution",this.tempsResolution);
         
            this.doughnutChartLabelsResolution.push(" " + item.category);
            this.doughnutChartDataResolution.push(Number(this.tempsResolution/this.nbTicketsConcernes).toFixed(2));
         
          this.doughnutChartReadyResolution= true;
        });
        //Détruire la souscription
        this.listSubscription.push(variable3);
  
  
  }
  this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
  this.colors=[]
  });
  //Détruire la souscription
  this.listSubscription.push(variable4);
  
  
  
     // this.sortFiches(value, fichesPeriode)
      console.log(value);
      console.log(periode);
      console.log(fichesPeriode);
  
      break;
      case 'Semaine':
        this.legendeResolution= "Moyenne de temps de résolution par "+this.selected2.toLowerCase()+" de la semaine de la base "+this.selectedBase+" de l'entreprise "+this.selectedEntreprise;
       
     
      
  
        this.doughnutChartType = 'doughnut';
        this.stats.filtre=this.selected2;
        console.log(this.selected);
        //On récupère les catégories selon le filtre.
        const variable5 = this.stats.getCategorieStats().subscribe((response:any) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
           this.CategorieObjetCount = response.data; 
       
    
    
      
        console.log(this.CategorieObjetCount);
        for(let item of this.CategorieObjetCount){
          this.colors.push(this.getRandomColor());
          this.stats.filtre=this.selected2;
          this.stats.categorie=item.category;
          console.log(this.CategorieObjetCount);
          console.log(this.stats.categorie)
          this.stats.entreprise = this.selectedEntreprise
          this.stats.base = this.selectedBase
          const variable3 = this.stats.getResolutionQuantityStatsByWeekbyEntrepriseAndBase().subscribe((response) => {
            //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
              console.log(response);
            this.tempsResolution= JSON.parse(JSON.stringify(response)).data[0].sum; this.nbTicketsConcernes=JSON.parse(JSON.stringify(response)).data[0].nbTickets
            console.log("categorie ",item.category," tempsResolution",this.tempsResolution);
           
              this.doughnutChartLabelsResolution.push(" " + item.category);
              this.doughnutChartDataResolution.push(Number(this.tempsResolution/this.nbTicketsConcernes).toFixed(2));
           
            this.doughnutChartReadyResolution= true;
          });
          //Détruire la souscription
          this.listSubscription.push(variable3);
    
    
    }
    this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
    this.colors=[]
    });
    //Détruire la souscription
    this.listSubscription.push(variable5);
    
    
    
       // this.sortFiches(value, fichesPeriode)
        console.log(value);
        console.log(periode);
        console.log(fichesPeriode);
    
        break;
        case 'Tout':
          this.legendeResolution= "Moyenne de temps de résolution par "+this.selected2.toLowerCase()+ " de la base "+this.selectedBase+" de l'entreprise "+this.selectedEntreprise;
       
     
      
  
      this.doughnutChartType = 'doughnut';
      this.stats.filtre=this.selected2;
      console.log(this.selected);
      //On récupère les catégories selon le filtre.
      const variable6 = this.stats.getCategorieStats().subscribe((response:any) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
         this.CategorieObjetCount = response.data; 
     
  
  
     
      console.log(this.CategorieObjetCount);
      for(let item of this.CategorieObjetCount){
        this.colors.push(this.getRandomColor());
        this.stats.filtre=this.selected2;
        this.stats.categorie=item.category;
        console.log(this.CategorieObjetCount);
        console.log(this.stats.categorie)
        this.stats.entreprise = this.selectedEntreprise
        this.stats.base = this.selectedBase
        const variable3 = this.stats.getResolutionAllQuantityStatsbyEntrepriseAndBase().subscribe((response) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
            console.log(response);
          this.tempsResolution= JSON.parse(JSON.stringify(response)).data[0].sum; this.nbTicketsConcernes=JSON.parse(JSON.stringify(response)).data[0].nbTickets
         
            this.doughnutChartLabelsResolution.push(" " + item.category);
            this.doughnutChartDataResolution.push(Number(this.tempsResolution/this.nbTicketsConcernes).toFixed(2));
         
          this.doughnutChartReadyResolution= true;
        });
        //Détruire la souscription
        this.listSubscription.push(variable3);
  
  
  }
  this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
  this.colors=[]
  });
  //Détruire la souscription
  this.listSubscription.push(variable6);
  
  
  
     // this.sortFiches(value, fichesPeriode)
      console.log(value);
      console.log(periode);
      console.log(fichesPeriode);
  
      break;
      case 'Periode':
        this.legendeResolution= "Moyenne de temps de résolution par "+this.selected2.toLowerCase()+" de la période  de la base "+this.selectedBase+" de l'entreprise "+this.selectedEntreprise;
       
     
      
  
        this.doughnutChartType = 'doughnut';
        this.stats.filtre=this.selected2;
        console.log(this.selected);
        //On récupère les catégories selon le filtre.
        const variable7 = this.stats.getCategorieStats().subscribe((response:any) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
           this.CategorieObjetCount = response.data; 
       
    
        console.log(this.CategorieObjetCount);
        for(let item of this.CategorieObjetCount){
          this.colors.push(this.getRandomColor());
          this.stats.filtre=this.selected2;
          this.stats.categorie=item.category;
          console.log(this.CategorieObjetCount);
          console.log(this.stats.categorie)
          this.stats.entreprise = this.selectedEntreprise
          this.stats.base = this.selectedBase
          const variable3 = this.stats.getResolutionPeriodeQuantityStatsbyEntrepriseAndBase().subscribe((response) => {
            //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
              console.log(response);
            this.tempsResolution= JSON.parse(JSON.stringify(response)).data[0].sum; this.nbTicketsConcernes=JSON.parse(JSON.stringify(response)).data[0].nbTickets
            console.log("categorie ",item.category," tempsResolution",this.tempsResolution);
           
              this.doughnutChartLabelsResolution.push(" " + item.category);
              this.doughnutChartDataResolution.push(Number(this.tempsResolution/this.nbTicketsConcernes).toFixed(2));
           
            this.doughnutChartReadyResolution= true;
          });
          //Détruire la souscription
          this.listSubscription.push(variable3);
    
    
    }
    this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
    this.colors=[]
    });
    //Détruire la souscription
    this.listSubscription.push(variable7);
    
    
    
       // this.sortFiches(value, fichesPeriode)
        console.log(this.stats);
        console.log(value);
        console.log(periode);
        console.log(fichesPeriode);
    
        break;
  



    }
 

  }
  this.cdRef.detectChanges();


  }


  handleClick(value: string, periode: string, fichesPeriode: any[]){
    this.selected=value;
    this.periode = periode
    console.log(this.selected)
    console.log('ICI')
 
    this.doughnutChartReadyResolution= false;
    //Calcul en pourcentage & Paramétrage DoughnutChart Nombre de Resolution
    this.doughnutChartLabelsResolution= [];
    this.doughnutChartDataResolution= [];
    if(this.selected!=='Entreprise' && this.selected!=='Base - Entreprise' )
    {
    switch(periode)
    {
      case 'Année':
        this.legendeResolution= "Moyenne de temps de résolution par "+this.selected.toLowerCase()+" de l\'année";
     
   
    

    this.doughnutChartType = 'doughnut';
    this.stats.filtre=this.selected;
    console.log(this.selected);
    //On récupère les catégories selon le filtre.
    const variable = this.stats.getCategorieStats().subscribe((response:any) => {
      //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
       this.CategorieObjetCount = response.data; 
       this.selected=value;
   


    console.log(this.CategorieObjetCount);
    for(let item of this.CategorieObjetCount){
      this.colors.push(this.getRandomColor());
      this.stats.filtre=this.selected;
      this.stats.categorie=item.category;
      console.log(this.CategorieObjetCount);
      console.log(this.stats.categorie)
      
      const variable3 = this.stats.getResolutionQuantityStats().subscribe((response) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
          console.log(response);
        this.tempsResolution= JSON.parse(JSON.stringify(response)).data[0].sum; this.nbTicketsConcernes=JSON.parse(JSON.stringify(response)).data[0].nbTickets
       console.log("Tmps resolution ",this.tempsResolution)
       console.log("nb Tickets",this.nbTicketsConcernes)
       console.log(response);
        console.log("categorie ",item.category," tempsResolution",this.tempsResolution);
       
          this.doughnutChartLabelsResolution.push(" " + item.category);
          this.doughnutChartDataResolution.push(Number(this.tempsResolution/this.nbTicketsConcernes).toFixed(2));
       
        this.doughnutChartReadyResolution= true;
      });
      //Détruire la souscription
      this.listSubscription.push(variable3);


}
this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
this.colors=[]
});
//Détruire la souscription
this.listSubscription.push(variable);



   // this.sortFiches(value, fichesPeriode)
    console.log(value);
    console.log(periode);
    console.log(fichesPeriode);

    break;
    case 'Mois':
      this.legendeResolution= "Moyenne de temps de résolution par "+this.selected.toLowerCase()+" du mois";
     
   
    

    this.doughnutChartType = 'doughnut';
    this.stats.filtre=this.selected;
    console.log(this.selected);
    //On récupère les catégories selon le filtre.
    const variable4 = this.stats.getCategorieStats().subscribe((response:any) => {
      //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
       this.CategorieObjetCount = response.data; 
       this.selected=value;
   


  
    console.log(this.CategorieObjetCount);
    for(let item of this.CategorieObjetCount){
      this.colors.push(this.getRandomColor());
      this.stats.filtre=this.selected;
      this.stats.categorie=item.category;
      console.log(this.CategorieObjetCount);
      console.log(this.stats.categorie)
      const variable3 = this.stats.getResolutionQuantityStatsByMonth().subscribe((response) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
          console.log(response);
        this.tempsResolution= JSON.parse(JSON.stringify(response)).data[0].sum; this.nbTicketsConcernes=JSON.parse(JSON.stringify(response)).data[0].nbTickets
        console.log("categorie ",item.category," tempsResolution",this.tempsResolution);
       
          this.doughnutChartLabelsResolution.push(" " + item.category);
          this.doughnutChartDataResolution.push(Number(this.tempsResolution/this.nbTicketsConcernes).toFixed(2));
       
        this.doughnutChartReadyResolution= true;
      });
      //Détruire la souscription
      this.listSubscription.push(variable3);


}
this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
this.colors=[]
});
//Détruire la souscription
this.listSubscription.push(variable4);



   // this.sortFiches(value, fichesPeriode)
    console.log(value);
    console.log(periode);
    console.log(fichesPeriode);

    break;
    case 'Semaine':
      this.legendeResolution= "Moyenne de temps de résolution par "+this.selected.toLowerCase()+" de la semaine";
     
   
    

      this.doughnutChartType = 'doughnut';
      this.stats.filtre=this.selected;
      console.log(this.selected);
      //On récupère les catégories selon le filtre.
      const variable5 = this.stats.getCategorieStats().subscribe((response:any) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
         this.CategorieObjetCount = response.data; 
         this.selected=value;
     
  
  
    
      console.log(this.CategorieObjetCount);
      for(let item of this.CategorieObjetCount){
        this.colors.push(this.getRandomColor());
        this.stats.filtre=this.selected;
        this.stats.categorie=item.category;
        console.log(this.CategorieObjetCount);
        console.log(this.stats.categorie)
        const variable3 = this.stats.getResolutionQuantityStatsByWeek().subscribe((response) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
            console.log(response);
          this.tempsResolution= JSON.parse(JSON.stringify(response)).data[0].sum; this.nbTicketsConcernes=JSON.parse(JSON.stringify(response)).data[0].nbTickets
          console.log("categorie ",item.category," tempsResolution",this.tempsResolution);
         
            this.doughnutChartLabelsResolution.push(" " + item.category);
            this.doughnutChartDataResolution.push(Number(this.tempsResolution/this.nbTicketsConcernes).toFixed(2));
         
          this.doughnutChartReadyResolution= true;
        });
        //Détruire la souscription
        this.listSubscription.push(variable3);
  
  
  }
  this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
  this.colors=[]
  });
  //Détruire la souscription
  this.listSubscription.push(variable5);
  
  
  
     // this.sortFiches(value, fichesPeriode)
      console.log(value);
      console.log(periode);
      console.log(fichesPeriode);
  
      break;
      case 'Tout':
        this.legendeResolution= "Moyenne de temps de résolution par "+this.selected.toLowerCase();
     
   
    

    this.doughnutChartType = 'doughnut';
    this.stats.filtre=this.selected;
    console.log(this.selected);
    //On récupère les catégories selon le filtre.
    const variable6 = this.stats.getCategorieStats().subscribe((response:any) => {
      //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
       this.CategorieObjetCount = response.data; 
       this.selected=value;
   

    console.log(this.CategorieObjetCount);
    for(let item of this.CategorieObjetCount){
      this.colors.push(this.getRandomColor());
      this.stats.filtre=this.selected;
      this.stats.categorie=item.category;
      console.log(this.CategorieObjetCount);
      console.log(this.stats.categorie)
      const variable3 = this.stats.getResolutionAllQuantityStats().subscribe((response) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
          console.log(response);
        this.tempsResolution= JSON.parse(JSON.stringify(response)).data[0].sum; this.nbTicketsConcernes=JSON.parse(JSON.stringify(response)).data[0].nbTickets
        console.log("categorie ",item.category," tempsResolution",this.tempsResolution);
       
          this.doughnutChartLabelsResolution.push(" " + item.category);
          this.doughnutChartDataResolution.push(Number(this.tempsResolution/this.nbTicketsConcernes).toFixed(2));
       
        this.doughnutChartReadyResolution= true;
      });
      //Détruire la souscription
      this.listSubscription.push(variable3);


}
this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
this.colors=[]
});
//Détruire la souscription
this.listSubscription.push(variable6);



   // this.sortFiches(value, fichesPeriode)
    console.log(value);
    console.log(periode);
    console.log(fichesPeriode);

    break;
    case 'Periode':
      this.legendeResolution= "Moyenne de temps de résolution par "+this.selected.toLowerCase()+" de la période ";
     
   
    

      this.doughnutChartType = 'doughnut';
      this.stats.filtre=this.selected;
      console.log(this.selected);
      //On récupère les catégories selon le filtre.
      const variable7 = this.stats.getCategorieStats().subscribe((response:any) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template  
         this.CategorieObjetCount = response.data; 
         this.selected=value;
     
  
  
      console.log(this.CategorieObjetCount);
      for(let item of this.CategorieObjetCount){
        this.colors.push(this.getRandomColor());
        this.stats.filtre=this.selected;
        this.stats.categorie=item.category;
        console.log(this.CategorieObjetCount);
        console.log(this.stats.categorie)
        const variable3 = this.stats.getResolutionPeriodeQuantityStats().subscribe((response) => {
          //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
            console.log(response);
          this.tempsResolution= JSON.parse(JSON.stringify(response)).data[0].sum; this.nbTicketsConcernes=JSON.parse(JSON.stringify(response)).data[0].nbTickets
          console.log("categorie ",item.category," tempsResolution",this.tempsResolution);
         
            this.doughnutChartLabelsResolution.push(" " + item.category);
            this.doughnutChartDataResolution.push(Number(this.tempsResolution/this.nbTicketsConcernes).toFixed(2));
         
          this.doughnutChartReadyResolution= true;
        });
        //Détruire la souscription
        this.listSubscription.push(variable3);
  
  
  }
  this.doughnutChartColors  = [ { backgroundColor: this.colors, borderColor: 'transparent' } ];
  this.colors=[]
  });
  //Détruire la souscription
  this.listSubscription.push(variable7);
  
  
  
     // this.sortFiches(value, fichesPeriode)
      console.log(this.stats);
      console.log(value);
      console.log(periode);
      console.log(fichesPeriode);
  
      break;


  }
}
else
{ this.doughnutChartReadyResolution= false;
  //Calcul en pourcentage & Paramétrage DoughnutChart Nombre de Resolution
  this.doughnutChartLabelsResolution= [];
  this.doughnutChartDataResolution= [];}


    this.cdRef.detectChanges();
  }
  /** FIN Doughnut Chart Nombre de tickets */

  // Affichage du graphe sur le dashboard
  checkCmpInDashboard(){
    let alreadyInDashboard = false;
    for(let cmp of this.dashboardComponents){
      // Vérification si le component est associé au user connecté et s'il s'agit du bon graphe
      if(cmp.userId == Number(this.currentUser.id) && cmp.titreComponent == "DoughnutChartResolution"){
        if(cmp.donnees[0] == this.selected && cmp.donnees[1] == this.periode)  alreadyInDashboard = true;
      }
    }
    return alreadyInDashboard
  }
  addToDashboard(){
    if(this.periode != 'Periode'){
      this.dashboardService.dataToAdd = []
      if(this.selected !== 'Entreprise' && this.selected !== 'Base - Entreprise')  this.dashboardService.dataToAdd.push({id: 0, userId: Number(this.currentUser.id), titreComponent: "DoughnutChartResolution", titreDashboard: "Statistiques", donnees: "/" + this.selected + "*" + "/" + this.periode + "*"});
      if(this.selected === 'Entreprise')  this.dashboardService.dataToAdd.push({id: 0, userId: Number(this.currentUser.id), titreComponent: "DoughnutChartResolution", titreDashboard: "Statistiques", donnees: "/" + this.selected + "*" + "/" + this.periode + "*" + "/" + this.stats.entreprise + "*"+ "/" + this.selected2 + "*"});
      if(this.selected === 'Base - Entreprise')  this.dashboardService.dataToAdd.push({id: 0, userId: Number(this.currentUser.id), titreComponent: "DoughnutChartResolution", titreDashboard: "Statistiques", donnees: "/" + this.selected + "*" + "/" + this.periode + "*" + "/" + this.stats.entreprise + "*"+ "/" + this.stats.base + "*"+ "/" + this.selected2 + "*"});

      const variable = this.dashboardService.postAddDashboardComponentToServer().subscribe(
        () => {
        console.log('Component du dashboard sauvegardé !');
        },
        (error) => {
        console.log('Erreur ! : ' + error);
        }
      );
      this.listSubscription.push(variable);
    }
  }
  removeFromDashboard(){
    for(let component of this.dashboardComponents){
      if(component.userId == Number(this.currentUser.id) && component.titreComponent == "DoughnutChartResolution")  this.dashboardService.idOfDataToDelete = component.id;
    }
    const variable = this.dashboardService.postDeleteDashboardComponentFromServer().subscribe(
      () => {
        console.log('Component du dashboard supprimé !');
      },
      (error) => {
        console.log('Erreur ! : ' + error);
      }
    );
    this.listSubscription.push(variable);
  }
  /* FIN Affichage du graphe sur le dashboard */

  // Quelques méthodes basiques qui sont utiles pour les algorithmes au-dessus
  getWeek(date: Date ) {
    // Create a copy of this date object  
    var target  = new Date(date.valueOf());
    // ISO week date weeks start on monday so correct the day number  
    var dayNr   = (date.getDay() + 6) % 7;
    // Set the target to the thursday of this week so the target date is in the right year  
    target.setDate(target.getDate() - dayNr + 3);
    // ISO 8601 states that week 1 is the week with january 4th in it  
    var jan4    = new Date(target.getFullYear(), 0, 4);
    // Number of days between target date and january 4th  
    var diff = Math.abs(target.getTime() - jan4.getTime());
    var dayDiff = Math.ceil(diff / (1000 * 3600 * 24));
    // Calculate week number: Week 1 (january 4th) plus the number of weeks between target date and january 4th    
    var weekNr = 1 + Math.ceil(dayDiff / 7);    
  
    return weekNr;
  }

  getDaysGap(start: Date, end: Date){
    let debut = new Date(start)
    let fin = new Date(end)

    // Si le msg du client a été envoyé en semaine en dehors des heures d'ouverture
    if(debut.getDay() == 1 || debut.getDay() == 2 || debut.getDay() == 3 || debut.getDay() == 4){
      if(debut.getHours() < 9) debut.setHours(9);
      if(debut.getHours() > 17) {
        debut.setDate(debut.getDate() + 1)
        debut.setHours(9);
        debut.setMinutes(0);
        debut.setSeconds(0);
      }
    }
    // Si le msg du bug tracker a été envoyé en semaine en dehors des heures d'ouverture
    if(fin.getDay() == 1 || fin.getDay() == 2 || fin.getDay() == 3 || fin.getDay() == 4){
      if(fin.getHours() < 9) fin.setHours(9);
      if(fin.getHours() > 17) {
        fin.setDate(fin.getDate() + 1)
        fin.setHours(9);
        debut.setMinutes(0);
        debut.setSeconds(0);
      }
    }
    
    // Si le msg du client a été envoyé vendredi hors heures d'ouverture
    if(debut.getDay() == 5){
      if(debut.getHours() < 9) debut.setHours(9);
      if(debut.getHours() > 17){
        debut.setDate(debut.getDate() + 3)
        debut.setHours(9);
        debut.setMinutes(0);
        debut.setSeconds(0);
      }
    }
    // Si le msg du bug tracker a été envoyé vendredi hors heures d'ouverture
    if(fin.getDay() == 5){
      if(fin.getHours() < 9) fin.setHours(9);
      if(fin.getHours() > 17){
        fin.setDate(fin.getDate() + 3)
        fin.setHours(9);
        debut.setMinutes(0);
        debut.setSeconds(0);
      }
    }

    // Si le msg du client a été envoyé le weekend
    if(debut.getDay() == 6 || debut.getDay() == 0){
      if(debut.getDay() == 6) debut.setDate(debut.getDate() + 2)
      if(debut.getDay() == 0) debut.setDate(debut.getDate() + 1)
      debut.setHours(9);
      debut.setMinutes(0);
      debut.setSeconds(0);
    }
    // Si le msg du bug tracker a été envoyé le weekend
    if(fin.getDay() == 6 || fin.getDay() == 0){
      if(fin.getDay() == 6) fin.setDate(fin.getDate() + 2)
      if(fin.getDay() == 0) fin.setDate(fin.getDate() + 1)
      fin.setHours(9);
      fin.setMinutes(0);
      fin.setSeconds(0);
    }


    let daysGap = this.daysBetween(debut, fin);
    // On retire les weekends
    if(this.countSpecificDayBetweenDates(debut, fin,'Sun') > 0){
      daysGap = daysGap - (this.countSpecificDayBetweenDates(debut, fin,'Sun') * 2)
    }

    return daysGap;
  }

  countSpecificDayBetweenDates(start, end, dayName) {
    var result = [];
    var days = {sun:0,mon:1,tue:2,wed:3,thu:4,fri:5,sat:6};
    var day = days[dayName.toLowerCase().substr(0,3)];
    // Copy start date
    var current = new Date(start);
    // Shift to next of required days
    current.setDate(current.getDate() + (day - current.getDay() + 7) % 7);
    // While less than end date, add dates to result array
    while (current < end) {
      result.push(new Date(+current));
      current.setDate(current.getDate() + 7);
    }
    return result.length;  
  }

  daysBetween(date1: Date, date2: Date){
    var diff = Math.abs(date1.getTime() - date2.getTime());
    var diffDays = Math.ceil(diff / (1000 * 3600 * 24));  
    return diffDays;
  }
}
