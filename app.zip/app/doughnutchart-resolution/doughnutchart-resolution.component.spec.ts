import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DoughnutchartResolutionComponent } from './doughnutchart-resolution.component';

describe('DoughnutchartResolutionComponent', () => {
  let component: DoughnutchartResolutionComponent;
  let fixture: ComponentFixture<DoughnutchartResolutionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DoughnutchartResolutionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DoughnutchartResolutionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
