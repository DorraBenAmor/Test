import { Component, OnInit, OnDestroy } from '@angular/core';
import { registerLocaleData } from '@angular/common';
import localeFr from '@angular/common/locales/fr';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { MessagerieTicketsService } from '../services/messagerie_tickets.service';
import { UserList } from '../services/user-list.service';
import { FicheModel } from '../models/fiche.model';
import { MessageModel } from '../models/message.model';
import { User } from '../models/user.model';

@Component({
  selector: 'app-tableau-ticket',
  templateUrl: './tableau-ticket.component.html',
  styleUrls: ['./tableau-ticket.component.css']
})
export class TableauTicketComponent implements OnInit, OnDestroy {

  dateActuelle: Date;
  dateHier;
  fiches: FicheModel[] = [];
  messages: MessageModel[] = [];
  users: User[] = [];
  tableauTikets: any[] = [];

  //Chemin de la page
  href: string;

  listSubscription = <Subscription[]>[];

  constructor(private router: Router, private messagerieTicketsService: MessagerieTicketsService, private userList: UserList) { }

  ngOnInit(): void {
    // Initialisation des variables
    registerLocaleData(localeFr, 'fr');
    this.href = this.router.url;
    this.dateActuelle = new Date();
    this.dateHier = new Date();
    this.dateHier.setDate(this.dateActuelle.getDate() - 1);
    this.tableauTikets = [];
    let msgTab = [], emetteur = "", respo = "";

    console.log('hello')
    
    const variable0 = this.messagerieTicketsService.getFichesFromServer().subscribe((response) => {
      this.fiches = JSON.parse(JSON.stringify(response)).data;
      console.log(this.fiches, 'fiches')

      const variable1 = this.messagerieTicketsService.getMessagesFromServer().subscribe((response) => {
        this.messages = JSON.parse(JSON.stringify(response)).data;
        console.log(this.messages, 'messages')

        const variable2 = this.userList.getUserFromServer().subscribe((response) => {
          this.users = JSON.parse(JSON.stringify(response)).data;
          console.log(this.users, 'users')
      
          for(let fiche of this.fiches){
            if(this.href == '/dashboard'){
              if(this.checkIfTicketOfCurrentWeek(new Date(fiche.date_ouverture)) == true){
                msgTab = [];
                for(let msg of this.messages){
                  if(msg.ficheID == fiche.id){
                    msgTab.push({date: new Date(msg.date_envoie), cree_par: msg.userID})
                  }
                }
                msgTab.sort((a, b) => a.date - b.date);

                for(let user of this.users){
                  if(msgTab.length != 0){
                    if(user.id == msgTab[0].cree_par) {
                      emetteur = user.prenom + " " + user.nom;
                    }
                  }
                  if(user.id == fiche.respo_dossier_ID) respo = user.prenom + " " + user.nom;
                }
          
                if(msgTab.length != 0) {
                  this.tableauTikets = [
                    ...this.tableauTikets,
                    {
                      id: fiche.id, 
                      etat: fiche.etat,
                      libelle: fiche.libelle, 
                      type_objet: fiche.type_objet, 
                      module: fiche.module, 
                      cree_par: emetteur,
                      respo_dossier: respo,
                      date_ouverture: new Date(msgTab[0].date)
                    }
                  ]
                }
              }
            }
            
            if(this.href == '/bugtracking_tableau'){
              msgTab = [];
              for(let msg of this.messages){
                if(msg.ficheID == fiche.id){
                  msgTab.push({date: new Date(msg.date_envoie), cree_par: msg.userID})
                }
              }
              msgTab.sort((a, b) => a.date - b.date);

              for(let user of this.users){
                if(msgTab.length != 0){
                  if(user.id == msgTab[0].cree_par) {
                    emetteur = user.prenom + " " + user.nom;
                  }
                }
                if(user.id == fiche.respo_dossier_ID) respo = user.prenom + " " + user.nom;
              }
        
              if(msgTab.length != 0) {
                this.tableauTikets = [
                  ...this.tableauTikets,
                  {
                    id: fiche.id, 
                    etat: fiche.etat,
                    libelle: fiche.libelle, 
                    type_objet: fiche.type_objet, 
                    module: fiche.module, 
                    cree_par: emetteur,
                    respo_dossier: respo,
                    date_ouverture: new Date(msgTab[0].date)
                  }
                ]
              }
            }
            
          }
          this.tableauTikets.sort((a, b) => b.date_ouverture - a.date_ouverture);

          console.log(this.tableauTikets, "Tableau Tickets")
        });
        //Détruire la souscription
        this.listSubscription.push(variable2);

      });
      //Détruire la souscription
      this.listSubscription.push(variable1);
    
    });
    //Détruire la souscription
    this.listSubscription.push(variable0);

    console.log(this.checkIfTicketOfCurrentWeek(new Date('2020-07-16')), "dateeeee")
  }

  ngOnDestroy(){
    this.listSubscription.map((elem) => elem.unsubscribe());
  }

  checkIfTicketOfCurrentWeek(date: Date) {
    const now = new Date();

    const weekDay = (now.getDay() + 6) % 7; // Make sure Sunday is 6, not 0
    const monthDay = now.getDate();
    const mondayThisWeek = monthDay - weekDay;

    const startOfThisWeek = new Date(+now);
    startOfThisWeek.setDate(mondayThisWeek);
    startOfThisWeek.setHours(0, 0, 0, 0);

    const startOfNextWeek = new Date(+startOfThisWeek);
    startOfNextWeek.setDate(mondayThisWeek + 7);

    return date >= startOfThisWeek && date < startOfNextWeek;
  }

}
