import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TableauTicketComponent } from './tableau-ticket.component';

describe('TableauTicketComponent', () => {
  let component: TableauTicketComponent;
  let fixture: ComponentFixture<TableauTicketComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TableauTicketComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TableauTicketComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
