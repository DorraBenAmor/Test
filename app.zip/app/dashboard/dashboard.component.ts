import { Component, OnInit, OnDestroy, AfterViewInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { Subscription } from 'rxjs';
import { registerLocaleData } from '@angular/common';
import localeFr from '@angular/common/locales/fr';
import { BaseChartDirective} from 'ng2-charts';
import * as annotations from 'chartjs-plugin-annotation';
import { DashboardService } from '../services/dashboard.service';
import { Connection } from '../models/connection.model';
import { ConnexionService } from '../services/connexion.service';
import { DashboardComponentModel } from '../models/dashboardComponent.model';
import { DoughnutChartTicketComponent } from '../doughnutchart-ticket/doughnut-chart-ticket.component';
import { DoughnutchartReponseComponent } from '../doughnutchart-reponse/doughnutchart-reponse.component';
import { DoughnutchartResolutionComponent } from '../doughnutchart-resolution/doughnutchart-resolution.component';
import { GrapheNiveau1TicketComponent } from '../graphe-niveau1-ticket/graphe-niveau1-ticket.component';
import { StatService } from '../services/statistique.service';
import { GrapheEvolutifGlobalComponent } from '../graphe-evolutif-global/graphe-evolutif-global.component'
import { GrapheEvolutifFiltreComponent } from '../graphe-evolutif-filtre/graphe-evolutif-filtre.component'


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit, OnDestroy, AfterViewInit{

  @ViewChild(DoughnutChartTicketComponent) doughnutChartTicketCmp: DoughnutChartTicketComponent;
  @ViewChild(DoughnutchartReponseComponent) doughnutChartReponseCmp: DoughnutchartReponseComponent;
  @ViewChild(DoughnutchartResolutionComponent) doughnutChartResolutionCmp: DoughnutchartResolutionComponent;
  @ViewChild(GrapheNiveau1TicketComponent) grapheNiveau1TicketCmp: GrapheNiveau1TicketComponent;

  @ViewChild(GrapheEvolutifGlobalComponent) grapheEvolutifGlobal:GrapheEvolutifGlobalComponent;
  @ViewChild(GrapheEvolutifFiltreComponent) grapheEvolutifFiltre:GrapheEvolutifFiltreComponent;

  // DECLARATION DES VARIABLES

  // Données du user connecté
  currentUser: Connection;
  private subscription: Subscription;

  //Données de la BDD
  dashboardComponents: DashboardComponentModel[] = [];
  myDashboardComponents: any[] = [];
  donneesTab: any[] = [];

  //Temps de résolutions (en jour)
  fichesResolues: any[] = [];

  // Choix components données
  periode: string;
  selectedCourbe: string;
  selected: string;
 
  listSubscription = <Subscription[]>[];

  constructor(private connexionService: ConnexionService, private statService: StatService, private dashboardService: DashboardService, public cdr: ChangeDetectorRef) { 
  }

  //METHODES

  ngOnInit(): void {
    registerLocaleData(localeFr, 'fr');

    // Récupération des données du user connecté
    this.subscription = this.connexionService.connexionSubject.subscribe(datas => {
      this.currentUser = datas;
      console.log(datas, 'Current user details')
    })
    this.connexionService.emitConnection();
  }

  ngOnDestroy(): void {
    this.listSubscription.map((elem) => elem.unsubscribe());
    this.subscription.unsubscribe();
  }

  ngAfterViewInit() {

    //Récupération des components du dashboard de la BDD
    const variable = this.dashboardService.getDashboardComponentsFromServer().subscribe((res) => {
      this.dashboardComponents = JSON.parse(JSON.stringify(res)).data;
      let listeEntrepriseBase = []
      let i
      for(let cmp of this.dashboardComponents){
        if(cmp.userId == Number(this.currentUser.id)) {
          this.donneesTab = cmp.donnees.split(/[/*]/);
          for(let i=0; i<this.donneesTab.length; i++){
            if(this.donneesTab[i] == "") this.donneesTab.splice(i, 1);
          }
          if (this.donneesTab[1] === 'Choix Entreprise') {
            listeEntrepriseBase = []
            i = 4
            while(this.donneesTab[i] != 'Filtre') {
              listeEntrepriseBase.push({entreprise: this.donneesTab[i].substring(0, this.donneesTab[i].indexOf(';')), url: this.donneesTab[i].substring(this.donneesTab[i].indexOf(';') + 1)})
              i++
            }
            i = 3
            while(this.donneesTab[i] != 'Filtre') {
              this.donneesTab.splice(i, 1)
            }
            this.donneesTab.splice(3, 0, listeEntrepriseBase);
          }

          console.log(this.donneesTab, "donnees tableau")
          this.myDashboardComponents.push({id: cmp.id, titreDashboard: cmp.titreDashboard, titreComponent: cmp.titreComponent, donnees: this.donneesTab});
        }
      }
      console.log(this.myDashboardComponents, "my dashCmp")
    });
    this.listSubscription.push(variable);

  }

  removeFromDashboard(id: number){
    console.log(this.myDashboardComponents, "dash component removed")
    for(let i = 0; i<this.dashboardComponents.length; i++){
      if(this.dashboardComponents[i].id == id)  this.dashboardService.idOfDataToDelete = this.dashboardComponents[i].id
    }
    const variable = this.dashboardService.postDeleteDashboardComponentFromServer().subscribe(
      () => {
        console.log('Component du dashboard supprimé !');
      },
      (error) => {
        console.log('Erreur ! : ' + error);
      }
    );
    this.listSubscription.push(variable);

    for(let i = 0; i<this.myDashboardComponents.length; i++){
      if(this.myDashboardComponents[i].id == id)  this.myDashboardComponents.splice(i, 1)
    }
    console.log(this.myDashboardComponents)
  }



  getHoursGap(start: Date, end: Date){
    let debut = new Date(start)
    let fin = new Date(end)

    // Si le msg du client a été envoyé en semaine en dehors des heures d'ouverture
    if(debut.getDay() == 1 || debut.getDay() == 2 || debut.getDay() == 3 || debut.getDay() == 4){
      if(debut.getHours() < 9) debut.setHours(9);
      if(debut.getHours() > 17) {
        debut.setDate(debut.getDate() + 1)
        debut.setHours(9);
        debut.setMinutes(0);
        debut.setSeconds(0);
      }
    }
    // Si le msg du bug tracker a été envoyé en semaine en dehors des heures d'ouverture
    if(fin.getDay() == 1 || fin.getDay() == 2 || fin.getDay() == 3 || fin.getDay() == 4){
      if(fin.getHours() < 9) fin.setHours(9);
      if(fin.getHours() > 17) {
        fin.setDate(fin.getDate() + 1)
        fin.setHours(9);
        debut.setMinutes(0);
        debut.setSeconds(0);
      }
    }
    
    // Si le msg du client a été envoyé vendredi hors heures d'ouverture
    if(debut.getDay() == 5){
      if(debut.getHours() < 9) debut.setHours(9);
      if(debut.getHours() > 17){
        debut.setDate(debut.getDate() + 3)
        debut.setHours(9);
        debut.setMinutes(0);
        debut.setSeconds(0);
      }
    }
    // Si le msg du bug tracker a été envoyé vendredi hors heures d'ouverture
    if(fin.getDay() == 5){
      if(fin.getHours() < 9) fin.setHours(9);
      if(fin.getHours() > 17){
        fin.setDate(fin.getDate() + 3)
        fin.setHours(9);
        debut.setMinutes(0);
        debut.setSeconds(0);
      }
    }

    // Si le msg du client a été envoyé le weekend
    if(debut.getDay() == 6 || debut.getDay() == 0){
      if(debut.getDay() == 6) debut.setDate(debut.getDate() + 2)
      if(debut.getDay() == 0) debut.setDate(debut.getDate() + 1)
      debut.setHours(9);
      debut.setMinutes(0);
      debut.setSeconds(0);
    }
    // Si le msg du bug tracker a été envoyé le weekend
    if(fin.getDay() == 6 || fin.getDay() == 0){
      if(fin.getDay() == 6) fin.setDate(fin.getDate() + 2)
      if(fin.getDay() == 0) fin.setDate(fin.getDate() + 1)
      fin.setHours(9);
      fin.setMinutes(0);
      fin.setSeconds(0);
    }
    
    // Calculer en respectant les horaires d'ouverture
    let gapMilliseconds = new Date(fin).getTime() - new Date(debut).getTime();
    let gapHours = gapMilliseconds/(3600 * 1000);
    let gapHoursCalculated = gapMilliseconds/(3600 * 1000);
    let extraHour = 0;
    
    // S'il il s'agit de 2 dates différentes
    if(debut.getDate() != fin.getDate() || debut.getMonth() != fin.getMonth() || debut.getFullYear() != fin.getFullYear()){
      //S'il y a qu'un jour d'écart, on retire lécart en millisecondes entre 17h et 9h du lendemain
      if(gapHours < 24) gapMilliseconds = gapMilliseconds - (16 * 3600 * 1000)
      // S'il y a plus d'un jour de différence
      if(gapHours >= 24){
        // On retire les horaires du weekend entre 9h et 17h (gap de 8h)
        if(this.countSpecificDayBetweenDates(new Date(debut), new Date(fin),'Sun') > 0){
          gapHoursCalculated = gapHoursCalculated - (this.countSpecificDayBetweenDates(new Date(debut), new Date(fin),'Sun') * 2 * 24)
        }
        // On retire les horaires après 17h et avant 9h tous les jour (gap de 16h entre la fermeture à 17h et l'ouverture le lendemine à 9h)
        if(fin.getHours() < debut.getHours()){
          extraHour = 1;
        }
        gapHoursCalculated = gapHoursCalculated - ((Math.floor(gapHours/24) + extraHour - (2 * this.countSpecificDayBetweenDates(new Date(debut), new Date(fin),'Sun'))) * 16)
      }
    }

    return gapHoursCalculated;
  }

  countSpecificDayBetweenDates(start, end, dayName) {
    var result = [];
    var days = {sun:0,mon:1,tue:2,wed:3,thu:4,fri:5,sat:6};
    var day = days[dayName.toLowerCase().substr(0,3)];
    // Copy start date
    var current = new Date(start);
    // Shift to next of required days
    current.setDate(current.getDate() + (day - current.getDay() + 7) % 7);
    // While less than end date, add dates to result array
    while (current < end) {
      result.push(new Date(+current));
      current.setDate(current.getDate() + 7);
    }
    return result.length;  
  }

  // Code pour l'insertion du temps de réponse à réutiliser dans la messagerie (CODE SOURCE A CONSERVER)
  insertTempsReponse(){
    const variable2 = this.statService.getTempsRep().subscribe((res) => {
      console.log(JSON.parse(JSON.stringify(res)).data, "Result")
      var table = JSON.parse(JSON.stringify(res)).data

      // données du 1er ticket
      var ficheID = table[0].ficheID

      // Insertion du 1er ticket
      this.statService.data = []
      this.statService.data.push({id: 0, entreprise: table[0].numero_ticket.substring(table[0].numero_ticket.indexOf('_') + 1), base: table[0].url, filtre: "Modules", categorie: table[0].module, jour: new Date(table[0].date_ouverture), tempsReponse: this.getHoursGap(new Date(table[0].date_ouverture), new Date(table[0].date_envoie)).toFixed(2), nbTicketsConcernes: 1})
      const variable2 = this.statService.postAddStatTempsRep().subscribe(
        () => {
          console.log('Added !')
        },
        (error) => {
          console.log('Erreur ! : ' + error)
        }
      );
      this.listSubscription.push(variable2)

      for(let i=1; i<table.length; i++) {
        // console.log(table[i].numero_ticket.substring(table[i].numero_ticket.indexOf('_') + 1), 'ticket')
        // s'il s'agit d'une autre fiche que le précédent, je calcule le temps de réponse et j'insère les données
        if(table[i].ficheID != ficheID) {
          ficheID = table[i].ficheID
          this.statService.data = []
          this.statService.data.push({id: 0, entreprise: table[i].numero_ticket.substring(table[i].numero_ticket.indexOf('_') + 1), base: table[i].url, filtre: "Modules", categorie: table[i].module, jour: new Date(table[i].date_ouverture), tempsReponse: this.getHoursGap(new Date(table[i].date_ouverture), new Date(table[i].date_envoie)).toFixed(2), nbTicketsConcernes: 1})
          const variable = this.statService.postAddStatTempsRep().subscribe(
            () => {
              console.log('Added !')
            },
            (error) => {
              console.log('Erreur ! : ' + error)
            }
          );
          this.listSubscription.push(variable)
        }
      }
      
      // console.log(this.statService.data, "Result data")
    });
    this.listSubscription.push(variable2);
  }
}



// this.statService.data = []
// this.statService.data.push({id: 0, entreprise: null, base: null, filtre: "Responsables de dossier", categorie: table[i].respo_dossier_ID, jour: jour, tempsReponse: Number(((new Date(table[i].date_envoie).getTime() - new Date(table[i-1].date_envoie).getTime()) / (1000 * 60 * 60)).toFixed(2))})
// const variable2 = this.statService.postAddStatTempsRep().subscribe(
//   () => {
//     console.log('Added !');
//   },
//   (error) => {
//     console.log('Erreur ! : ' + error);
//   }
// );
// this.listSubscription.push(variable2);