import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StatistiquesTicketComponent } from './statistiques-ticket.component';

describe('StatistiquesTicketComponent', () => {
  let component: StatistiquesTicketComponent;
  let fixture: ComponentFixture<StatistiquesTicketComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StatistiquesTicketComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StatistiquesTicketComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
