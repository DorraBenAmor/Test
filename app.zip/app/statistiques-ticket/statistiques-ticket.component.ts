import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Title } from '@angular/platform-browser';
import { MessagerieTicketsService } from '../services/messagerie_tickets.service';
import { UserList } from '../services/user-list.service';
import { EntrepriseList } from '../services/entreprise-list.service';
import { ConnexionService } from '../services/connexion.service';
import { Connection } from '../models/connection.model';
import { DataLoadingService } from '../services/dataLoading.service';



@Component({
  selector: 'app-statistiques-ticket',
  templateUrl: './statistiques-ticket.component.html',
  styleUrls: ['./statistiques-ticket.component.css']
})
export class StatistiquesTicketComponent implements OnInit, OnDestroy {

  /**Déclaration des variables**/

  //Socket
  currentUser: Connection;
  private subscription: Subscription;

  // Chemin de la page
  currentPath: string
  // Choix de graphe à afficher
  graphChoice: string = ""
  grapheIndividuelChoice: string = ''
  // MatTab menu
  tabIndex: number
  
  listSubscription = <Subscription[]>[];

  constructor(private titleService: Title, private connexionService: ConnexionService, private dataLoadingService: DataLoadingService, private router: Router) { }

  ngOnInit(): void {
    // Initialisation des variables
    this.currentPath = this.router.url;
    if (this.currentPath === '/bugtracking_statistiques') this.titleService.setTitle('BugTracking - Statistiques');
    this.graphChoice = "Courbe d\'évolution"
    this.grapheIndividuelChoice = "Courbe d\'évolution Perso"
    // A CHANGER A 0
    this.tabIndex = 0

    // Recupération infos du user connecté
    this.subscription = this.connexionService.connexionSubject.subscribe(datas => {
      this.currentUser = datas;
    })
    this.connexionService.emitConnection();
  }

  ngOnDestroy(): void {
    this.listSubscription.map((elem) => elem.unsubscribe());
    this.subscription.unsubscribe();
  }

  getTabIndex($event){
    console.log($event.index, "tab index")
    this.tabIndex = $event.index
  }

  OnChoseGraph(graph: string){
    this.graphChoice = graph
  }
  OnChoseIndividuelGraph(graph: string){
    this.grapheIndividuelChoice = graph
  }
}
