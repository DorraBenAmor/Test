import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { ConnexionService } from '../services/connexion.service';
import { ConnexionGuardService } from '../services/connexion-guard.service';
import { UserList } from '../services/user-list.service';
import { Observable, Subscription } from 'rxjs';
import { Connection } from '../models/connection.model';
import { StatistiquesTicketsService } from '../services/statistiques_tickets.service';


@Component({
  selector: 'app-connexion',
  templateUrl: './connexion.component.html',
  styleUrls: ['./connexion.component.css']
})
export class ConnexionComponent implements OnInit, OnDestroy {

  //DECLARATION DES VARIABLES

  //socket
  // Données du user connecté
  currentUser: Connection;
  private subscription: Subscription;

  //autres
  connected: boolean;
  registerForm: FormGroup;
  submitted = false;
    
  email: string = "";
  mdp: string = "";
  emailFound: boolean = false;
  errorMsgEmail: string = "";
  errorMsgMdp: string = "";
  inputValid: boolean = false;
  users: any[];
  errorIDS: boolean = false

  listSubscription = <Subscription[]>[];
  
  constructor(private titleService: Title, private statistiquesTicketsService: StatistiquesTicketsService, private connexionService: ConnexionService, private connexionGuardService: ConnexionGuardService, private userList: UserList, private formBuilder: FormBuilder, private router: Router) { }

  //METHODES

  ngOnInit(): void {

    /**Socket */
    // Récupération des données du user connecté
    this.subscription = this.connexionService.connexionSubject.subscribe(datas => {
      this.currentUser = datas;
      console.log(datas, "Connexion - current User")
    })
    this.connexionService.emitConnection();

    this.titleService.setTitle('Connexion');
    this.connected = this.connexionService.connected;
    //this.users = this.userList.users;
    this.users = this.userList.userSample;
    //METHODE GET Working !
    const vare = this.userList.getUserFromServer().subscribe((response) => {
      //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
      this.users = JSON.parse(JSON.stringify(response)).data;
      
      for (let i=0; i<JSON.parse(JSON.stringify(response)).data; i++) {
        this.users.push({id: JSON.parse(JSON.stringify(response)).data[i].id, nom: JSON.parse(JSON.stringify(response)).data[i].nom, prenom: JSON.parse(JSON.stringify(response)).data[i].prenom, image: JSON.parse(JSON.stringify(response)).data[i].image, entreprise: JSON.parse(JSON.stringify(response)).data[i].entreprise, fonction: JSON.parse(JSON.stringify(response)).data[i].fonction, statut: JSON.parse(JSON.stringify(response)).data[i].statut, module: JSON.parse(JSON.stringify(response)).data[i].module, projet: JSON.parse(JSON.stringify(response)).data[i].projet, connected: JSON.parse(JSON.stringify(response)).data[i].connected, emailPerso: JSON.parse(JSON.stringify(response)).data[i].emailPerso, emailPro: JSON.parse(JSON.stringify(response)).data[i].emailPro, mdpPro: JSON.parse(JSON.stringify(response)).data[i].mdpPro, isReferant: JSON.parse(JSON.stringify(response)).data[i].isReferant, nomReferant: JSON.parse(JSON.stringify(response)).data[i].nomReferant})
      }

    });
    //Détruire la souscription
    this.listSubscription.push(vare);
    this.registerForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      mdp: ['', Validators.required]
    });
  }

  ngOnDestroy(){
    this.listSubscription.map((elem) => elem.unsubscribe());
    this.subscription.unsubscribe();
  }

  //Getter for easy access to form fields
  get f() { 
    return this.registerForm.controls; 
  }

  handleEmailInput(value: string) {
    this.email = value;
  }

  handleMdpInput(value: string) {
    this.mdp= value;
  }

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.registerForm.invalid) {
      return;
    }
    else{
      // verification des identifiants
      this.connexionService.identifiants = []
      this.connexionService.identifiants.push(this.email)
      this.connexionService.identifiants.push(this.mdp)
      const variable5 = this.connexionService.getUserConnection().subscribe((res) => {
        var values = JSON.parse(JSON.stringify(res)).data
        console.log(values, 'VALUES')
        if(values.length !== 1)  {
          // Incorrect: les identifiants sont incorrects
          this.errorIDS = true
          return
        }
        else {  // Correct
          //passer au statut connecté dans connexionService
          this.connexionService.signIn()
          
          // passer au statut connecté
          let user = values[0]
          //Ajout de la connexion via socket
          this.connexionService.newConnection(user.id, user.nom, user.prenom, user.emailPro, user.statut, user.image, user.tags, user.tel, user.entreprise, user.base);
          console.log(this.currentUser, "User connecté")
          let connectedUserId = user.id
          user.connected = true;
          this.connexionService.connectedUserEmail = user.emailPro;
          this.connexionService.userID = user.id;
          this.connexionService.userNom = user.nom;
          this.connexionService.userPrenom = user.prenom;
          this.connexionService.userImage = user.image;
          this.connexionService.userTags = user.tags;
          this.connexionService.userStatut = user.statut;
          this.connexionService.userFonction = user.fonction;

          // chargement de toutes les données
          //this.statistiquesTicketsService.loadData()

          // Session Login
          console.log(connectedUserId, 'connectedUserId')
          this.connexionGuardService.doLogin(connectedUserId.toString());

          // Redirection page du dashboard
          this.router.navigate(['dashboard']);
        }
      });
      this.listSubscription.push(variable5);
    }
  }

}
