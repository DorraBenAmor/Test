import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { TimelineData } from '../services/timeline-data.service';
import { Subscription } from 'rxjs';
import { ConnexionService } from '../services/connexion.service';

@Component({
  selector: 'app-timeline',
  templateUrl: './timeline.component.html',
  styleUrls: ['./timeline.component.css']
})
export class TimelineComponent implements OnInit, OnDestroy {

  //DECLARATION DES VARIABLES
  ajoutEvtClicked: boolean = false;
  registerForm: FormGroup;
  submitted = false;

  date: Date;
  heure: string = "";
  motif: string = "";
  isUserConcerned: boolean = false;
  valid: boolean = false;
  dataToAdd: any[];
  timelineArray: any[];
  length: number;

  listSubscription = <Subscription[]>[];

  constructor(private connexionService: ConnexionService, private titleService: Title, private timelineService: TimelineData, private formBuilder: FormBuilder) { }

  //METHODES

  // convenience getter for easy access to form fields
  get f() { return this.registerForm.controls; }

  ngOnInit(): void {
    this.dataToAdd = this.timelineService.dataToAdd;
    this.titleService.setTitle('Timeline');
    this.registerForm = this.formBuilder.group({
      date: ['', Validators.required],
      heure: ['', Validators.required],     
      motif: ['', Validators.required],
      isUserConcerned: [false]
    });
  }

  ngOnDestroy(){
    this.listSubscription.map((elem) => elem.unsubscribe());
  }
  
  handleDateInput(value: Date) {
    this.date = new Date(value);
  }

  handleHeureInput(value: string) {
    this.heure = value;
  }

  handleEvtInput(value: string) {
    this.motif = value;
  }

  onCheckedConcerned(e) {
    if (e.target.checked) {
      this.isUserConcerned = true;
    } 
  }

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.registerForm.invalid) {
      return;
    }
    else{
      this.valid = true;
      //ajout de l'évènement au données
      //Methode GET Event: to know the length of the table
      const variable0 = this.timelineService.getEvtFromServer().subscribe((response) => {
        this.length = JSON.parse(JSON.stringify(response)).data.length;
      });
      //Détruire la souscription
      this.listSubscription.push(variable0);

      if(this.isUserConcerned == false)   this.dataToAdd.push({id: this.length + 1, date: this.date, heure: this.heure, motif: this.motif, isUserConcerned: 0});
      if(this.isUserConcerned == true)   this.dataToAdd.push({id: this.length + 1, date: this.date, heure: this.heure, motif: this.motif, isUserConcerned: this.connexionService.userID});
      
      //METHODE POST Add Event
      const variable  = this.timelineService.postEvtToServer().subscribe(
        () => {
          console.log('Données de la timeline sauvegardées !');
        },
        (error) => {
          console.log('Erreur ! : ' + error);
        }
      );
      //Détruite la souscription
      this.listSubscription.push(variable);
      this.dataToAdd = this.timelineService.dataToAdd;

      //On réinitialise le formulaire
      this.submitted = false;
      this.registerForm.reset();
      
      //Rafraichir la page pour afficher le nouvel évènement donnée ajoutée
      setTimeout(() => {
        console.log("Chargement...")
      }, 2000);
      location.reload();
    }
  }

  AjoutEvt(){
    if(this.ajoutEvtClicked == false) this.ajoutEvtClicked = true;
    else{
      this.ajoutEvtClicked = false;
      this.submitted = false;
      this.registerForm.reset();
    } 
  }

}
