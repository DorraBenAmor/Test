import { Component, OnInit } from '@angular/core';
import { UserList } from '../services/user-list.service';
import { EntrepriseList } from '../services/entreprise-list.service';
import { ConnexionService } from '../services/connexion.service';
import { Connection } from '../models/connection.model';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { Observable, Subject, Subscription } from 'rxjs';
import { DataLoadingService } from '../services/dataLoading.service';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {
  
  //DECLARATION DES VARIABLES
  // Données du user connecté
  currentUser: Connection;
  private subscription: Subscription;

  allConnections: Connection[];
  private subscriptionCo: Subscription;

  //socket
  connections: Observable<Connection[]>;
  connectionTab: Connection[] = [];

  currentConnection: Connection;
  private subscriptionTab: Subscription;

  tableauSubject = new Subject<any[]>();
  tableauFinal: any[];
  subscriptionTabFinal: Subscription;

   // Loading Data
   private subscriptionLoadData: Subscription

  //Autres
  entreprises: any[];
  users: any[];
  dropdownMenuElt: string;
  arrayOfElements: string[] = [];
  arrayContingElements: number[] = [];
  sortedArray: any[] = [];
  i: number = 2;
 

  users2: any[];
  usersFinal: any[];

  // Pour afficher les user créés il y a moins de 7 jours sur le dashboard
  dateActuelle: Date
  before7Days: Date
  // Maximum users to display
  maxToDisplay: number

  // Chemin de la page
  currentPath: string

  listSubscription = <Subscription[]>[];

  constructor(private titleService: Title, private userService: UserList, private entrepriseService: EntrepriseList, private dataLoadingService: DataLoadingService, private connexionService: ConnexionService, private userList: UserList, private entrepriseList: EntrepriseList, private router: Router) { }

  //METHODES

  ngOnInit(): void {
    // Recuperation user connecté
    this.subscription = this.connexionService.connexionSubject.subscribe(datas => {
      this.currentUser = datas
      console.log(datas, 'USER CONNECTED')
    })
    this.connexionService.emitConnection()

    // Initialisation des variables
    this.currentPath = this.router.url;
    if(this.currentPath === '/collaborateurs') this.titleService.setTitle('Collaborateurs');
    this.maxToDisplay = 20
    this.dateActuelle = new Date()
    this.before7Days = new Date(this.dateActuelle.getTime() - (7 * 24 * 60 * 60 * 1000));

    // // Mise à jour du tableau des graphes ouverts
    // if(this.currentPath == '/dashboard')  this.dataLoadingService.chartOpened.dashboardCollaborateurs = 1
    // if(this.currentPath == '/collaborateurs')  this.dataLoadingService.chartOpened.collaborateurs = 1

    // this.subscriptionLoadData = this.dataLoadingService.DashboardCollaborateursloadDataCalled.subscribe(() => {
    //   this.entreprises = this.dataLoadingService.entreprises
    //   this.users = this.dataLoadingService.usersCreatedLast7Days

    //   // Initialisation
    //   this.sortedArray = this.users

    //   // Lancement
    //   this.dropdownMenuElt = 'Trier'
    // });

    // this.subscriptionLoadData = this.dataLoadingService.CollaborateursloadDataCalled.subscribe(() => {
    //   console.log('IN SUB 2')
    //   this.entreprises = this.dataLoadingService.entreprises
    //   this.users = this.dataLoadingService.users

    //   // Initialisation
    //   this.sortedArray = this.users

    //   // Lancement
    //   this.dropdownMenuElt = 'Trier'
    // });

    this.chargementDonneesBDD()
    

    /**Socket */
    // Tentative de récupération de tous les user connectés dans un tableau
    // console.time('sub')
    // console.time('now')
    // this.subscriptionTab = this.connexionService.connectionTab.subscribe(value => { 
    //   this.connectionTab = value;
    //   console.timeEnd('sub')
    //   //Avec Observable
    //   console.log(value, "valeur (Observable)"); 
    // });
    // console.log(this.connectionTab, "OK")
    // console.timeEnd('now')

    // Récupération des données des users connectés
    // this.subscriptionCo = this.connexionService.allConnectionsSubject.subscribe(datas => {
    //   this.allConnections = datas;
    //   console.log(this.allConnections, "test in")
    // })
    // this.connexionService.emitAllConnection();
    // console.log(this.allConnections, "test out")

  }

  ngOnDestroy(){
    this.listSubscription.map((elem) => elem.unsubscribe());
    this.subscription.unsubscribe();
    // this.subscriptionTab.unsubscribe();
    // this.subscriptionCo.unsubscribe();
    // this.subscriptionLoadData.unsubscribe();
  }

  emitTab() {
    this.tableauSubject.next(this.connectionTab);
  }

  chargementDonneesBDD() {
    console.log(this.currentUser, 'curent user collab')
    if(this.currentPath == '/collaborateurs') {
      if(this.currentUser.statut === 'Externe') {
        this.userService.dataUsersOfEntrepriseBase = []
        this.userService.dataUsersOfEntrepriseBase.push(this.currentUser.entreprise)
        this.userService.dataUsersOfEntrepriseBase.push(this.currentUser.base)
        const variable3 = this.userService.getUsersOfEntrepriseBase().subscribe((res3) => {
          this.users = JSON.parse(JSON.stringify(res3)).data

          // Recuperation des entreprises
          this.entrepriseService.dataEntrepriseNom = []
          this.entrepriseService.dataEntrepriseNom.push(this.currentUser.entreprise)
          const variable4 = this.entrepriseService.getEntrepriseSpecifique().subscribe((res3) => {
            this.entreprises = JSON.parse(JSON.stringify(res3)).data

            // Initialisation
            this.sortedArray = this.users

            // Lancement
            this.dropdownMenuElt = 'Trier'
          });
          this.listSubscription.push(variable4)
        });
        this.listSubscription.push(variable3);
        this.entreprises = []
        this.entreprises.push(this.currentUser.entreprise)
      }
      else {  // si interne connecté
        const variable3 = this.userService.getUserFromServer().subscribe((res3) => {
          this.users = JSON.parse(JSON.stringify(res3)).data
          console.log(this.users, 'users collab')

          // Recuperation des entreprises
          const variable4 = this.entrepriseService.getEntrepriseFromServer().subscribe((res3) => {
            this.entreprises = JSON.parse(JSON.stringify(res3)).data
          });
          this.listSubscription.push(variable4);

          // Initialisation
          this.sortedArray = this.users

          // Lancement
          this.dropdownMenuElt = 'Trier'
        });
        this.listSubscription.push(variable3);
        
      }
    }

    if(this.currentPath == '/dashboard') {
      if(this.currentUser.statut === 'Externe') {
        this.userService.dataUsersOfEntrepriseBase = []
        this.userService.dataUsersOfEntrepriseBase.push(this.currentUser.entreprise)
        this.userService.dataUsersOfEntrepriseBase.push(this.currentUser.base)
        const variable3 = this.userService.getUsersOfEntrepriseBaseCreatedLast7Days().subscribe((res3) => {
          this.users = JSON.parse(JSON.stringify(res3)).data

          // Recuperation des entreprises
          this.entrepriseService.dataEntrepriseNom = []
          this.entrepriseService.dataEntrepriseNom.push(this.currentUser.entreprise)
          const variable4 = this.entrepriseService.getEntrepriseSpecifique().subscribe((res3) => {
            this.entreprises = JSON.parse(JSON.stringify(res3)).data

            // Initialisation
            this.sortedArray = this.users

            // Lancement
            this.dropdownMenuElt = 'Trier'
          });
          this.listSubscription.push(variable4)
        });
        this.listSubscription.push(variable3)
      }
      else {  // si interne connecté
        const variable3 = this.userService.getUsersCreatedLast7DaysFromServer().subscribe((res3) => {
          this.users = JSON.parse(JSON.stringify(res3)).data
          console.log(this.users, 'users dash')

          // Recuperation des entreprises
          const variable4 = this.entrepriseService.getEntrepriseFromServer().subscribe((res3) => {
            this.entreprises = JSON.parse(JSON.stringify(res3)).data
          });
          this.listSubscription.push(variable4);

          // Initialisation
          this.sortedArray = this.users

          // Lancement
          this.dropdownMenuElt = 'Trier'
        });
        this.listSubscription.push(variable3)
      }
    }
  }

  handleClick(selectedElt: string) {
    switch (selectedElt) {
      case 'Entreprise':
        this.dropdownMenuElt = "Entreprise";
        this.sortUsersByEntreprise()
        break;
      case 'Statut':
        this.dropdownMenuElt = "Statut";
        this.sortUsersByStatut()
        break;
      case 'Fonction':
        this.dropdownMenuElt = "Fonction";
        this.sortUsersByFonction()
        break;
      case 'Module':
        this.dropdownMenuElt = "Module";
        this.sortUsersByModule()
        break;
      case 'Projet':
        this.dropdownMenuElt = "Projet";
        this.sortUsersByProjet()
        break;
      case 'Connecté':
        this.dropdownMenuElt = "Connecté";
        this.sortUsersByConnecte()
        break;
      default:
        this.dropdownMenuElt = "Trier";
        this.sortedArray = this.users
      }
  }

  sortUsersByEntreprise(){
    // Réinitialisation
    this.arrayOfElements = [];
    this.sortedArray = [];
    this.arrayContingElements = [];

    //Listing des entreprises de tous les users dans un array
    for (let user of this.users){
      if (!this.arrayOfElements.includes(user.entreprise)) this.arrayOfElements.push(user.entreprise);
    }

    // Tri de la liste des users ordonnée par Entreprise et on compte le nombre user dans chaque Entreprise dans l'ordre
    for(let item of this.arrayOfElements){  
      let i = 0;
      for(let user of this.users){
        if(user.entreprise == item){
          this.sortedArray.push(user);
          this.arrayContingElements.push(i++);
        } 
      }
    }
   
    console.log(this.sortedArray, 'sortedArray')
    console.log(this.entreprises, 'entreprises')
    // console.log("sorted arrayOfElements: " + this.arrayOfElements);
    console.log("nombre de user par Entreprise: " + this.arrayContingElements);
    // return this.sortedArray;
  }

  sortUsersByStatut(){
    // Réinitialisation
    this.arrayOfElements = [];
    this.sortedArray = [];
    this.arrayContingElements = [];

    // Listing des entreprises de tous les users dans un array
    for(let user of this.users){
      if(!this.arrayOfElements.includes(user.statut)) this.arrayOfElements.push(user.statut);
    }

    // Tri de la liste des users ordonnée par Entreprise et on compte le nombre user dans chaque Entreprise dans l'ordre
    for(let item of this.arrayOfElements){  
      let i = 0;
      for(let user of this.users){
        if(user.statut == item){
          this.sortedArray.push(user);
          this.arrayContingElements.push(i++);
        } 
      }
    }

    // console.log("sorted arrayOfElements: " + this.arrayOfElements);
    // console.log("nombre de user par Entreprise: " + this.arrayContingElements);
    // return this.sortedArray;
  }

  sortUsersByFonction(){
    // Réinitialisation
    this.arrayOfElements = [];
    this.sortedArray = [];
    this.arrayContingElements = [];

    // Listing des entreprises de tous les users dans un array
    for(let user of this.users){
      if(!this.arrayOfElements.includes(user.fonction)) this.arrayOfElements.push(user.fonction);
    }

    // Tri de la liste des users ordonnée par Entreprise et on compte le nombre user dans chaque Entreprise dans l'ordre

    for(let item of this.arrayOfElements){  
      let i = 0;
      for(let user of this.users){
        if(user.fonction == item){
          this.sortedArray.push(user);
          this.arrayContingElements.push(i++);
        } 
      }
    }
   
    // console.log("sorted arrayOfElements: " + this.arrayOfElements);
    // console.log("nombre de user par Entreprise: " + this.arrayContingElements);
    // return this.sortedArray;
  }

  sortUsersByModule(){
    // Réinitialisation
    this.arrayOfElements = [];
    this.sortedArray = [];
    this.arrayContingElements = [];

    // Listing des entreprises de tous les users dans un array
    for(let user of this.users){
      if(!this.arrayOfElements.includes(user.module)) this.arrayOfElements.push(user.module);
    }

    // Tri de la liste des users ordonnée par Entreprise et on compte le nombre user dans chaque Entreprise dans l'ordre

    for (let item of this.arrayOfElements){  
      let i = 0;
      for (let user of this.users){
        if (user.module == item){
          this.sortedArray.push(user);
          this.arrayContingElements.push(i++);
        } 
      }
    }
   
    // console.log("sorted arrayOfElements: " + this.arrayOfElements);
    // console.log("nombre de user par Entreprise: " + this.arrayContingElements);
    // return this.sortedArray;
  }

  sortUsersByProjet(){
    // Réinitialisation
    this.arrayOfElements = [];
    this.sortedArray = [];
    this.arrayContingElements = [];

    // Listing des entreprises de tous les users dans un array
    for (let user of this.users){
      if (!this.arrayOfElements.includes(user.projet)) this.arrayOfElements.push(user.projet);
    }

    // Tri de la liste des users ordonnée par Entreprise et on compte le nombre user dans chaque Entreprise dans l'ordre

    for (let item of this.arrayOfElements){  
      let i = 0;
      for (let user of this.users){
        if (user.projet == item){
          this.sortedArray.push(user);
          this.arrayContingElements.push(i++);
        } 
      }
    }
   
    // console.log("sorted arrayOfElements: " + this.arrayOfElements);
    // console.log("nombre de user par Entreprise: " + this.arrayContingElements);
    // return this.sortedArray;
  }

  sortUsersByConnecte(){
    // Réinitialisation
    this.arrayOfElements = [];
    this.sortedArray = [];
    this.arrayContingElements = [];

    //Listing des entreprises de tous les users dans un array
    for (let user of this.users){
      if (!this.arrayOfElements.includes(user.connected)) this.arrayOfElements.push(user.connected);
    }

    // Tri de la liste des users ordonnée par Entreprise et on compte le nombre user dans chaque Entreprise dans l'ordre

    for (const item of this.arrayOfElements){
      let i = 0;
      for (const user of this.users){
        if (user.connected === item){
          this.sortedArray.push(user);
          this.arrayContingElements.push(i++);
        }
      }
    }

    // console.log('sorted arrayOfElements: ' + this.arrayOfElements);
    // console.log('nombre de user par Entreprise: ' + this.arrayContingElements);
    // return this.sortedArray;
  }

  getEntreprise(eseNom: string){
    for (let entreprise of this.entreprises){
      if(eseNom === entreprise.nom) return entreprise.logo
    }
  }

  isInPast7Days(date: Date){
    if(this.before7Days <= new Date(date) && new Date(date) <= this.dateActuelle) return true
    else return false 
  }

  viewMore(){
    this.maxToDisplay = this.maxToDisplay + 20
  }

}
