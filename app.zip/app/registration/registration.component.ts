import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { StatService } from '../services/statistique.service';
import { UserList } from '../services/user-list.service';
import { EntrepriseList } from '../services/entreprise-list.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit, OnDestroy {

  isLinear = true
  firstFormGroup: FormGroup
  secondFormGroup: FormGroup
  thirdFormGroup: FormGroup
  fourthFormGroup: FormGroup

  // step 1
  compte: string = ""
  // step 2
  nom: string = ""
  prenom: string = ""
  fonction: string = ""
  tags: string[] = []
  photoProfil: File = null;
  adresse: string = ""
  adresse2: string = ""
  codePostal: number = 0
  ville: string = ""
  pays: string = ""
  tel: number = 0
  email: string = ""
  // step 3
  entreprise: string = ""
  base: string = ""
  formDisplayed: boolean = false
  // step 4
  projet: string = ""
  secteur: string = ""
  equipe: string = ""
  isReferent: string = ""
  referentNom: string = ""
  // step final
  emailPro = ""
  mdpPro = ""

  // Données de la BDD
  listeEntreprises: any[] = []
  listeEntreprisesBases: any[] = []
  referents: any[] = []
  listReferents: any[] = []

  listSubscription = <Subscription[]>[]

  constructor(private _formBuilder: FormBuilder, private entrepriseService: EntrepriseList, private userService: UserList, private statService: StatService) {}

  ngOnInit() {
    // Récupération de la liste des entreprise et base
    const variable = this.statService.getEntreprisesFromFiches().subscribe((res) => {
      this.listeEntreprises = JSON.parse(JSON.stringify(res)).data
    });
    this.listSubscription.push(variable)

    const variable2 = this.statService.getEntreprisesBasesFromFiches().subscribe((res) => {
      this.listeEntreprisesBases = JSON.parse(JSON.stringify(res)).data
    });
    this.listSubscription.push(variable2)

    const variable3 = this.userService.getReferents().subscribe((res) => {
      this.referents = JSON.parse(JSON.stringify(res)).data
      for (let ref of this.referents) this.listReferents.push(ref.prenom + ' ' + ref.nom)
    });
    this.listSubscription.push(variable2)

    // Formulaires
    this.firstFormGroup = this._formBuilder.group({
      typeCompte: ['', Validators.required]
    })
    this.secondFormGroup = this._formBuilder.group({
      nom: ['', Validators.required],
      prenom: ['', Validators.required],
      fonction: ['', Validators.required],
      tags: ['', Validators.required],
      adresse: ['', Validators.required],
      adresse2: [''],
      codePostal: ['', Validators.required],
      ville: ['', Validators.required],
      pays: ['', Validators.required],
      tel: ['', [Validators.required, Validators.pattern("^[0-9]*$")]],
      email: ['', [Validators.required, Validators.email]],
    })
    if(this.compte === 'Interne'){
      this.thirdFormGroup = this._formBuilder.group({
        entreprise: ['', Validators.required],
      })
    }
    else {
      this.thirdFormGroup = this._formBuilder.group({
        entreprise: ['', Validators.required],
        base: ['', Validators.required],
      })
    }
    this.fourthFormGroup = this._formBuilder.group({
      projet: ['', Validators.required],
      secteur: ['', Validators.required],
      equipe: ['', Validators.required],
      isReferent: ['', Validators.required],
      referentNom: ['', Validators.required],
    })
  }

  init(){
    if(this.compte === 'Interne'){
      this.thirdFormGroup = this._formBuilder.group({
        entreprise: ['', Validators.required],
      })
    }
    else {
      this.thirdFormGroup = this._formBuilder.group({
        entreprise: ['', Validators.required],
        base: ['', Validators.required],
      })
    }
  }

  ngOnDestroy(): void {
    this.listSubscription.map((elem) => elem.unsubscribe())
  }

  handleFileInput(files: FileList) {
    this.photoProfil = files.item(0);
    console.log(files.item(0))
  }

  onDisplayForm(){
    this.formDisplayed = true;
  }

  creation() {
    // Varibles
    let listags = ""
    let photo = ""
    let isRef = false
    let refNom = ""
    // Préparation des varibales à insérer dans la BDD avec la bonne notation
    if (this.tags.length !== 0) {
      for (let tag of this.tags) {
        listags += tag + "/"
      }
    }
    if (this.isReferent === 'Oui')  isRef = true
    if(this.referentNom !== 'Aucun')  refNom = this.referentNom
    //Générer de nouveaux identifiants
    //VERIFIER si le mail générer existe déjà dans la BDD (dans ce cas en générer un nouveau)
    if(this.compte === "Interne") this.emailPro = this.prenom.toLowerCase().charAt(0) + this.nom.toLowerCase() + "@gtp-conseil.fr";
    if(this.compte == "Externe") this.emailPro = this.prenom.toLowerCase().charAt(0) + this.nom.toLowerCase() + "@gtp-conseil.client.fr";
    this.mdpPro = Math.random().toString(36).slice(-8);
    // A MODIFIER (car ici photo ajoutée provient du dossier images et n'est pas enregistré MAIS plutard elle devra être enregistrée dans la BDD)
    if (this.photoProfil != null) {
      photo = "../assets/images/" + this.photoProfil.name
      
      // Insertion
      this.userService.dataToAdd = []
      this.userService.dataToAdd.push({id: 0, tags: listags, nom: this.nom, prenom: this.prenom, image: photo, entreprise: this.entreprise, base: this.base, dateCreationCompte: new Date(), fonction: this.fonction, statut: this.compte, module: this.secteur, equipe: this.equipe, projet: this.projet, connected: false, emailPerso: this.email, emailPro: this.emailPro, mdpPro: this.mdpPro, isReferant: isRef, referantNom: refNom, domaineTravail: null, adresse: this.adresse, adresse2: this.adresse2, codePostal: this.codePostal, ville: this.ville, pays: this.pays, tel: this.tel.toString(), fax: null});
      const variable  = this.userService.postUserToServer().subscribe(
          () => {
              console.log('Données des user sauvegardées !')
              this.onReset()
          },
          (error) => {
              console.log('Erreur ! : ' + error);
          }
      );
      //Détruite la souscription
      this.listSubscription.push(variable)
    }
    else {
      this.entrepriseService.dataEntrepriseNom = []
      this.entrepriseService.dataEntrepriseNom.push(this.entreprise)
      const variable = this.entrepriseService.getEntrepriseSpecifique().subscribe((res) => {
        photo = JSON.parse(JSON.stringify(res)).data[0].logo

        // Insertion
        this.userService.dataToAdd = []
        this.userService.dataToAdd.push({id: 0, tags: listags, nom: this.nom, prenom: this.prenom, image: photo, entreprise: this.entreprise, base: this.base, dateCreationCompte: new Date(), fonction: this.fonction, statut: this.compte, module: this.secteur, equipe: this.equipe, projet: this.projet, connected: false, emailPerso: this.email, emailPro: this.emailPro, mdpPro: this.mdpPro, isReferant: isRef, referantNom: refNom, domaineTravail: null, adresse: this.adresse, adresse2: this.adresse2, codePostal: this.codePostal, ville: this.ville, pays: this.pays, tel: this.tel.toString(), fax: null});
        const variable  = this.userService.postUserToServer().subscribe(
            () => {
                console.log('Données des users sauvegardées !')
                this.onReset()
            },
            (error) => {
                console.log('Erreur ! : ' + error);
            }
        );
        //Détruite la souscription
        this.listSubscription.push(variable)
      });
      //Détruite la souscription
      this.listSubscription.push(variable)
    }

    

    
  }

  onReset() {
    this.firstFormGroup.reset()
    this.secondFormGroup.reset()
    this.thirdFormGroup.reset()
    this.fourthFormGroup.reset()
  }

  sendMail() {}

  sendSMS() {}

  getBaseOfEntreprise(entreprise: string) {
    let listBases = []
    for(let item of this.listeEntreprisesBases) {
      if (entreprise === item.entreprise)  listBases.push(item.url)
    }
    return listBases
  }
}
