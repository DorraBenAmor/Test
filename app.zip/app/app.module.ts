import { FormsModule } from '@angular/forms';
import { BrowserModule, Title } from '@angular/platform-browser';
import { NgModule, LOCALE_ID, NO_ERRORS_SCHEMA } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http'
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSelectModule } from '@angular/material/select';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatMenuModule } from '@angular/material/menu';
import { EditorModule, TINYMCE_SCRIPT_SRC } from '@tinymce/tinymce-angular';
import { MatTabsModule } from '@angular/material/tabs';
import { SocketIoModule, SocketIoConfig } from 'ngx-socket-io';
import { Subject } from 'rxjs';
import { MatBadgeModule } from '@angular/material/badge';
import { ChartsModule } from 'ng2-charts';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDatepickerModule } from '@angular/material/datepicker'; 
import { MatMomentDateModule } from "@angular/material-moment-adapter";
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { ToastrModule } from 'ngx-toastr';
import { MatDialogModule } from '@angular/material/dialog'
import { MatInputModule } from '@angular/material/input'
import { MatStepperModule } from '@angular/material/stepper';

//Importation pour le calendrier
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CommonModule } from '@angular/common';
import { FlatpickrModule } from 'angularx-flatpickr';
import { CalendarModule, DateAdapter, CalendarDateFormatter, CalendarMomentDateFormatter, MOMENT } from 'angular-calendar';
//import { adapterFactory } from 'angular-calendar/date-adapters/date-fns';
import { NgbModalModule } from '@ng-bootstrap/ng-bootstrap';
import * as moment from 'moment-timezone';
import { adapterFactory } from 'angular-calendar/date-adapters/moment';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MenuComponent } from './menu/menu.component';
import { Routes, RouterModule } from '@angular/router';
import { InscriptionCheckService } from './services/inscription-check.service';
import { ConnexionService } from './services/connexion.service';
import { EntrepriseList } from './services/entreprise-list.service';
import { UserList } from './services/user-list.service';
import { TagService } from './services/tag.service';
import { UserListComponent } from './user-list/user-list.component';
import { ConnexionComponent } from './connexion/connexion.component';
import { HeaderComponent } from './header/header.component';
import { Erreur404Component } from './erreur404/erreur404.component';
import { ConnexionGuardService } from './services/connexion-guard.service';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CollaborateursComponent } from './collaborateurs/collaborateurs.component';
import { TimelineData } from './services/timeline-data.service';
import { FriseComponent } from './frise/frise.component';
import { TimelineComponent } from './timeline/timeline.component';
import { CalendarService } from './services/calendar.service';
import { MessagerieTicketsService } from './services/messagerie_tickets.service';
import { StatistiquesTicketsService } from './services/statistiques_tickets.service';
import { NotificationService } from './services/notification.service';
import { CalendrierComponent } from './calendrier/calendrier.component';
import { Calendar2Component } from './calendar2/calendar2.component';
import { MessagerieTicketsComponent } from './messagerie-tickets/messagerie-tickets.component';
import { ChiffresComponent } from './chiffres/chiffres.component';
import { TableauTicketComponent } from './tableau-ticket/tableau-ticket.component';
import { StatistiquesTicketComponent } from './statistiques-ticket/statistiques-ticket.component';
import { GrapheNiveau1TicketComponent } from './graphe-niveau1-ticket/graphe-niveau1-ticket.component';
import { GrapheNiveau2TicketComponent } from './graphe-niveau2-ticket/graphe-niveau2-ticket.component';
import { DoughnutChartTicketComponent } from './doughnutchart-ticket/doughnut-chart-ticket.component';
import { DoughnutchartReponseComponent } from './doughnutchart-reponse/doughnutchart-reponse.component';
import { DoughnutchartResolutionComponent } from './doughnutchart-resolution/doughnutchart-resolution.component';
import { BaseComponent } from './creationBase/creationBase/basecomponent';
import { BaseService } from './services/base.service';
import { FAQComponent } from './faq/faq.component';
import { BaseListComponent } from './base-list/base-list.component';
import { ModuleList} from 'src/app/services/module-list.service';
import { FAQService } from './services/faq.service';
import { FAQVisualComponent } from './faqvisual/faqvisual.component';
import { FAQVisualcontainerComponent } from './faqvisualcontainer/faqvisualcontainer.component';
import { UpdateBaseComponent } from './update-base/update-base.component';
import { BaseConfirmeComponent } from './base-confirme/base-confirme.component';
import { ListBaseComponent } from './list-base/list-base.component';
import { AuthService } from './services/auth.service';
import { DataLoadingService } from './services/dataLoading.service';
import { StatService } from './services/statistique.service'
import { updateSousModuleService } from './services/update-sousmodule.service';

import { RegistrationComponent } from './registration/registration.component';
import { GrapheEvolutifGlobalComponent } from './graphe-evolutif-global/graphe-evolutif-global.component';
import { GrouppementGrapheEvolutifComponent } from './grouppement-graphe-evolutif/grouppement-graphe-evolutif.component';
import { GrapheEvolutifFiltreComponent } from './graphe-evolutif-filtre/graphe-evolutif-filtre.component';
import { DialogComponent } from './dialog/dialog.component';



const appRoutes: Routes = [
  { path: '',  component: ConnexionComponent },
  { path: 'dashboard',  component: DashboardComponent},
  { path: 'registration', component: RegistrationComponent },
  { path: 'chiffres', component: ChiffresComponent },
  { path: 'collaborateurs', component: UserListComponent },
  { path: 'userlist', component: UserListComponent },
  { path: 'timeline', component: TimelineComponent },
  { path: 'calendrier',  component: CalendrierComponent },
  { path: 'bugtracking_messagerie',  component: MessagerieTicketsComponent },
  { path: 'bugtracking_tableau', component: TableauTicketComponent },
  { path: 'bugtracking_statistiques', component: StatistiquesTicketComponent },
  { path: 'faq', component: FAQComponent},
  { path: 'faqvisual', component: FAQVisualComponent},
  { path: 'faqvisualcontainer', component: FAQVisualcontainerComponent},
  { path: 'base', component: BaseComponent},
  { path: 'listbase', component: ListBaseComponent},
  { path: 'updater', component: UpdateBaseComponent},
  { path: 'baselist', component: BaseListComponent},
  //{ path: '', component: ConnexionComponent },
 // { path: 'not-found', component: Erreur404Component},
  { path: '**', redirectTo: '/connexion'}
];

export function momentAdapterFactory() {
  return adapterFactory(moment);
}

const config: SocketIoConfig = { url: 'http://localhost:3000', options: {} };

@NgModule({
  declarations: [
    AppComponent,
    MenuComponent,
    UserListComponent,
    ConnexionComponent,
    HeaderComponent,
    Erreur404Component,
    DashboardComponent,
    CollaborateursComponent,
    FriseComponent,
    TimelineComponent,
    CalendrierComponent,
    Calendar2Component,
    MessagerieTicketsComponent,
    ChiffresComponent,
    TableauTicketComponent,
    StatistiquesTicketComponent,
    GrapheNiveau1TicketComponent,
    GrapheNiveau2TicketComponent,
    DoughnutChartTicketComponent,
    DoughnutchartReponseComponent,
    DoughnutchartResolutionComponent,
    BaseComponent,
    FAQComponent,
    FAQVisualcontainerComponent,
    FAQVisualComponent,
    BaseListComponent,
    UpdateBaseComponent,
    ListBaseComponent,
    BaseConfirmeComponent,
    RegistrationComponent,
    GrapheEvolutifGlobalComponent,
    GrouppementGrapheEvolutifComponent,
    GrapheEvolutifFiltreComponent,
    DialogComponent,
    ],
  entryComponents: [
    DialogComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot(appRoutes),
    NgbModalModule,
    FlatpickrModule.forRoot(),
    CalendarModule.forRoot({
      provide: DateAdapter,
      useFactory: adapterFactory,
    }),
    NgMultiSelectDropDownModule.forRoot(),
    BrowserAnimationsModule,
    CommonModule,
    CalendarModule.forRoot(
      {
        provide: DateAdapter,
        useFactory: momentAdapterFactory,
      },
      {
        dateFormatter: {
          provide: CalendarDateFormatter,
          useClass: CalendarMomentDateFormatter,
        },
      }
    ),
    MatToolbarModule,
    MatSidenavModule,
    MatCheckboxModule,
    MatSelectModule,
    MatTooltipModule,
    EditorModule,
    MatMenuModule,
    MatTabsModule,
    SocketIoModule.forRoot(config),
    MatBadgeModule,
    ChartsModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatMomentDateModule,
    Ng2SearchPipeModule,
    ToastrModule.forRoot(),
    MatDialogModule,
    MatInputModule,
    MatStepperModule
  ],
  providers: [
    Title,
    InscriptionCheckService,
    ConnexionService,
    ConnexionGuardService,
    EntrepriseList,
    UserList,
    TimelineData,
    CalendarService,
    TagService,
    MessagerieTicketsService,
    StatistiquesTicketsService,
    NotificationService,
    FAQService,
    Subject,
    BaseService,
    ModuleList,
    AuthService,
    DataLoadingService,
    StatService,
    updateSousModuleService,
    { provide: LOCALE_ID, useValue: "fr-FR" },
    { provide: MOMENT, useValue: moment },
    { provide: TINYMCE_SCRIPT_SRC, useValue: 'tinymce/tinymce.min.js' }
  ],
  bootstrap: [AppComponent],
  schemas: [
    NO_ERRORS_SCHEMA
  ]
})
export class AppModule { }
