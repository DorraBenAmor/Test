import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Connection } from '../models/connection.model';
import { TimelineElement } from '../models/timeline-element.model';
import { ConnexionService } from '../services/connexion.service';
import { TimelineData } from '../services/timeline-data.service';
import { DataLoadingService } from '../services/dataLoading.service';


@Component({
  selector: 'app-frise',
  templateUrl: './frise.component.html',
  styleUrls: ['./frise.component.css']
})
export class FriseComponent implements OnInit, OnDestroy {

  //DECLARATION DES VARIABLES

  // Données du user connecté
  currentUser: Connection;
  private subscription: Subscription;

  timeline: TimelineElement[] = []
  timelineArray: any[] = [];
  timelineArrayFinal: any[] = [];
  datesArray: string[] = [];
  arrayContingElements: number[] = [];
  arrayHeureOrdered: string[] = [];
  arrayHeure: string[] = [];
  arrayMotif: string[] = [];

  // Dates pour affiches les donnéees
  dateActuelle: Date
  // Page de la timeline
  before6Months: Date
  after2Weeks: Date
  maxDaysBefore: number
  maxDaysAfter: number
  // Page du dashboard
  before14Days: Date
  after14Days: Date

  // Currant page path
  currentPath: string;

  listSubscription = <Subscription[]>[];

  constructor(private connexionService: ConnexionService, private dataLoadingService: DataLoadingService, private timelineData: TimelineData, private router: Router) { }

  ngOnInit(): void {
    // Initialisation des variables
    this.currentPath = this.router.url;
    this.maxDaysBefore = 183  // 6 mois ~ 183 jours
    this.maxDaysAfter = 14  // 2 semainess ~ 14 jours
    this.dateActuelle = new Date()
    this.before6Months = new Date(this.dateActuelle.getTime() - (this.maxDaysBefore * 24 * 60 * 60 * 1000)); 
    this.after2Weeks = new Date(this.dateActuelle.getTime() + (this.maxDaysAfter * 24 * 60 * 60 * 1000)); 
    this.before14Days = new Date(this.dateActuelle.getTime() - (14 * 24 * 60 * 60 * 1000)); 
    this.after14Days = new Date(this.dateActuelle.getTime() + (14 * 24 * 60 * 60 * 1000));

    // Récupération des données du user connecté
    this.subscription = this.connexionService.connexionSubject.subscribe(datas => {
      this.currentUser = datas;
    })
    this.connexionService.emitConnection();

    // Chargement des données
    const variable = this.timelineData.getEvtFromServer().subscribe((response) => {
      //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
      for (let item of JSON.parse(JSON.stringify(response)).data) {
        if(item.userID == Number(this.currentUser.id))   this.timelineArray.push({id: item.id, eventID: item.eventID, date: item.date, heure: item.heure, motif: item.motif, userID: item.userID, isUserConcerned: item.isUserConcerned})
      }
      // On trie les données pour les afficher par date et heure 
      this.timelineArrayFinal = this.sortDataByDates();
      console.log(this.timelineArrayFinal, 'events')
    });
    //Détruire la souscription
    this.listSubscription.push(variable);
    
    // const variable = this.timelineData.getEvtFromServer().subscribe((response) => {
    //   //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
    //   for (let item of JSON.parse(JSON.stringify(response)).data) {
    //     if(item.userID == this.currentUser.id)   this.timelineArray.push({id: item.id, eventID: item.eventID, date: item.date, heure: item.heure, motif: item.motif, userID: item.userID, isUserConcerned: item.isUserConcerned})
    //   }
    //   // On trie les données pour les afficher par date et heure 
    //   this.timelineArrayFinal = this.sortDataByDates();
    // });
    // //Détruire la souscription
    // this.listSubscription.push(variable);
    
  }

  ngOnDestroy(): void {
    this.listSubscription.map((elem) => elem.unsubscribe());
    this.subscription.unsubscribe();
  }

  sortDataByDates(){
     //Réinitialisation
     this.datesArray = [];
     this.arrayContingElements = [];
     this.arrayHeure = [];
     this.arrayHeureOrdered = [];
     this.arrayMotif = [];
    
    //Tri de la liste par heure et date
    //this.timelineArray.sort((a, b) => b.heure - a.heure);
    this.timelineArray.sort((a, b) => a.heure.localeCompare(b.heure))
    //this.timelineArray.sort((a, b) => b.date - a.date);
    this.timelineArray.sort((a, b) => b.date.localeCompare(a.date))

    //Listing des données par date dans un array
    for(let element of this.timelineArray){
      if(!(this.datesArray.includes(element.date.toString()))) this.datesArray.push(element.date.toString());
    }

    //On compte le nombre de fois qu'une date spécifique apparaît et on trie les heures dans l'ordre
    for(let item of this.datesArray){  
      let i = 0;
      for(let element of this.timelineArray){
        if(element.date.toString() == item){
          this.arrayHeure.push(element.heure);
          this.arrayContingElements.push(i++);
        } 
      }
      for(let heure of this.arrayHeure.sort()){
        this.arrayHeureOrdered.push(heure);
        //On trie les motifs dans l'ordre
        for(let element of this.timelineArray){
          if(element.date.toString() == item && element.heure == heure) this.arrayMotif.push(element.motif);
        }
      }
      this.arrayHeure = [];
    }

    console.log(this.timelineArray, 'timelineArray')
    console.log(this.datesArray, 'datesArray')

    return this.timelineArray;
    
  }

  verifyDateEquality(dateString: string){
    for (let date of this.datesArray){
      if(date === dateString) return true
    }
  }

  // Pour la page de la timeline
  isInPast6MonthsAndNext2Weeks(date: Date){
    if(this.before6Months <= new Date(date) && new Date(date) <= this.after2Weeks) return true
    else return false 
  }

  viewMoreBefore(){
    this.maxDaysBefore = this.maxDaysBefore + 183
    this.before6Months = new Date(this.dateActuelle.getTime() - (this.maxDaysBefore * 24 * 60 * 60 * 1000)); 
  }

  viewMoreAfter(){
    this.maxDaysAfter = this.maxDaysAfter + 14
    this.after2Weeks = new Date(this.dateActuelle.getTime() + (this.maxDaysAfter * 24 * 60 * 60 * 1000)); 
  }

  // Pour la page du dashboard
  isInPast14DaysAndNext14Days(date: Date){
    if(this.before14Days <= new Date(date) && new Date(date) <= this.after14Days) return true
    else return false 
  }

}
