import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FriseComponent } from './frise.component';

describe('FriseComponent', () => {
  let component: FriseComponent;
  let fixture: ComponentFixture<FriseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FriseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FriseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
