import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { ConnexionService } from '../services/connexion.service';
import { UserList } from '../services/user-list.service';
import { Observable, Subscription } from 'rxjs';
import { NotificationService } from '../services/notification.service';
import { NotificationModel } from '../models/notification.model';
import { User } from '../models/user.model';
import { Connection } from '../models/connection.model';
import { ConnexionGuardService } from '../services/connexion-guard.service';
import { DataLoadingService } from '../services/dataLoading.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit, OnDestroy {
  
  //DECLARATION DES VARIABLES
  //Socket
  currentUser: Connection
  //currentUser: Connection = new Connection("", false, "", "","", "", "", "", "", "")
  private subscriptionCurrentUser: Subscription;

  tableauConnexions: Connection[] = [];
  private subscriptionTableauConnexions: Subscription;

  connectionTab: Observable<any[]>;
  currentConnection: Connection;
  private subscription: Subscription;
  newNotification: NotificationModel;
  private subscriptionNotif: Subscription;

  users: User[] = [];
  
  userNom: string;
  userPrenom: string;
  userImage: string;
  userEntreprise: string;
  href: string = "";

  notifs: NotificationModel[] = [];
  notifNumber: any[] = [];
  nbNotifOfUser: number = 0

  statut: string = ""

  listSubscription = <Subscription[]>[];

  constructor(private connexionGuardService: ConnexionGuardService, public dataLoadingService: DataLoadingService, private notificationService: NotificationService, private connexionService: ConnexionService, private userList: UserList, private router: Router) { }

  ngOnInit(): void {
    this.href = this.router.url;
    this.statut = this.connexionService.userStatut;
    
    /**Socket */
    this.connectionTab = this.connexionService.connectionTab;
    console.log(this.connectionTab, "Connection tab")
    this.subscription = this.connexionService.currentConnection.subscribe(connection => this.currentConnection = connection);
    
    // Récupération des données dues users connectés
    this.subscriptionTableauConnexions = this.connexionService.allConnectionsSubject.subscribe(datas => {
      this.tableauConnexions = datas;
      console.log(datas, 'Menu - Tableau Connected user')
    })
    this.connexionService.emitAllConnection();

    // Récupération des données du user connecté
    this.subscriptionCurrentUser = this.connexionService.connexionSubject.subscribe(datas => {
      this.currentUser = datas;
      console.log(datas, 'Menu - Connected user')
    })
    this.connexionService.emitConnection();
    console.log(this.currentUser, "current userrrrrr")

    this.subscriptionNotif = this.notificationService.newNotification.subscribe(notif => {
      this.newNotification = notif;

      //initialisation tab notifications
      this.notifNumber = [];
      for(let user of this.users){
        this.notifNumber.push({userID: user.id, nbNotif: 0});
      }
      //Ajout des 
      this.notifs.push({id: this.newNotification.id, userID: Number(this.newNotification.userID), date: new Date(this.newNotification.date), notification: this.newNotification.notification });
      for(let user of this.users){
        let nbNotifUser = 0;
        for(let notif of this.notifs){
          if(notif.userID == user.id){
            nbNotifUser++;
          }
        }
        for(let ligne of this.notifNumber){
          if(ligne.userID == user.id) ligne.nbNotif = nbNotifUser;
        }
      }
    });

    // const vare = this.userList.getUserFromServer().subscribe((response) => {
    //   //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
    //   this.users = JSON.parse(JSON.stringify(response)).data;

    //   for(let user of this.users){
    //     if(user.emailPro == this.connexionService.connectedUserEmail){
    //       this.userNom = user.nom;
    //       this.userPrenom = user.prenom;
    //       this.userImage = user.image;
    //       this.userEntreprise = user.entreprise;
    //     }
    //   }
      
    //  });
    // //Détruire la souscription
    // this.listSubscription.push(vare);

    /*
    this.notificationService.dataUserId = Number(this.currentUser.id)
    const vare = this.notificationService.getNumberNotifOfUserFromServer().subscribe((response) => {
      this.nbNotifOfUser = JSON.parse(JSON.stringify(response)).data
      console.log(this.nbNotifOfUser, "Number Notifications")
    });
    //Détruire la souscription
    this.listSubscription.push(vare);
    */
    
    //REACTIVER LA RECUPERERATION DES NOTIFICATIONS 
/*
    const variable = this.notificationService.getNotifsFromServer().subscribe((res) => {
      const vare = this.userList.getUserFromServer().subscribe((response) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
        let users = JSON.parse(JSON.stringify(response)).data;
        //initialisation tab notifications
        this.notifNumber = [];
        for(let user of users){
          this.notifNumber.push({userID: user.id, nbNotif: 0});
        }
      

        this.notifs = JSON.parse(JSON.stringify(res)).data;
        for(let user of this.users){
          let nbNotifUser = 0;
          for(let notif of this.notifs){
            if(notif.userID == user.id){
              nbNotifUser++;
            }
          }
          for(let ligne of this.notifNumber){
            if(ligne.userID == user.id) ligne.nbNotif = nbNotifUser;
          }
        }
      });
      //Détruire la souscription
      this.listSubscription.push(vare);
    });
    this.listSubscription.push(variable);*/
    
    // Initialisation
    this.chargementDonneesBDD()
    this.initialisation()
    
  }

  ngOnDestroy(){
    this.listSubscription.map((elem) => elem.unsubscribe());
    this.subscription.unsubscribe();
    this.subscriptionCurrentUser.unsubscribe();
    this.subscriptionTableauConnexions.unsubscribe();
    this.subscriptionNotif.unsubscribe();
  }

  convertStringToNumber(value: string){
    return Number(value);
  }

  convertNumberToString(value: number){
    return value.toString();
  }

  chargementDonneesBDD(){
    // Chargement des données
    // Verfication chargement des données des users
    if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.users) == true) {
      const vare = this.userList.getUserFromServer().subscribe((response) => {
        this.users = JSON.parse(JSON.stringify(response)).data;
        for(let user of this.users){
          if(user.id == Number(this.currentUser.id)){
            console.log('Found it')
            this.userNom = user.nom;
            this.userPrenom = user.prenom;
            this.userImage = user.image;
            this.userEntreprise = user.entreprise;
          }
        }
        });
      //Détruire la souscription
      this.listSubscription.push(vare);
      this.dataLoadingService.loadDataUsers()
      console.log('I am loading users data')
    }
    else{
      this.users = this.dataLoadingService.users
      for(let user of this.users){
        if(user.id == Number(this.currentUser.id)){
          console.log('Found it')
          this.userNom = user.nom;
          this.userPrenom = user.prenom;
          this.userImage = user.image;
          this.userEntreprise = user.entreprise;
        }
      }
    }
  }

  initialisation(){
    
    
  }

  onSignOut(){
    console.log(this.currentUser, "CurrentUser Test")
    console.log(this.currentConnection, "Current Connection Test")
    this.currentUser.online = false;
    this.connexionService.editConnection(this.currentUser);
    this.connexionService.deleteConnection(this.currentUser);
    this.connexionService.signOut();
    this.connexionGuardService.doLogout();
    console.log("connexion service exit: " + this.connexionService.connected);
    for(let user of this.users){
      if(user.emailPro == this.connexionService.connectedUserEmail){
        user.connected = false;
        this.userList.dataConnexionUpdate = [];
        this.userList.dataConnexionUpdate.push({id: user.id, tags: user.tags, nom: user.nom, prenom: user.prenom, image: user.image, entreprise: user.entreprise, base: user.base, dateCreationCompte: user.dateCreationCompte, fonction: user.fonction, statut: user.statut, module: user.module, equipe: user.equipe, projet: user.projet, connected: false, emailPerso: user.emailPerso, emailPro: user.emailPro, mdpPro: user.mdpPro, isReferant: user.isReferant, referantNom: user.referantNom, domaineTravail: user.domaineTravail, adresse: user.adresse, adresse2: user.adresse2, codePostal: user.codePostal, ville: user.ville, pays: user.pays, tel: user.tel, fax: user.fax});
          const variable = this.userList.updateUserConnexionToServer().subscribe(
              () => {
              console.log('Données du user mis à jour !');
              },
              (error) => {
              console.log('Erreur ! : ' + error);
              }
          );
          //Détruite la souscription
          this.listSubscription.push(variable);
        this.connexionService.connectedUserEmail = "";
        console.log("connexion service email (must be empty): " + this.connexionService.connectedUserEmail);
      }
    }
    this.router.navigate(['']);
  }
  

}
