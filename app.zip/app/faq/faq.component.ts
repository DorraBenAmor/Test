import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, AbstractControl } from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { is } from 'date-fns/locale';
import { Subscription, from } from 'rxjs';
import { InscriptionCheckService } from 'src/app/services/inscription-check.service';
import { Variable } from '@angular/compiler/src/render3/r3_ast';
import { TimelineData } from 'src/app/services/timeline-data.service';
import { ThrowStmt } from '@angular/compiler';
import { ConnexionService } from 'src/app/services/connexion.service';
import { ModuleList} from 'src/app/services/module-list.service';
import { FAQService} from 'src/app/services/faq.service';
import { faq } from '../models/faq.model';
@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.css']
})
export class FAQComponent implements OnInit {
  modules: any[]; 
  sous_modules: any[];
  dataToAdd: any[] = []; 
  submitted:boolean=false;

  listSubscription = <Subscription[]>[];
  formDisplayed: boolean = false;
  registerForm: FormGroup;
  module:string;
  sous_module:string;
  question:string;
  reponse:string;
  responsable:string;
  is_prived:number=0;
  date:Date;
  nb_like:number=0;
  nb_dislike:number=0;
  id:number;
  reactions:string='';
  faqs:faq[];
  showModal:boolean=false;
  modified:boolean=false;
  valide:boolean=false;
  clicked:boolean=false;

  constructor(private titleService: Title, private moduleList:ModuleList, private faq:FAQService, private inscriptionCheckService: InscriptionCheckService, private formBuilder: FormBuilder,private timeline: TimelineData, private connexion: ConnexionService,  private router: Router) { }
  get f() { return this.registerForm.controls; }
  ngOnInit(): void {
    this.responsable=this.connexion.userNom+" "+this.connexion.userPrenom;
    this.modules=this.moduleList.moduleSample;
    const variable = this.moduleList.getModuleFromServer().subscribe((response) => {
      //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
    
        
      this.modules = JSON.parse(JSON.stringify(response)).data;
     
             
  });
  this.registerForm = this.formBuilder.group({
    module: ['', [Validators.required]],
    sous_module: ['', [Validators.required]],
    question: ['', [Validators.required]],
    reponse: ['', [Validators.required]],
  
  
  
          });
  this.listSubscription.push(variable);
  }


  handleModule(value: string)
  {
     this.module=value;
     this.f.sous_module.reset();
    this.moduleList.clear();
    this.sous_modules=[];
    this.sous_modules=this.moduleList.moduleSample;
    this.moduleList.module=this.module;
    const variable2 = this.moduleList.getSousModuleByModuleFromServer().subscribe((response) => {
      //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
    
        
      this.sous_modules = JSON.parse(JSON.stringify(response)).data;
     
             
  });
  this.listSubscription.push(variable2);
  this.moduleList.clear();

  }
  ngOnDestroy(){
    this.listSubscription.map((elem) => elem.unsubscribe());
}    

onDisplayForm(){
  this.formDisplayed = true;
}

  handleSousModule(value: string)
  {
    this.sous_module=value;
    console.log(this.sous_module)
  }

  handleQuestion(value: string)
  {

    this.question=value;
  }

  handleReponse(value: string)
  {
    this.reponse=value;
  }
  handleIsPrived(value: number)
  {
    if(this.is_prived==1)
    {value=0;}
    else{
    value=1;
    
    }
    this.is_prived=value;
  }

  onCondition()
  {
    this.submitted = true;


    // stop here if form is invalid
   if(this.registerForm.invalid)

   { 
    console.log("Il y a une erreur de form");
    this.valide=false;
    return;
   }
   
     
     else{
     this.valide=true;
     


     }



   

    
  }


onSubmit()
{
this.submitted=true;

var identifier;
if(this.registerForm.invalid)

   { 
    console.log("Il y a une erreur de form");
    return;
   }else {
     this.faq.clear();
     this.faqs=this.faq.faqSample;
    const variable20  = this.faq.getfaqFromServer().subscribe(
      (response) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
      console.log(JSON.parse(JSON.stringify(response)).data.length);
      
        identifier=JSON.parse(JSON.stringify(response)).data.length+1;
        console.log(identifier);
      
    console.log(this.faqs)
  
      
this.faq.module=this.module;
this.faq.sous_module=this.sous_module;
this.faq.question=this.question;
this.faq.reponse=this.reponse;
this.faq.responsable=this.responsable;
this.faq.is_prived=this.is_prived;
this.faq.date=new Date();
this.date=this.faq.date;
this.faq.nb_dislike=this.nb_dislike;
this.faq.nb_like=this.nb_like;
this.faq.id=this.id;
this.faq.reactions=this.reactions;



this.faq.dataToAdd.push({id:identifier,module: this.faq.module, sous_module: this.faq.sous_module, question: this.faq.question, reponse: this.faq.reponse, is_prived: this.faq.is_prived,date:this.date,responsable:this.responsable,nb_like:this.faq.nb_like, nb_dislike:this.faq.nb_dislike,reactions:this.faq.reactions });
console.log(this.faq.dataToAdd);
  const variable  = this.faq.postfaqToServer().subscribe(
    () => {
        console.log('Données sauvegardées !');
    },
    (error) => {
        console.log('Erreur ! : ' + error);
    }
);




this.listSubscription.push(variable);
}
);
this.listSubscription.push(variable20);
this.faq.dataToAdd=[];
this.faq.dataToAdd=[];

}
}

close()
{
  if(this.modified==true)
  {
    this.router.navigate(['dashboard']);
  }

this.showModal=false;
this.modified=false;
this.clicked=false;


}

onReset() {
  this.submitted = false;
  this.registerForm.reset();
}


}
