import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BaseConfirmeComponent } from './base-confirme.component';

describe('BaseConfirmeComponent', () => {
  let component: BaseConfirmeComponent;
  let fixture: ComponentFixture<BaseConfirmeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BaseConfirmeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BaseConfirmeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
