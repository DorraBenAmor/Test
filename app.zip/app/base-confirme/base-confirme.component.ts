import { Component, OnInit, OnDestroy } from '@angular/core';
import { base } from '../models/base.model';
import { Subscription } from 'rxjs';
import { BaseService } from '../services/base.service';
import { ConnexionService } from '../services/connexion.service'; 
import { UserList } from '../services/user-list.service';
import { Title } from '@angular/platform-browser'
import * as moment from 'moment';
import { Days } from 'rrule/dist/esm/src/rrule';

@Component({
  selector: 'app-base-confirme',
  templateUrl: './base-confirme.component.html',
  styleUrls: ['./base-confirme.component.css']
})



export class BaseConfirmeComponent implements OnInit  {

  bases : base[]; 
  baseSubscription= <Subscription[]>[];; 
  nomDemandeur : string; 
  baseFiltrer : any[] = [];
  statue: number;  
  listSubscription = <Subscription[]>[];
  searchText;
  ConnectedUserFonction : string ; 
  dateConfirmation : Date; 
  dateCreation : Date ; 
  



  constructor(private baseService: BaseService, private connexion: ConnexionService , private  userService: UserList, private titleService: Title) {
   
   }

  ngOnInit() {
    this.bases=this.baseService.dataToAdd;
    this.statue=this.baseService.statue; 
    this.ConnectedUserFonction= this.connexion.userFonction; 
    this.titleService.setTitle('base');
    this.dateConfirmation= this.baseService.dateConfirmation;
  
  
const variable = this.baseService. getBaseFromServer().subscribe((response) => {
  //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template

  
    this.bases = JSON.parse(JSON.stringify(response)).data; 
    console.log(this.bases);
    this.baseFiltrer=this.bases;

});

//Détruire la souscription
this.baseSubscription.push(variable);
  
  }
  
ngOnDestroy() {
  this.listSubscription.map((elem) => elem.unsubscribe());


}
 

ConfimeDate(base){
  const dateB = moment (base.dateConfirmation);
  const dateC = moment ();
  

   if (base.statue==1 && dateB.diff (dateC, "days") <= 2) {
     return true ;

   }
  


  }



}
