import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FAQVisualComponent } from './faqvisual.component';

describe('FAQVisualComponent', () => {
  let component: FAQVisualComponent;
  let fixture: ComponentFixture<FAQVisualComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FAQVisualComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FAQVisualComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
