import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, AbstractControl } from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { is } from 'date-fns/locale';
import { Subscription } from 'rxjs';
import { InscriptionCheckService } from 'src/app/services/inscription-check.service';
import { Variable } from '@angular/compiler/src/render3/r3_ast';
import { ThrowStmt, Identifiers } from '@angular/compiler';
import { ConnexionService } from 'src/app/services/connexion.service';
import { ModuleList } from '../services/module-list.service';
import { FAQService } from '../services/faq.service';
import { stringify } from 'querystring';
import { Connection } from '../models/connection.model';


@Component({
  selector: 'app-faqvisual',
  templateUrl: './faqvisual.component.html',
  styleUrls: ['./faqvisual.component.css']
})
export class FAQVisualComponent implements OnInit {
  module:string;
  sous_module:string;
  sous_modules:any[];
  dropdownMenuElt1: string;
  dropdownMenuElt2: string;
  recents: any[]=[];
  selected:number=0;
  question: string;
  reponse: string;
  modules: any[];
  Questions: any[];
  status:string;
  listSubscription = <Subscription[]>[];
  registerForm: FormGroup;
  registerForm2: FormGroup;
  identity:number;
  nb_like:number;
  nb_dislike:number;
  react:string;
  id2:number;
  reponse2:string;
  is_prived2:number;
  is_prived:number=0;
  showModal:boolean=false;
  modified:boolean=false;

  // Données du user connecté
  currentUser: Connection;
  private subscription: Subscription;

  constructor(private titleService: Title, private connexionService: ConnexionService, private moduleList:ModuleList, private faq:FAQService, private inscriptionCheckService: InscriptionCheckService, private formBuilder: FormBuilder, private connexion: ConnexionService,  private router: Router) { }

  ngOnInit(): void {

    // Récupération des données du user connecté
    this.subscription = this.connexionService.connexionSubject.subscribe(datas => {
      this.currentUser = datas
      this.status = this.currentUser.statut
    })
    this.connexionService.emitConnection()

    this.faq.is_prived=0;
  
    this.identity=this.connexion.userID;
    this.faq.id_connected=this.identity;
    
    this.registerForm = this.formBuilder.group({
    module: ['', [Validators.required]],
    sous_module: ['', [Validators.required]],
    });
    this.registerForm2 = this.formBuilder.group({
      reponse: ['', [Validators.required]],
    });

    this.modules=this.faq.faqSample;
    
    const variable = this.moduleList.getModuleFromServer().subscribe((response) => {
      //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
      this.modules = JSON.parse(JSON.stringify(response)).data;
      console.log(this.modules);
    });
    this.listSubscription.push(variable);
    this.dropdownMenuElt1="Module";

    console.log(this.module);

    this.recents=this.faq.faqSample;
    const variable8=this.faq.getfaqFromServer().subscribe((response:any)=>{
      this.recents=response.data;
    });
    this.listSubscription.push(variable8);
    console.log(this.recents)
  }
  


  handleModule(value: string)
  { this.module=value;
    console.log(this.module);
    this.faq.module=this.module;
   
    this.sous_modules=this.moduleList.moduleSample;
    this.moduleList.module=this.module;
    const variable2 = this.moduleList.getSousModuleByModuleFromServer().subscribe((response) => {
      //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
    
        
      this.sous_modules = JSON.parse(JSON.stringify(response)).data;
      console.log(this.module);
             
  });
  this.listSubscription.push(variable2);
  console.log(this.sous_modules);
  this.moduleList.clear();

  }
  ngOnDestroy(){
    this.listSubscription.map((elem) => elem.unsubscribe());
}
handleSousModule(value: string)
{console.log(this.recents);
  this.sous_module=value;
  this.faq.sous_module=this.sous_module;
  console.log(this.sous_module)
  this.Questions=this.faq.faqSample;
  const variable3 = this.faq.getQuestionBySousModule().subscribe((response) => {
    //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
  
      
    this.Questions = JSON.parse(JSON.stringify(response)).data;
    console.log(this.Questions, 'questions')
   this.selected=1;
           
});
console.log(this.Questions);
this.listSubscription.push(variable3);
this.faq.clear();



}    
update()
{
 
  const variable8=this.faq.getfaqFromServer().subscribe((response:any)=>
  
  {
  
  this.recents=response.data;

  
  }
  
  
  );
  this.listSubscription.push(variable8);
  if(this.selected==1)
  {

  
  const variable3 = this.faq.getQuestionBySousModule().subscribe((response) => {
    //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
  
      
    this.Questions = JSON.parse(JSON.stringify(response)).data;
   this.selected=1;
           
});
console.log(this.Questions);
this.listSubscription.push(variable3);
this.faq.clear();



  }

  
}
delete(id:number)
{
this.faq.id=id;
console.log(this.faq.id);
const variable  = this.faq.deleteTable().subscribe(
  () => {
   
      console.log('deleted !');
      this.update();
  },
  (error) => {
      console.log('Erreur ! : ' + error);
  }
);

this.listSubscription.push(variable);

this.update();

}
increment(id:number,reaction:string,id_connected:number)
{
  this.faq.id=id;
console.log(this.faq.id);
if(this.verifReaction(reaction,id_connected)==false)
{ 
  const variable  = this.faq.updateLikes().subscribe(
    () => {
     
        console.log('incremented !');
    },
    (error) => {
        console.log('Erreur ! : ' + error);
    }
);

this.listSubscription.push(variable);

this.update();
  }
  else{
    const variable2  = this.faq.updateLikes2().subscribe(
      () => {
       
          console.log('incremented !');
      },
      (error) => {
          console.log('Erreur ! : ' + error);
      }
  );
  
  this.listSubscription.push(variable2);
  
  this.update();
  }
  console.log(this.verifReaction(reaction,id_connected));


}

decrement(id:number,reaction:string,id_connected:number)
{
  this.faq.id=id;
console.log(this.faq.id);
if(this.verifReaction(reaction,id_connected)==false)
{
  const variable  = this.faq.updateDislikes().subscribe(
    () => {

        console.log('incremented !');
     
    },
    (error) => {
        console.log('Erreur ! : ' + error);
    }
);

this.listSubscription.push(variable);

this.update();
  }
  else{
    if(this.react=="0")
console.log("vous avez déjà réagit avec un 'j'aime' ")
else
console.log("vous avez déjà réagit avec un 'je n'aime pas' ")

  }


}


verifReaction(reaction:string,id_connected:number){
var i=0;
var j=0;
var k=0;
var id:string='';
 this.react="";
var exist=false;

while(exist==false && k<reaction.length)
{
while(reaction[i]!==";")
{
while(reaction[j]!==":")
{
id=id+reaction[j];
j++;
i++;
k++;

}
j++;
i++;
k++
while(reaction[j]!==";")
{
this.react=this.react+reaction[j]
j++;
i++;
k++
}


}
if(id==id_connected+'')
{

exist=true;

}
j++;
i++;
k++
if(exist==false)
{
id='';
this.react='';
}
}

return exist;

}
handleReponse(value:string)
{if(value!==null)
  this.reponse=value;
  else this.reponse=this.reponse2;
this.faq.reponse=this.reponse;
console.log(this.reponse);
console.log(this.faq.id);


}
handleIsPrived()
{
 
if(this.is_prived==0)
{this.is_prived=1;}
else
this.is_prived=0;



this.faq.is_prived=this.is_prived;
console.log("this", this.is_prived);
console.log("faq",this.faq.is_prived);

}

submit(id:number)
{
  this.faq.id=id;
  console.log(this.faq.id);

const variable2  = this.faq.modifyTable().subscribe(
  () => {

      console.log('Modified !');
   
  },
  (error) => {
      console.log('Erreur ! : ' + error);
  }
);

this.listSubscription.push(variable2);
this.modified=true;
this.registerForm2.reset();
this.faq.clear();
}
close()
{

this.showModal=false;
this.modified=false;
this.update();
this.modified=false

}

set(value1:number, value2:string, value3:number)
{
this.id2=value1;
this.reponse2=value2;
this.is_prived2=value3;
this.is_prived=this.is_prived2;
console.log(this.id2);
console.log(this.reponse2);
console.log(this.is_prived2);



}
}