import { Component, OnInit, OnDestroy } from '@angular/core';
import { base } from '../models/base.model';
import { Subscription } from 'rxjs';
import { BaseService } from '../services/base.service';
import { ConnexionService } from '../services/connexion.service'; 
import { UserList } from '../services/user-list.service';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router'




@Component({
  selector: 'app-list-base',
  templateUrl: './list-base.component.html',
  styleUrls: ['./list-base.component.css']
})
export class ListBaseComponent implements OnInit, OnDestroy {
  bases : base[]; 
  baseSubscription= <Subscription[]>[];; 
  nomDemandeur : string; 
  baseFiltrer : any[] = [];
  statue: number;  
  listSubscription = <Subscription[]>[];
  searchText;
  ConnectedUserFonction : string ; 
  statut : string ; 
  



  constructor(private baseService: BaseService, private connexion: ConnexionService , private  userService: UserList, private titleService: Title, private router: Router) {
   
   }

  ngOnInit() {
    this.bases=this.baseService.dataToAdd;
    this.statue=this.baseService.statue; 
    this.ConnectedUserFonction= this.connexion.userFonction; 
    this.titleService.setTitle('base');
    this.statut=this.connexion.userStatut; 
  
  
const variable = this.baseService. getBaseFromServer().subscribe((response) => {
  //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template

  
    this.bases = JSON.parse(JSON.stringify(response)).data; 
    console.log(this.bases);
    this.baseFiltrer=this.bases;

});

//Détruire la souscription
this.baseSubscription.push(variable);
  
  }
  
ngOnDestroy() {
  this.listSubscription.map((elem) => elem.unsubscribe());


}
radioChangeHandler (event : any){

}
handleClick(selectedElt: string) {
  console.log(selectedElt);
  var type;
  switch(selectedElt)
  {
    case 'Interne':
    type=0;
    break;
    case 'prod':
    type=1;
    break;
    case 'preprod':
    type=2;
    break;

  }
      const variable = this.baseService. getBaseFromServer().subscribe((response:any) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
      
        
          this.baseFiltrer = response.data.filter(x=> x.typeBase===type)
       
      
      });
      
      //Détruire la souscription
      this.baseSubscription.push(variable);
        
  
  
    




}
Search(){
  
  
  this.bases=this.bases.filter(res=> {
    return res.nomDemandeur.toLocaleLowerCase().match(this.nomDemandeur.toLocaleLowerCase());

  }) ; 
  


}
onConfirm(code: string ){
  
  this.baseService.codeConfirmation=code;
  const variable  = this.baseService.confirmBase().subscribe(
    (response:any) => {
        console.log('Données confirmées !');
        this.update();
       
    },
    (error) => {
        console.log('Erreur ! : ' + error);
    }
);
this.listSubscription.push(variable)

this.update();
  }

  update()
{
 
  const variable = this.baseService. getBaseFromServer().subscribe((response) => {
    //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
  
    
      this.bases = JSON.parse(JSON.stringify(response)).data; 
      console.log(this.bases);
      this.baseFiltrer=this.bases;
  
  });
  
  //Détruire la souscription
  this.baseSubscription.push(variable);




  }

  

  onSupprimer(baseId: number){
   
  const variable  = this.baseService.deleteTable(baseId).subscribe(
  () => {
   
      console.log('deleted !');
  },
  (error) => {
      console.log('Erreur ! : ' + error);
  }
);

this.listSubscription.push(variable);

this.update();

}
 onModifie(base: base){
  
  console.log(base);
  this.baseService.Id=base.Id;
  console.log(this.baseService.Id);
  
  this.baseService.coordonnees=base.coordonneesSociete;
      this.baseService.responsable=base.responsable;
      this.baseService.effectifs=base.effectifs;
      this.baseService.utilisationPrev=base.utilisation;
      this.baseService.url=base.urlBase;
      this.baseService.dateLivraison=base.dateLivraison;
      this.baseService.adresseMail=base.adresseMail;
      this.baseService.coordinateur=base.coordinateurProjet;
      this.baseService.chef=base.chefProjet;
      this.baseService.type=base.typeBase;
      this.baseService.copiebase=base.copieBase;
      this.baseService.siAutres=base.autres;
      this.baseService.lieeBase=base.lieeGlobal;
      this.baseService.siOui=base.lieeGl;
      this.baseService.lieeCDF=base.lieeCDF;
      this.baseService.siOuiCDF=base.lieeC;
      this.baseService.nettoyage=base.nettoyage;
      this.baseService.sitePro=base.sitePro;
      this.baseService.siOuiSiteP=base.siteP;
      this.baseService.siteCl=base.siteCl;
      this.baseService.siOuiSiteC=base.siteC;
      this.baseService.dateCreation=base.dateCreation;
      this.baseService.statue=base.statue;
      this.baseService.forModif=true;
      console.log(this.baseService);
  
  this.router.navigate(['base']);
  




 }


  }




