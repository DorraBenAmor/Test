import { Component, OnInit, OnDestroy, ChangeDetectorRef, Input} from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Connection } from '../models/connection.model';
import { ConnexionService } from '../services/connexion.service';
import { DashboardService } from '../services/dashboard.service';
import { StatService } from '../services/statistique.service';

@Component({
  selector: 'app-graphe-evolutif-global',
  templateUrl: './graphe-evolutif-global.component.html',
  styleUrls: ['./graphe-evolutif-global.component.css']
})
export class GrapheEvolutifGlobalComponent implements OnInit, OnDestroy {

  /**Declaration des variables**/

  @Input() selectedCourbe: string;
  @Input() periode: string;

  // Données du user connecté
  currentUser: Connection;
  private subscription: Subscription;

  //Données de la BDD
  dashboardComponents: any[] = [];

  //Paramètres du line chart global
  public lineChartReadyGlobal: boolean = false;
  public lineChartOptionsGlobal;
  public lineChartLabelsGlobal: string[] = [];
  public lineChartTypeGlobal;
  public lineChartLegendGlobal;
  public lineChartDataGlobal = [];
  legendeGlobal: string;
  unite: string

  //Chemin de la page
  href: string;

  listSubscription = <Subscription[]>[];

  constructor(private router: Router, private statService: StatService, private connexionService: ConnexionService, private dashboardService: DashboardService, public cdr: ChangeDetectorRef) { }

  ngOnInit(): void {
    // Initialisation des variables
    this.href = this.router.url;
    this.lineChartOptionsGlobal = {
      responsive: true, 
      legend: {position: 'right'},
    };
    this.lineChartLegendGlobal = true;
    this.lineChartTypeGlobal = 'line';

    // Récupération des données du user connecté
    this.subscription = this.connexionService.connexionSubject.subscribe(datas => {
      this.currentUser = datas;
    })
    this.connexionService.emitConnection();

    const variable = this.dashboardService.getDashboardComponentsFromServer().subscribe((res) => {
      let donneesTab;
      for(let cmp of JSON.parse(JSON.stringify(res)).data){
          donneesTab = cmp.donnees.split(/[/*]/);
          for(let i=0; i<donneesTab.length; i++){
              if(donneesTab[i] == "") donneesTab.splice(i, 1);
          }
          this.dashboardComponents.push({id: cmp.id, userId: cmp.userId, titreComponent: cmp.titreComponent, titreDashboard: cmp.titreDashboard, donnees: donneesTab});
      }
    });
    this.listSubscription.push(variable);

    // Lancement Graphe
    this.chargementDonnees(this.selectedCourbe, this.periode)
  }

  ngOnDestroy(): void {
    this.listSubscription.map((elem) => elem.unsubscribe());
  }

  activeLegend() {
    this.lineChartLegendGlobal = !this.lineChartLegendGlobal
  }

  // Chargement du graphe
  chargementDonnees(selectedCourbe: string, periode: string){
    this.selectedCourbe = selectedCourbe
    this.periode = periode
    let color
    let dataGlobal = []
    let nbFichesResoluesGlobal = []

    // Par periode
    switch(this.periode){
      case "Tout":
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legendeGlobal = "Nombre total de tickets ouverts de toute(s) entreprise(s)";
                // Application du filtre
                this.statService.filtre = 'Global'
                const variable = this.statService.getStatNombreTicketsTout().subscribe((res) => {
                  // Récupération des données de la table StatNombreTickets
                  var statNbTickets = JSON.parse(JSON.stringify(res)).data
                  console.log(statNbTickets, 'statNbTickets')
                  //Chart Labels
                  this.lineChartLabelsGlobal = []
                  for(let row of statNbTickets){
                    this.lineChartLabelsGlobal.push(row.year)
                    dataGlobal.push(row.quantite)
                  }

                  // Graphe global
                  this.lineChartDataGlobal = [];
                  color = this.getRandomColor();
                  this.lineChartDataGlobal.push({data: dataGlobal, label: "Global", backgroundColor: [color]});
                  this.lineChartReadyGlobal = true;

                });
                this.listSubscription.push(variable);
              break;

              case "Temps de réponse": 
                this.legendeGlobal = "Moyenne du temps de réponse global de toute(s) entreprise(s)";
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Global'
                const variable2 = this.statService.getStatTempsReponseTout().subscribe((res) => {
                  // Récupération des données de la table StatTempsReponse
                  var statTempsReponse = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')
                  //Chart Labels & Affectation de valeurs pour le graphe global
                  this.lineChartLabelsGlobal = [];
                  for(let row of statTempsReponse){
                    this.lineChartLabelsGlobal.push(row.year)
                    dataGlobal.push(row.tempsReponse/row.nbTicketsConcernes)
                  }
                  
                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReadyGlobal = false;
                  // Graphe global
                  this.lineChartDataGlobal = [];
                  color = this.getRandomColor();
                  this.lineChartDataGlobal.push({data: dataGlobal, label: "Global", backgroundColor: [color]});
                  this.lineChartReadyGlobal = true;
                });
                this.listSubscription.push(variable2);
              break;

              case "Temps de résolution": 
                this.legendeGlobal = "Moyenne du temps de résolution global de toute(s) entreprise(s)";
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Global'
                const variable3 = this.statService.getStatTempsResolutionTout().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')
                  //Chart Labels
                  this.lineChartLabelsGlobal = [];
                  for(let row of statTempsResolution){
                    this.lineChartLabelsGlobal.push(row.year)
                    dataGlobal.push(row.tempsResolution)
                    nbFichesResoluesGlobal.push(row.nbTicketsConcernes)
                  }

                  // Affectation de valeurs pour le graphe global
                  for(let i=0; i<this.lineChartLabelsGlobal.length; i++){
                    if(nbFichesResoluesGlobal[i] != 0) dataGlobal[i] = (dataGlobal[i]/nbFichesResoluesGlobal[i]).toFixed(2)
                    else dataGlobal[i] = 0;
                  }
                  // Graphe global
                  this.lineChartDataGlobal = [];
                  color = this.getRandomColor();
                  this.lineChartDataGlobal.push({data: dataGlobal, label: "Global", backgroundColor: [color]});
                  this.lineChartReadyGlobal = true;
                });
                this.listSubscription.push(variable3);
              break;
            }
        break;

      case "Année":
        //Chart Labels
        this.lineChartLabelsGlobal = [];
        this.lineChartLabelsGlobal = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];
        let labels = [];
        for(let i = 1; i < 13; i++) labels.push(i);
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legendeGlobal = "Nombre total de tickets ouverts de toute(s) entreprise(s) cette année";
                this.unite = ''
                 // Application du filtre
                 this.statService.filtre = 'Global'
                 const variable3 = this.statService.getStatNombreTicketsAnnee().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statNbTickets = JSON.parse(JSON.stringify(res)).data
                  console.log(statNbTickets, 'statNbTickets')

                  // Affectation de valeurs pour le graphe global
                  for(let i=0; i<labels.length; i++){
                    dataGlobal.push(0)
                    for(let row of statNbTickets){
                      if(labels[i] === row.month) dataGlobal[i] = row.quantite
                    }
                  }

                  // Graphe global
                  this.lineChartDataGlobal = [];
                  color = this.getRandomColor();
                  this.lineChartDataGlobal.push({data: dataGlobal, label: "Global", backgroundColor: [color]});
                  this.lineChartReadyGlobal = true;
                });
                this.listSubscription.push(variable3);
              break;

              case "Temps de réponse": 
                this.legendeGlobal = "Moyenne du temps de réponse global de toute(s) entreprise(s) cette année";
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Global'
                const variable4 = this.statService.getStatTempsReponseAnnee().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsReponse= JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  // Affectation de valeurs pour le graphe global
                  for(let i=0; i<labels.length; i++){
                    dataGlobal.push(0)
                    for(let row of statTempsReponse){
                      if(labels[i] === row.month) dataGlobal[i] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2) 
                    }
                  }

                  // Graphe global
                  this.lineChartDataGlobal = [];
                  color = this.getRandomColor();
                  this.lineChartDataGlobal.push({data: dataGlobal, label: "Global", backgroundColor: [color]});
                  this.lineChartReadyGlobal = true;
                });
                this.listSubscription.push(variable4);

              break;

              case "Temps de résolution": 
                this.legendeGlobal = "Moyenne du temps de résolution global de toute(s) entreprise(s) cette année";
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Global'
                const variable5 = this.statService.getStatTempsResolutionAnnee().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')
                  
                  // Affectation de valeurs pour le graphe global
                  for(let i=0; i<labels.length; i++){
                    dataGlobal.push(0);
                    nbFichesResoluesGlobal.push(0);
                    for(let row of statTempsResolution){
                      if(labels[i] === row.month) {
                        if(row.nbTicketsConcernes !== 0)  dataGlobal[i] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)
                      }
                    }
                  }

                  // Graphe global
                  this.lineChartDataGlobal = [];
                  color = this.getRandomColor();
                  this.lineChartDataGlobal.push({data: dataGlobal, label: "Global", backgroundColor: [color]});
                  this.lineChartReadyGlobal = true;
                });
                this.listSubscription.push(variable5);
              break;
            }
        break;

      case "Mois":
        //Chart Labels
        this.lineChartLabelsGlobal = [];
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legendeGlobal = "Nombre total de tickets ouverts de toute(s) entreprise(s) ce mois-ci";
                this.unite = ''
                // Application du filtre
                this.statService.filtre = 'Global'
                const variable3 = this.statService.getStatNombreTicketsMois().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statNbTickets = JSON.parse(JSON.stringify(res)).data
                  console.log(statNbTickets, 'statNbTickets')

                  // Alimentation des données
                  for(let row of statNbTickets){
                    this.lineChartLabelsGlobal.push(row.week.substr(0, row.week.indexOf('T')))
                    dataGlobal.push(row.quantite)
                  }

                  // Graphe global
                  this.lineChartDataGlobal = [];
                  color = this.getRandomColor();
                  this.lineChartDataGlobal.push({data: dataGlobal, label: "Global", backgroundColor: [color]});
                  this.lineChartReadyGlobal = true;
                });
                this.listSubscription.push(variable3);
              break;

              case "Temps de réponse": 
                this.legendeGlobal = "Moyenne du temps de réponse global de toute(s) entreprise(s) ce mois-ci";
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Global'
                const variable4 = this.statService.getStatTempsReponseMois().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsReponse= JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  // Alimentation des données
                  for(let row of statTempsReponse){
                    this.lineChartLabelsGlobal.push(row.week.substr(0, row.week.indexOf('T')))
                    dataGlobal.push((row.tempsReponse/row.nbTicketsConcernes).toFixed(2)) 
                  }

                  // Graphe global
                  this.lineChartDataGlobal = [];
                  color = this.getRandomColor();
                  this.lineChartDataGlobal.push({data: dataGlobal, label: "Global", backgroundColor: [color]});
                  this.lineChartReadyGlobal = true;

                });
                this.listSubscription.push(variable4);
              break;

              case "Temps de résolution": 
                this.legendeGlobal = "Moyenne du temps de résolution global de toute(s) entreprise(s) ce mois-ci";
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Global'
                const variable5 = this.statService.getStatTempsResolutionMois().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')

                  // Alimentation des données
                  for(let row of statTempsResolution){
                    this.lineChartLabelsGlobal.push(row.week.substr(0, row.week.indexOf('T')))
                    if(row.nbTicketsConcernes !== 0)  dataGlobal.push((row.tempsResolution/row.nbTicketsConcernes).toFixed(2))
                    else dataGlobal.push(0)
                  }

                  // Graphe global
                  this.lineChartDataGlobal = [];
                  color = this.getRandomColor();
                  this.lineChartDataGlobal.push({data: dataGlobal, label: "Global", backgroundColor: [color]});
                  this.lineChartReadyGlobal = true;
                });
                this.listSubscription.push(variable5);
              break;
        }
        break;

      case "Semaine":
        //Chart Labels
        this.lineChartLabelsGlobal = []
        this.lineChartLabelsGlobal = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"];
        
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legendeGlobal = "Nombre total de tickets ouverts de toute(s) entreprise(s) cette semaine";
                this.unite = ''
                // Application du filtre
                this.statService.filtre = 'Global'
                const variable3 = this.statService.getStatNombreTicketsSemaine().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statNbTickets = JSON.parse(JSON.stringify(res)).data
                  console.log(statNbTickets, 'statNbTickets')

                  // Alimentation des données
                  for(let row of statNbTickets){
                    dataGlobal.push(row.quantite)
                  }

                  // Graphe global
                  this.lineChartDataGlobal = [];
                  color = this.getRandomColor();
                  this.lineChartDataGlobal.push({data: dataGlobal, label: "Global", backgroundColor: [color]});
                  this.lineChartReadyGlobal = true;
                });
                this.listSubscription.push(variable3);
              break;

              case "Temps de réponse": 
                this.legendeGlobal = "Moyenne du temps de réponse global de toute(s) entreprise(s) cette semaine";
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Global'
                const variable4 = this.statService.getStatTempsReponseSemaine().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsReponse= JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  // Alimentation des données
                  for(let row of statTempsReponse){
                    dataGlobal.push((row.tempsReponse/row.nbTicketsConcernes).toFixed(2)) 
                  }

                  // Graphe global
                  this.lineChartDataGlobal = [];
                  color = this.getRandomColor();
                  this.lineChartDataGlobal.push({data: dataGlobal, label: "Global", backgroundColor: [color]});
                  this.lineChartReadyGlobal = true;
                });
                this.listSubscription.push(variable4);
              break;

              case "Temps de résolution": 
                this.legendeGlobal = "Moyenne du temps de résolution global de toute(s) entreprise(s) cette semaine";
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Global'
                const variable5 = this.statService.getStatTempsResolutionSemaine().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')

                  // Alimentation des données
                  for(let row of statTempsResolution){
                    if(row.nbTicketsConcernes !== 0)  dataGlobal.push((row.tempsResolution/row.nbTicketsConcernes).toFixed(2))
                    else dataGlobal.push(0)
                  }

                  // Graphe global
                  this.lineChartDataGlobal = [];
                  color = this.getRandomColor();
                  this.lineChartDataGlobal.push({data: dataGlobal, label: "Global", backgroundColor: [color]});
                  this.lineChartReadyGlobal = true;
                });
                this.listSubscription.push(variable5);
              break;
        }
        break;
        
    }
  }

  chargementPeriodeDonnees(selectedCourbe: string, periode: string, debutDate: Date, finDate: Date){
    this.selectedCourbe = selectedCourbe;
    this.periode = periode;
    let debut = new Date(debutDate)
    let fin = new Date(finDate)

    //Alimentation données des graphes
    
    // Variables nécessaires pour les calculs et l'alimentation des données
    let color;
    let dataGlobal = [];

    // Chart Labels
    this.lineChartLabelsGlobal = [];
    // Par donnée
    switch(this.selectedCourbe){
      case "Nombre de tickets": 
        this.legendeGlobal = "Nombre total de tickets ouverts de toute(s) entreprise(s) durant la période saisie";
        this.unite = ''
        // Application du filtre
        this.statService.filtrePeriode = []
        this.statService.filtrePeriode.push('Global')
        this.statService.filtrePeriode.push(debut)
        this.statService.filtrePeriode.push(fin)
        const variable3 = this.statService.getStatNombreTicketsPeriodeSaisie().subscribe((res) => {
          // Récupération des données de la table StatTempsResolution
          var statNbTickets = JSON.parse(JSON.stringify(res)).data
          console.log(statNbTickets, 'statNbTickets')

          // Alimentation des données
          for(let row of statNbTickets){
            this.lineChartLabelsGlobal.push(row.week.substr(0, row.week.indexOf('T')))
            dataGlobal.push(row.quantite)
          }

          // Graphe global
          this.lineChartDataGlobal = [];
          color = this.getRandomColor();
          this.lineChartDataGlobal.push({data: dataGlobal, label: "Global", backgroundColor: [color]});
          this.lineChartReadyGlobal = true;
        });
        this.listSubscription.push(variable3);
      break;

      case "Temps de réponse": 
        this.legendeGlobal = "Moyenne du temps de réponse global de toute(s) entreprise(s) durant la période saisie";
        this.unite = '(en heure)'
        // Application du filtre
        this.statService.filtrePeriode = []
        this.statService.filtrePeriode.push('Global')
        this.statService.filtrePeriode.push(debut)
        this.statService.filtrePeriode.push(fin)
        const variable4 = this.statService.getStatTempsReponsePeriodeSaisie().subscribe((res) => {
          // Récupération des données de la table StatTempsResolution
          var statTempsReponse= JSON.parse(JSON.stringify(res)).data
          console.log(statTempsReponse, 'statTempsReponse')

          // Alimentation des données
          for(let row of statTempsReponse){
            this.lineChartLabelsGlobal.push(row.week.substr(0, row.week.indexOf('T')))
            dataGlobal.push((row.tempsReponse/row.nbTicketsConcernes).toFixed(2))
          }

          // Graphe global
          this.lineChartDataGlobal = [];
          color = this.getRandomColor();
          this.lineChartDataGlobal.push({data: dataGlobal, label: "Global", backgroundColor: [color]});
          this.lineChartReadyGlobal = true;
        });
        this.listSubscription.push(variable4);
      break;

      case "Temps de résolution": 
        this.legendeGlobal = "Moyenne du temps de résolution global de toute(s) entreprise(s) durant la période saisie";
        this.unite = '(en jour)'
        // Application du filtre
        this.statService.filtrePeriode = []
        this.statService.filtrePeriode.push('Global')
        this.statService.filtrePeriode.push(debut)
        this.statService.filtrePeriode.push(fin)
        const variable5 = this.statService.getStatTempsResolutionPeriodeSaisie().subscribe((res) => {
          // Récupération des données de la table StatTempsResolution
          var statTempsResolution = JSON.parse(JSON.stringify(res)).data
          console.log(statTempsResolution, 'statTempsResolution')

          // Alimentation des données
          for(let row of statTempsResolution){
            this.lineChartLabelsGlobal.push(row.week.substr(0, row.week.indexOf('T')))
            if(row.nbTicketsConcernes !== 0)  dataGlobal.push((row.tempsResolution/row.nbTicketsConcernes).toFixed(2))
            else dataGlobal.push(0)
          }

          // Graphe global
          this.lineChartDataGlobal = [];
          color = this.getRandomColor();
          this.lineChartDataGlobal.push({data: dataGlobal, label: "Global", backgroundColor: [color]});
          this.lineChartReadyGlobal = true;
        });
        this.listSubscription.push(variable5);
      break;
    }
  }

  // Affichage du graphe sur le dashboard
  checkCmpInDashboard(){
    let alreadyInDashboard = false;
    for(let cmp of this.dashboardComponents){
      // Vérification si le component est associé au user connecté et s'il s'agit du bon graphe
      if(cmp.userId == Number(this.currentUser.id) && cmp.titreComponent == "LineChartGlobalTicket"){
        if(cmp.donnees[0] == this.selectedCourbe && cmp.donnees[1] == this.periode)  alreadyInDashboard = true;
      }
    }
    return alreadyInDashboard;
  }

  addToDashboard(){
    this.dashboardService.dataToAdd = []
    this.dashboardService.dataToAdd.push({id: 0, userId: Number(this.currentUser.id), titreComponent: "LineChartGlobalTicket", titreDashboard: "Statistiques", donnees: "/" + this.selectedCourbe + "*" + "/" + this.periode + "*"});
    const variable = this.dashboardService.postAddDashboardComponentToServer().subscribe(
      () => {
      console.log('Component du dashboard sauvegardé !');
      },
      (error) => {
      console.log('Erreur ! : ' + error);
      }
    );
    this.listSubscription.push(variable);
  }

  removeFromDashboard(){
    for(let component of this.dashboardComponents){
      if(component.userId == Number(this.currentUser.id) && component.titreComponent == "LineChartGlobalTicket")  this.dashboardService.idOfDataToDelete = component.id;
    }
    const variable = this.dashboardService.postDeleteDashboardComponentFromServer().subscribe(
      () => {
        console.log('Component du dashboard supprimé !');
      },
      (error) => {
        console.log('Erreur ! : ' + error);
      }
    );
    this.listSubscription.push(variable);
  }

  // Quelques fonctions simples nécessaires
  getRandomColor() {
    var x = Math.floor(Math.random() * 256);
    var y = Math.floor(Math.random() * 256);
    var z = Math.floor(Math.random() * 256);
    var bgColor = "rgb(" + x + "," + y + "," + z + ", 0)";
    return bgColor;
  }

  monthDiff(d1: Date, d2: Date) {
    var months;
    months = (d2.getFullYear() - d1.getFullYear()) * 12;
    months -= d1.getMonth();
    months += d2.getMonth();
    return months <= 0 ? 0 : months;
  }

}
