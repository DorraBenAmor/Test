import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GrapheEvolutifGlobalComponent } from './graphe-evolutif-global.component';

describe('GrapheEvolutifGlobalComponent', () => {
  let component: GrapheEvolutifGlobalComponent;
  let fixture: ComponentFixture<GrapheEvolutifGlobalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GrapheEvolutifGlobalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GrapheEvolutifGlobalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
