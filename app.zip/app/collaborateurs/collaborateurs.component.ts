import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-collaborateurs',
  templateUrl: './collaborateurs.component.html',
  styleUrls: ['./collaborateurs.component.css']
})
export class CollaborateursComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
