import { Component, OnInit, OnDestroy } from '@angular/core';
import { UserList } from '../services/user-list.service';
import { Subscription } from 'rxjs';
import { FormControl } from '@angular/forms';
import { MessagerieTicketsService } from '../services/messagerie_tickets.service';


@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.css']
})
export class DialogComponent implements OnInit, OnDestroy {

  internes: any[] = []
  selectedInterne = new FormControl()
  commentaire: string = ""

  listSubscription = <Subscription[]>[]

  constructor(private userService: UserList, private messagerieService: MessagerieTicketsService) { }

  ngOnInit(): void {
    const variable5 = this.userService.getInternesHorsHotliners().subscribe((res) => {
      this.internes = JSON.parse(JSON.stringify(res)).data;
      console.log(this.internes, 'internes')
    });
    //Détruire la souscription
    this.listSubscription.push(variable5);
    console.log(this.selectedInterne, 'selectedInterne')
  }

  ngOnDestroy(){
    this.listSubscription.map((elem) => elem.unsubscribe());
  }

  
  isDisabled(){
    if(this.selectedInterne.value === null)  return true;
    else return false;
  }

  interneChoice() {
    this.messagerieService.selectedInterneTransfert = this.selectedInterne.value
    this.messagerieService.commentaireTransfert = this.commentaire
  }

}
