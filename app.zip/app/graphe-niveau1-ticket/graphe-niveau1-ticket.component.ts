import { Component, OnInit, OnDestroy, ViewChild, ChangeDetectorRef } from '@angular/core';
import { Subscription, empty } from 'rxjs';
import { DoughnutChartTicketComponent } from '../doughnutchart-ticket/doughnut-chart-ticket.component';
import { DoughnutchartReponseComponent } from '../doughnutchart-reponse/doughnutchart-reponse.component';
import { DoughnutchartResolutionComponent } from '../doughnutchart-resolution/doughnutchart-resolution.component';
import { StatistiquesTicketsService } from '../services/statistiques_tickets.service';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { Connection } from '../models/connection.model';
import { ConnexionService } from '../services/connexion.service';

@Component({
  selector: 'app-graphe-niveau1-ticket',
  templateUrl: './graphe-niveau1-ticket.component.html',
  styleUrls: ['./graphe-niveau1-ticket.component.css']
})

export class GrapheNiveau1TicketComponent implements OnInit, OnDestroy {

  @ViewChild(DoughnutChartTicketComponent) doughnutChartTicketCmp: DoughnutChartTicketComponent;
  @ViewChild(DoughnutchartReponseComponent) doughnutChartReponseCmp: DoughnutchartReponseComponent;
  @ViewChild(DoughnutchartResolutionComponent) doughnutChartResolutionCmp: DoughnutchartResolutionComponent;

  /**Déclaration des variables**/
  currentUser: Connection;
  private subscription: Subscription;
  //Paramètres DoughnutChart
  //Selection menu
  selected: string='';
  selected2:string='';
  //Choix de periode
  periode: string = "";
  //Saisie période
  debut: Date;
  fin: Date;
  erreurPeriodeManquante: boolean = false;
  erreurPeriodeIncorrect: boolean = false;

  listSubscription = <Subscription[]>[];
  stats:any[]=[];
  stats2:any[]=[];
  entreprises: any[] = []
  bases: any[] = []
  showEntreprise:boolean=false;
  showBase:boolean=false;
  base:string;
  entreprise:string;
  statut:string;
  constructor(public cdr: ChangeDetectorRef,private statistique:StatistiquesTicketsService, private connexionService: ConnexionService) { }
  handleclickCritere(value:string)
  {   
   
    console.log(this.doughnutChartReponseCmp.stats.base)
    console.log(this.doughnutChartReponseCmp.stats.entreprise)
    console.log(this.doughnutChartReponseCmp.stats.filtre)

    console.log(this.doughnutChartTicketCmp.stats.base)
    console.log(this.doughnutChartTicketCmp.stats.entreprise)
    console.log(this.doughnutChartTicketCmp.stats.filtre)


    this.selected2=value;
    this.doughnutChartTicketCmp.selected2=value;
    this.doughnutChartReponseCmp.selected2=value;
    this.doughnutChartResolutionCmp.selected2=value;
    this.doughnutChartTicketCmp.handleClickCritère(this.selected2, this.periode,[]);
    this.doughnutChartReponseCmp.handleClickCritère(this.selected2, this.periode,[]);
    this.doughnutChartResolutionCmp.handleClickCritère(this.selected2, this.periode,[]);



  }

  ngOnInit(): void {

    this.subscription = this.connexionService.connexionSubject.subscribe(datas => {
      this.currentUser = datas;
      console.log(datas, 'Current user details')
    })
    this.connexionService.emitConnection();

    //initialisation des variables
    this.statut=this.currentUser.statut;
 
    const variable3 = this.statistique.getAllFilter().subscribe((response:any) => {
      //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
        
       this.stats = response.data; 
    });
    //Détruire la souscription
    this.listSubscription.push(variable3);
    const variable5 = this.statistique.getAllFilter2().subscribe((response:any) => {
      //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
        
       this.stats2 = response.data; 
    });
    //Détruire la souscription
    this.listSubscription.push(variable5);
 
    const variable4 = this.statistique.getAllEntreprises().subscribe((response:any) => {
      //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
        
       this.entreprises = response.data; 
    });
    //Détruire la souscription
    this.listSubscription.push(variable4);

  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
    this.listSubscription.map((elem) => elem.unsubscribe());
  }

  ngAfterViewInit() {
   // this.doughnutChartTicketCmp.chargementDonneesBDD()
   //this.doughnutChartReponseCmp.chargementDonneesBDD()
   // this.doughnutChartResolutionCmp.chargementDonneesBDD()
  }

  /** Choix de période */

  handleEntreprise(value:string)
  { 
    this.statistique.entreprise= value;
    this.entreprise=value;
    this.doughnutChartTicketCmp.selectedEntreprise=value
    this.doughnutChartReponseCmp.selectedEntreprise=value;
    this.doughnutChartResolutionCmp.selectedEntreprise=value;
    
    this.doughnutChartTicketCmp.stats.entreprise=value;
    this.doughnutChartReponseCmp.stats.entreprise=value;
    this.doughnutChartResolutionCmp.stats.entreprise=value;
    console.log(value)
     
    const variable6 = this.statistique.getAllBases().subscribe((response:any) => {
      //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
        
       this.bases = response.data; 
    
       console.log(this.bases)
    
    
    
      
    });
    //Détruire la souscription
    this.listSubscription.push(variable6);
    if(this.selected!=='')
    {

      if(this.selected==='Entreprise' || this.selected==='Base - Entreprise' )
      {
  
    this.handleclickCritere(this.selected2);
  
      }
      else{
     this.handleclick(this.selected)
      }


    }
   



  }


  handleBase(value:string)
  {

    this.base=value;
    this.statistique.base=value;
    this.doughnutChartTicketCmp.stats.base=value;
    this.doughnutChartTicketCmp.selectedBase=value;
    this.doughnutChartReponseCmp.selectedBase=value;
    this.doughnutChartResolutionCmp.selectedBase=value;


    this.doughnutChartReponseCmp.stats.base=value;
    this.doughnutChartTicketCmp.stats.base=value;
    this.doughnutChartResolutionCmp.stats.base=value;
    if(this.selected!=='')
    {

      if(this.selected==='Entreprise' || this.selected==='Base - Entreprise' )
      {
  
    this.handleclickCritere(this.selected2);
  
      }
      else{
     this.handleclick(this.selected)
      }


    }
   

  }


  handleDebutInput(value: Date) {
    this.debut = value;
    console.log(this.debut)
  }

  handleFinInput(value: Date) {
    this.fin = value;
  }

  chargementPeriode(){
    this.erreurPeriodeManquante = false;
    this.erreurPeriodeIncorrect = false;
    if(this.debut == undefined || this.fin == undefined){
      this.erreurPeriodeManquante = true;
    }
    if(this.debut > this.fin){
      this.erreurPeriodeIncorrect = true;
    }
    if(this.debut <= this.fin && this.debut != undefined && this.fin != undefined){
      this.doughnutChartTicketCmp.stats.debut=this.debut;
      this.doughnutChartTicketCmp.stats.fin=this.fin;
      this.doughnutChartReponseCmp.stats.debut=this.debut;
      this.doughnutChartReponseCmp.stats.fin=this.fin;
      this.doughnutChartResolutionCmp.stats.debut=this.debut;
      this.doughnutChartResolutionCmp.stats.fin=this.fin;
      this.handleClickPeriode('Periode');
    }
  }
 
  handleClickPeriode(value: string){
    this.periode = value;
    
    if(this.selected==='Entreprise' || this.selected==='Base - Entreprise' )
    {

  this.handleclickCritere(this.selected2);

    }
    else{
   this.handleclick(this.selected)
    }
  
  }



  handleBase2(value:string)
  { this.selected='Base - Entreprise' 
  this.doughnutChartTicketCmp.selected='Base - Entreprise';
    this.doughnutChartReponseCmp.selected='Base - Entreprise';
    this.doughnutChartTicketCmp.selected='Base - Entreprise';

    this.doughnutChartResolutionCmp.selected='Base - Entreprise';
    this.base=value;
    this.statistique.base=value;
    this.doughnutChartTicketCmp.stats.base=value;
    this.doughnutChartTicketCmp.selectedBase=value;
    this.doughnutChartReponseCmp.selectedBase=value;
    this.doughnutChartResolutionCmp.selectedBase=value;


    this.doughnutChartReponseCmp.stats.base=value;
    this.doughnutChartTicketCmp.stats.base=value;
    this.doughnutChartResolutionCmp.stats.base=value;
    this.entreprise=value;
    this.doughnutChartTicketCmp.selectedEntreprise=this.currentUser.entreprise
    this.doughnutChartReponseCmp.selectedEntreprise=this.currentUser.entreprise;
    this.doughnutChartResolutionCmp.selectedEntreprise=this.currentUser.entreprise;
    
    this.doughnutChartTicketCmp.stats.entreprise=this.currentUser.entreprise;
    this.doughnutChartReponseCmp.stats.entreprise=this.currentUser.entreprise;
    this.doughnutChartResolutionCmp.stats.entreprise=this.currentUser.entreprise;
    
    this.handleclickCritere(this.selected2);

  }
  /** FIN Choix de période */

  handleclick(value: string){
   
    this.selected=value;
    console.log(this.selected);
    if(this.currentUser.statut==='Interne')
    {
    if(this.selected==='Entreprise')
    { 
      this.showEntreprise=true;
      this.showBase=false;
    }else
    {
    if(this.selected==='Base - Entreprise')
    {  this.showEntreprise=true;
      this.showBase=true;
    
   
    }
    else{
      this.showEntreprise=false;
      this.showBase=false;
      this.doughnutChartTicketCmp.handleClick(this.selected, this.periode,[]);
      this.doughnutChartReponseCmp.handleClick(this.selected, this.periode,[])
      this.doughnutChartResolutionCmp.handleClick(this.selected, this.periode,[]);
    }
  }


}
else{

  this.selected='Entreprise'
  
  this.statistique.entreprise= this.currentUser.entreprise;
  console.log( this.currentUser.entreprise);
    this.entreprise=this.currentUser.entreprise;
    this.doughnutChartTicketCmp.stats.entreprise=this.currentUser.entreprise;
    this.doughnutChartReponseCmp.stats.entreprise=this.currentUser.entreprise;
    this.doughnutChartResolutionCmp.stats.entreprise=this.currentUser.entreprise;
    const variable6 = this.statistique.getAllBases().subscribe((response:any) => {
      //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
        
       this.bases = response.data; 
    
       console.log(this.bases)
    
    
    
      
    });
    //Détruire la souscription
    this.listSubscription.push(variable6);

    this.handleclickCritere(this.selected2);

}

   // 
  }

}
