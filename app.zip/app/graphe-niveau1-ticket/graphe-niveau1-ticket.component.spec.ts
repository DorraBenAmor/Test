import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GrapheNiveau1TicketComponent } from './graphe-niveau1-ticket.component';

describe('GrapheNiveau1TicketComponent', () => {
  let component: GrapheNiveau1TicketComponent;
  let fixture: ComponentFixture<GrapheNiveau1TicketComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GrapheNiveau1TicketComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GrapheNiveau1TicketComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
