import { Component, OnInit, ViewChild, TemplateRef, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { startOfDay, endOfDay, subDays, addDays, endOfMonth, isSameDay, isSameMonth, addHours } from 'date-fns';
import { Subject } from 'rxjs';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CalendarEvent, CalendarEventAction, CalendarEventTimesChangedEvent, CalendarView, CalendarDayViewBeforeRenderEvent, CalendarMonthViewBeforeRenderEvent, CalendarWeekViewBeforeRenderEvent, } from 'angular-calendar';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CalendarService } from '../services/calendar.service';
import { Subscription } from 'rxjs';
import { TimelineData } from '../services/timeline-data.service';
import { registerLocaleData } from '@angular/common';
import localeFr from '@angular/common/locales/fr';
import { UserList } from '../services/user-list.service';
import { EntrepriseList } from '../services/entreprise-list.service';
import { ConnexionService } from '../services/connexion.service';
import { TagService } from '../services/tag.service';

import * as moment from 'moment-timezone';
import RRule from 'rrule';
import { ViewPeriod } from 'calendar-utils';


interface RecurringEvent {
  id: number,
  title: string;
  color: any;
  rrule?: {
    freq: any;
    bymonth?: number;
    bymonthday?: number;
    byweekday?: any;
  };
  quantite: number;
}

// we set the timezone to UTC to avoid issues with DST changes
// see https://github.com/mattlewis92/angular-calendar/issues/717 for more info
moment.tz.setDefault('Utc');

const colors: any = {
  blue: {
    primary: '#1e90ff',
    secondary: '#D1E8FF',
  },
  yellow: {
    primary: '#e3bc08',
    secondary: '#FDF1BA',
  },
  magenta: {
    primary: "#C91BA6",
    secondary: "#F0A1DE",
  },
  purple: {
    primary: "#A5259D",
    secondary: "#D793EE",
  },
  cyan: {
    primary: "rgb(24, 213, 219)",
    secondary: "#A9F4F2",
  },
  red: {
    primary: "rgb(247, 2, 84)",
    secondary: "#F28787",
  },
  orange: {
    primary: "#FE9006",
    secondary: "#F9B55E",
  }
};
var $: any;

@Component({
  selector: 'app-calendar2',
  //changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './calendar2.component.html',
  styleUrls: ['./calendar2.component.css']
})
export class Calendar2Component implements OnInit {

  //DECLARATION DES VARIABLES
  @ViewChild('modalContent', { static: true }) modalContent: TemplateRef<any>;
  view: CalendarView = CalendarView.Month;
  CalendarView = CalendarView;
  viewDate: Date = moment().toDate();
  modalData: {
    action: string;
    event: CalendarEvent;
  };
  refresh: Subject<any> = new Subject();
  initialEvents: CalendarEvent[] = [];
  events: CalendarEvent[] = [];
  recurringEvents: RecurringEvent[] = [];
  recurringDejeuner: RecurringEvent[] = [];
  activeDayIsOpen: boolean = true;

  viewPeriod: ViewPeriod;

  actions: CalendarEventAction[] = [
    {
      label: '<i class="fas fa-fw fa-pencil-alt text-white"></i>',
      a11yLabel: 'Edit',
      onClick: ({ event }: { event: CalendarEvent }): void => {
        this.handleEvent('Edited', event);
      },
    },
    {
      label: '<i class="fas fa-fw fa-trash-alt text-danger"></i>',
      a11yLabel: 'Delete',
      onClick: ({ event }: { event: CalendarEvent }): void => {
        this.events = this.events.filter((iEvent) => iEvent !== event);
        //this.handleEvent('Deleted', event);

        //Suprimer dans la BDD
        let color;
        if(event.color == colors.blue) color = "blue";
        else if(event.color == colors.yellow) color = "yellow";
        else if(event.color == colors.magenta) color = "magenta";
        else if(event.color == colors.purple) color = "purple";
        else if(event.color == colors.cyan) color = "cyan";
        else if(event.color == colors.red) color = "red";
        else if(event.color == colors.orange) color = "orange";
        this.calendarService.dataToDelete.push({id: Number(event.id), eventID: 0, title: event.title, start: event.start, end: event.end, color: color, longEvent: event.allDay, recursif: false, quantite: 0, jours: "", jourParMois: "", jourParAnnee: "", userID: 0});
        console.log(this.calendarService.dataToDelete, "delete item")
        //METHODE DELETE POST
        const variable  = this.calendarService.postDeleteEventInServer().subscribe(
            () => {
            console.log('Données du calendrier supprimées !');
            },
            (error) => {
            console.log('Erreur ! : ' + error);
            }
        );
        //Détruite la souscription
        this.listSubscription.push(variable);

        location.reload()
      },
    },
  ];

  registerForm: FormGroup;
  submitted = false;
  title: string;
  start: Date;
  end: string = "";
  color: any;
  selectedColor: string;
  eventType: string;
  longEvent: boolean = false;
  ajoutTimeline: boolean = false;
  userConcerned: boolean = false;
  users: any[] = [];
  entreprises: any[] = [];
  eventID: number;
  eventsLength: number;
  valid: boolean = false;
  userList_EventAdded: number[] = [];

  /**Déjeuner */
  nbPersonne: number = 0;
  recursif: boolean = false;
  jours: string = "";
  lundi: boolean = false;
  mardi: boolean = false;
  mercredi: boolean = false;
  jeudi: boolean = false;
  vendredi: boolean = false;
  jourParMois: number;
  jourParAnnee: number;
  moisParAnnee: string = "";
  addParMois: string = "";
  addParAnnee: string = "";
  numbers: number[] = []
  months: string[] = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];

  //multi select list
  disabled = false;
  limitSelection = false;
  tags: any = [];
  selectedItems: any = [];
  dropdownSettings: any = {};
  
  registerFormEdit: FormGroup;
  submitted2 = false;
  title2: string;
  start2: string;
  end2: string;
  color2: any;
  selectedColor2: string;
  eventType2: string;
  longEvent2: boolean = false;
  valid2: boolean = false;

  length: number;

  listSubscription = <Subscription[]>[];

  constructor(private cdr: ChangeDetectorRef, private tagService: TagService, private connexionService: ConnexionService, private entrepriseList: EntrepriseList, private userList: UserList, private timelineService: TimelineData, private modal: NgbModal, private calendarService: CalendarService, private formBuilder: FormBuilder, private router: Router) { }

  // convenience getter for easy access to form fields
  get f() { return this.registerForm.controls; }
  get f2() { return this.registerFormEdit.controls; }

  ngOnInit(){
    registerLocaleData(localeFr, 'fr');
    
    for(let i=1; i<=31; i++){ this.numbers.push(i)};

    //METHODE GET Tags: pour afficher dans le formulaire d'ajout d'evenemnt du template
    const variable0 = this.tagService.getTagsFromServer().subscribe((response) => {
      for(let item of JSON.parse(JSON.stringify(response)).data){
        this.tags = [
          ...this.tags,
          { item_id: this.tags.length + 1, item_text: item.tag, persoID: item.id, statut: "Tag"},
        ];
      }
     });
    //Détruire la souscription
    this.listSubscription.push(variable0);
    
    //METHODE GET Users: pour afficher dans le formulaire d'ajout d'evenemnt du template
    const variable = this.entrepriseList.getEntrepriseFromServer().subscribe((response) => {
      //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
      //////this.entreprises = JSON.parse(JSON.stringify(response)).data;
      for(let item of JSON.parse(JSON.stringify(response)).data){
        this.tags = [
          ...this.tags,
          { item_id: this.tags.length + 1, item_text: item.nom, persoID: item.id, statut: "Entreprise"},
        ];
      }
     });
    //Détruire la souscription
    this.listSubscription.push(variable);

    //METHODE GET Users: pour afficher dans le formulaire d'ajout d'evenemnt du template
    const variable2 = this.userList.getUserFromServer().subscribe((response) => {
      //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
      ////this.users = JSON.parse(JSON.stringify(response)).data;
      for(let item of JSON.parse(JSON.stringify(response)).data){
        this.tags = [
          ...this.tags,
          { item_id: this.tags.length + 1, item_text: item.prenom + " " + item.nom, persoID: item.id, statut: "User" },
        ];
        if(item.id == this.connexionService.userID) this.selectedItems = [
          ...this.selectedItems,
            { item_id: this.tags.length, item_text: item.prenom + " " + item.nom},
        ];
      }
     });
    //Détruire la souscription
    this.listSubscription.push(variable2);
    
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 2,
      allowSearchFilter: true
    };

    //METHODE GET Events
    const variable3 = this.calendarService.getEventsFromServer().subscribe((response) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template (pour editer l'evenement)
        console.log(JSON.parse(JSON.stringify(response)).data, "DATA")

        let color: any;
        for(let item of JSON.parse(JSON.stringify(response)).data){

          if(item.color == "blue") color = colors.blue;
          else if(item.color == "yellow") color = colors.yellow;
          else if(item.color == "magenta") color = colors.magenta;
          else if(item.color == "purple") color = colors.purple;
          else if(item.color == "cyan") color = colors.cyan;
          else if(item.color == "red") color = colors.red;
          else if(item.color == "orange") color = colors.orange;

          if(item.userID == this.connexionService.userID){
            if(item.recursif == 0){
              this.events = [
                ...this.events,
                {
                  id: item.id,
                  title: item.title,
                  start: new Date(item.start),
                  end: new Date(item.end),
                  color: color,
                  allDay: item.longEvent,
                  actions: this.actions,
                  resizable: {
                    beforeStart: true,
                    afterEnd: true,
                  },
                  draggable: true,
                },
              ];
            }
            else{ //recursif

              if(item.jours.length != 0){ //si ce n'est pas vide
                var days = [];
                if(item.jours.includes("/lundi")) days.push(RRule.MO);
                if(item.jours.includes("/mardi")) days.push(RRule.TU);
                if(item.jours.includes("/mercredi")) days.push(RRule.WE);
                if(item.jours.includes("/jeudi")) days.push(RRule.TH);
                if(item.jours.includes("/vendredi")) days.push(RRule.FR);
                
                  this.recurringEvents = [
                    ...this.recurringEvents,
                    {
                      id: item.id,
                      title: item.title,
                      color: color,
                      rrule: {
                        freq: RRule.WEEKLY,
                        byweekday: days,
                      },
                      quantite: item.quantite,
                    },
                  ];
              }
              if(item.jourParMois != ""){
                for(let number of this.numbers){
                  if(item.jourParMois.includes(number.toString() + "/")){

                    this.recurringEvents = [
                      ...this.recurringEvents,
                      {
                        id: item.id,
                        title: item.title,
                        color: color,
                        rrule: {
                          freq: RRule.MONTHLY,
                          bymonthday: number,
                        },
                        quantite: item.quantite,
                      },
                    ];
                  }
                }
              }
              if(item.jourParAnnee.length != 0){
                for(let number of this.numbers){
                  let monthNb = 0;
                  for(let month of this.months){
                    monthNb++;
                    if(item.jourParAnnee.includes(number.toString() + month + "/")){
                      this.recurringEvents = [
                        ...this.recurringEvents,
                        {
                          id: item.id,
                          title: item.title,
                          color: color,
                          rrule: {
                            freq: RRule.YEARLY,
                            bymonth: monthNb,
                            bymonthday: number,
                          },
                          quantite: item.quantite,
                        },
                      ];
                    }
                  }
                }
              }
            }
          }
          //On vérifie si l'utilisateur possède le tag "planning_cuisine" afin de compter le nombre de plat pour chaque jour
          if(this.connexionService.userTags.includes("planning_cuisine/")){
            if(item.recursif == 1){
              if(item.jours.length != 0){ //si ce n'est pas vide
                var days = [];
                if(item.jours.includes("/lundi")) days.push(RRule.MO);
                if(item.jours.includes("/mardi")) days.push(RRule.TU);
                if(item.jours.includes("/mercredi")) days.push(RRule.WE);
                if(item.jours.includes("/jeudi")) days.push(RRule.TH);
                if(item.jours.includes("/vendredi")) days.push(RRule.FR);
                
                  this.recurringDejeuner = [
                    ...this.recurringDejeuner,
                    {
                      id: item.id,
                      title: item.title,
                      color: color,
                      rrule: {
                        freq: RRule.WEEKLY,
                        byweekday: days,
                      },
                      quantite: item.quantite,
                    },
                  ];
              }
              if(item.jourParMois != ""){
                for(let number of this.numbers){
                  if(item.jourParMois.includes(number.toString() + "/")){

                    this.recurringDejeuner = [
                      ...this.recurringDejeuner,
                      {
                        id: item.id,
                        title: item.title,
                        color: color,
                        rrule: {
                          freq: RRule.MONTHLY,
                          bymonthday: number,
                        },
                        quantite: item.quantite,
                      },
                    ];
                  }
                }
              }
              if(item.jourParAnnee.length != 0){
                for(let number of this.numbers){
                  let monthNb = 0;
                  for(let month of this.months){
                    monthNb++;
                    if(item.jourParAnnee.includes(number.toString() + month + "/")){
                      this.recurringDejeuner = [
                        ...this.recurringDejeuner,
                        {
                          id: item.id,
                          title: item.title,
                          color: color,
                          rrule: {
                            freq: RRule.YEARLY,
                            bymonth: monthNb,
                            bymonthday: number,
                          },
                          quantite: item.quantite,
                        },
                      ];
                    }
                  }
                }
              }
            }
          }
        }
        this.initialEvents = this.events;
        console.log(this.initialEvents, "Initial Events")
        console.log(this.events, "EVENTS")
        console.log(this.recurringEvents, "RECEvents")
        console.log(this.recurringDejeuner, "RECDejeuner")
    });
    //Détruire la souscription
    this.listSubscription.push(variable3);
    
   
    this.registerForm = this.formBuilder.group({
      evenement: ['', Validators.required],
      eventType: ['', Validators.required],
      start: ['', Validators.required],
      end: ['', Validators.required],
      tags: ['', Validators.required]
    });

    /*Partie modification de l'evenement*/

    this.registerFormEdit = this.formBuilder.group({
      evenement2: ['', Validators.required],
      eventType2: ['', Validators.required],
      start2: ['', Validators.required],
      end2: ['', Validators.required]
    });
  } 

  ngOnDestroy(){
    this.listSubscription.map((elem) => elem.unsubscribe());
  }

  updateCalendarEvents(
    viewRender:
      | CalendarMonthViewBeforeRenderEvent
      | CalendarWeekViewBeforeRenderEvent
      | CalendarDayViewBeforeRenderEvent
  ): void {

    
    if (
      !this.viewPeriod ||
      !moment(this.viewPeriod.start).isSame(viewRender.period.start) ||
      !moment(this.viewPeriod.end).isSame(viewRender.period.end)
    ) {
      this.viewPeriod = viewRender.period;

      //Récupération des évènements déjeuner
      this.recurringEvents.forEach((event) => {
        const rule: RRule = new RRule({
          ...event.rrule,
          dtstart: moment(viewRender.period.start).startOf('day').toDate(),
          until: moment(viewRender.period.end).endOf('day').toDate(),
        });
        const { title, color } = event;

        rule.all().forEach((date) => {
          let permissionToPush = true;
          for(let e of this.events){
            if(e.id == event.id){
              if(e.start.getTime() == moment(date).toDate().getTime()){ //getTime(): renvoie le nb de millisecondes écoulés depuis 1970
                permissionToPush = false;
              }
            } 
          }
          if(permissionToPush == true){
            this.events.push({
              id: event.id,
              title,
              color,
              start: moment(date).toDate(),
            });
          }

        });
      });
      this.cdr.detectChanges();

      //Calcul du nombre de dejeuner
      this.recurringDejeuner.forEach((event) => {
        const rule: RRule = new RRule({
          ...event.rrule,
          dtstart: moment(viewRender.period.start).startOf('day').toDate(),
          until: moment(viewRender.period.end).endOf('day').toDate(),
        });
        const { title, color } = event;
        
        rule.all().forEach((date) => {
          let permissionToPush2 = true;
          let quantite = 0;
          for(let e of this.events){ 
            if(e.title.includes("REPAS x")){
              if(e.start.getTime() == moment(date).toDate().getTime()){ //getTime(): renvoie le nb de millisecondes écoulés depuis 1970
                permissionToPush2 = false;
                //On modifie l'evenement en question avec la bonne quantité de repas du jour
                quantite = Number(e.title.substring(7)) + event.quantite;
                e.title = "REPAS x" + quantite.toString();
              }
            }
          }
          if(permissionToPush2 == true){
            quantite = event.quantite;
            this.events.push({
              id: event.id,
              title: "REPAS x" + quantite.toString(),
              color,
              start: moment(date).toDate(),
            });
          }
        }); 
      });
      this.cdr.detectChanges();
      

      console.log(this.events, "EVENTS")
    }
  }

  /**Form add Event */
  handleEvenementInput(value: string) {
    this.title = value;
  }
  handleEventTypeInput(value: string) {
    this.eventType = value;
  }
  handleStartInput(value: Date) {
    this.start = value;
    console.log(value, "START")
    console.log(new Date(value), "START")
  }
  handleEndInput(value: string) {
    this.end = value;
  }
  handleTagsInput(value) {
    this.tags = value;
  }
  handleJourParMoisInput(value: number) {
    this.jourParMois = value;
    console.log(this.jourParMois, "J/M")
  }
  handleJourParAnneeInput(value: number) {
    this.jourParAnnee = value;
    console.log(this.jourParAnnee, "J/A")
  }
  handleMoisParAnneInput(value: string) {
    this.moisParAnnee = value;
    console.log(this.moisParAnnee, "M/A")
  }
  handleNbPersonneInput(value) {
    this.nbPersonne = value;
  }
  onCheckedLongEvent(e) {
    if (e.target.checked) {
      this.longEvent = true;
    } 
  }
  onCheckedAjoutTimeline(e) {
    if (e.target.checked) {
      this.ajoutTimeline = true;
    } 
  }
  onCheckedUserConcerned(e) {
    if (e.target.checked) {
      this.userConcerned = true;
    } 
  }
  onCheckedRecursif(e){
    if (e.target.checked) {
      this.recursif = true;
    } 
    else{
      this.recursif = false;
    }
    console.log(this.recursif)
  }
  onCheckedLundi(e){
    if (e.target.checked) {
      this.lundi = true;
    } 
  }
  onCheckedMardi(e){
    if (e.target.checked) {
      this.mardi = true;
    } 
  }
  onCheckedMercredi(e){
    if (e.target.checked) {
      this.mercredi = true;
    } 
  }
  onCheckedJeudi(e){
    if (e.target.checked) {
      this.jeudi = true;
    } 
  }
  onCheckedVendredi(e){
    if (e.target.checked) {
      this.vendredi = true;
    } 
  }

  /**Form Edit Event */
  handleEvenementInput2(value: string) {
    this.title2 = value;
  }
  handleEventTypeInput2(value: string) {
    this.eventType2= value;
  }
  handleStartInput2(value: string) {
    this.start2 = value;
  }
  handleEndInput2(value: string) {
    this.end2 = value;
  }
  onCheckedLongEvent2(e) {
    if (e.target.checked) {
      this.longEvent2 = true;
    } 
  }

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.registerForm.invalid) {
        return;
    }
    else{
      this.valid = true;
      if(this.eventType == "RDV") {
        this.color = colors.blue;
        this.selectedColor = "blue";
      }
      else if(this.eventType == "Réunion") {
        this.color = colors.purple;
        this.selectedColor = "purple";
      }
      else if(this.eventType == "Entretien d'embauche") {
        this.color = colors.cyan;
        this.selectedColor = "cyan";
      }
      else if(this.eventType == "Dépôt projet") {
        this.color = colors.red;
        this.selectedColor = "red";
      }
      else if(this.eventType == "Déjeuner") {
        this.color = colors.orange;
        this.selectedColor = "orange";
      }
      else if(this.eventType == "Autres") {
        this.color = colors.yellow;
        this.selectedColor = "yellow";
      }

      
      /** On spécifie les détails de l'évènement **/
      var days = [];
      if(this.lundi == true) {this.jours = this.jours + "/lundi"; days.push(RRule.MO);};
      if(this.mardi == true) {this.jours = this.jours + "/mardi"; days.push(RRule.TU);};
      if(this.mercredi == true) {this.jours = this.jours + "/mercredi"; days.push(RRule.WE);};
      if(this.jeudi == true) {this.jours = this.jours + "/jeudi"; days.push(RRule.TH);};
      if(this.vendredi == true) {this.jours = this.jours + "/vendredi"; days.push(RRule.FR);};

      //On récupère les users
      const variable5 = this.userList.getUserFromServer().subscribe((response) => {
        this.users = JSON.parse(JSON.stringify(response)).data;
      });
      //Détruire la souscription
      this.listSubscription.push(variable5);
      
      let count = 0;
      //On récupère le nombre d'evenements
      const variable6 = this.calendarService.getEventsFromServer().subscribe((response) => {
        this.eventsLength = JSON.parse(JSON.stringify(response)).data.length;

        if(this.recursif == true){
          if(!(this.jours == "")){
            this.recurringEvents = [
              ...this.recurringEvents,
              {
                id: this.eventsLength + 1,
                title: this.title,
                color: this.color,
                rrule: {
                  freq: RRule.WEEKLY,
                  byweekday: days,
                },
                quantite: this.nbPersonne,
              }
            ];
          }
          for(let number of this.numbers){
            if(number == this.jourParMois){
              this.recurringEvents = [
                ...this.recurringEvents,
                {
                  id: this.eventsLength + 1,
                  title: this.title,
                  color: this.color,
                  rrule: {
                    freq: RRule.MONTHLY,
                    bymonthday: this.jourParMois,
                  },
                  quantite: this.nbPersonne,
                }
              ];
              this.addParMois = this.jourParMois.toString() + "/";
            }
          }
          for(let number of this.numbers){
            if(number == this.jourParAnnee && this.months.includes(this.moisParAnnee) ){
              var mois;
              for(let i=1; i<=12; i++){
                if(this.months[i] == this.moisParAnnee) mois = i;
              }
              this.recurringEvents = [
                ...this.recurringEvents,
                {
                  id: this.eventsLength + 1,
                  title: this.title,
                  color: this.color,
                  rrule: {
                    freq: RRule.YEARLY,
                    bymonth: mois,
                    bymonthday: this.jourParAnnee,
                  },
                  quantite: this.nbPersonne,
                }
              ];
              this.addParAnnee = this.jourParAnnee.toString() + this.moisParAnnee + "/";
            }
          }
          this.eventID = this.events.length + 2;
          count = 2;
        }
        else{
          

          this.events = [
            ...this.events,
            {
              id: this.eventsLength,
              title: this.title,
              start: startOfDay(new Date(this.start)),
              end: endOfDay(new Date(this.end)),
              color: this.color,
              draggable: true,
              resizable: {
                beforeStart: true,
                afterEnd: true,
              },
            },
          ];

          console.log(this.eventsLength, "EE")
        
          this.eventID = this.events.length + 1;
          count = 1;

        }
      });
      //Détruire la souscription
      this.listSubscription.push(variable6);
      
      

       
      this.eventID = this.events.length + count;
      /**On insère l'évènement à chaque personne taggée*/
      for(let selection of this.selectedItems){
        for(let tag of this.tags){
          if(selection.item_id == tag.item_id){
            if(tag.statut == "User"){
              if(!this.userList_EventAdded.includes(tag.persoID)){

                /*Ajout de l'évènement dans le CALENDRIER*/
                console.log(this.eventsLength, "EL")
                this.userList_EventAdded.push(tag.persoID);
                
                this.calendarService.dataToAdd.push({id: this.eventsLength + 1, eventID: this.eventID, title: this.title, start: new Date(this.start), end: addHours(new Date(this.end), 2), color: this.selectedColor, longEvent: this.longEvent, recursif: this.recursif, quantite: this.nbPersonne, jours: this.jours, jourParMois: this.addParMois, jourParAnnee: this.addParAnnee, userID: tag.persoID});
                //METHODE POST
                const variable  = this.calendarService.postNewEventToServer().subscribe(
                    () => {
                    console.log('Evènement sauvegardé !');
                    },
                    (error) => {
                    console.log('Erreur ! : ' + error);
                    }
                );
                //Destruction de la souscription
                this.listSubscription.push(variable);
                //une fois ajouté, on réinitialise/vide dataToAdd
                this.calendarService.dataToAdd = [];

                /*Souhait d'ajouter l'évènement à la TIMELINE*/
                if(this.ajoutTimeline == true){
                  //Methode GET Event: to know the length of the table
                  const variable0 = this.timelineService.getEvtFromServer().subscribe((response) => {
                    this.length = JSON.parse(JSON.stringify(response)).data.length;
                  
                    //METHODE POST
                    this.timelineService.dataToAdd = [];
                    console.log(new Date(this.start), "add START")
                    this.timelineService.dataToAdd.push({id: this.length + 1, update_ID: null, base_ID: null, eventID: this.eventID, date: new Date(this.start), heure: new Date(this.start).toString().substring(16,21), motif: this.title, userID: tag.persoID, isUserConcerned: this.userConcerned});
                    const variable  = this.timelineService.postEvtToServer().subscribe(
                      () => {
                        console.log('Données de la timeline sauvegardées !');
                      },
                      (error) => {
                        console.log('Erreur ! : ' + error);
                      }
                    );
                    //Détruite la souscription
                    this.listSubscription.push(variable);

                  });
                  //Détruire la souscription
                  this.listSubscription.push(variable0);
                }
              }
            }
            if(tag.statut == "Entreprise"){
              //On récupère les entreprises
              const variable6 = this.entrepriseList.getEntrepriseFromServer().subscribe((response) => {
                this.entreprises = JSON.parse(JSON.stringify(response)).data;
                for(let entreprise of this.entreprises){
                  if(tag.persoID == entreprise.id){
                    for(let user of this.users){
                      if(user.entreprise == entreprise.nom){
                        if(!this.userList_EventAdded.includes(user.id)){

                          /*Ajout de l'évènement dans le CALENDRIER*/
                          this.userList_EventAdded.push(user.id);
                          this.calendarService.dataToAdd.push({id: this.eventsLength + 1, eventID: this.eventID, title: this.title, start: addHours(new Date(this.start), 2), end: addHours(new Date(this.end), 2), color: this.selectedColor, longEvent: this.longEvent, recursif: this.recursif, quantite: this.nbPersonne, jours: this.jours, jourParMois: this.addParMois, jourParAnnee: this.addParAnnee, userID: user.id});
                          //METHODE POST
                          const variable  = this.calendarService.postNewEventToServer().subscribe(
                              () => {
                              console.log('Evènement sauvegardé !');
                              },
                              (error) => {
                              console.log('Erreur ! : ' + error);
                              }
                          );
                          //Destruction de la souscription
                          this.listSubscription.push(variable);
                          //une fois ajouté, on réinitialise/vide dataToAdd
                          this.calendarService.dataToAdd = [];

                          /*Souhait d'ajouter l'évènement à la TIMELINE*/
                          if(this.ajoutTimeline == true){
                            //Methode GET Event: to know the length of the table
                            const variable0 = this.timelineService.getEvtFromServer().subscribe((response) => {
                              this.length = JSON.parse(JSON.stringify(response)).data.length;
                            });
                            //Détruire la souscription
                            this.listSubscription.push(variable0);
                            //METHODE POST
                            //console.log(addHours(new Date(this.start), 2).toString(), "HEURE");
                            this.timelineService.dataToAdd = [];
                            this.timelineService.dataToAdd.push({id: this.length + 1, eventID: this.eventID, update_ID: null, base_ID: null, date: new Date(this.start), heure: new Date(this.start).toString().substring(16,21), motif: this.title, userID: user.id, isUserConcerned: this.userConcerned});
                            const variable  = this.timelineService.postEvtToServer().subscribe(
                              () => {
                                console.log('Données de la timeline sauvegardées !');
                              },
                              (error) => {
                                console.log('Erreur ! : ' + error);
                              }
                            );
                            //Détruite la souscription
                            this.listSubscription.push(variable);
                          }

                        }
                      }
                    }
                  }
                }
              });
              //Détruire la souscription
              this.listSubscription.push(variable6);
            }
            if(tag.statut == "Tag"){
              const variable0 = this.userList.getUserFromServer().subscribe((response) => {
                for(let user of JSON.parse(JSON.stringify(response)).data){
                  if(user.tags.includes(tag.item_text)){
                    console.log(user.tags, "User tag")
                    console.log(tag.item_text, "tag selected")
                    if(!this.userList_EventAdded.includes(user.id)){
                      
                      /*Ajout de l'évènement dans le CALENDRIER*/
                      this.userList_EventAdded.push(user.id);
                      this.calendarService.dataToAdd.push({id: this.eventsLength + 1, eventID: this.eventID, title: this.title, start: addHours(new Date(this.start), 2), end: addHours(new Date(this.end), 2), color: this.selectedColor, longEvent: this.longEvent, recursif: this.recursif, quantite: this.nbPersonne, jours: this.jours, jourParMois: this.addParMois, jourParAnnee: this.addParAnnee, userID: user.id});
                      //METHODE POST
                      const variable  = this.calendarService.postNewEventToServer().subscribe(
                        () => {
                        console.log('Evènement sauvegardé !');
                        },
                        (error) => {
                        console.log('Erreur ! : ' + error);
                        }
                      );
                      //Destruction de la souscription
                      this.listSubscription.push(variable);
                      //une fois ajouté, on réinitialise/vide dataToAdd
                      this.calendarService.dataToAdd = [];

                      /*Souhait d'ajouter l'évènement à la TIMELINE*/
                      if(this.ajoutTimeline == true){
                        //Methode GET Event: to know the length of the table
                        const variable0 = this.timelineService.getEvtFromServer().subscribe((response) => {
                          this.length = JSON.parse(JSON.stringify(response)).data.length;
                        });
                        //Détruire la souscription
                        this.listSubscription.push(variable0);
                        //METHODE POST
                        //console.log(addHours(new Date(this.start), 2).toString(), "HEURE");
                        this.timelineService.dataToAdd = [];
                        this.timelineService.dataToAdd.push({id: this.length + 1, eventID: this.eventID, update_ID: null, base_ID: null, date: new Date(this.start), heure: new Date(this.start).toString().substring(16,21), motif: this.title, userID: user.id, isUserConcerned: this.userConcerned});
                        const variable  = this.timelineService.postEvtToServer().subscribe(
                          () => {
                            console.log('Données de la timeline sauvegardées !');
                          },
                          (error) => {
                            console.log('Erreur ! : ' + error);
                          }
                        );
                        //Détruite la souscription
                        this.listSubscription.push(variable);
                      }

                    }
                  }
                }
               });
              //Détruire la souscription
              this.listSubscription.push(variable0);
            }
          }
        }
      }

      this.onReset();
      //on actualise le component
      this.router.navigate(['calendrier']);
      //location.reload()
    }
  }

  onSubmit2(id, eventID) {
    this.submitted2 = true;

    // stop here if form is invalid
    if (this.registerFormEdit.invalid) {
      return;
    }
    else{
      this.valid2 = true;
      if(this.eventType2 == "RDV") {
        this.color2 = colors.blue;
        this.selectedColor2 = "blue";
      }
      else if(this.eventType2 == "Réunion") {
        this.color2 = colors.purple;
        this.selectedColor2 = "purple";
      }
      else if(this.eventType2 == "Entretien d'embauche") {
        this.color2 = colors.cyan;
        this.selectedColor2 = "cyan";
      }
      else if(this.eventType2 == "Dépôt projet") {
        this.color2 = colors.red;
        this.selectedColor2 = "red";
      }
      else if(this.eventType2 == "Autres") {
        this.color2 = colors.yellow;
        this.selectedColor2 = "yellow";
      }

      //Update event in calendar
      this.calendarService.dataToUpdate.push({id: id, eventID: eventID, title: this.title2, start: addHours(new Date(this.start2), 2), end: addHours(new Date(this.end2), 2), color: this.selectedColor2, longEvent: this.longEvent2, recursif: false, quantite: 0, jours: "", jourParMois: "", jourParAnnee: "", userID: this.connexionService.userID});
      //METHODE POST Update Event
      const variable  = this.calendarService.postUpdateEventInServer().subscribe(
          () => {
          console.log('Evènement mis à jour !');
          },
          (error) => {
          console.log('Erreur ! : ' + error);
          }
      );
      //Destruction de la souscription
      this.listSubscription.push(variable);
      
      //on actualise le component
      this.router.navigate(['calendrier']);
      //location.reload()
    }
  }

  onReset() {
      this.submitted = false;
      this.registerForm.reset();
  }

  dayClicked({ date, events }: { date: Date; events: CalendarEvent[] }): void {
    console.log("here")
    if (isSameMonth(date, this.viewDate)) {
      if (
        (isSameDay(this.viewDate, date) && this.activeDayIsOpen === true) ||
        events.length === 0
      ) {
        this.activeDayIsOpen = false;
      } else {
        this.activeDayIsOpen = true;
      }
      this.viewDate = date;
    }
  }

  /**Déplacer la date d'un évènement avec la souris */
  eventTimesChanged({
    event,
    newStart,
    newEnd,
  }: CalendarEventTimesChangedEvent): void {
    this.events = this.events.map((iEvent) => {
      if (iEvent === event) {
        let startUpdate = newStart;
        let endUpdate = newEnd;
        let currentColor;
        //get color
        if(event.color == colors.blue) currentColor = "blue";
        if(event.color == colors.purple) currentColor = "purple";
        if(event.color == colors.cyan) currentColor = "cyan";
        if(event.color == colors.red) currentColor = "red";
        if(event.color == colors.yellow) currentColor = "yellow";
        //Update event date
        this.calendarService.dataToUpdate.push({id: Number(event.id), eventID: 0, title: event.title, start: startUpdate, end: endUpdate, color: currentColor, longEvent: event.allDay, recursif: false, quantite: 0, jours: "", jourParMois: "", jourParAnnee: "", userID: 0});
        console.log(this.calendarService.dataToUpdate, "updated item")
        //METHODE DELETE POST
        const variable  = this.calendarService.postUpdateEventInServer().subscribe(
            () => {
            console.log('Données du calendrier mis à jour !');
            },
            (error) => {
            console.log('Erreur ! : ' + error);
            }
        );
        //Détruite la souscription
        this.listSubscription.push(variable);

        const variable3 = this.calendarService.getEventsFromServer().subscribe((response) => {
          for(let item of JSON.parse(JSON.stringify(response)).data){
            if(item.id == Number(event.id)){
              const variable4 = this.timelineService.getEvtFromServer().subscribe((response2) => {
                for(let itemT of JSON.parse(JSON.stringify(response2)).data){
                  if(itemT.eventID == item.eventID && itemT.userID == this.connexionService.userID){
                    this.timelineService.dataToUpdate.push({id: itemT.id, eventID: itemT.eventID, update_ID: null, base_ID: null, date: startUpdate, heure: startUpdate.toString().substring(16,21), motif: itemT.motif, userID: this.connexionService.userID, isUserConcerned: itemT.isUserConcerned});
                    console.log(startUpdate, "strat date")
                    //METHODE POST Update
                    //console.log(addHours(new Date(this.start), 2).toString(), "HEURE");
                    const variable2  = this.timelineService.postUpdateEventTimelineInServer().subscribe(
                      () => {
                        console.log('Données de la timeline mis à jour !');
                      },
                      (error) => {
                        console.log('Erreur ! : ' + error);
                      }
                    );
                    //Détruite la souscription
                    this.listSubscription.push(variable2);
                  }
                }
              });
              //Détruire la souscription
              this.listSubscription.push(variable4);
            }    
          }
        });
        //Détruire la souscription
        this.listSubscription.push(variable3);

        setTimeout(() => location.reload(), 1000);
      }
      return iEvent;
    });
    //this.handleEvent('Dropped or resized', event);
  }

  handleEvent(action: string, event: CalendarEvent): void {
    this.modalData = { event, action };
    this.modal.open(this.modalContent, { size: 'lg' });
  }

  deleteEvent(eventToDelete: CalendarEvent) {
    this.events = this.events.filter((event) => event !== eventToDelete);

    let color;
    if(eventToDelete.color == colors.blue) color = "blue";
    else if(eventToDelete.color == colors.yellow) color = "yellow";
    else if(eventToDelete.color == colors.magenta) color = "magenta";
    else if(eventToDelete.color == colors.purple) color = "purple";
    else if(eventToDelete.color == colors.cyan) color = "cyan";
    else if(eventToDelete.color == colors.red) color = "red";
    this.calendarService.dataToDelete.push({id: Number(eventToDelete.id), eventID: 0, title: eventToDelete.title, start: eventToDelete.start, end: eventToDelete.end, color: color, longEvent: eventToDelete.allDay, recursif: false, quantite: 0, jours: "", jourParMois: "", jourParAnnee: "", userID: 0});
    console.log(this.calendarService.dataToDelete, "delete item")
    //METHODE DELETE POST
    const variable  = this.calendarService.postDeleteEventInServer().subscribe(
        () => {
        console.log('Données du calendrier supprimées !');
        },
        (error) => {
        console.log('Erreur ! : ' + error);
        }
    );
    //Détruite la souscription
    this.listSubscription.push(variable);

    location.reload()
  }

  setView(view: CalendarView) {
    this.view = view;
  }

  closeOpenMonthViewDay() {
    this.activeDayIsOpen = false;
  }

}
