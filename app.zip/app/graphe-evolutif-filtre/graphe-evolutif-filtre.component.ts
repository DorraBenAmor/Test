import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';
import { Connection } from '../models/connection.model';
import { ConnexionService } from '../services/connexion.service';
import { DashboardService } from '../services/dashboard.service';
import { StatService } from '../services/statistique.service';
import { months } from 'moment';

interface dataCategorie{
  data: any[];
  categorie: string;   
}
@Component({
  selector: 'app-graphe-evolutif-filtre',
  templateUrl: './graphe-evolutif-filtre.component.html',
  styleUrls: ['./graphe-evolutif-filtre.component.css']
})
export class GrapheEvolutifFiltreComponent implements OnInit, OnDestroy {
  @Input() selectedCourbe: string;
  @Input() selected: string;
  @Input() listeEntrepriseBase: any[];
  @Input() selectedFiltre: string;
  @Input() checkedGlobal: boolean;
  @Input() periode: string;

  /**Declaration des variables**/

  // Données du user connecté
  currentUser: Connection;
  private subscription: Subscription;

  //Données de la BDD
  dashboardComponents: any[] = [];

  //Paramètres du line chart par type 
  public lineChartReady: boolean = false;
  public lineChartOptions;
  public lineChartLabels: string[] = [];
  public lineChartType;
  public lineChartLegend;
  public lineChartData = [];
  legende: string;
  unite: string

  //Chemin de la page
  href: string;

  listSubscription = <Subscription[]>[];

  constructor(private router: Router, private statService: StatService, private connexionService: ConnexionService, private dashboardService: DashboardService) {}
  
  ngOnInit(): void {
    // Initialisation des variables
    this.href = this.router.url;
    // Paramétrage graphe
    this.lineChartOptions = {
      responsive: true,
      legend: {position: 'right',
        onClick: function(e, legendItem) {
          var index = legendItem.datasetIndex;
          var ci = this.chart;
          var alreadyHidden = (ci.getDatasetMeta(index).hidden === null) ? false : ci.getDatasetMeta(index).hidden;

          ci.data.datasets.forEach(function(e, i) {
            var meta = ci.getDatasetMeta(i);

            if (i !== index) {
              if (!alreadyHidden) {
                meta.hidden = meta.hidden === null ? !meta.hidden : null;
              } else if (meta.hidden === null) {
                meta.hidden = true;
              }
            } else if (i === index) {
              meta.hidden = null;
            }
          });

          ci.update();
        }
      }
    };
    this.lineChartLegend = true;
    this.lineChartType = 'line';

    // Récupération des données du user connecté
    this.subscription = this.connexionService.connexionSubject.subscribe(datas => {
      this.currentUser = datas
    })
    this.connexionService.emitConnection()

    // Lancement Graphe
    this.chargementDonnees(this.selectedCourbe, this.selected, this.listeEntrepriseBase, this.selectedFiltre, this.checkedGlobal, this.periode)
  }

  ngOnDestroy(): void {
    this.listSubscription.map((elem) => elem.unsubscribe());
    this.subscription.unsubscribe();
  }

  activeLegend() {
    this.lineChartLegend = !this.lineChartLegend
  }

  // Chargement du graphe
  chargementDonnees(selectedCourbe: string, selected: string, listeEntrepriseBase: any[], selectedFiltre: string, checkedGlobal: boolean, periode: string){
    this.selectedCourbe = selectedCourbe
    this.selected = selected
    this.listeEntrepriseBase = listeEntrepriseBase
    this.selectedFiltre = selectedFiltre
    this.checkedGlobal = checkedGlobal
    this.periode = periode

    /**Alimentation données des graphes**/

    // Variables nécessaires pour les calculs et l'alimentation des données
    let color;
    let categories = []
    let dataEtCategorie: dataCategorie[] = [];

    // Par periode
    switch(this.periode){
      case "Tout":
        // Par type
        switch(this.selected){
          case "Type d\'objet":
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legende = 'Nombre de tickets ouverts par type d\'objet'
                this.unite = ''
                // Application du filtre
                this.statService.filtre = 'Type d\'objet'
                const variable = this.statService.getStatNombreTicketsTout().subscribe((res) => {
                  // Récupération des données de la table StatNombreTickets
                  var statNbTickets = JSON.parse(JSON.stringify(res)).data
                  console.log(statNbTickets, 'statNbTickets')

                  //Chart Labels
                  this.lineChartLabels = []
                  categories = []
                  for(let row of statNbTickets){
                    if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statNbTickets){
                        if(this.lineChartLabels[i] === row.year && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;
                });
                this.listSubscription.push(variable);
              break;

              case "Temps de réponse": 
                this.legende = "Moyenne du temps de réponse par type d'objet";
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Type d\'objet'
                const variable1 = this.statService.getStatTempsReponseTout().subscribe((res) => {
                  var statTempsReponse = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  //Chart Labels
                  this.lineChartLabels = []
                  categories = []
                  for(let row of statTempsReponse){
                    if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsReponse){
                        if(this.lineChartLabels[i] === row.year && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2)   
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;
                });
                this.listSubscription.push(variable1);
              break;

              case "Temps de résolution": 
                this.legende = "Moyenne du temps de résolution par type d'objet"
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Type d\'objet'
                const variable2 = this.statService.getStatTempsResolutionTout().subscribe((res) => {
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')

                  //Chart Labels
                  this.lineChartLabels = []
                  categories = []
                  for(let row of statTempsResolution){
                    if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsResolution){
                        if(this.lineChartLabels[i] === row.year && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)   // moyenne
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable2);
              break;
            }
            break;

          case "Impact":
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legende = "Nombre de tickets ouverts par impact";
                this.unite = ''
                // Application du filtre
                this.statService.filtre = 'Impact'
                const variable = this.statService.getStatNombreTicketsTout().subscribe((res) => {
                  // Récupération des données de la table StatNombreTickets
                  var statNbTickets = JSON.parse(JSON.stringify(res)).data
                  console.log(statNbTickets, 'statNbTickets')

                  //Chart Labels
                  this.lineChartLabels = []
                  categories = []
                  for(let row of statNbTickets){
                    if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statNbTickets){
                        if(this.lineChartLabels[i] === row.year && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;
                });
                this.listSubscription.push(variable);
              break;

              case "Temps de réponse": 
              this.legende = "Moyenne du temps de réponse par impact";
              this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Impact'
                const variable1 = this.statService.getStatTempsReponseTout().subscribe((res) => {
                  var statTempsReponse = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  //Chart Labels
                  this.lineChartLabels = []
                  categories = []
                  for(let row of statTempsReponse){
                    if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsReponse){
                        if(this.lineChartLabels[i] === row.year && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2)   
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;
                });
                this.listSubscription.push(variable1);
              break;

              case "Temps de résolution": 
                this.legende = "Moyenne du temps de résolution par impact"
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Impact'
                const variable2 = this.statService.getStatTempsResolutionTout().subscribe((res) => {
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')

                  //Chart Labels
                  this.lineChartLabels = []
                  categories = []
                  for(let row of statTempsResolution){
                    if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsResolution){
                        if(this.lineChartLabels[i] === row.year && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)   // moyenne
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable2);
              break;
            }
            break;

          case "Etat":
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legende = "Nombre de tickets ouverts par état";
                this.unite = ''
                // Application du filtre
                this.statService.filtre = 'Etat'
                const variable = this.statService.getStatNombreTicketsTout().subscribe((res) => {
                  // Récupération des données de la table StatNombreTickets
                  var statNbTickets = JSON.parse(JSON.stringify(res)).data
                  console.log(statNbTickets, 'statNbTickets')

                  //Chart Labels
                  this.lineChartLabels = []
                  categories = []
                  for(let row of statNbTickets){
                    if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statNbTickets){
                        if(this.lineChartLabels[i] === row.year && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;
                });
                this.listSubscription.push(variable);
              break;

              case "Temps de réponse": 
                this.legende = "Moyenne du temps de réponse par état";
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Etat'
                const variable1 = this.statService.getStatTempsReponseTout().subscribe((res) => {
                  var statTempsReponse = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  //Chart Labels
                  this.lineChartLabels = []
                  categories = []
                  for(let row of statTempsReponse){
                    if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsReponse){
                        if(this.lineChartLabels[i] === row.year && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2)   
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;
                });
                this.listSubscription.push(variable1);
              break;

              case "Temps de résolution": 
                this.legende = "Moyenne du temps de résolution par état"
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Etat'
                const variable2 = this.statService.getStatTempsResolutionTout().subscribe((res) => {
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')

                  //Chart Labels
                  this.lineChartLabels = []
                  categories = []
                  for(let row of statTempsResolution){
                    if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsResolution){
                        if(this.lineChartLabels[i] === row.year && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)   // moyenne
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable2);
              break;
            }
            break;

          case "Module":
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legende = "Nombre de tickets ouverts par module";
                this.unite = ''
                // Application du filtre
                this.statService.filtre = 'Module'
                const variable = this.statService.getStatNombreTicketsTout().subscribe((res) => {
                  // Récupération des données de la table StatNombreTickets
                  var statNbTickets = JSON.parse(JSON.stringify(res)).data
                  console.log(statNbTickets, 'statNbTickets')

                  //Chart Labels
                  this.lineChartLabels = []
                  categories = []
                  for(let row of statNbTickets){
                    if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statNbTickets){
                        if(this.lineChartLabels[i] === row.year && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;
                });
                this.listSubscription.push(variable);
              break;

              case "Temps de réponse": 
                this.legende = "Moyenne du temps de réponse par module";
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Module'
                const variable1 = this.statService.getStatTempsReponseTout().subscribe((res) => {
                  var statTempsReponse = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  //Chart Labels
                  this.lineChartLabels = []
                  categories = []
                  for(let row of statTempsReponse){
                    if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsReponse){
                        if(this.lineChartLabels[i] === row.year && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2)   
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;
                });
                this.listSubscription.push(variable1);
              break;

              case "Temps de résolution": 
                this.legende = "Moyenne du temps de résolution par module"
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Module'
                const variable2 = this.statService.getStatTempsResolutionTout().subscribe((res) => {
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')

                  //Chart Labels
                  this.lineChartLabels = []
                  categories = []
                  for(let row of statTempsResolution){
                    if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsResolution){
                        if(this.lineChartLabels[i] === row.year && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)   // moyenne
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable2);
              break;
            }
            break;

          case "Ordre de priorité":
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legende = "Nombre de tickets ouverts par ordre de priorité";
                this.unite = ''
                // Application du filtre
                this.statService.filtre = 'Ordre de priorité'
                const variable = this.statService.getStatNombreTicketsTout().subscribe((res) => {
                  // Récupération des données de la table StatNombreTickets
                  var statNbTickets = JSON.parse(JSON.stringify(res)).data
                  console.log(statNbTickets, 'statNbTickets')

                  //Chart Labels
                  this.lineChartLabels = []
                  categories = []
                  for(let row of statNbTickets){
                    if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statNbTickets){
                        if(this.lineChartLabels[i] === row.year && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;
                });
                this.listSubscription.push(variable);
              break;

              case "Temps de réponse": 
                this.legende = "Moyenne du temps de réponse par ordre de priorité";
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Ordre de priorité'
                const variable1 = this.statService.getStatTempsReponseTout().subscribe((res) => {
                  var statTempsReponse = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  //Chart Labels
                  this.lineChartLabels = []
                  categories = []
                  for(let row of statTempsReponse){
                    if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsReponse){
                        if(this.lineChartLabels[i] === row.year && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2) 
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;
                });
                this.listSubscription.push(variable1);
              break;

              case "Temps de résolution": 
                this.legende = "Moyenne du temps de résolution par ordre de priorité"
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Ordre de priorité'
                const variable2 = this.statService.getStatTempsResolutionTout().subscribe((res) => {
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')

                  //Chart Labels
                  this.lineChartLabels = []
                  categories = []
                  for(let row of statTempsResolution){
                    if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsResolution){
                        if(this.lineChartLabels[i] === row.year && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)   // moyenne
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable2);
              break;
            }
            break;

          case "Base":
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legende = "Nombre de tickets ouverts par base";
                this.unite = ''
                // Application du filtre
                this.statService.filtre = 'Base'
                const variable = this.statService.getStatNombreTicketsTout().subscribe((res) => {
                  // Récupération des données de la table StatNombreTickets
                  var statNbTickets = JSON.parse(JSON.stringify(res)).data
                  console.log(statNbTickets, 'statNbTickets')

                  //Chart Labels
                  this.lineChartLabels = []
                  categories = []
                  for(let row of statNbTickets){
                    if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statNbTickets){
                        if(this.lineChartLabels[i] === row.year && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;
                });
                this.listSubscription.push(variable);
              break;

              case "Temps de réponse": 
                this.legende = "Moyenne du temps de réponse par base";
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Base'
                const variable1 = this.statService.getStatTempsReponseTout().subscribe((res) => {
                  var statTempsReponse = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  //Chart Labels
                  this.lineChartLabels = []
                  categories = []
                  for(let row of statTempsReponse){
                    if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsReponse){
                        if(this.lineChartLabels[i] === row.year && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2)
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;
                });
                this.listSubscription.push(variable1);
              break;

              case "Temps de résolution": 
                this.legende = "Moyenne du temps de résolution par base"
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Base'
                const variable2 = this.statService.getStatTempsResolutionTout().subscribe((res) => {
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')

                  //Chart Labels
                  this.lineChartLabels = []
                  categories = []
                  for(let row of statTempsResolution){
                    if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsResolution){
                        if(this.lineChartLabels[i] === row.year && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)   // moyenne
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable2);
              break;
            }
            break;

          case "Entreprise":
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legende = "Nombre de tickets ouverts par entreprise";
                this.unite = ''
                // Application du filtre
                this.statService.filtre = 'Entreprise'
                const variable = this.statService.getStatNombreTicketsTout().subscribe((res) => {
                  // Récupération des données de la table StatNombreTickets
                  var statNbTickets = JSON.parse(JSON.stringify(res)).data
                  console.log(statNbTickets, 'statNbTickets')

                  //Chart Labels
                  this.lineChartLabels = []
                  categories = []
                  for(let row of statNbTickets){
                    if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statNbTickets){
                        if(this.lineChartLabels[i] === row.year && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;
                });
                this.listSubscription.push(variable);
              break;

              case "Temps de réponse": 
                this.legende = "Moyenne du temps de réponse par entreprise cliente";
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Entreprise'
                const variable1 = this.statService.getStatTempsReponseTout().subscribe((res) => {
                  var statTempsReponse = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  //Chart Labels
                  this.lineChartLabels = []
                  categories = []
                  for(let row of statTempsReponse){
                    if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsReponse){
                        if(this.lineChartLabels[i] === row.year && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2)   
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;
                });
                this.listSubscription.push(variable1);
              break;

              case "Temps de résolution": 
                this.legende = "Moyenne du temps de résolution par entreprise"
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Entreprise'
                const variable2 = this.statService.getStatTempsResolutionTout().subscribe((res) => {
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')

                  //Chart Labels
                  this.lineChartLabels = []
                  categories = []
                  for(let row of statTempsResolution){
                    if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsResolution){
                        if(this.lineChartLabels[i] === row.year && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)   // moyenne
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable2);
              break;
            }
            break;

          case "Choix Entreprise":
            // Le filtre sélectionné n'est pas 'Global'
            if(this.selectedFiltre !== 'Global') {
              console.log(this.checkedGlobal, 'checkedGlobal')
              if(this.checkedGlobal.toString() === 'false') {
                console.log('in 1')
                // Par donnée
                switch(this.selectedCourbe){
                  case "Nombre de tickets": 
                    this.legende = "Nombre de tickets ouverts par base filtré par " + this.selectedFiltre.toLowerCase();
                    this.unite = ''
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push(this.selectedFiltre)
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable = this.statService.getStatNombreTicketsToutChoixEntreprise().subscribe((res) => {
                      // Récupération des données de la table StatNombreTickets
                      var statNbTickets = JSON.parse(JSON.stringify(res)).data
                      console.log(statNbTickets, 'statNbTickets')

                      //Chart Labels
                      this.lineChartLabels = []
                      categories = []
                      for(let row of statNbTickets){
                        if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                        if(!categories.includes(row.entreprise + ' - ' + row.base + ': ' + row.categorie))  categories.push(row.entreprise + ' - ' + row.base + ': ' + row.categorie)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<this.lineChartLabels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statNbTickets){
                            let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                            let debutbase: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                            let base = debutbase.substr(0, debutbase.indexOf(':'))
                            let categorie = item.categorie.substr(item.categorie.indexOf(': ') + 2)
                            if(this.lineChartLabels[i] === row.year && ese === row.entreprise && base === row.base && categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;
                    });
                    this.listSubscription.push(variable);
                  break;

                  case "Temps de réponse": 
                    this.legende = "Moyenne du temps de réponse par base filtré par " + this.selectedFiltre.toLowerCase();
                    this.unite = '(en heure)'
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push(this.selectedFiltre)
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable1 = this.statService.getStatTempsReponseToutChoixEntreprise().subscribe((res) => {
                      var statTempsReponse = JSON.parse(JSON.stringify(res)).data
                      console.log(statTempsReponse, 'statTempsReponse')

                      //Chart Labels
                      this.lineChartLabels = []
                      categories = []
                      for(let row of statTempsReponse){
                        if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                        if(!categories.includes(row.entreprise + ' - ' + row.base + ': ' + row.categorie))  categories.push(row.entreprise + ' - ' + row.base + ': ' + row.categorie)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<this.lineChartLabels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statTempsReponse){
                            let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                            let debutbase: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                            let base = debutbase.substr(0, debutbase.indexOf(':'))
                            let categorie = item.categorie.substr(item.categorie.indexOf(': ') + 2)
                            if(this.lineChartLabels[i] === row.year && ese === row.entreprise && base === row.base && categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2)   
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;
                    });
                    this.listSubscription.push(variable1);
                  break;

                  case "Temps de résolution": 
                    this.legende = "Moyenne du temps de résolution par base filtré par " + this.selectedFiltre.toLowerCase();
                    this.unite = '(en jour)'
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push(this.selectedFiltre)
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable2 = this.statService.getStatTempsResolutionToutChoixEntreprise().subscribe((res) => {
                      var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                      console.log(statTempsResolution, 'statTempsResolution')

                      //Chart Labels
                      this.lineChartLabels = []
                      categories = []
                      for(let row of statTempsResolution){
                        if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                        if(!categories.includes(row.entreprise + ' - ' + row.base + ': ' + row.categorie))  categories.push(row.entreprise + ' - ' + row.base + ': ' + row.categorie)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<this.lineChartLabels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statTempsResolution){
                            let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                            let debutbase: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                            let base = debutbase.substr(0, debutbase.indexOf(':'))
                            let categorie = item.categorie.substr(item.categorie.indexOf(': ') + 2)
                            if(this.lineChartLabels[i] === row.year && ese === row.entreprise && base === row.base && categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)   // moyenne
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;

                    });
                    this.listSubscription.push(variable2);
                  break;
                }
              }
              else {
                // Par donnée
                switch(this.selectedCourbe){
                  case "Nombre de tickets": 
                    this.legende = 'Nombre de tickets ouverts par base'
                    this.unite = ''
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push('Global')
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable = this.statService.getStatNombreTicketsToutChoixEntreprise().subscribe((res) => {
                      // Récupération des données de la table StatNombreTickets
                      var statNbTickets = JSON.parse(JSON.stringify(res)).data
                      console.log(statNbTickets, 'statNbTickets')

                      //Chart Labels
                      this.lineChartLabels = []
                      categories = []
                      for(let row of statNbTickets){
                        if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                        if(!categories.includes(row.entreprise + ' - ' + row.base))  categories.push(row.entreprise + ' - ' + row.base)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<this.lineChartLabels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statNbTickets){
                            let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                            let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                            if(this.lineChartLabels[i] === row.year && ese === row.entreprise && base === row.base)  item.data[item.data.length - 1] = row.quantite
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;
                    });
                    this.listSubscription.push(variable);
                  break;

                  case "Temps de réponse": 
                    this.legende = "Moyenne du temps de réponse par base"
                    this.unite = '(en heure)'
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push('Global')
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable1 = this.statService.getStatTempsReponseToutChoixEntreprise().subscribe((res) => {
                      var statTempsReponse = JSON.parse(JSON.stringify(res)).data
                      console.log(statTempsReponse, 'statTempsReponse')

                      //Chart Labels
                      this.lineChartLabels = []
                      categories = []
                      for(let row of statTempsReponse){
                        if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                        if(!categories.includes(row.entreprise + ' - ' + row.base))  categories.push(row.entreprise + ' - ' + row.base)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<this.lineChartLabels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statTempsReponse){
                            let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                            let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                            if(this.lineChartLabels[i] === row.year && ese === row.entreprise && base === row.base)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2)   
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;
                    });
                    this.listSubscription.push(variable1);
                  break;

                  case "Temps de résolution": 
                    this.legende = "Moyenne du temps de résolution par base"
                    this.unite = '(en jour)'
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push('Global')
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable2 = this.statService.getStatTempsResolutionToutChoixEntreprise().subscribe((res) => {
                      var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                      console.log(statTempsResolution, 'statTempsResolution')

                      //Chart Labels
                      this.lineChartLabels = []
                      categories = []
                      for(let row of statTempsResolution){
                        if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                        if(!categories.includes(row.entreprise + ' - ' + row.base))  categories.push(row.entreprise + ' - ' + row.base)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<this.lineChartLabels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statTempsResolution){
                            let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                            let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                            if(this.lineChartLabels[i] === row.year && ese === row.entreprise && base === row.base && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)   // moyenne
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;

                    });
                    this.listSubscription.push(variable2);
                    break;
                }
              }
            }
            else {
              console.log(this.checkedGlobal, 'checkedGlobal')
              if(this.checkedGlobal.toString() === 'false'){
                // Par donnée
                switch(this.selectedCourbe){
                  case "Nombre de tickets": 
                    this.legende = "Nombre de tickets ouverts par base"
                    this.unite = ''
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push(this.selectedFiltre)
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable = this.statService.getStatNombreTicketsToutChoixEntreprise().subscribe((res) => {
                      // Récupération des données de la table StatNombreTickets
                      var statNbTickets = JSON.parse(JSON.stringify(res)).data
                      console.log(statNbTickets, 'statNbTickets')

                      //Chart Labels
                      this.lineChartLabels = []
                      categories = []
                      for(let row of statNbTickets){
                        if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                        if(!categories.includes(row.entreprise + ' - ' + row.base))  categories.push(row.entreprise + ' - ' + row.base)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<this.lineChartLabels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statNbTickets){
                            let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                            let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                            if(this.lineChartLabels[i] === row.year && ese === row.entreprise && base === row.base )  item.data[item.data.length - 1] = row.quantite
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;
                    });
                    this.listSubscription.push(variable);
                  break;

                  case "Temps de réponse": 
                    this.legende = "Moyenne du temps de réponse par base"
                    this.unite = '(en heure)'
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push(this.selectedFiltre)
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable1 = this.statService.getStatTempsReponseToutChoixEntreprise().subscribe((res) => {
                      var statTempsReponse = JSON.parse(JSON.stringify(res)).data
                      console.log(statTempsReponse, 'statTempsReponse')

                      //Chart Labels
                      this.lineChartLabels = []
                      categories = []
                      for(let row of statTempsReponse){
                        if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                        if(!categories.includes(row.entreprise + ' - ' + row.base))  categories.push(row.entreprise + ' - ' + row.base)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<this.lineChartLabels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statTempsReponse){
                            let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                            let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                            if(this.lineChartLabels[i] === row.year && ese === row.entreprise && base === row.base)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2)  
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;
                    });
                    this.listSubscription.push(variable1);
                  break;

                  case "Temps de résolution": 
                    this.legende = "Moyenne du temps de résolution par base"
                    this.unite = '(en jour)'
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push(this.selectedFiltre)
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable2 = this.statService.getStatTempsResolutionToutChoixEntreprise().subscribe((res) => {
                      var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                      console.log(statTempsResolution, 'statTempsResolution')

                      //Chart Labels
                      this.lineChartLabels = []
                      categories = []
                      for(let row of statTempsResolution){
                        if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                        if(!categories.includes(row.entreprise + ' - ' + row.base))  categories.push(row.entreprise + ' - ' + row.base)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<this.lineChartLabels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statTempsResolution){
                            let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                            let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                            if(this.lineChartLabels[i] === row.year && ese === row.entreprise && base === row.base && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)   // moyenne
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;

                    });
                    this.listSubscription.push(variable2);
                    break;
                  }
              }
              else{
                // Par donnée
                switch(this.selectedCourbe){
                  case "Nombre de tickets": 
                    this.legende = "Nombre de tickets ouverts par entreprise"
                    this.unite = ''
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push(this.selectedFiltre)
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable = this.statService.getStatNombreTicketsToutChoixEntreprise().subscribe((res) => {
                      // Récupération des données de la table StatNombreTickets
                      var statNbTickets = JSON.parse(JSON.stringify(res)).data
                      console.log(statNbTickets, 'statNbTickets')

                      //Chart Labels
                      this.lineChartLabels = []
                      categories = []
                      for(let row of statNbTickets) {
                        if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                        if(!categories.includes(row.entreprise))  categories.push(row.entreprise)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<this.lineChartLabels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statNbTickets){
                            if(this.lineChartLabels[i] === row.year && item.categorie === row.entreprise)  item.data[item.data.length - 1] += row.quantite
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;
                    });
                    this.listSubscription.push(variable);
                  break;

                  case "Temps de réponse": 
                    this.legende = "Moyenne du temps de réponse par entreprise";
                    this.unite = '(en heure)'
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push('Global')
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable1 = this.statService.getStatTempsReponseToutChoixEntreprise().subscribe((res) => {
                      var statTempsReponse = JSON.parse(JSON.stringify(res)).data
                      console.log(statTempsReponse, 'statTempsReponse')

                      //Chart Labels
                      this.lineChartLabels = []
                      categories = []
                      for(let row of statTempsReponse){
                        if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                        if(!categories.includes(row.entreprise))  categories.push(row.entreprise)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<this.lineChartLabels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statTempsReponse){
                            if(this.lineChartLabels[i] === row.year && item.categorie === row.entreprise)  item.data[item.data.length - 1] += (row.tempsReponse/row.nbTicketsConcernes).toFixed(2)   
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;
                    });
                    this.listSubscription.push(variable1);
                  break;

                  case "Temps de résolution": 
                    this.legende = "Moyenne du temps de résolution par entreprise"
                    this.unite = '(en jour)'
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push('Global')
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable2 = this.statService.getStatTempsResolutionToutChoixEntreprise().subscribe((res) => {
                      var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                      console.log(statTempsResolution, 'statTempsResolution')

                      //Chart Labels
                      this.lineChartLabels = []
                      categories = []
                      for(let row of statTempsResolution){
                        if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                        if(!categories.includes(row.entreprise))  categories.push(row.entreprise)                      
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<this.lineChartLabels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statTempsResolution){
                            if(this.lineChartLabels[i] === row.year && item.categorie === row.entreprise && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] += (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)   // moyenne
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;

                    });
                    this.listSubscription.push(variable2);
                    break;
                  }
                }
            }
            break;

          case "Responsable de dossier":
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legende = "Nombre de tickets ouverts par responsable de dossier";
                this.unite = ''
                // Application du filtre
                this.statService.filtre = 'Responsable de dossier'
                const variable = this.statService.getStatNombreTicketsTout().subscribe((res) => {
                  // Récupération des données de la table StatNombreTickets
                  var statNbTickets = JSON.parse(JSON.stringify(res)).data
                  console.log(statNbTickets, 'statNbTickets')

                  //Chart Labels
                  this.lineChartLabels = []
                  categories = []
                  for(let row of statNbTickets){
                    if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statNbTickets){
                        if(this.lineChartLabels[i] === row.year && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;
                });
                this.listSubscription.push(variable);
              break;

              case "Temps de réponse": 
                this.legende = "Moyenne du temps de réponse par responsable de dossier";
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Responsable de dossier'
                const variable1 = this.statService.getStatTempsReponseTout().subscribe((res) => {
                  var statTempsReponse = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  //Chart Labels
                  this.lineChartLabels = []
                  categories = []
                  for(let row of statTempsReponse){
                    if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsReponse){
                        if(this.lineChartLabels[i] === row.year && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2)   
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;
                });
                this.listSubscription.push(variable1);
              break;

              case "Temps de résolution": 
                this.legende = "Moyenne du temps de résolution par reponsable de dossier"
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Responsable de dossier'
                const variable2 = this.statService.getStatTempsResolutionTout().subscribe((res) => {
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')

                  //Chart Labels
                  this.lineChartLabels = []
                  categories = []
                  for(let row of statTempsResolution){
                    if(!this.lineChartLabels.includes(row.year))  this.lineChartLabels.push(row.year)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsResolution){
                        if(this.lineChartLabels[i] === row.year && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)   // moyenne
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable2);
              break;
            }
            break;
        }
        break;

      case "Année":
        //Chart Labels
        this.lineChartLabels = [];
        this.lineChartLabels = ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"];
        let labels = [];
        for(let i = 1; i < 13; i++) labels.push(i);
        // Par type
        switch(this.selected){
          case "Type d\'objet":
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legende = "Nombre de tickets ouverts cette année filtré par type d'objet";
                this.unite = ''
                // Application du filtre
                this.statService.filtre = 'Type d\'objet'
                const variable = this.statService.getStatNombreTicketsAnnee().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statNbTickets = JSON.parse(JSON.stringify(res)).data
                  console.log(statNbTickets, 'statNbTickets')

                  //Chart Labels
                  categories = []
                  for(let row of statNbTickets){
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<labels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statNbTickets){
                        if(labels[i] === row.month && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable);
              break;

              case "Temps de réponse": 
                this.legende = "Moyenne du temps de réponse de cette année filtré par type d'objet";
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Type d\'objet'
                const variable1 = this.statService.getStatTempsReponseAnnee().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsReponse= JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  //Chart Labels
                  categories = []
                  for(let row of statTempsReponse){
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<labels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsReponse){
                        if(labels[i] === row.month && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2) 
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable1);
              break;

              case "Temps de résolution":
                this.legende = "Moyenne du temps de résolution de cette année filtré par type d'objet";
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Type d\'objet'
                const variable2 = this.statService.getStatTempsResolutionAnnee().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')
                  
                  //Chart Labels
                  categories = []
                  for(let row of statTempsResolution){
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<labels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsResolution){
                        if(labels[i] === row.month && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2) // moyenne
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable2);
              break;
            }
            break;

           case "Impact":
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legende = "Nombre de tickets ouverts cette année filtré par impact";
                this.unite = ''
                // Application du filtre
                this.statService.filtre = 'Impact'
                const variable = this.statService.getStatNombreTicketsAnnee().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statNbTickets = JSON.parse(JSON.stringify(res)).data
                  console.log(statNbTickets, 'statNbTickets')

                  //Chart Labels
                  categories = []
                  for(let row of statNbTickets){
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<labels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statNbTickets){
                        if(labels[i] === row.month && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable);
              break;

              case "Temps de réponse": 
                this.legende = "Moyenne du temps de réponse de cette année filtré par impact";
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Impact'
                const variable1 = this.statService.getStatTempsReponseAnnee().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsReponse= JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  //Chart Labels
                  categories = []
                  for(let row of statTempsReponse){
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<labels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsReponse){
                        if(labels[i] === row.month && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2) 
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable1);
              break;

              case "Temps de résolution": 
                this.legende = "Moyenne du temps de résolution de cette année filtré par impact";
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Impact'
                const variable2 = this.statService.getStatTempsResolutionAnnee().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')
                  
                  //Chart Labels
                  categories = []
                  for(let row of statTempsResolution){
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<labels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsResolution){
                        if(labels[i] === row.month && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2) // moyenne
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable2);
              break;
            }
            break;

          case "Etat":
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legende = "Nombre de tickets ouverts cette année filtré par état";
                this.unite = ''
                // Application du filtre
                this.statService.filtre = 'Etat'
                const variable = this.statService.getStatNombreTicketsAnnee().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statNbTickets = JSON.parse(JSON.stringify(res)).data
                  console.log(statNbTickets, 'statNbTickets')

                  //Chart Labels
                  categories = []
                  for(let row of statNbTickets){
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<labels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statNbTickets){
                        if(labels[i] === row.month && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable);
              break;

              case "Temps de réponse": 
                this.legende = "Moyenne du temps de réponse de cette année filtré par état";
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Etat'
                const variable1 = this.statService.getStatTempsReponseAnnee().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsReponse= JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  //Chart Labels
                  categories = []
                  for(let row of statTempsReponse){
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<labels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsReponse){
                        if(labels[i] === row.month && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2) 
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable1);
              break;

              case "Temps de résolution": 
                this.legende = "Moyenne du temps de résolution de cette année filtré par état";
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Etat'
                const variable2 = this.statService.getStatTempsResolutionAnnee().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')
                  
                  //Chart Labels
                  categories = []
                  for(let row of statTempsResolution){
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<labels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsResolution){
                        if(labels[i] === row.month && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2) // moyenne
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable2);
              break;
            }
            break;

          case "Module":
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legende = "Nombre de tickets ouverts cette année filtré par module";
                this.unite = ''
                // Application du filtre
                this.statService.filtre = 'Module'
                const variable = this.statService.getStatNombreTicketsAnnee().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statNbTickets = JSON.parse(JSON.stringify(res)).data
                  console.log(statNbTickets, 'statNbTickets')

                  //Chart Labels
                  categories = []
                  for(let row of statNbTickets){
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<labels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statNbTickets){
                        if(labels[i] === row.month && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable);
              break;

              case "Temps de réponse": 
                this.legende = "Moyenne du temps de réponse de cette année filtré par module";
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Module'
                const variable1 = this.statService.getStatTempsReponseAnnee().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsReponse= JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  //Chart Labels
                  categories = []
                  for(let row of statTempsReponse){
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<labels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsReponse){
                        if(labels[i] === row.month && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2) 
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable1);
              break;

              case "Temps de résolution": 
                this.legende = "Moyenne du temps de résolution de cette année filtré par module";
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Module'
                const variable2 = this.statService.getStatTempsResolutionAnnee().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')
                  
                  //Chart Labels
                  categories = []
                  for(let row of statTempsResolution){
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<labels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsResolution){
                        if(labels[i] === row.month && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2) // moyenne
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable2);
              break;
            }
            break;

          case "Ordre de priorité":
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legende = "Nombre de tickets ouverts cette année filtré par ordre de priorité";
                this.unite = ''
                // Application du filtre
                this.statService.filtre = 'Ordre de priorité'
                const variable = this.statService.getStatNombreTicketsAnnee().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statNbTickets = JSON.parse(JSON.stringify(res)).data
                  console.log(statNbTickets, 'statNbTickets')

                  //Chart Labels
                  categories = []
                  for(let row of statNbTickets){
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<labels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statNbTickets){
                        if(labels[i] === row.month && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable);
              break;

              case "Temps de réponse": 
                this.legende = "Moyenne du temps de réponse de cette année filtré par ordre de priorité";
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Ordre de priorité'
                const variable1 = this.statService.getStatTempsReponseAnnee().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsReponse= JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  //Chart Labels
                  categories = []
                  for(let row of statTempsReponse){
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<labels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsReponse){
                        if(labels[i] === row.month && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2) 
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable1);
              break;

              case "Temps de résolution": 
                this.legende = "Moyenne du temps de résolution de cette année filtré par ordre de priorité";
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Ordre de priorité'
                const variable2 = this.statService.getStatTempsResolutionAnnee().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')
                  
                  //Chart Labels
                  categories = []
                  for(let row of statTempsResolution){
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<labels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsResolution){
                        if(labels[i] === row.month && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2) // moyenne
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable2);
              break;
            }
            break;

          case "Entreprise":
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legende = "Nombre de tickets ouverts cette année filtré par entreprise";
                this.unite = ''
                // Affectation de valeurs pour le graphe par type
                // Application du filtre
                this.statService.filtre = 'Entreprise'
                const variable = this.statService.getStatNombreTicketsAnnee().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statNbTickets = JSON.parse(JSON.stringify(res)).data
                  console.log(statNbTickets, 'statNbTickets')

                  //Chart Labels
                  categories = []
                  for(let row of statNbTickets){
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<labels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statNbTickets){
                        if(labels[i] === row.month && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable);
              break;

              case "Temps de réponse": 
                this.legende = "Moyenne du temps de réponse de cette année filtré par entreprise";
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Entreprise'
                const variable1 = this.statService.getStatTempsReponseAnnee().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsReponse= JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  //Chart Labels
                  categories = []
                  for(let row of statTempsReponse){
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<labels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsReponse){
                        if(labels[i] === row.month && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2)
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable1);
              break;

              case "Temps de résolution": 
                this.legende = "Moyenne du temps de résolution de cette année filtré par entreprise";
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Entreprise'
                const variable2 = this.statService.getStatTempsResolutionAnnee().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')
                  
                  //Chart Labels
                  categories = []
                  for(let row of statTempsResolution){
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<labels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsResolution){
                        if(labels[i] === row.month && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2) // moyenne
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable2);
              break;
            }
            break;

          case "Choix Entreprise":
            // Le filtre sélectionné n'est pas 'Global'
            if(this.selectedFiltre !== 'Global') {
              console.log(this.checkedGlobal, 'checkedGlobal')
              if(this.checkedGlobal.toString() === 'false'){
                // Par donnée
                switch(this.selectedCourbe){
                  case "Nombre de tickets": 
                    this.legende = "Nombre de tickets ouverts cette année par base filtré par " + this.selectedFiltre.toLowerCase();
                    this.unite = ''
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push(this.selectedFiltre)
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable = this.statService.getStatNombreTicketsAnneeChoixEntreprise().subscribe((res) => {
                      // Récupération des données de la table StatNombreTickets
                      var statNbTickets = JSON.parse(JSON.stringify(res)).data
                      console.log(statNbTickets, 'statNbTickets')

                      //Chart Labels
                      categories = []
                      for(let row of statNbTickets){
                        if(!categories.includes(row.entreprise + ' - ' + row.base + ': ' + row.categorie))  categories.push(row.entreprise + ' - ' + row.base + ': ' + row.categorie)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<labels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statNbTickets){
                            let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                            let debutbase: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                            let base = debutbase.substr(0, debutbase.indexOf(':'))
                            let categorie = item.categorie.substr(item.categorie.indexOf(': ') + 2)
                            if(labels[i] === row.month && ese === row.entreprise && base === row.base && categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;
                    });
                    this.listSubscription.push(variable);
                  break;

                  case "Temps de réponse": 
                    this.legende = "Moyenne du temps de réponse de cette année par base filtré par " + this.selectedFiltre.toLowerCase();
                    this.unite = '(en heure)'
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push(this.selectedFiltre)
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable1 = this.statService.getStatTempsReponseAnneeChoixEntreprise().subscribe((res) => {
                      var statTempsReponse = JSON.parse(JSON.stringify(res)).data
                      console.log(statTempsReponse, 'statTempsReponse')

                      //Chart Labels
                      categories = []
                      for(let row of statTempsReponse){
                        if(!categories.includes(row.entreprise + ' - ' + row.base + ': ' + row.categorie))  categories.push(row.entreprise + ' - ' + row.base + ': ' + row.categorie)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<labels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statTempsReponse){
                            let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                            let debutbase: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                            let base = debutbase.substr(0, debutbase.indexOf(':'))
                            let categorie = item.categorie.substr(item.categorie.indexOf(': ') + 2)
                            if(labels[i] === row.month && ese === row.entreprise && base === row.base && categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2) 
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;
                    });
                    this.listSubscription.push(variable1);
                  break;

                  case "Temps de résolution": 
                    this.legende = "Moyenne du temps de résolution de cette année par base filtré par " + this.selectedFiltre.toLowerCase();
                    this.unite = '(en jour)'
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push(this.selectedFiltre)
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable2 = this.statService.getStatTempsResolutionAnneeChoixEntreprise().subscribe((res) => {
                      var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                      console.log(statTempsResolution, 'statTempsResolution')

                      //Chart Labels
                      categories = []
                      for(let row of statTempsResolution){
                        if(!categories.includes(row.entreprise + ' - ' + row.base + ': ' + row.categorie))  categories.push(row.entreprise + ' - ' + row.base + ': ' + row.categorie)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<labels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statTempsResolution){
                            let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                            let debutbase: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                            let base = debutbase.substr(0, debutbase.indexOf(':'))
                            let categorie = item.categorie.substr(item.categorie.indexOf(': ') + 2)
                            if(labels[i] === row.month && ese === row.entreprise && base === row.base && categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2) // moyenne
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;

                    });
                    this.listSubscription.push(variable2);
                  break;
                }
              }
              else{
                // Par donnée
                switch(this.selectedCourbe){
                  case "Nombre de tickets": 
                    this.legende = "Nombre de tickets ouverts cette année par base";
                    this.unite = ''
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push('Global')
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable = this.statService.getStatNombreTicketsAnneeChoixEntreprise().subscribe((res) => {
                      // Récupération des données de la table StatNombreTickets
                      var statNbTickets = JSON.parse(JSON.stringify(res)).data
                      console.log(statNbTickets, 'statNbTickets')

                      //Chart Labels
                      categories = []
                      for(let row of statNbTickets){
                        if(!categories.includes(row.entreprise + ' - ' + row.base))  categories.push(row.entreprise + ' - ' + row.base)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<labels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statNbTickets){
                            let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                            let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                            console.log(labels[i] + "/" + months, 'month')
                            console.log(ese + "/" + row.entreprise, 'ese')
                            console.log(base + "/" + row.base, 'base')
                            console.log(item.categorie, 'base item.categorie')
                            if(labels[i] === row.month && ese === row.entreprise && base === row.base)  item.data[item.data.length - 1] = row.quantite
                          }
                        }
                      }
                      console.log(dataEtCategorie, 'statNbTickets 2')

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;
                    });
                    this.listSubscription.push(variable);
                  break;

                  case "Temps de réponse": 
                    this.legende = "Moyenne du temps de réponse de cette année par base";
                    this.unite = '(en heure)'
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push('Global')
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable1 = this.statService.getStatTempsReponseAnneeChoixEntreprise().subscribe((res) => {
                      var statTempsReponse = JSON.parse(JSON.stringify(res)).data
                      console.log(statTempsReponse, 'statTempsReponse')

                      //Chart Labels
                      categories = []
                      for(let row of statTempsReponse){
                        if(!categories.includes(row.entreprise + ' - ' + row.base))  categories.push(row.entreprise + ' - ' + row.base)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<labels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statTempsReponse){
                            let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                            let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                            if(labels[i] === row.month && ese === row.entreprise && base === row.base)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2)
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;
                    });
                    this.listSubscription.push(variable1);
                  break;

                  case "Temps de résolution": 
                    this.legende = "Moyenne du temps de résolution de cette année par base";
                    this.unite = '(en jour)'
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push('Global')
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable2 = this.statService.getStatTempsResolutionAnneeChoixEntreprise().subscribe((res) => {
                      var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                      console.log(statTempsResolution, 'statTempsResolution')

                      //Chart Labels
                      categories = []
                      for(let row of statTempsResolution){
                        if(!categories.includes(row.entreprise + ' - ' + row.base))  categories.push(row.entreprise + ' - ' + row.base)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<labels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statTempsResolution){
                            let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                            let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                            if(labels[i] === row.month && ese === row.entreprise && base === row.base && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)   // moyenne
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;

                    });
                    this.listSubscription.push(variable2);
                    break;
                  }
                }
            }
            else {
              console.log(this.checkedGlobal, 'checkedGlobal')
              if(this.checkedGlobal.toString() === 'false'){
                // Par donnée
                switch(this.selectedCourbe){
                  case "Nombre de tickets": 
                    this.legende = "Nombre de tickets ouverts cette année par base";
                    this.unite = ''
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push(this.selectedFiltre)
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable = this.statService.getStatNombreTicketsAnneeChoixEntreprise().subscribe((res) => {
                      // Récupération des données de la table StatNombreTickets
                      var statNbTickets = JSON.parse(JSON.stringify(res)).data
                      console.log(statNbTickets, 'statNbTickets')

                      //Chart Labels
                      categories = []
                      for(let row of statNbTickets){
                        if(!categories.includes(row.entreprise + ' - ' + row.base))  categories.push(row.entreprise + ' - ' + row.base)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<labels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statNbTickets){
                            let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                            let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                            if(labels[i] === row.month && ese === row.entreprise && base === row.base)  item.data[item.data.length - 1] = row.quantite
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;
                    });
                    this.listSubscription.push(variable);
                  break;

                  case "Temps de réponse": 
                    this.legende = "Moyenne du temps de réponse de cette année par base";
                    this.unite = '(en heure)'
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push(this.selectedFiltre)
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable1 = this.statService.getStatTempsReponseAnneeChoixEntreprise().subscribe((res) => {
                      var statTempsReponse = JSON.parse(JSON.stringify(res)).data
                      console.log(statTempsReponse, 'statTempsReponse')

                      //Chart Labels
                      categories = []
                      for(let row of statTempsReponse){
                        if(!categories.includes(row.entreprise + ' - ' + row.base))  categories.push(row.entreprise + ' - ' + row.base)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<labels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statTempsReponse){
                            let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                            let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                            if(labels[i] === row.month && ese === row.entreprise && base === row.base)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2) 
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;
                    });
                    this.listSubscription.push(variable1);
                  break;

                  case "Temps de résolution": 
                    this.legende = "Moyenne du temps de résolution de cette année par base";
                    this.unite = '(en jour)'
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push(this.selectedFiltre)
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable2 = this.statService.getStatTempsResolutionAnneeChoixEntreprise().subscribe((res) => {
                      var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                      console.log(statTempsResolution, 'statTempsResolution')

                      //Chart Labels
                      categories = []
                      for(let row of statTempsResolution){
                        if(!categories.includes(row.entreprise + ' - ' + row.base))  categories.push(row.entreprise + ' - ' + row.base)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<labels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statTempsResolution){
                            let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                            let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                            if(labels[i] === row.month && ese === row.entreprise && base === row.base && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)   // moyenne
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;

                    });
                    this.listSubscription.push(variable2);
                    break;
                  }
              }
              else{
                // Par donnée
                switch(this.selectedCourbe){
                  case "Nombre de tickets": 
                    this.legende = "Nombre de tickets ouverts cette année par entreprise"
                    this.unite = ''
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push('Global')
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable = this.statService.getStatNombreTicketsAnneeChoixEntreprise().subscribe((res) => {
                      // Récupération des données de la table StatNombreTickets
                      var statNbTickets = JSON.parse(JSON.stringify(res)).data
                      console.log(statNbTickets, 'statNbTickets')

                      //Chart Labels
                      categories = []
                      for(let row of statNbTickets) {
                        if(!categories.includes(row.entreprise))  categories.push(row.entreprise)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<labels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statNbTickets){
                            if(labels[i] === row.month && item.categorie === row.entreprise)  item.data[item.data.length - 1] += row.quantite
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;
                    });
                    this.listSubscription.push(variable);
                  break;

                  case "Temps de réponse": 
                    this.legende = "Moyenne du temps de réponse de cette année par entreprise"
                    this.unite = '(en heure)'
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push('Global')
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable1 = this.statService.getStatTempsReponseAnneeChoixEntreprise().subscribe((res) => {
                      var statTempsReponse = JSON.parse(JSON.stringify(res)).data
                      console.log(statTempsReponse, 'statTempsReponse')

                      //Chart Labels
                      categories = []
                      for(let row of statTempsReponse){
                        if(!categories.includes(row.entreprise))  categories.push(row.entreprise)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<labels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statTempsReponse){
                            if(labels[i] === row.month && item.categorie === row.entreprise) item.data[item.data.length - 1] += (row.tempsReponse/row.nbTicketsConcernes).toFixed(2)
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;
                    });
                    this.listSubscription.push(variable1);
                  break;

                  case "Temps de résolution": 
                    this.legende = "Moyenne du temps de résolution de cette année par entreprise"
                    this.unite = '(en jour)'
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push('Global')
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable2 = this.statService.getStatTempsResolutionAnneeChoixEntreprise().subscribe((res) => {
                      var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                      console.log(statTempsResolution, 'statTempsResolution')

                      //Chart Labels
                      categories = []
                      for(let row of statTempsResolution){
                        if(!categories.includes(row.entreprise))  categories.push(row.entreprise)                      
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<labels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statTempsResolution){
                            if(labels[i] === row.month && item.categorie === row.entreprise && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] += (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)   // moyenne
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;

                    });
                    this.listSubscription.push(variable2);
                    break;
                  }
                }
            }
            break;

          case "Responsable de dossier":
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legende = "Nombre de tickets ouverts cette année filtré par responsable de dossier"
                this.unite = ''
                // Application du filtre
                this.statService.filtre = 'Responsable de dossier'
                const variable = this.statService.getStatNombreTicketsAnnee().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statNbTickets = JSON.parse(JSON.stringify(res)).data
                  console.log(statNbTickets, 'statNbTickets')

                  //Chart Labels
                  categories = []
                  for(let row of statNbTickets){
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<labels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statNbTickets){
                        if(labels[i] === row.month && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable);
              break;

              case "Temps de réponse": 
                this.legende = "Moyenne du temps de réponse de cette année filtré par responsable de dossier"
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Responsable de dossier'
                const variable1 = this.statService.getStatTempsReponseAnnee().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsReponse= JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  //Chart Labels
                  categories = []
                  for(let row of statTempsReponse){
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<labels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsReponse){
                        if(labels[i] === row.month && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2) 
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable1);
              break;

              case "Temps de résolution": 
                this.legende = "Moyenne du temps de résolution de cette année filtré par responsable de dossier"
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Responsable de dossier'
                const variable2 = this.statService.getStatTempsResolutionAnnee().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')
                  
                  //Chart Labels
                  categories = []
                  for(let row of statTempsResolution){
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<labels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsResolution){
                        if(labels[i] === row.month && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2) // moyenne
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable2);
              break;
            }
            break;
        }
        break;

      case "Mois":
        //Chart Labels
        this.lineChartLabels = [];
        // Par type
        switch(this.selected){
          case "Type d\'objet":
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legende = "Nombre de tickets ouverts ce mois-ci filtré par type d'objet";
                this.unite = ''
                 // Application du filtre
                 this.statService.filtre = 'Type d\'objet'
                 const variable = this.statService.getStatNombreTicketsMois().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statNbTickets = JSON.parse(JSON.stringify(res)).data
                  console.log(statNbTickets, 'statNbTickets')

                  //Chart Labels
                  categories = []
                  for(let row of statNbTickets){
                    this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statNbTickets){
                        if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable);
              break;

              case "Temps de réponse":
                this.legende = "Moyenne du temps de réponse de ce mois-ci filtré par type d'objet";
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Type d\'objet'
                const variable1 = this.statService.getStatTempsReponseMois().subscribe((res) => {
                  // Récupération des données de la table StatTempsReponse
                  var statTempsReponse= JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  //Chart Labels
                  categories = []
                  for(let row of statTempsReponse){
                    this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsReponse){
                        if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2) 
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable1);
              break;

              case "Temps de résolution": 
                this.legende = "Moyenne du temps de résolution de ce mois-ci filtré par type d'objet";
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Type d\'objet'
                const variable2 = this.statService.getStatTempsResolutionMois().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')
                  
                  //Chart Labels
                  categories = []
                  for(let row of statTempsResolution){
                    this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsResolution){
                        if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2) // moyenne
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable2);

              break;
            }
            break;

          case "Impact":
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legende = "Nombre de tickets ouverts ce mois-ci filtré par impact";
                this.unite = ''
                // Application du filtre
                this.statService.filtre = 'Impact'
                const variable = this.statService.getStatNombreTicketsMois().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statNbTickets = JSON.parse(JSON.stringify(res)).data
                  console.log(statNbTickets, 'statNbTickets')

                  //Chart Labels
                  categories = []
                  for(let row of statNbTickets){
                    this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statNbTickets){
                        if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable);
              break;

              case "Temps de réponse": 
                this.legende = "Moyenne du temps de réponse de ce mois-ci filtré par impact";
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Impact'
                const variable1 = this.statService.getStatTempsReponseMois().subscribe((res) => {
                  // Récupération des données de la table StatTempsReponse
                  var statTempsReponse= JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  //Chart Labels
                  categories = []
                  for(let row of statTempsReponse){
                    this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsReponse){
                        if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2) 
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable1);
              break;

              case "Temps de résolution": 
                this.legende = "Moyenne du temps de résolution de ce mois-ci filtré par impact";
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Impact'
                const variable2 = this.statService.getStatTempsResolutionMois().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')
                  
                  //Chart Labels
                  categories = []
                  for(let row of statTempsResolution){
                    this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsResolution){
                        if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2) // moyenne
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable2);
              break;
            }
            break;

          case "Etat":
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legende = "Nombre de tickets ouverts ce mois-ci filtré par état";
                this.unite = ''
                // Application du filtre
                this.statService.filtre = 'Etat'
                const variable = this.statService.getStatNombreTicketsMois().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statNbTickets = JSON.parse(JSON.stringify(res)).data
                  console.log(statNbTickets, 'statNbTickets')

                  //Chart Labels
                  categories = []
                  for(let row of statNbTickets){
                    this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statNbTickets){
                        if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable);
              break;

              case "Temps de réponse": 
                this.legende = "Moyenne du temps de réponse de ce mois-ci filtré par état";
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Etat'
                const variable1 = this.statService.getStatTempsReponseMois().subscribe((res) => {
                  // Récupération des données de la table StatTempsReponse
                  var statTempsReponse= JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  //Chart Labels
                  categories = []
                  for(let row of statTempsReponse){
                    this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsReponse){
                        if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2) 
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable1);
              break;

              case "Temps de résolution": 
                this.legende = "Moyenne du temps de résolution de ce mois-ci filtré par état";
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Etat'
                const variable2 = this.statService.getStatTempsResolutionMois().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')
                  
                  //Chart Labels
                  categories = []
                  for(let row of statTempsResolution){
                    this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsResolution){
                        if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2) // moyenne
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable2);
              break;
            }
            break;

          case "Module":
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legende = "Nombre de tickets ouverts ce mois-ci filtré par module";
                this.unite = ''
                // Application du filtre
                this.statService.filtre = 'Module'
                const variable = this.statService.getStatNombreTicketsMois().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statNbTickets = JSON.parse(JSON.stringify(res)).data
                  console.log(statNbTickets, 'statNbTickets')

                  //Chart Labels
                  categories = []
                  for(let row of statNbTickets){
                    this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statNbTickets){
                        if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable);

              break;

              case "Temps de réponse": 
                this.legende = "Moyenne du temps de réponse de ce mois-ci filtré par module";
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Module'
                const variable1 = this.statService.getStatTempsReponseMois().subscribe((res) => {
                  // Récupération des données de la table StatTempsReponse
                  var statTempsReponse= JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  //Chart Labels
                  categories = []
                  for(let row of statTempsReponse){
                    this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsReponse){
                        if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2) 
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable1);
              break;

              case "Temps de résolution": 
                this.legende = "Moyenne du temps de résolution de ce mois-ci filtré par module";
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Module'
                const variable2 = this.statService.getStatTempsResolutionMois().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')
                  
                  //Chart Labels
                  categories = []
                  for(let row of statTempsResolution){
                    this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsResolution){
                        if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2) // moyenne
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable2);
              break;
            }
            break;

          case "Ordre de priorité":
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legende = "Nombre de tickets ouverts ce mois-ci filtré par ordre de priorité";
                this.unite = ''
                // Application du filtre
                this.statService.filtre = 'Ordre de priorité'
                const variable = this.statService.getStatNombreTicketsMois().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statNbTickets = JSON.parse(JSON.stringify(res)).data
                  console.log(statNbTickets, 'statNbTickets')

                  //Chart Labels
                  categories = []
                  for(let row of statNbTickets){
                    this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statNbTickets){
                        if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable);
              break;

              case "Temps de réponse": 
                this.legende = "Moyenne du temps de réponse de ce mois-ci filtré par ordre de priorité";
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Ordre de priorité'
                const variable1 = this.statService.getStatTempsReponseMois().subscribe((res) => {
                  // Récupération des données de la table StatTempsReponse
                  var statTempsReponse= JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  //Chart Labels
                  categories = []
                  for(let row of statTempsReponse){
                    this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsReponse){
                        if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2) 
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable1);
              break;

              case "Temps de résolution": 
                this.legende = "Moyenne du temps de résolution de ce mois-ci filtré par ordre de priorité";
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Ordre de priorité'
                const variable2 = this.statService.getStatTempsResolutionMois().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')
                  
                  //Chart Labels
                  categories = []
                  for(let row of statTempsResolution){
                    this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsResolution){
                        if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2) // moyenne
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable2);
              break;
            }
            break;

          case "Entreprise":
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legende = "Nombre de tickets ouverts ce mois-ci filtré par entreprise";
                this.unite = ''
                // Application du filtre
                this.statService.filtre = 'Entreprise'
                const variable = this.statService.getStatNombreTicketsMois().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statNbTickets = JSON.parse(JSON.stringify(res)).data
                  console.log(statNbTickets, 'statNbTickets')

                  //Chart Labels
                  categories = []
                  for(let row of statNbTickets){
                    this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statNbTickets){
                        if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable);
              break;

              case "Temps de réponse": 
                this.legende = "Moyenne du temps de réponse de ce mois-ci filtré par entreprise";
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Entreprise'
                const variable1 = this.statService.getStatTempsReponseMois().subscribe((res) => {
                  // Récupération des données de la table StatTempsReponse
                  var statTempsReponse= JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  //Chart Labels
                  categories = []
                  for(let row of statTempsReponse){
                    this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsReponse){
                        if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2) 
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable1);
              break;

              case "Temps de résolution": 
                this.legende = "Moyenne du temps de résolution de ce mois-ci filtré par entreprise";
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Entreprise'
                const variable2 = this.statService.getStatTempsResolutionMois().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')
                  
                  //Chart Labels
                  categories = []
                  for(let row of statTempsResolution){
                    this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsResolution){
                        if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2) // moyenne
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable2);
              break;
            }
            break;

          case "Choix Entreprise":
            // Le filtre sélectionné n'est pas 'Global'
            if(this.selectedFiltre !== 'Global') {
              console.log(this.checkedGlobal, 'checkedGlobal')
              if(this.checkedGlobal.toString() === 'false'){
                // Par donnée
                switch(this.selectedCourbe){
                  case "Nombre de tickets": 
                    this.legende = "Nombre de tickets ouverts ce mois-ci par base filtré par " + this.selectedFiltre.toLowerCase();
                    this.unite = ''
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push(this.selectedFiltre)
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable = this.statService.getStatNombreTicketsMoisChoixEntreprise().subscribe((res) => {
                      // Récupération des données de la table StatNombreTickets
                      var statNbTickets = JSON.parse(JSON.stringify(res)).data
                      console.log(statNbTickets, 'statNbTickets')

                      //Chart Labels
                      this.lineChartLabels = []
                      categories = []
                      for(let row of statNbTickets){
                        this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                        if(!categories.includes(row.entreprise + ' - ' + row.base + ': ' + row.categorie))  categories.push(row.entreprise + ' - ' + row.base + ': ' + row.categorie)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<this.lineChartLabels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statNbTickets){
                            let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                            let debutbase: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                            let base = debutbase.substr(0, debutbase.indexOf(':'))
                            let categorie = item.categorie.substr(item.categorie.indexOf(': ') + 2)
                            if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && ese === row.entreprise && base === row.base && categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;
                    });
                    this.listSubscription.push(variable);
                  break;

                  case "Temps de réponse": 
                    this.legende = "Moyenne du temps de réponse de ce mois-ci par base filtré par " + this.selectedFiltre.toLowerCase();
                    this.unite = '(en heure)'
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push(this.selectedFiltre)
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable1 = this.statService.getStatTempsReponseMoisChoixEntreprise().subscribe((res) => {
                      var statTempsReponse = JSON.parse(JSON.stringify(res)).data
                      console.log(statTempsReponse, 'statTempsReponse')

                      //Chart Labels
                      this.lineChartLabels = []
                      categories = []
                      for(let row of statTempsReponse){
                        this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                        if(!categories.includes(row.entreprise + ' - ' + row.base + ': ' + row.categorie))  categories.push(row.entreprise + ' - ' + row.base + ': ' + row.categorie)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<this.lineChartLabels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statTempsReponse){
                            let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                            let debutbase: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                            let base = debutbase.substr(0, debutbase.indexOf(':'))
                            let categorie = item.categorie.substr(item.categorie.indexOf(': ') + 2)
                            if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && ese === row.entreprise && base === row.base && categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2)
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;
                    });
                    this.listSubscription.push(variable1);
                  break;

                  case "Temps de résolution": 
                    this.legende = "Moyenne du temps de résolution de ce mois-ci par base filtré par " + this.selectedFiltre.toLowerCase();
                    this.unite = '(en jour)'
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push(this.selectedFiltre)
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable2 = this.statService.getStatTempsResolutionMoisChoixEntreprise().subscribe((res) => {
                      var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                      console.log(statTempsResolution, 'statTempsResolution')

                      //Chart Labels
                      this.lineChartLabels = []
                      categories = []
                      for(let row of statTempsResolution){
                        this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                        if(!categories.includes(row.entreprise + ' - ' + row.base + ': ' + row.categorie))  categories.push(row.entreprise + ' - ' + row.base + ': ' + row.categorie)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<this.lineChartLabels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statTempsResolution){
                            let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                            let debutbase: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                            let base = debutbase.substr(0, debutbase.indexOf(':'))
                            let categorie = item.categorie.substr(item.categorie.indexOf(': ') + 2)
                            if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && ese === row.entreprise && base === row.base && categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)   // moyenne
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;

                    });
                    this.listSubscription.push(variable2);
                  break;
                }
              }
              else{
                // Par donnée
                switch(this.selectedCourbe){
                  case "Nombre de tickets": 
                    this.legende = "Nombre de tickets ouverts ce mois-ci par base";
                    this.unite = ''
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push('Global')
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable = this.statService.getStatNombreTicketsMoisChoixEntreprise().subscribe((res) => {
                      // Récupération des données de la table StatNombreTickets
                      var statNbTickets = JSON.parse(JSON.stringify(res)).data
                      console.log(statNbTickets, 'statNbTickets')

                      //Chart Labels
                      this.lineChartLabels = []
                      categories = []
                      for(let row of statNbTickets){
                        this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                        if(!categories.includes(row.entreprise + ' - ' + row.base))  categories.push(row.entreprise + ' - ' + row.base)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<this.lineChartLabels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statNbTickets){
                            let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                            let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                            if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && ese === row.entreprise && base === row.base)  item.data[item.data.length - 1] = row.quantite
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;
                    });
                    this.listSubscription.push(variable);
                  break;

                  case "Temps de réponse": 
                    this.legende = "Moyenne du temps de réponse de ce mois-ci par base";
                    this.unite = '(en heure)'
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push('Global')
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable1 = this.statService.getStatTempsReponseMoisChoixEntreprise().subscribe((res) => {
                      var statTempsReponse = JSON.parse(JSON.stringify(res)).data
                      console.log(statTempsReponse, 'statTempsReponse')

                      //Chart Labels
                      this.lineChartLabels = []
                      categories = []
                      for(let row of statTempsReponse){
                        this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                        if(!categories.includes(row.entreprise + ' - ' + row.base))  categories.push(row.entreprise + ' - ' + row.base)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<this.lineChartLabels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statTempsReponse){
                            let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                            let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                            if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && ese === row.entreprise && base === row.base)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2) 
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;
                    });
                    this.listSubscription.push(variable1);
                  break;

                  case "Temps de résolution": 
                    this.legende = "Moyenne du temps de résolution de ce mois-ci par base";
                    this.unite = '(en jour)'
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push('Global')
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable2 = this.statService.getStatTempsResolutionMoisChoixEntreprise().subscribe((res) => {
                      var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                      console.log(statTempsResolution, 'statTempsResolution')

                      //Chart Labels
                      this.lineChartLabels = []
                      categories = []
                      for(let row of statTempsResolution){
                        this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                        if(!categories.includes(row.entreprise + ' - ' + row.base))  categories.push(row.entreprise + ' - ' + row.base)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<this.lineChartLabels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statTempsResolution){
                            let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                            let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                            if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && ese === row.entreprise && base === row.base && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)   // moyenne
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;

                    });
                    this.listSubscription.push(variable2);
                    break;
                  }
                }
            }
            else {
              console.log(this.checkedGlobal, 'checkedGlobal')
              if(this.checkedGlobal.toString() === 'false'){
                // Par donnée
                switch(this.selectedCourbe){
                  case "Nombre de tickets": 
                    this.legende = "Nombre de tickets ouverts ce mois-ci par base";
                    this.unite = ''
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push(this.selectedFiltre)
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable = this.statService.getStatNombreTicketsMoisChoixEntreprise().subscribe((res) => {
                      // Récupération des données de la table StatNombreTickets
                      var statNbTickets = JSON.parse(JSON.stringify(res)).data
                      console.log(statNbTickets, 'statNbTickets')

                      //Chart Labels
                      this.lineChartLabels = []
                      categories = []
                      for(let row of statNbTickets){
                        this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                        if(!categories.includes(row.entreprise + ' - ' + row.base))  categories.push(row.entreprise + ' - ' + row.base)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<this.lineChartLabels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statNbTickets){
                            let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                            let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                            if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && ese === row.entreprise && base === row.base )  item.data[item.data.length - 1] = row.quantite
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;
                    });
                    this.listSubscription.push(variable);
                  break;

                  case "Temps de réponse": 
                    this.legende = "Moyenne du temps de réponse de ce mois-ci par base";
                    this.unite = '(en heure)'
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push(this.selectedFiltre)
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable1 = this.statService.getStatTempsReponseMoisChoixEntreprise().subscribe((res) => {
                      var statTempsReponse = JSON.parse(JSON.stringify(res)).data
                      console.log(statTempsReponse, 'statTempsReponse')

                      //Chart Labels
                      this.lineChartLabels = []
                      categories = []
                      for(let row of statTempsReponse){
                        this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                        if(!categories.includes(row.entreprise + ' - ' + row.base))  categories.push(row.entreprise + ' - ' + row.base)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<this.lineChartLabels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statTempsReponse){
                            let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                            let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                            if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && ese === row.entreprise && base === row.base)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2) 
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;
                    });
                    this.listSubscription.push(variable1);
                  break;

                  case "Temps de résolution": 
                    this.legende = "Moyenne du temps de résolution de ce mois-ci par base";
                    this.unite = '(en jour)'
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push(this.selectedFiltre)
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable2 = this.statService.getStatTempsResolutionMoisChoixEntreprise().subscribe((res) => {
                      var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                      console.log(statTempsResolution, 'statTempsResolution')

                      //Chart Labels
                      this.lineChartLabels = []
                      categories = []
                      for(let row of statTempsResolution){
                        this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                        if(!categories.includes(row.entreprise + ' - ' + row.base))  categories.push(row.entreprise + ' - ' + row.base)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<this.lineChartLabels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statTempsResolution){
                            let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                            let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                            if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && ese === row.entreprise && base === row.base && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)   // moyenne
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;

                    });
                    this.listSubscription.push(variable2);
                    break;
                  }
              }
              else{
                // Par donnée
                switch(this.selectedCourbe){
                  case "Nombre de tickets": 
                    this.legende = "Nombre de tickets ouverts ce mois-ci par entreprise";
                    this.unite = ''
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push('Global')
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable = this.statService.getStatNombreTicketsMoisChoixEntreprise().subscribe((res) => {
                      // Récupération des données de la table StatNombreTickets
                      var statNbTickets = JSON.parse(JSON.stringify(res)).data
                      console.log(statNbTickets, 'statNbTickets')

                      //Chart Labels
                      this.lineChartLabels = []
                      categories = []
                      for(let row of statNbTickets) {
                        this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                        if(!categories.includes(row.entreprise))  categories.push(row.entreprise)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<this.lineChartLabels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statNbTickets){
                            if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.entreprise)  item.data[item.data.length - 1] += row.quantite
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;
                    });
                    this.listSubscription.push(variable);
                  break;

                  case "Temps de réponse": 
                    this.legende = "Moyenne du temps de réponse de ce mois-ci par entreprise";
                    this.unite = '(en heure)'
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push('Global')
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable1 = this.statService.getStatTempsReponseMoisChoixEntreprise().subscribe((res) => {
                      var statTempsReponse = JSON.parse(JSON.stringify(res)).data
                      console.log(statTempsReponse, 'statTempsReponse')

                      //Chart Labels
                      this.lineChartLabels = []
                      categories = []
                      for(let row of statTempsReponse){
                        this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                        if(!categories.includes(row.entreprise))  categories.push(row.entreprise)
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<this.lineChartLabels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statTempsReponse){
                            if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.entreprise)  item.data[item.data.length - 1] += (row.tempsReponse/row.nbTicketsConcernes).toFixed(2) 
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;
                    });
                    this.listSubscription.push(variable1);
                  break;

                  case "Temps de résolution": 
                    this.legende = "Moyenne du temps de résolution de ce mois-ci par entreprise";
                    this.unite = '(en jour)'
                    // Application du filtre
                    this.statService.filtreEntreprise = []
                    this.statService.filtreEntreprise.push('Global')
                    this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                    console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                    const variable2 = this.statService.getStatTempsResolutionMoisChoixEntreprise().subscribe((res) => {
                      var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                      console.log(statTempsResolution, 'statTempsResolution')

                      //Chart Labels
                      this.lineChartLabels = []
                      categories = []
                      for(let row of statTempsResolution){
                        this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                        if(!categories.includes(row.entreprise))  categories.push(row.entreprise)                      
                      }

                      // Insertion des categories
                      dataEtCategorie = []
                      for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                      // Alimentation data
                      for(let i=0; i<this.lineChartLabels.length; i++){
                        for(let item of dataEtCategorie){
                          item.data.push(0);
                          for(let row of statTempsResolution){
                            if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.entreprise && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] += (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)   // moyenne
                          }
                        }
                      }

                      // Paramétrage du graphe par type et du graphe global avec les données
                      this.lineChartReady = false;
                      // Graphe par type
                      this.lineChartData = [];
                      for(let item of dataEtCategorie){
                        color = this.getRandomColor();
                        this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                      }
                      this.lineChartReady = true;

                    });
                    this.listSubscription.push(variable2);
                    break;
                  }
                }
            }
            break;

          case "Responsable de dossier":
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legende = "Nombre de tickets ouverts ce mois-ci filtré par responsable de dossier";
                    this.unite = ''
                // Application du filtre
                this.statService.filtre = 'Responsable de dossier'
                const variable = this.statService.getStatNombreTicketsMois().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statNbTickets = JSON.parse(JSON.stringify(res)).data
                  console.log(statNbTickets, 'statNbTickets')

                  //Chart Labels
                  categories = []
                  for(let row of statNbTickets){
                    this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statNbTickets){
                        if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable);
              break;

              case "Temps de réponse": 
                this.legende = "Moyenne du temps de réponse de ce mois-ci filtré par responsable de dossier";
                    this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Responsable de dossier'
                const variable1 = this.statService.getStatTempsReponseMois().subscribe((res) => {
                  // Récupération des données de la table StatTempsReponse
                  var statTempsReponse= JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  //Chart Labels
                  categories = []
                  for(let row of statTempsReponse){
                    this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsReponse){
                        if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2) 
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable1);
              break;

              case "Temps de résolution": 
                this.legende = "Moyenne du temps de résolution de ce mois-ci filtré par responsable de dossier";
                    this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Responsable de dossier'
                const variable2 = this.statService.getStatTempsResolutionMois().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')
                  
                  //Chart Labels
                  categories = []
                  for(let row of statTempsResolution){
                    this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsResolution){
                        if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2) // moyenne
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable2);
              break;
            }
            break;
        }
        break;

      case "Semaine":
        //Chart Labels
        //Chart Labels
        this.lineChartLabels = []
        this.lineChartLabels = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"];
        let checkLabels = []
        // Par type
        switch(this.selected){
          case "Type d\'objet":
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legende = "Nombre de tickets ouverts cette semaine filtré par type d'objet";
                this.unite = ''
                // Application du filtre
                this.statService.filtre = 'Type d\'objet'
                const variable = this.statService.getStatNombreTicketsSemaine().subscribe((res) => {
                   // Récupération des données de la table statNbTickets
                   var statNbTickets = JSON.parse(JSON.stringify(res)).data
                   console.log(statNbTickets, 'statNbTickets')

                   //Chart Labels
                    categories = []
                    for(let row of statNbTickets){
                      if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                      if(!categories.includes(row.categorie))  categories.push(row.categorie)
                    }

                    // Insertion des categories
                    dataEtCategorie = []
                    for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                    // Alimentation data
                    for(let i=0; i<this.lineChartLabels.length; i++){
                      for(let item of dataEtCategorie){
                        item.data.push(0);
                        for(let row of statNbTickets){
                          if(checkLabels[i] === row.jour && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                        }
                      }
                    }

                    // Paramétrage du graphe par type et du graphe global avec les données
                    this.lineChartReady = false;
                    // Graphe par type
                    this.lineChartData = [];
                    for(let item of dataEtCategorie){
                      color = this.getRandomColor();
                      this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                    }
                    this.lineChartReady = true;

                });
                this.listSubscription.push(variable);
              break;

              case "Temps de réponse": 
                this.legende = "Moyenne du temps de réponse de cette semaine filtré par type d'objet";
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Type d\'objet'
                const variable1 = this.statService.getStatTempsReponseSemaine().subscribe((res) => {
                  // Récupération des données de la table StatTempsReponse
                  var statTempsReponse= JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  //Chart Labels
                  categories = []
                  for(let row of statTempsReponse){
                    if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsReponse){
                        if(checkLabels[i] === row.jour && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse).toFixed(2) 
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable1);
              break;

              case "Temps de résolution": 
                this.legende = "Moyenne du temps de résolution de cette semaine filtré par type d'objet";
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Type d\'objet'
                const variable2 = this.statService.getStatTempsResolutionSemaine().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')

                  //Chart Labels
                  categories = []
                  for(let row of statTempsResolution){
                    if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsResolution){
                        if(checkLabels[i] === row.jour && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2) // moyenne
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;
                });
                this.listSubscription.push(variable2);
              break;
            }
            break;

          case "Impact":
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legende = "Nombre de tickets ouverts cette semaine filtré par impact";
                this.unite = ''
                // Application du filtre
                this.statService.filtre = 'Impact'
                const variable = this.statService.getStatNombreTicketsSemaine().subscribe((res) => {
                   // Récupération des données de la table statNbTickets
                   var statNbTickets = JSON.parse(JSON.stringify(res)).data
                   console.log(statNbTickets, 'statNbTickets')

                   //Chart Labels
                    categories = []
                    for(let row of statNbTickets){
                      if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                      if(!categories.includes(row.categorie))  categories.push(row.categorie)
                    }

                    // Insertion des categories
                    dataEtCategorie = []
                    for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                    // Alimentation data
                    for(let i=0; i<this.lineChartLabels.length; i++){
                      for(let item of dataEtCategorie){
                        item.data.push(0);
                        for(let row of statNbTickets){
                          if(checkLabels[i] === row.jour && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                        }
                      }
                    }

                    // Paramétrage du graphe par type et du graphe global avec les données
                    this.lineChartReady = false;
                    // Graphe par type
                    this.lineChartData = [];
                    for(let item of dataEtCategorie){
                      color = this.getRandomColor();
                      this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                    }
                    this.lineChartReady = true;

                });
                this.listSubscription.push(variable);
              break;

              case "Temps de réponse": 
                this.legende = "Moyenne du temps de réponse de cette semaine filtré par impact";
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Impact'
                const variable1 = this.statService.getStatTempsReponseSemaine().subscribe((res) => {
                  // Récupération des données de la table StatTempsReponse
                  var statTempsReponse= JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  //Chart Labels
                  categories = []
                  for(let row of statTempsReponse){
                    if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsReponse){
                        if(checkLabels[i] === row.jour && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse).toFixed(2) // 7 jours dans 1 semaine
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable1);
              break;

              case "Temps de résolution": 
                this.legende = "Moyenne du temps de résolution de cette semaine filtré par impact";
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Impact'
                const variable2 = this.statService.getStatTempsResolutionSemaine().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')

                  //Chart Labels
                  categories = []
                  for(let row of statTempsResolution){
                    if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsResolution){
                        if(checkLabels[i] === row.jour && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2) // moyenne
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;
                });
                this.listSubscription.push(variable2);
              break;
            }
            break;

          case "Etat":
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legende = "Nombre de tickets ouverts cette semaine filtré par état";
                this.unite = ''
                // Application du filtre
                this.statService.filtre = 'Etat'
                const variable = this.statService.getStatNombreTicketsSemaine().subscribe((res) => {
                   // Récupération des données de la table statNbTickets
                   var statNbTickets = JSON.parse(JSON.stringify(res)).data
                   console.log(statNbTickets, 'statNbTickets')

                   //Chart Labels
                    categories = []
                    for(let row of statNbTickets){
                      if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                      if(!categories.includes(row.categorie))  categories.push(row.categorie)
                    }

                    // Insertion des categories
                    dataEtCategorie = []
                    for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                    // Alimentation data
                    for(let i=0; i<this.lineChartLabels.length; i++){
                      for(let item of dataEtCategorie){
                        item.data.push(0);
                        for(let row of statNbTickets){
                          if(checkLabels[i] === row.jour && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                        }
                      }
                    }

                    // Paramétrage du graphe par type et du graphe global avec les données
                    this.lineChartReady = false;
                    // Graphe par type
                    this.lineChartData = [];
                    for(let item of dataEtCategorie){
                      color = this.getRandomColor();
                      this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                    }
                    this.lineChartReady = true;

                });
                this.listSubscription.push(variable);
              break;

              case "Temps de réponse": 
                this.legende = "Moyenne du temps de réponse de cette semaine filtré par état";
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Etat'
                const variable1 = this.statService.getStatTempsReponseSemaine().subscribe((res) => {
                  // Récupération des données de la table StatTempsReponse
                  var statTempsReponse= JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  //Chart Labels
                  categories = []
                  for(let row of statTempsReponse){
                    if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsReponse){
                        if(checkLabels[i] === row.jour && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse).toFixed(2) // 7 jours dans 1 semaine
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable1);
              break;

              case "Temps de résolution": 
                this.legende = "Moyenne du temps de résolution de cette semaine filtré par état";
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Etat'
                const variable2 = this.statService.getStatTempsResolutionSemaine().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')

                  //Chart Labels
                  categories = []
                  for(let row of statTempsResolution){
                    if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsResolution){
                        if(checkLabels[i] === row.jour && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2) // moyenne
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;
                });
                this.listSubscription.push(variable2);
              break;
            }
            break;

          case "Module":
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legende = "Nombre de tickets ouverts cette semaine filtré par module";
                this.unite = ''
                // Application du filtre
                this.statService.filtre = 'Module'
                const variable = this.statService.getStatNombreTicketsSemaine().subscribe((res) => {
                   // Récupération des données de la table statNbTickets
                   var statNbTickets = JSON.parse(JSON.stringify(res)).data
                   console.log(statNbTickets, 'statNbTickets')

                   //Chart Labels
                    categories = []
                    for(let row of statNbTickets){
                      if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                      if(!categories.includes(row.categorie))  categories.push(row.categorie)
                    }

                    // Insertion des categories
                    dataEtCategorie = []
                    for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                    // Alimentation data
                    for(let i=0; i<this.lineChartLabels.length; i++){
                      for(let item of dataEtCategorie){
                        item.data.push(0);
                        for(let row of statNbTickets){
                          if(checkLabels[i] === row.jour && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                        }
                      }
                    }

                    // Paramétrage du graphe par type et du graphe global avec les données
                    this.lineChartReady = false;
                    // Graphe par type
                    this.lineChartData = [];
                    for(let item of dataEtCategorie){
                      color = this.getRandomColor();
                      this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                    }
                    this.lineChartReady = true;

                });
                this.listSubscription.push(variable);
              break;

              case "Temps de réponse": 
                this.legende = "Moyenne du temps de réponse de cette semaine filtré par module";
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Module'
                const variable1 = this.statService.getStatTempsReponseSemaine().subscribe((res) => {
                  // Récupération des données de la table StatTempsReponse
                  var statTempsReponse= JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  //Chart Labels
                  categories = []
                  for(let row of statTempsReponse){
                    if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsReponse){
                        if(checkLabels[i] === row.jour && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse).toFixed(2) // 7 jours dans 1 semaine
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable1);
              break;

              case "Temps de résolution": 
                this.legende = "Moyenne du temps de résolution de cette semaine filtré par module";
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Module'
                const variable2 = this.statService.getStatTempsResolutionSemaine().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')

                  //Chart Labels
                  categories = []
                  for(let row of statTempsResolution){
                    if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsResolution){
                        if(checkLabels[i] === row.jour && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2) // moyenne
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;
                });
                this.listSubscription.push(variable2);
              break;
            }
            break;

          case "Ordre de priorité":
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legende = "Nombre de tickets ouverts cette semaine filtré par ordre de priorité";
                this.unite = ''
                // Application du filtre
                this.statService.filtre = 'Ordre de priorité'
                const variable = this.statService.getStatNombreTicketsSemaine().subscribe((res) => {
                   // Récupération des données de la table statNbTickets
                   var statNbTickets = JSON.parse(JSON.stringify(res)).data
                   console.log(statNbTickets, 'statNbTickets')

                   //Chart Labels
                    categories = []
                    for(let row of statNbTickets){
                      if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                      if(!categories.includes(row.categorie))  categories.push(row.categorie)
                    }

                    // Insertion des categories
                    dataEtCategorie = []
                    for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                    // Alimentation data
                    for(let i=0; i<this.lineChartLabels.length; i++){
                      for(let item of dataEtCategorie){
                        item.data.push(0);
                        for(let row of statNbTickets){
                          if(checkLabels[i] === row.jour && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                        }
                      }
                    }

                    // Paramétrage du graphe par type et du graphe global avec les données
                    this.lineChartReady = false;
                    // Graphe par type
                    this.lineChartData = [];
                    for(let item of dataEtCategorie){
                      color = this.getRandomColor();
                      this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                    }
                    this.lineChartReady = true;

                });
                this.listSubscription.push(variable);
              break;

              case "Temps de réponse": 
                this.legende = "Moyenne du temps de réponse de cette semaine filtré par ordre de priorité";
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Ordre de priorité'
                const variable1 = this.statService.getStatTempsReponseSemaine().subscribe((res) => {
                  // Récupération des données de la table StatTempsReponse
                  var statTempsReponse= JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  //Chart Labels
                  categories = []
                  for(let row of statTempsReponse){
                    if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsReponse){
                        if(checkLabels[i] === row.jour && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse).toFixed(2) // 7 jours dans 1 semaine
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable1);
              break;

              case "Temps de résolution": 
                this.legende = "Moyenne du temps de résolution de cette semaine filtré par ordre de priorité";
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Ordre de priorité'
                const variable2 = this.statService.getStatTempsResolutionSemaine().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')

                  //Chart Labels
                  categories = []
                  for(let row of statTempsResolution){
                    if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsResolution){
                        if(checkLabels[i] === row.jour && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2) // moyenne
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;
                });
                this.listSubscription.push(variable2);
              break;
            }
            break;

          case "Entreprise":
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legende = "Nombre de tickets ouverts cette semaine filtré par entreprise";
                this.unite = ''
                // Application du filtre
                this.statService.filtre = 'Entreprise'
                const variable = this.statService.getStatNombreTicketsSemaine().subscribe((res) => {
                   // Récupération des données de la table statNbTickets
                   var statNbTickets = JSON.parse(JSON.stringify(res)).data
                   console.log(statNbTickets, 'statNbTickets')

                   //Chart Labels
                    categories = []
                    for(let row of statNbTickets){
                      if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                      if(!categories.includes(row.categorie))  categories.push(row.categorie)
                    }

                    // Insertion des categories
                    dataEtCategorie = []
                    for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                    // Alimentation data
                    for(let i=0; i<this.lineChartLabels.length; i++){
                      for(let item of dataEtCategorie){
                        item.data.push(0);
                        for(let row of statNbTickets){
                          if(checkLabels[i] === row.jour && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                        }
                      }
                    }

                    // Paramétrage du graphe par type et du graphe global avec les données
                    this.lineChartReady = false;
                    // Graphe par type
                    this.lineChartData = [];
                    for(let item of dataEtCategorie){
                      color = this.getRandomColor();
                      this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                    }
                    this.lineChartReady = true;

                });
                this.listSubscription.push(variable);
              break;

              case "Temps de réponse": 
                this.legende = "Moyenne du temps de réponse de cette semaine filtré par entreprise";
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Entreprise'
                const variable1 = this.statService.getStatTempsReponseSemaine().subscribe((res) => {
                  // Récupération des données de la table StatTempsReponse
                  var statTempsReponse= JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  //Chart Labels
                  categories = []
                  for(let row of statTempsReponse){
                    if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsReponse){
                        if(checkLabels[i] === row.jour && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse).toFixed(2) // 7 jours dans 1 semaine
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable1);
              break;

              case "Temps de résolution": 
                this.legende = "Moyenne du temps de résolution de cette semaine filtré par entreprise";
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Entreprise'
                const variable2 = this.statService.getStatTempsResolutionSemaine().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')

                  //Chart Labels
                  categories = []
                  for(let row of statTempsResolution){
                    if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsResolution){
                        if(checkLabels[i] === row.jour && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2) // moyenne
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;
                });
                this.listSubscription.push(variable2);
              break;
            }
            break;

          case "Choix Entreprise":
              // Le filtre sélectionné n'est pas 'Global'
              if(this.selectedFiltre !== 'Global') {
                console.log(this.checkedGlobal, 'checkedGlobal')
                if(this.checkedGlobal.toString() === 'false'){
                  // Par donnée
                  switch(this.selectedCourbe){
                    case "Nombre de tickets": 
                      this.legende = "Nombre de tickets ouverts cette semaine par base filtré par " + this.selectedFiltre.toLowerCase();
                      this.unite = ''
                      // Application du filtre
                      this.statService.filtreEntreprise = []
                      this.statService.filtreEntreprise.push(this.selectedFiltre)
                      this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                      console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                      const variable = this.statService.getStatNombreTicketsSemaineChoixEntreprise().subscribe((res) => {
                        // Récupération des données de la table StatNombreTickets
                        var statNbTickets = JSON.parse(JSON.stringify(res)).data
                        console.log(statNbTickets, 'statNbTickets')
  
                        //Chart Labels
                        this.lineChartLabels = []
                        categories = []
                        for(let row of statNbTickets){
                          if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                          if(!categories.includes(row.entreprise + ' - ' + row.base + ': ' + row.categorie))  categories.push(row.entreprise + ' - ' + row.base + ': ' + row.categorie)
                        }
  
                        // Insertion des categories
                        dataEtCategorie = []
                        for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                        // Alimentation data
                        for(let i=0; i<this.lineChartLabels.length; i++){
                          for(let item of dataEtCategorie){
                            item.data.push(0);
                            for(let row of statNbTickets){
                              let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                              let debutbase: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                              let base = debutbase.substr(0, debutbase.indexOf(':'))
                              let categorie = item.categorie.substr(item.categorie.indexOf(': ') + 2)
                              if(checkLabels[i] === row.jour && ese === row.entreprise && base === row.base && categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                            }
                          }
                        }
  
                        // Paramétrage du graphe par type et du graphe global avec les données
                        this.lineChartReady = false;
                        // Graphe par type
                        this.lineChartData = [];
                        for(let item of dataEtCategorie){
                          color = this.getRandomColor();
                          this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                        }
                        this.lineChartReady = true;
                      });
                      this.listSubscription.push(variable);
                    break;
  
                    case "Temps de réponse": 
                      this.legende = "Moyenne du temps de réponse de cette semaine par base filtré par " + this.selectedFiltre.toLowerCase();
                      this.unite = '(en heure)'
                      // Application du filtre
                      this.statService.filtreEntreprise = []
                      this.statService.filtreEntreprise.push(this.selectedFiltre)
                      this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                      console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                      const variable1 = this.statService.getStatTempsReponseSemaineChoixEntreprise().subscribe((res) => {
                        var statTempsReponse = JSON.parse(JSON.stringify(res)).data
                        console.log(statTempsReponse, 'statTempsReponse')
  
                        //Chart Labels
                        this.lineChartLabels = []
                        categories = []
                        for(let row of statTempsReponse){
                          if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                          if(!categories.includes(row.entreprise + ' - ' + row.base + ': ' + row.categorie))  categories.push(row.entreprise + ' - ' + row.base + ': ' + row.categorie)
                        }
  
                        // Insertion des categories
                        dataEtCategorie = []
                        for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                        // Alimentation data
                        for(let i=0; i<this.lineChartLabels.length; i++){
                          for(let item of dataEtCategorie){
                            item.data.push(0);
                            for(let row of statTempsReponse){
                              let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                              let debutbase: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                              let base = debutbase.substr(0, debutbase.indexOf(':'))
                              let categorie = item.categorie.substr(item.categorie.indexOf(': ') + 2)
                              if(checkLabels[i] === row.jour && ese === row.entreprise && base === row.base && categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse).toFixed(2) // 7 jours dans 1 semaine
                            }
                          }
                        }
  
                        // Paramétrage du graphe par type et du graphe global avec les données
                        this.lineChartReady = false;
                        // Graphe par type
                        this.lineChartData = [];
                        for(let item of dataEtCategorie){
                          color = this.getRandomColor();
                          this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                        }
                        this.lineChartReady = true;
                      });
                      this.listSubscription.push(variable1);
                    break;
  
                    case "Temps de résolution": 
                      this.legende = "Moyenne du temps de résolution de cette semaine par base filtré par " + this.selectedFiltre.toLowerCase();
                      this.unite = '(en jour)'
                      // Application du filtre
                      this.statService.filtreEntreprise = []
                      this.statService.filtreEntreprise.push(this.selectedFiltre)
                      this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                      console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                      const variable2 = this.statService.getStatTempsResolutionSemaineChoixEntreprise().subscribe((res) => {
                        var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                        console.log(statTempsResolution, 'statTempsResolution')
  
                        //Chart Labels
                        this.lineChartLabels = []
                        categories = []
                        for(let row of statTempsResolution){
                          if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                          if(!categories.includes(row.entreprise + ' - ' + row.base + ': ' + row.categorie))  categories.push(row.entreprise + ' - ' + row.base + ': ' + row.categorie)
                        }
  
                        // Insertion des categories
                        dataEtCategorie = []
                        for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                        // Alimentation data
                        for(let i=0; i<this.lineChartLabels.length; i++){
                          for(let item of dataEtCategorie){
                            item.data.push(0);
                            for(let row of statTempsResolution){
                              let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                              let debutbase: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                              let base = debutbase.substr(0, debutbase.indexOf(':'))
                              let categorie = item.categorie.substr(item.categorie.indexOf(': ') + 2)
                              if(checkLabels[i] === row.jour && ese === row.entreprise && base === row.base && categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2) // moyenne
                            }
                          }
                        }

  
                        // Paramétrage du graphe par type et du graphe global avec les données
                        this.lineChartReady = false;
                        // Graphe par type
                        this.lineChartData = [];
                        for(let item of dataEtCategorie){
                          color = this.getRandomColor();
                          this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                        }
                        this.lineChartReady = true;
  
                      });
                      this.listSubscription.push(variable2);
                    break;
                  }
                }
                else{
                  // Par donnée
                  switch(this.selectedCourbe){
                    case "Nombre de tickets": 
                      this.legende = "Nombre de tickets ouverts cette semaine par base";
                      this.unite = ''
                      // Application du filtre
                      this.statService.filtreEntreprise = []
                      this.statService.filtreEntreprise.push('Global')
                      this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                      console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                      const variable = this.statService.getStatNombreTicketsSemaineChoixEntreprise().subscribe((res) => {
                        // Récupération des données de la table StatNombreTickets
                        var statNbTickets = JSON.parse(JSON.stringify(res)).data
                        console.log(statNbTickets, 'statNbTickets')
  
                        //Chart Labels
                        this.lineChartLabels = []
                        categories = []
                        for(let row of statNbTickets){
                          if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                          if(!categories.includes(row.entreprise + ' - ' + row.base))  categories.push(row.entreprise + ' - ' + row.base)
                        }
  
                        // Insertion des categories
                        dataEtCategorie = []
                        for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                        // Alimentation data
                        for(let i=0; i<this.lineChartLabels.length; i++){
                          for(let item of dataEtCategorie){
                            item.data.push(0);
                            for(let row of statNbTickets){
                              let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                              let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                              if(checkLabels[i] === row.jour && ese === row.entreprise && base === row.base)  item.data[item.data.length - 1] = row.quantite
                            }
                          }
                        }
  
                        // Paramétrage du graphe par type et du graphe global avec les données
                        this.lineChartReady = false;
                        // Graphe par type
                        this.lineChartData = [];
                        for(let item of dataEtCategorie){
                          color = this.getRandomColor();
                          this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                        }
                        this.lineChartReady = true;
                      });
                      this.listSubscription.push(variable);
                    break;
  
                    case "Temps de réponse": 
                      this.legende = "Moyenne du temps de réponse de cette semaine par base";
                      this.unite = '(en heure)'
                      // Application du filtre
                      this.statService.filtreEntreprise = []
                      this.statService.filtreEntreprise.push('Global')
                      this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                      console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                      const variable1 = this.statService.getStatTempsReponseSemaineChoixEntreprise().subscribe((res) => {
                        var statTempsReponse = JSON.parse(JSON.stringify(res)).data
                        console.log(statTempsReponse, 'statTempsReponse')
  
                        //Chart Labels
                        this.lineChartLabels = []
                        categories = []
                        for(let row of statTempsReponse){
                          if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                          if(!categories.includes(row.entreprise + ' - ' + row.base))  categories.push(row.entreprise + ' - ' + row.base)
                        }
  
                        // Insertion des categories
                        dataEtCategorie = []
                        for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})
  
                        // Alimentation data
                        for(let i=0; i<this.lineChartLabels.length; i++){
                          for(let item of dataEtCategorie){
                            item.data.push(0);
                            for(let row of statTempsReponse){
                              let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                              let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                              if(checkLabels[i] === row.jour && ese === row.entreprise && base === row.base)  item.data[item.data.length - 1] = (row.tempsReponse).toFixed(2)
                            }
                          }
                        }
  
                        // Paramétrage du graphe par type et du graphe global avec les données
                        this.lineChartReady = false;
                        // Graphe par type
                        this.lineChartData = [];
                        for(let item of dataEtCategorie){
                          color = this.getRandomColor();
                          this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                        }
                        this.lineChartReady = true;
                      });
                      this.listSubscription.push(variable1);
                    break;
  
                    case "Temps de résolution": 
                      this.legende = "Moyenne du temps de résolution de cette semaine par base";
                      this.unite = '(en jour)'
                      // Application du filtre
                      this.statService.filtreEntreprise = []
                      this.statService.filtreEntreprise.push('Global')
                      this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                      console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                      const variable2 = this.statService.getStatTempsResolutionSemaineChoixEntreprise().subscribe((res) => {
                        var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                        console.log(statTempsResolution, 'statTempsResolution')
  
                        //Chart Labels
                        this.lineChartLabels = []
                        categories = []
                        for(let row of statTempsResolution){
                          if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                          if(!categories.includes(row.entreprise + ' - ' + row.base))  categories.push(row.entreprise + ' - ' + row.base)
                        }
  
                        // Insertion des categories
                        dataEtCategorie = []
                        for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                        // Alimentation data
                        for(let i=0; i<this.lineChartLabels.length; i++){
                          for(let item of dataEtCategorie){
                            item.data.push(0);
                            for(let row of statTempsResolution){
                              let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                              let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                              if(checkLabels[i] === row.jour && ese === row.entreprise && base === row.base && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)   // moyenne
                            }
                          }
                        }
  
                        // Paramétrage du graphe par type et du graphe global avec les données
                        this.lineChartReady = false;
                        // Graphe par type
                        this.lineChartData = [];
                        for(let item of dataEtCategorie){
                          color = this.getRandomColor();
                          this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                        }
                        this.lineChartReady = true;

                      });
                      this.listSubscription.push(variable2);
                      break;
                    }
                  }
              }
              else {
                console.log(this.checkedGlobal, 'checkedGlobal')
                if(this.checkedGlobal.toString() === 'false'){
                  // Par donnée
                  switch(this.selectedCourbe){
                    case "Nombre de tickets": 
                      this.legende = "Nombre de tickets ouverts cette semaine par base";
                      this.unite = ''
                      // Application du filtre
                      this.statService.filtreEntreprise = []
                      this.statService.filtreEntreprise.push(this.selectedFiltre)
                      this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                      console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                      const variable = this.statService.getStatNombreTicketsSemaineChoixEntreprise().subscribe((res) => {
                        // Récupération des données de la table StatNombreTickets
                        var statNbTickets = JSON.parse(JSON.stringify(res)).data
                        console.log(statNbTickets, 'statNbTickets')
  
                        //Chart Labels
                        this.lineChartLabels = []
                        categories = []
                        for(let row of statNbTickets){
                          if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                          if(!categories.includes(row.entreprise + ' - ' + row.base))  categories.push(row.entreprise + ' - ' + row.base)
                        }
  
                        // Insertion des categories
                        dataEtCategorie = []
                        for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                        // Alimentation data
                        for(let i=0; i<this.lineChartLabels.length; i++){
                          for(let item of dataEtCategorie){
                            item.data.push(0);
                            for(let row of statNbTickets){
                              let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                              let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                              if(checkLabels[i] === row.jour && ese === row.entreprise && base === row.base)  item.data[item.data.length - 1] = row.quantite
                            }
                          }
                        }
  
                        // Paramétrage du graphe par type et du graphe global avec les données
                        this.lineChartReady = false;
                        // Graphe par type
                        this.lineChartData = [];
                        for(let item of dataEtCategorie){
                          color = this.getRandomColor();
                          this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                        }
                        this.lineChartReady = true;
                      });
                      this.listSubscription.push(variable);
                    break;
  
                    case "Temps de réponse": 
                      this.legende = "Moyenne du temps de réponse de cette semaine par base";
                      this.unite = '(en heure)'
                      // Application du filtre
                      this.statService.filtreEntreprise = []
                      this.statService.filtreEntreprise.push(this.selectedFiltre)
                      this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                      console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                      const variable1 = this.statService.getStatTempsReponseSemaineChoixEntreprise().subscribe((res) => {
                        var statTempsReponse = JSON.parse(JSON.stringify(res)).data
                        console.log(statTempsReponse, 'statTempsReponse')
  
                        //Chart Labels
                        this.lineChartLabels = []
                        categories = []
                        for(let row of statTempsReponse){
                          if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                          if(!categories.includes(row.entreprise + ' - ' + row.base))  categories.push(row.entreprise + ' - ' + row.base)
                        }
  
                        // Insertion des categories
                        dataEtCategorie = []
                        for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                        // Alimentation data
                        for(let i=0; i<this.lineChartLabels.length; i++){
                          for(let item of dataEtCategorie){
                            item.data.push(0);
                            for(let row of statTempsReponse){
                              let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                              let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                              if(checkLabels[i] === row.jour && ese === row.entreprise && base === row.base)  item.data[item.data.length - 1] = (row.tempsReponse).toFixed(2)
                            }
                          }
                        }
  
                        // Paramétrage du graphe par type et du graphe global avec les données
                        this.lineChartReady = false;
                        // Graphe par type
                        this.lineChartData = [];
                        for(let item of dataEtCategorie){
                          color = this.getRandomColor();
                          this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                        }
                        this.lineChartReady = true;
                      });
                      this.listSubscription.push(variable1);
                    break;
  
                    case "Temps de résolution": 
                      this.legende = "Moyenne du temps de résolution de cette semaine par base";
                      this.unite = '(en jour)'
                      // Application du filtre
                      this.statService.filtreEntreprise = []
                      this.statService.filtreEntreprise.push(this.selectedFiltre)
                      this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                      console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                      const variable2 = this.statService.getStatTempsResolutionSemaineChoixEntreprise().subscribe((res) => {
                        var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                        console.log(statTempsResolution, 'statTempsResolution')
  
                        //Chart Labels
                        this.lineChartLabels = []
                        categories = []
                        for(let row of statTempsResolution){
                          if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                          if(!categories.includes(row.entreprise + ' - ' + row.base))  categories.push(row.entreprise + ' - ' + row.base)
                        }
  
                        // Insertion des categories
                        dataEtCategorie = []
                        for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                        // Alimentation data
                        for(let i=0; i<this.lineChartLabels.length; i++){
                          for(let item of dataEtCategorie){
                            item.data.push(0);
                            for(let row of statTempsResolution){
                              let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                              let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                              if(checkLabels[i] === row.jour && ese === row.entreprise && base === row.base && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)   // moyenne
                            }
                          }
                        }
  
                        // Paramétrage du graphe par type et du graphe global avec les données
                        this.lineChartReady = false;
                        // Graphe par type
                        this.lineChartData = [];
                        for(let item of dataEtCategorie){
                          color = this.getRandomColor();
                          this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                        }
                        this.lineChartReady = true;
  
                      });
                      this.listSubscription.push(variable2);
                      break;
                    }
                }
                else{
                  // Par donnée
                  switch(this.selectedCourbe){
                    case "Nombre de tickets": 
                      this.legende = "Nombre de tickets ouverts cette semaine par entreprise";
                      this.unite = ''
                      // Application du filtre
                      this.statService.filtreEntreprise = []
                      this.statService.filtreEntreprise.push('Global')
                      this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                      console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                      const variable = this.statService.getStatNombreTicketsSemaineChoixEntreprise().subscribe((res) => {
                        // Récupération des données de la table StatNombreTickets
                        var statNbTickets = JSON.parse(JSON.stringify(res)).data
                        console.log(statNbTickets, 'statNbTickets')
  
                        //Chart Labels
                        this.lineChartLabels = []
                        categories = []
                        for(let row of statNbTickets) {
                          if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                          if(!categories.includes(row.entreprise))  categories.push(row.entreprise)
                        }
  
                        // Insertion des categories
                        dataEtCategorie = []
                        for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                        // Alimentation data
                        for(let i=0; i<this.lineChartLabels.length; i++){
                          for(let item of dataEtCategorie){
                            item.data.push(0);
                            for(let row of statNbTickets){
                              if(checkLabels[i] === row.jour && item.categorie === row.entreprise)  item.data[item.data.length - 1] += row.quantite
                            }
                          }
                        }
  
                        // Paramétrage du graphe par type et du graphe global avec les données
                        this.lineChartReady = false;
                        // Graphe par type
                        this.lineChartData = [];
                        for(let item of dataEtCategorie){
                          color = this.getRandomColor();
                          this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                        }
                        this.lineChartReady = true;
                      });
                      this.listSubscription.push(variable);
                    break;
  
                    case "Temps de réponse": 
                      this.legende = "Moyenne du temps de réponse de cette semaine par entreprise";
                      this.unite = '(en heure)'
                      // Application du filtre
                      this.statService.filtreEntreprise = []
                      this.statService.filtreEntreprise.push('Global')
                      this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                      console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                      const variable1 = this.statService.getStatTempsReponseSemaineChoixEntreprise().subscribe((res) => {
                        var statTempsReponse = JSON.parse(JSON.stringify(res)).data
                        console.log(statTempsReponse, 'statTempsReponse')
  
                        //Chart Labels
                        this.lineChartLabels = []
                        categories = []
                        for(let row of statTempsReponse){
                          if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                          if(!categories.includes(row.entreprise))  categories.push(row.entreprise)
                        }
  
                        // Insertion des categories
                        dataEtCategorie = []
                        for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                        // Alimentation data
                        for(let i=0; i<this.lineChartLabels.length; i++){
                          for(let item of dataEtCategorie){
                            item.data.push(0);
                            for(let row of statTempsReponse){
                              if(checkLabels[i] === row.jour && item.categorie === row.entreprise)  item.data[item.data.length - 1] += (row.tempsReponse).toFixed(2)
                            }
                          }
                        }
  
                        // Paramétrage du graphe par type et du graphe global avec les données
                        this.lineChartReady = false;
                        // Graphe par type
                        this.lineChartData = [];
                        for(let item of dataEtCategorie){
                          color = this.getRandomColor();
                          this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                        }
                        this.lineChartReady = true;
                      });
                      this.listSubscription.push(variable1);
                    break;
  
                    case "Temps de résolution": 
                      this.legende = "Moyenne du temps de résolution de cette semaine par entreprise";
                      this.unite = '(en jour)'
                      // Application du filtre
                      this.statService.filtreEntreprise = []
                      this.statService.filtreEntreprise.push('Global')
                      this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                      console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                      const variable2 = this.statService.getStatTempsResolutionSemaineChoixEntreprise().subscribe((res) => {
                        var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                        console.log(statTempsResolution, 'statTempsResolution')
  
                        //Chart Labels
                        this.lineChartLabels = []
                        categories = []
                        for(let row of statTempsResolution){
                          if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                          if(!categories.includes(row.entreprise))  categories.push(row.entreprise)                      
                        }
  
                        // Insertion des categories
                        dataEtCategorie = []
                        for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                        // Alimentation data
                        for(let i=0; i<this.lineChartLabels.length; i++){
                          for(let item of dataEtCategorie){
                            item.data.push(0);
                            for(let row of statTempsResolution){
                              if(checkLabels[i] === row.jour && item.categorie === row.entreprise && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] += (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)   // moyenne
                            }
                          }
                        }
  
                        // Paramétrage du graphe par type et du graphe global avec les données
                        this.lineChartReady = false;
                        // Graphe par type
                        this.lineChartData = [];
                        for(let item of dataEtCategorie){
                          color = this.getRandomColor();
                          this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                        }
                        this.lineChartReady = true;
  
                      });
                      this.listSubscription.push(variable2);
                      break;
                    }
                  }
              }
              break;

          case "Responsable de dossier":
            // Par donnée
            switch(this.selectedCourbe){
              case "Nombre de tickets": 
                this.legende = "Nombre de tickets ouverts cette semaine par responsable de dossier";
                this.unite = ''
                // Application du filtre
                this.statService.filtre = 'Responsable de dossier'
                const variable = this.statService.getStatNombreTicketsSemaine().subscribe((res) => {
                   // Récupération des données de la table statNbTickets
                   var statNbTickets = JSON.parse(JSON.stringify(res)).data
                   console.log(statNbTickets, 'statNbTickets')

                   //Chart Labels
                    categories = []
                    for(let row of statNbTickets){
                      if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                      if(!categories.includes(row.categorie))  categories.push(row.categorie)
                    }

                    // Insertion des categories
                    dataEtCategorie = []
                    for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                    // Alimentation data
                    for(let i=0; i<this.lineChartLabels.length; i++){
                      for(let item of dataEtCategorie){
                        item.data.push(0);
                        for(let row of statNbTickets){
                          if(checkLabels[i] === row.jour && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                        }
                      }
                    }

                    // Paramétrage du graphe par type et du graphe global avec les données
                    this.lineChartReady = false;
                    // Graphe par type
                    this.lineChartData = [];
                    for(let item of dataEtCategorie){
                      color = this.getRandomColor();
                      this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                    }
                    this.lineChartReady = true;

                });
                this.listSubscription.push(variable);
              break;

              case "Temps de réponse": 
                this.legende = "Moyenne du temps de réponse de cette semaine par responsable de dossier";
                this.unite = '(en heure)'
                // Application du filtre
                this.statService.filtre = 'Responsable de dossier'
                const variable1 = this.statService.getStatTempsReponseSemaine().subscribe((res) => {
                  // Récupération des données de la table StatTempsReponse
                  var statTempsReponse= JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsReponse, 'statTempsReponse')

                  //Chart Labels
                  categories = []
                  for(let row of statTempsReponse){
                    if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsReponse){
                        if(checkLabels[i] === row.jour && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse).toFixed(2) // 7 jours dans 1 semaine
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;

                });
                this.listSubscription.push(variable1);
              break;

              case "Temps de résolution": 
                this.legende = "Moyenne du temps de résolution de cette semaine par responsable de dossier";
                this.unite = '(en jour)'
                // Application du filtre
                this.statService.filtre = 'Responsable de dossier'
                const variable2 = this.statService.getStatTempsResolutionSemaine().subscribe((res) => {
                  // Récupération des données de la table StatTempsResolution
                  var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                  console.log(statTempsResolution, 'statTempsResolution')

                  //Chart Labels
                  categories = []
                  for(let row of statTempsResolution){
                    if(!checkLabels.includes(row.jour))  checkLabels.push(row.jour)
                    if(!categories.includes(row.categorie))  categories.push(row.categorie)
                  }

                  // Insertion des categories
                  dataEtCategorie = []
                  for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                  // Alimentation data
                  for(let i=0; i<this.lineChartLabels.length; i++){
                    for(let item of dataEtCategorie){
                      item.data.push(0);
                      for(let row of statTempsResolution){
                        if(checkLabels[i] === row.jour && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2) // moyenne
                      }
                    }
                  }

                  // Paramétrage du graphe par type et du graphe global avec les données
                  this.lineChartReady = false;
                  // Graphe par type
                  this.lineChartData = [];
                  for(let item of dataEtCategorie){
                    color = this.getRandomColor();
                    this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                  }
                  this.lineChartReady = true;
                });
                this.listSubscription.push(variable2);
              break;
            }
            break;
        }
        break;
    }
  }

  chargementPeriodeDonnees(selectedCourbe: string, selected: string, listeEntrepriseBase: any[], selectedFiltre: string, checkedGlobal: boolean, periode: string, debutDate: Date, finDate: Date){
    this.selectedCourbe = selectedCourbe;
    this.selected = selected;
    this.listeEntrepriseBase = listeEntrepriseBase
    this.selectedFiltre = selectedFiltre
    this.checkedGlobal = checkedGlobal
    this.periode = periode;
    let debut = new Date(debutDate)
    let fin = new Date(finDate)

    //Alimentation données des graphes

    // Variables nécessaires pour les calculs et l'alimentation des données
    let color;
    let categories = []
    let dataEtCategorie: dataCategorie[] = []

    // Chart Labels
    this.lineChartLabels= []

    // Par type
    switch(this.selected){
      case "Type d\'objet":
        // Par donnée
        switch(this.selectedCourbe){
          case "Nombre de tickets": 
            this.legende = "Nombre de tickets ouverts durant la période saisie filtré par type d'objet";
            this.unite = ''
            // Application du filtre
            this.statService.filtrePeriode = []
            this.statService.filtrePeriode.push('Type d\'objet')
            this.statService.filtrePeriode.push(debut)
            this.statService.filtrePeriode.push(fin)
            const variable = this.statService.getStatNombreTicketsPeriodeSaisie().subscribe((res) => {
              // Récupération des données de la table StatTempsResolution
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              //Chart Labels
              categories = []
              for(let row of statNbTickets){
                if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                if(!categories.includes(row.categorie))  categories.push(row.categorie)
              }

              // Insertion des categories
              dataEtCategorie = []
              for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

              // Alimentation data
              for(let i=0; i<this.lineChartLabels.length; i++){
                for(let item of dataEtCategorie){
                  item.data.push(0);
                  for(let row of statNbTickets){
                    if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                  }
                }
              }

              // Paramétrage du graphe par type et du graphe global avec les données
              this.lineChartReady = false;
              // Graphe par type
              this.lineChartData = [];
              for(let item of dataEtCategorie){
                color = this.getRandomColor();
                this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
              }
              this.lineChartReady = true;

            });
            this.listSubscription.push(variable);
          break;

          case "Temps de réponse": 
            this.legende = "Moyenne du temps de réponse de la période saisie filtré par type d'objet";
            this.unite = '(en heure/jour)'
            // Application du filtre
            this.statService.filtrePeriode = []
            this.statService.filtrePeriode.push('Type d\'objet')
            this.statService.filtrePeriode.push(debut)
            this.statService.filtrePeriode.push(fin)
            const variable1 = this.statService.getStatTempsReponsePeriodeSaisie().subscribe((res) => {
              // Récupération des données de la table statTempsReponse
              var statTempsReponse= JSON.parse(JSON.stringify(res)).data
              console.log(statTempsReponse, 'statTempsReponse')
              
               //Chart Labels
               categories = []
               for(let row of statTempsReponse){
                if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                 if(!categories.includes(row.categorie))  categories.push(row.categorie)
               }
 
               // Insertion des categories
               dataEtCategorie = []
               for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})
 
               // Alimentation data
               for(let i=0; i<this.lineChartLabels.length; i++){
                 for(let item of dataEtCategorie){
                   item.data.push(0);
                   for(let row of statTempsReponse){
                     if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2)
                   }
                 }
               }
 
               // Paramétrage du graphe par type et du graphe global avec les données
               this.lineChartReady = false;
               // Graphe par type
               this.lineChartData = [];
               for(let item of dataEtCategorie){
                 color = this.getRandomColor();
                 this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
               }
               this.lineChartReady = true;

            });
            this.listSubscription.push(variable1)
          break;

          case "Temps de résolution": 
            this.legende = "Moyenne du temps de résolution de la période saisie filtré par type d'objet";
            this.unite = '(en jour)'
             // Application du filtre
            this.statService.filtrePeriode = []
            this.statService.filtrePeriode.push('Type d\'objet')
            this.statService.filtrePeriode.push(debut)
            this.statService.filtrePeriode.push(fin)
            const variable2 = this.statService.getStatTempsResolutionPeriodeSaisie().subscribe((res) => {
              // Récupération des données de la table StatTempsResolution
              var statTempsResolution = JSON.parse(JSON.stringify(res)).data
              console.log(statTempsResolution, 'statTempsResolution')

              //Chart Labels
              categories = []
              for(let row of statTempsResolution){
                if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                if(!categories.includes(row.categorie))  categories.push(row.categorie)
              }

              // Insertion des categories
              dataEtCategorie = []
              for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

              // Alimentation data
              for(let i=0; i<this.lineChartLabels.length; i++){
                for(let item of dataEtCategorie){
                  item.data.push(0);
                  for(let row of statTempsResolution){
                    if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)
                  }
                }
              }

              // Paramétrage du graphe par type et du graphe global avec les données
              this.lineChartReady = false;
              // Graphe par type
              this.lineChartData = [];
              for(let item of dataEtCategorie){
                color = this.getRandomColor();
                this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
              }
              this.lineChartReady = true;
            });
            this.listSubscription.push(variable2)
          break;
        }
        break;

       case "Impact":
        // Par donnée
        switch(this.selectedCourbe){
          case "Nombre de tickets": 
            this.legende = "Nombre de tickets ouverts durant la période saisie filtré par impact";
            this.unite = ''
            // Application du filtre
            this.statService.filtrePeriode = []
            this.statService.filtrePeriode.push('Impact')
            this.statService.filtrePeriode.push(debut)
            this.statService.filtrePeriode.push(fin)
            const variable = this.statService.getStatNombreTicketsPeriodeSaisie().subscribe((res) => {
              // Récupération des données de la table StatTempsResolution
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              //Chart Labels
              categories = []
              for(let row of statNbTickets){
                if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                if(!categories.includes(row.categorie))  categories.push(row.categorie)
              }

              // Insertion des categories
              dataEtCategorie = []
              for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

              // Alimentation data
              for(let i=0; i<this.lineChartLabels.length; i++){
                for(let item of dataEtCategorie){
                  item.data.push(0);
                  for(let row of statNbTickets){
                    if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                  }
                }
              }

              // Paramétrage du graphe par type et du graphe global avec les données
              this.lineChartReady = false;
              // Graphe par type
              this.lineChartData = [];
              for(let item of dataEtCategorie){
                color = this.getRandomColor();
                this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
              }
              this.lineChartReady = true;

            });
            this.listSubscription.push(variable);
          break;

          case "Temps de réponse": 
            this.legende = "Moyenne du temps de réponse de la période saisie filtré par impact";
            this.unite = '(en heure/jour)'
            // Application du filtre
            this.statService.filtrePeriode = []
            this.statService.filtrePeriode.push('Impact')
            this.statService.filtrePeriode.push(debut)
            this.statService.filtrePeriode.push(fin)
            const variable1 = this.statService.getStatTempsReponsePeriodeSaisie().subscribe((res) => {
              // Récupération des données de la table statTempsReponse
              var statTempsReponse= JSON.parse(JSON.stringify(res)).data
              console.log(statTempsReponse, 'statTempsReponse')
              
               //Chart Labels
               categories = []
               for(let row of statTempsReponse){
                if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                 if(!categories.includes(row.categorie))  categories.push(row.categorie)
               }
 
               // Insertion des categories
               dataEtCategorie = []
               for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})
 
               // Alimentation data
               for(let i=0; i<this.lineChartLabels.length; i++){
                 for(let item of dataEtCategorie){
                   item.data.push(0);
                   for(let row of statTempsReponse){
                     if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2)
                   }
                 }
               }
 
               // Paramétrage du graphe par type et du graphe global avec les données
               this.lineChartReady = false;
               // Graphe par type
               this.lineChartData = [];
               for(let item of dataEtCategorie){
                 color = this.getRandomColor();
                 this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
               }
               this.lineChartReady = true;

            });
            this.listSubscription.push(variable1)
          break;

          case "Temps de résolution": 
            this.legende = "Moyenne du temps de résolution de la période saisie filtré par impact";
            this.unite = '(en jour)'
             // Application du filtre
             this.statService.filtrePeriode = []
             this.statService.filtrePeriode.push('Impact')
             this.statService.filtrePeriode.push(debut)
             this.statService.filtrePeriode.push(fin)
             const variable2 = this.statService.getStatTempsResolutionPeriodeSaisie().subscribe((res) => {
               // Récupération des données de la table StatTempsResolution
               var statTempsResolution = JSON.parse(JSON.stringify(res)).data
               console.log(statTempsResolution, 'statTempsResolution')
 
               //Chart Labels
               categories = []
               for(let row of statTempsResolution){
                 if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                 if(!categories.includes(row.categorie))  categories.push(row.categorie)
               }
 
               // Insertion des categories
               dataEtCategorie = []
               for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})
 
               // Alimentation data
               for(let i=0; i<this.lineChartLabels.length; i++){
                 for(let item of dataEtCategorie){
                   item.data.push(0);
                   for(let row of statTempsResolution){
                     if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)
                   }
                 }
               }
 
               // Paramétrage du graphe par type et du graphe global avec les données
               this.lineChartReady = false;
               // Graphe par type
               this.lineChartData = [];
               for(let item of dataEtCategorie){
                 color = this.getRandomColor();
                 this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
               }
               this.lineChartReady = true;
             });
             this.listSubscription.push(variable2)
          break;
        }
        break;


      case "Etat":
        // Par donnée
        switch(this.selectedCourbe){
          case "Nombre de tickets": 
            this.legende = "Nombre de tickets ouverts durant la période saisie filtré par état";
            this.unite = ''
            // Application du filtre
            this.statService.filtrePeriode = []
            this.statService.filtrePeriode.push('Etat')
            this.statService.filtrePeriode.push(debut)
            this.statService.filtrePeriode.push(fin)
            const variable = this.statService.getStatNombreTicketsPeriodeSaisie().subscribe((res) => {
              // Récupération des données de la table StatTempsResolution
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              //Chart Labels
              categories = []
              for(let row of statNbTickets){
                if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                if(!categories.includes(row.categorie))  categories.push(row.categorie)
              }

              // Insertion des categories
              dataEtCategorie = []
              for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

              // Alimentation data
              for(let i=0; i<this.lineChartLabels.length; i++){
                for(let item of dataEtCategorie){
                  item.data.push(0);
                  for(let row of statNbTickets){
                    if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                  }
                }
              }

              // Paramétrage du graphe par type et du graphe global avec les données
              this.lineChartReady = false;
              // Graphe par type
              this.lineChartData = [];
              for(let item of dataEtCategorie){
                color = this.getRandomColor();
                this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
              }
              this.lineChartReady = true;

            });
            this.listSubscription.push(variable);
          break;

          case "Temps de réponse": 
            this.legende = "Moyenne du temps de réponse de la période saisie filtré par état";
            this.unite = '(en heure/jour)'
            // Application du filtre
            this.statService.filtrePeriode = []
            this.statService.filtrePeriode.push('Etat')
            this.statService.filtrePeriode.push(debut)
            this.statService.filtrePeriode.push(fin)
            const variable1 = this.statService.getStatTempsReponsePeriodeSaisie().subscribe((res) => {
              // Récupération des données de la table statTempsReponse
              var statTempsReponse= JSON.parse(JSON.stringify(res)).data
              console.log(statTempsReponse, 'statTempsReponse')
              
               //Chart Labels
               categories = []
               for(let row of statTempsReponse){
                if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                 if(!categories.includes(row.categorie))  categories.push(row.categorie)
               }
 
               // Insertion des categories
               dataEtCategorie = []
               for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})
 
               // Alimentation data
               for(let i=0; i<this.lineChartLabels.length; i++){
                 for(let item of dataEtCategorie){
                   item.data.push(0);
                   for(let row of statTempsReponse){
                     if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2)
                   }
                 }
               }
 
               // Paramétrage du graphe par type et du graphe global avec les données
               this.lineChartReady = false;
               // Graphe par type
               this.lineChartData = [];
               for(let item of dataEtCategorie){
                 color = this.getRandomColor();
                 this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
               }
               this.lineChartReady = true;

            });
            this.listSubscription.push(variable1)
          break;

          case "Temps de résolution": 
            this.legende = "Moyenne du temps de résolution de la période saisie filtré par état";
            this.unite = '(en jour)'
             // Application du filtre
             this.statService.filtrePeriode = []
             this.statService.filtrePeriode.push('Etat')
             this.statService.filtrePeriode.push(debut)
             this.statService.filtrePeriode.push(fin)
             const variable2 = this.statService.getStatTempsResolutionPeriodeSaisie().subscribe((res) => {
               // Récupération des données de la table StatTempsResolution
               var statTempsResolution = JSON.parse(JSON.stringify(res)).data
               console.log(statTempsResolution, 'statTempsResolution')
 
               //Chart Labels
               categories = []
               for(let row of statTempsResolution){
                 if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                 if(!categories.includes(row.categorie))  categories.push(row.categorie)
               }
 
               // Insertion des categories
               dataEtCategorie = []
               for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})
 
               // Alimentation data
               for(let i=0; i<this.lineChartLabels.length; i++){
                 for(let item of dataEtCategorie){
                   item.data.push(0);
                   for(let row of statTempsResolution){
                     if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)
                   }
                 }
               }
 
               // Paramétrage du graphe par type et du graphe global avec les données
               this.lineChartReady = false;
               // Graphe par type
               this.lineChartData = [];
               for(let item of dataEtCategorie){
                 color = this.getRandomColor();
                 this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
               }
               this.lineChartReady = true;
             });
             this.listSubscription.push(variable2)
          break;
        }
        break;

      case "Module":
        // Par donnée
        switch(this.selectedCourbe){
          case "Nombre de tickets": 
            this.legende = "Nombre de tickets ouverts durant la période saisie filtré par module";
            this.unite = ''
            // Application du filtre
            this.statService.filtrePeriode = []
            this.statService.filtrePeriode.push('Module')
            this.statService.filtrePeriode.push(debut)
            this.statService.filtrePeriode.push(fin)
            const variable = this.statService.getStatNombreTicketsPeriodeSaisie().subscribe((res) => {
              // Récupération des données de la table StatTempsResolution
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              //Chart Labels
              categories = []
              for(let row of statNbTickets){
                if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                if(!categories.includes(row.categorie))  categories.push(row.categorie)
              }

              // Insertion des categories
              dataEtCategorie = []
              for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

              // Alimentation data
              for(let i=0; i<this.lineChartLabels.length; i++){
                for(let item of dataEtCategorie){
                  item.data.push(0);
                  for(let row of statNbTickets){
                    if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                  }
                }
              }

              // Paramétrage du graphe par type et du graphe global avec les données
              this.lineChartReady = false;
              // Graphe par type
              this.lineChartData = [];
              for(let item of dataEtCategorie){
                color = this.getRandomColor();
                this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
              }
              this.lineChartReady = true;

            });
            this.listSubscription.push(variable);
          break;

          case "Temps de réponse": 
            this.legende = "Moyenne du temps de réponse de la période saisie filtré par module";
            this.unite = '(en heure/jour)'
            // Application du filtre
            this.statService.filtrePeriode = []
            this.statService.filtrePeriode.push('Module')
            this.statService.filtrePeriode.push(debut)
            this.statService.filtrePeriode.push(fin)
            const variable1 = this.statService.getStatTempsReponsePeriodeSaisie().subscribe((res) => {
              // Récupération des données de la table statTempsReponse
              var statTempsReponse= JSON.parse(JSON.stringify(res)).data
              console.log(statTempsReponse, 'statTempsReponse')
              
               //Chart Labels
               categories = []
               for(let row of statTempsReponse){
                if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                 if(!categories.includes(row.categorie))  categories.push(row.categorie)
               }
 
               // Insertion des categories
               dataEtCategorie = []
               for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})
 
               // Alimentation data
               for(let i=0; i<this.lineChartLabels.length; i++){
                 for(let item of dataEtCategorie){
                   item.data.push(0);
                   for(let row of statTempsReponse){
                     if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2)
                   }
                 }
               }
 
               // Paramétrage du graphe par type et du graphe global avec les données
               this.lineChartReady = false;
               // Graphe par type
               this.lineChartData = [];
               for(let item of dataEtCategorie){
                 color = this.getRandomColor();
                 this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
               }
               this.lineChartReady = true;

            });
            this.listSubscription.push(variable1)
          break;

          case "Temps de résolution": 
            this.legende = "Moyenne du temps de résolution de la période saisie filtré par module";
            this.unite = '(en jour)'
             // Application du filtre
             this.statService.filtrePeriode = []
             this.statService.filtrePeriode.push('Module')
             this.statService.filtrePeriode.push(debut)
             this.statService.filtrePeriode.push(fin)
             const variable2 = this.statService.getStatTempsResolutionPeriodeSaisie().subscribe((res) => {
               // Récupération des données de la table StatTempsResolution
               var statTempsResolution = JSON.parse(JSON.stringify(res)).data
               console.log(statTempsResolution, 'statTempsResolution')
 
               //Chart Labels
               categories = []
               for(let row of statTempsResolution){
                 if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                 if(!categories.includes(row.categorie))  categories.push(row.categorie)
               }
 
               // Insertion des categories
               dataEtCategorie = []
               for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})
 
               // Alimentation data
               for(let i=0; i<this.lineChartLabels.length; i++){
                 for(let item of dataEtCategorie){
                   item.data.push(0);
                   for(let row of statTempsResolution){
                     if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)
                   }
                 }
               }
 
               // Paramétrage du graphe par type et du graphe global avec les données
               this.lineChartReady = false;
               // Graphe par type
               this.lineChartData = [];
               for(let item of dataEtCategorie){
                 color = this.getRandomColor();
                 this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
               }
               this.lineChartReady = true;
             });
             this.listSubscription.push(variable2)
          break;
        }
        break;

      case "Ordre de priorité":
        // Par donnée
        switch(this.selectedCourbe){
          case "Nombre de tickets": 
            this.legende = "Nombre de tickets ouverts durant la période saisie filtré par ordre de priorité";
            this.unite = ''
            // Application du filtre
            this.statService.filtrePeriode = []
            this.statService.filtrePeriode.push('Ordre de priorité')
            this.statService.filtrePeriode.push(debut)
            this.statService.filtrePeriode.push(fin)
            const variable = this.statService.getStatNombreTicketsPeriodeSaisie().subscribe((res) => {
              // Récupération des données de la table StatTempsResolution
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              //Chart Labels
              categories = []
              for(let row of statNbTickets){
                if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                if(!categories.includes(row.categorie))  categories.push(row.categorie)
              }

              // Insertion des categories
              dataEtCategorie = []
              for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

              // Alimentation data
              for(let i=0; i<this.lineChartLabels.length; i++){
                for(let item of dataEtCategorie){
                  item.data.push(0);
                  for(let row of statNbTickets){
                    if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                  }
                }
              }

              // Paramétrage du graphe par type et du graphe global avec les données
              this.lineChartReady = false;
              // Graphe par type
              this.lineChartData = [];
              for(let item of dataEtCategorie){
                color = this.getRandomColor();
                this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
              }
              this.lineChartReady = true;

            });
            this.listSubscription.push(variable);
          break;

          case "Temps de réponse": 
            this.legende = "Moyenne du temps de réponse de la période saisie filtré par ordre de priorité";
            this.unite = '(en heure/jour)'
            // Application du filtre
            this.statService.filtrePeriode = []
            this.statService.filtrePeriode.push('Ordre de priorité')
            this.statService.filtrePeriode.push(debut)
            this.statService.filtrePeriode.push(fin)
            const variable1 = this.statService.getStatTempsReponsePeriodeSaisie().subscribe((res) => {
              // Récupération des données de la table statTempsReponse
              var statTempsReponse= JSON.parse(JSON.stringify(res)).data
              console.log(statTempsReponse, 'statTempsReponse')
              
               //Chart Labels
               categories = []
               for(let row of statTempsReponse){
                if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                 if(!categories.includes(row.categorie))  categories.push(row.categorie)
               }
 
               // Insertion des categories
               dataEtCategorie = []
               for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})
 
               // Alimentation data
               for(let i=0; i<this.lineChartLabels.length; i++){
                 for(let item of dataEtCategorie){
                   item.data.push(0);
                   for(let row of statTempsReponse){
                     if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2)
                   }
                 }
               }
 
               // Paramétrage du graphe par type et du graphe global avec les données
               this.lineChartReady = false;
               // Graphe par type
               this.lineChartData = [];
               for(let item of dataEtCategorie){
                 color = this.getRandomColor();
                 this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
               }
               this.lineChartReady = true;

            });
            this.listSubscription.push(variable1)
          break;

          case "Temps de résolution": 
            this.legende = "Moyenne du temps de résolution de la période saisie filtré par ordre de priorité";
            this.unite = '(en jour)'
             // Application du filtre
             this.statService.filtrePeriode = []
             this.statService.filtrePeriode.push('Ordre de priorité')
             this.statService.filtrePeriode.push(debut)
             this.statService.filtrePeriode.push(fin)
             const variable2 = this.statService.getStatTempsResolutionPeriodeSaisie().subscribe((res) => {
               // Récupération des données de la table StatTempsResolution
               var statTempsResolution = JSON.parse(JSON.stringify(res)).data
               console.log(statTempsResolution, 'statTempsResolution')
 
               //Chart Labels
               categories = []
               for(let row of statTempsResolution){
                 if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                 if(!categories.includes(row.categorie))  categories.push(row.categorie)
               }
 
               // Insertion des categories
               dataEtCategorie = []
               for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})
 
               // Alimentation data
               for(let i=0; i<this.lineChartLabels.length; i++){
                 for(let item of dataEtCategorie){
                   item.data.push(0);
                   for(let row of statTempsResolution){
                     if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)
                   }
                 }
               }
 
               // Paramétrage du graphe par type et du graphe global avec les données
               this.lineChartReady = false;
               // Graphe par type
               this.lineChartData = [];
               for(let item of dataEtCategorie){
                 color = this.getRandomColor();
                 this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
               }
               this.lineChartReady = true;
             });
             this.listSubscription.push(variable2)
          break;
        }
        break;

      case "Entreprise":
        // Par donnée
        switch(this.selectedCourbe){
          case "Nombre de tickets": 
            this.legende = "Nombre de tickets ouverts durant la période saisie filtré par entreprise";
            this.unite = ''
            // Application du filtre
            this.statService.filtrePeriode = []
            this.statService.filtrePeriode.push('Entreprise')
            this.statService.filtrePeriode.push(debut)
            this.statService.filtrePeriode.push(fin)
            const variable = this.statService.getStatNombreTicketsPeriodeSaisie().subscribe((res) => {
              // Récupération des données de la table StatTempsResolution
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              //Chart Labels
              categories = []
              for(let row of statNbTickets){
                if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                if(!categories.includes(row.categorie))  categories.push(row.categorie)
              }

              // Insertion des categories
              dataEtCategorie = []
              for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

              // Alimentation data
              for(let i=0; i<this.lineChartLabels.length; i++){
                for(let item of dataEtCategorie){
                  item.data.push(0);
                  for(let row of statNbTickets){
                    if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                  }
                }
              }

              // Paramétrage du graphe par type et du graphe global avec les données
              this.lineChartReady = false;
              // Graphe par type
              this.lineChartData = [];
              for(let item of dataEtCategorie){
                color = this.getRandomColor();
                this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
              }
              this.lineChartReady = true;

            });
            this.listSubscription.push(variable);
          break;

          case "Temps de réponse": 
            this.legende = "Moyenne du temps de réponse de la période saisie filtré par entreprise";
            this.unite = '(en heure/jour)'
            // Application du filtre
            this.statService.filtrePeriode = []
            this.statService.filtrePeriode.push('Entreprise')
            this.statService.filtrePeriode.push(debut)
            this.statService.filtrePeriode.push(fin)
            const variable1 = this.statService.getStatTempsReponsePeriodeSaisie().subscribe((res) => {
              // Récupération des données de la table statTempsReponse
              var statTempsReponse= JSON.parse(JSON.stringify(res)).data
              console.log(statTempsReponse, 'statTempsReponse')
              
               //Chart Labels
               categories = []
               for(let row of statTempsReponse){
                if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                 if(!categories.includes(row.categorie))  categories.push(row.categorie)
               }
 
               // Insertion des categories
               dataEtCategorie = []
               for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})
 
               // Alimentation data
               for(let i=0; i<this.lineChartLabels.length; i++){
                 for(let item of dataEtCategorie){
                   item.data.push(0);
                   for(let row of statTempsReponse){
                     if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2)
                   }
                 }
               }
 
               // Paramétrage du graphe par type et du graphe global avec les données
               this.lineChartReady = false;
               // Graphe par type
               this.lineChartData = [];
               for(let item of dataEtCategorie){
                 color = this.getRandomColor();
                 this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
               }
               this.lineChartReady = true;

            });
            this.listSubscription.push(variable1)
          break;

          case "Temps de résolution": 
            this.legende = "Moyenne du temps de résolution de la période saisie filtré par entreprise";
            this.unite = '(en jour)'
             // Application du filtre
             this.statService.filtrePeriode = []
             this.statService.filtrePeriode.push('Entreprise')
             this.statService.filtrePeriode.push(debut)
             this.statService.filtrePeriode.push(fin)
             const variable2 = this.statService.getStatTempsResolutionPeriodeSaisie().subscribe((res) => {
               // Récupération des données de la table StatTempsResolution
               var statTempsResolution = JSON.parse(JSON.stringify(res)).data
               console.log(statTempsResolution, 'statTempsResolution')
 
               //Chart Labels
               categories = []
               for(let row of statTempsResolution){
                 if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                 if(!categories.includes(row.categorie))  categories.push(row.categorie)
               }
 
               // Insertion des categories
               dataEtCategorie = []
               for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})
 
               // Alimentation data
               for(let i=0; i<this.lineChartLabels.length; i++){
                 for(let item of dataEtCategorie){
                   item.data.push(0);
                   for(let row of statTempsResolution){
                     if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)
                   }
                 }
               }
 
               // Paramétrage du graphe par type et du graphe global avec les données
               this.lineChartReady = false;
               // Graphe par type
               this.lineChartData = [];
               for(let item of dataEtCategorie){
                 color = this.getRandomColor();
                 this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
               }
               this.lineChartReady = true;
             });
             this.listSubscription.push(variable2)
          break;
        }
        break;

      case "Choix Entreprise":
          // Le filtre sélectionné n'est pas 'Global'
          if(this.selectedFiltre !== 'Global') {
            console.log(this.checkedGlobal, 'checkedGlobal')
            if(this.checkedGlobal.toString() === 'false'){
              // Par donnée
              switch(this.selectedCourbe){
                case "Nombre de tickets": 
                  this.legende = "Nombre de tickets ouverts durant la période saisie par base filtré par " + this.selectedFiltre.toLowerCase();
                  this.unite = ''
                  // Application du filtre
                  this.statService.filtreEntreprise = []
                  this.statService.filtreEntreprise.push(this.selectedFiltre)
                  this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                  this.statService.filtreEntreprise.push(debut)
                  this.statService.filtreEntreprise.push(fin)
                  console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                  const variable = this.statService.getStatNombreTicketsPeriodeSaisieChoixEntreprise().subscribe((res) => {
                    // Récupération des données de la table StatNombreTickets
                    var statNbTickets = JSON.parse(JSON.stringify(res)).data
                    console.log(statNbTickets, 'statNbTickets')

                    //Chart Labels
                    this.lineChartLabels = []
                    categories = []
                    for(let row of statNbTickets){
                      if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                      if(!categories.includes(row.entreprise + ' - ' + row.base + ': ' + row.categorie))  categories.push(row.entreprise + ' - ' + row.base + ': ' + row.categorie)
                    }

                    // Insertion des categories
                    dataEtCategorie = []
                    for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                    // Alimentation data
                    for(let i=0; i<this.lineChartLabels.length; i++){
                      for(let item of dataEtCategorie){
                        item.data.push(0);
                        for(let row of statNbTickets){
                          let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                          let debutbase: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                          let base = debutbase.substr(0, debutbase.indexOf(':'))
                          let categorie = item.categorie.substr(item.categorie.indexOf(': ') + 2)
                          if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) &&  ese === row.entreprise && base === row.base && categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                        }
                      }
                    }

                    // Paramétrage du graphe par type et du graphe global avec les données
                    this.lineChartReady = false;
                    // Graphe par type
                    this.lineChartData = [];
                    for(let item of dataEtCategorie){
                      color = this.getRandomColor();
                      this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                    }
                    this.lineChartReady = true;
                  });
                  this.listSubscription.push(variable);
                break;

                case "Temps de réponse": 
                  this.legende = "Moyenne du temps de réponse de la période saisie par base filtré par " + this.selectedFiltre.toLowerCase();
                  this.unite = '(en heure/jour)'
                  // Application du filtre
                  this.statService.filtreEntreprise = []
                  this.statService.filtreEntreprise.push(this.selectedFiltre)
                  this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                  this.statService.filtreEntreprise.push(debut)
                  this.statService.filtreEntreprise.push(fin)
                  console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                  const variable1 = this.statService.getStatTempsReponsePeriodeSaisieChoixEntreprise().subscribe((res) => {
                    var statTempsReponse = JSON.parse(JSON.stringify(res)).data
                    console.log(statTempsReponse, 'statTempsReponse')

                    //Chart Labels
                    this.lineChartLabels = []
                    categories = []
                    for(let row of statTempsReponse){
                      if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                      if(!categories.includes(row.entreprise + ' - ' + row.base + ': ' + row.categorie))  categories.push(row.entreprise + ' - ' + row.base + ': ' + row.categorie)
                    }

                    // Insertion des categories
                    dataEtCategorie = []
                    for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                    // Alimentation data
                    for(let i=0; i<this.lineChartLabels.length; i++){
                      for(let item of dataEtCategorie){
                        item.data.push(0);
                        for(let row of statTempsReponse){
                          let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                          let debutbase: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                          let base = debutbase.substr(0, debutbase.indexOf(':'))
                          let categorie = item.categorie.substr(item.categorie.indexOf(': ') + 2)
                          if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && ese === row.entreprise && base === row.base && categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2)
                        }
                      }
                    }

                    // Paramétrage du graphe par type et du graphe global avec les données
                    this.lineChartReady = false;
                    // Graphe par type
                    this.lineChartData = [];
                    for(let item of dataEtCategorie){
                      color = this.getRandomColor();
                      this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                    }
                    this.lineChartReady = true;
                  });
                  this.listSubscription.push(variable1);
                break;

                case "Temps de résolution": 
                  this.legende = "Moyenne du temps de résolution de la période saisie par base filtré par " + this.selectedFiltre.toLowerCase();
                  this.unite = '(en jour)'
                  // Application du filtre
                  this.statService.filtreEntreprise = []
                  this.statService.filtreEntreprise.push(this.selectedFiltre)
                  this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                  this.statService.filtreEntreprise.push(debut)
                  this.statService.filtreEntreprise.push(fin)
                  console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                  const variable2 = this.statService.getStatTempsResolutionPeriodeSaisieChoixEntreprise().subscribe((res) => {
                    var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                    console.log(statTempsResolution, 'statTempsResolution')

                    //Chart Labels
                    this.lineChartLabels = []
                    categories = []
                    for(let row of statTempsResolution){
                      if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                      if(!categories.includes(row.entreprise + ' - ' + row.base + ': ' + row.categorie))  categories.push(row.entreprise + ' - ' + row.base + ': ' + row.categorie)
                    }

                    // Insertion des categories
                    dataEtCategorie = []
                    for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                    // Alimentation data
                    for(let i=0; i<this.lineChartLabels.length; i++){
                      for(let item of dataEtCategorie){
                        item.data.push(0);
                        for(let row of statTempsResolution){
                          let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                          let debutbase: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                          let base = debutbase.substr(0, debutbase.indexOf(':'))
                          let categorie = item.categorie.substr(item.categorie.indexOf(': ') + 2)
                          if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && ese === row.entreprise && base === row.base && categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)
                        }
                      }
                    }

                    // Paramétrage du graphe par type et du graphe global avec les données
                    this.lineChartReady = false;
                    // Graphe par type
                    this.lineChartData = [];
                    for(let item of dataEtCategorie){
                      color = this.getRandomColor();
                      this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                    }
                    this.lineChartReady = true;

                  });
                  this.listSubscription.push(variable2);
                break;
              }
            }
            else{
              // Par donnée
              switch(this.selectedCourbe){
                case "Nombre de tickets": 
                  this.legende = "Nombre de tickets ouverts durant la période saisie par base"
                  this.unite = ''
                  // Application du filtre
                  this.statService.filtreEntreprise = []
                  this.statService.filtreEntreprise.push('Global')
                  this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                  this.statService.filtreEntreprise.push(debut)
                  this.statService.filtreEntreprise.push(fin)
                  console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                  const variable = this.statService.getStatNombreTicketsPeriodeSaisieChoixEntreprise().subscribe((res) => {
                    // Récupération des données de la table StatNombreTickets
                    var statNbTickets = JSON.parse(JSON.stringify(res)).data
                    console.log(statNbTickets, 'statNbTickets')

                    //Chart Labels
                    this.lineChartLabels = []
                    categories = []
                    for(let row of statNbTickets){
                      if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                      if(!categories.includes(row.entreprise + ' - ' + row.base))  categories.push(row.entreprise + ' - ' + row.base)
                    }

                    // Insertion des categories
                    dataEtCategorie = []
                    for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                    // Alimentation data
                    for(let i=0; i<this.lineChartLabels.length; i++){
                      for(let item of dataEtCategorie){
                        item.data.push(0);
                        for(let row of statNbTickets){
                          let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                          let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                          if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && ese === row.entreprise && base === row.base)  item.data[item.data.length - 1] = row.quantite
                        }
                      }
                    }

                    // Paramétrage du graphe par type et du graphe global avec les données
                    this.lineChartReady = false;
                    // Graphe par type
                    this.lineChartData = [];
                    for(let item of dataEtCategorie){
                      color = this.getRandomColor();
                      this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                    }
                    this.lineChartReady = true;
                  });
                  this.listSubscription.push(variable);
                break;

                case "Temps de réponse": 
                  this.legende = "Moyenne du temps de réponse de la période saisie par base"
                  this.unite = '(en heure/jour)'
                  // Application du filtre
                  this.statService.filtreEntreprise = []
                  this.statService.filtreEntreprise.push('Global')
                  this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                  this.statService.filtreEntreprise.push(debut)
                  this.statService.filtreEntreprise.push(fin)
                  console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                  const variable1 = this.statService.getStatTempsReponsePeriodeSaisieChoixEntreprise().subscribe((res) => {
                    var statTempsReponse = JSON.parse(JSON.stringify(res)).data
                    console.log(statTempsReponse, 'statTempsReponse')

                    //Chart Labels
                    this.lineChartLabels = []
                    categories = []
                    for(let row of statTempsReponse){
                      if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                      if(!categories.includes(row.entreprise + ' - ' + row.base))  categories.push(row.entreprise + ' - ' + row.base)
                    }

                    // Insertion des categories
                    dataEtCategorie = []
                    for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                    // Alimentation data
                    for(let i=0; i<this.lineChartLabels.length; i++){
                      for(let item of dataEtCategorie){
                        item.data.push(0);
                        for(let row of statTempsReponse){
                          let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                          let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                          if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && ese === row.entreprise && base === row.base)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2)
                        }
                      }
                    }

                    // Paramétrage du graphe par type et du graphe global avec les données
                    this.lineChartReady = false;
                    // Graphe par type
                    this.lineChartData = [];
                    for(let item of dataEtCategorie){
                      color = this.getRandomColor();
                      this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                    }
                    this.lineChartReady = true;
                  });
                  this.listSubscription.push(variable1);
                break;

                case "Temps de résolution": 
                  this.legende = "Moyenne du temps de résolution de la période saisie par base"
                  this.unite = '(en jour)'
                  // Application du filtre
                  this.statService.filtreEntreprise = []
                  this.statService.filtreEntreprise.push('Global')
                  this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                  this.statService.filtreEntreprise.push(debut)
                  this.statService.filtreEntreprise.push(fin)
                  console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                  const variable2 = this.statService.getStatTempsResolutionPeriodeSaisieChoixEntreprise().subscribe((res) => {
                    var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                    console.log(statTempsResolution, 'statTempsResolution')

                    //Chart Labels
                    this.lineChartLabels = []
                    categories = []
                    for(let row of statTempsResolution){
                      if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                      if(!categories.includes(row.entreprise + ' - ' + row.base))  categories.push(row.entreprise + ' - ' + row.base)
                    }

                    // Insertion des categories
                    dataEtCategorie = []
                    for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                    // Alimentation data
                    for(let i=0; i<this.lineChartLabels.length; i++){
                      for(let item of dataEtCategorie){
                        item.data.push(0);
                        for(let row of statTempsResolution){
                          let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                          let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                          if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && ese === row.entreprise && base === row.base && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)   // moyenne
                        }
                      }
                    }

                    // Paramétrage du graphe par type et du graphe global avec les données
                    this.lineChartReady = false;
                    // Graphe par type
                    this.lineChartData = [];
                    for(let item of dataEtCategorie){
                      color = this.getRandomColor();
                      this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                    }
                    this.lineChartReady = true;

                  });
                  this.listSubscription.push(variable2);
                  break;
                }
              }
          }
          else {
            console.log(this.checkedGlobal, 'checkedGlobal')
            if(this.checkedGlobal.toString() === 'false'){
              // Par donnée
              switch(this.selectedCourbe){
                case "Nombre de tickets": 
                  this.legende = "Nombre de tickets ouverts durant la période saisie par base"
                  this.unite = ''
                  // Application du filtre
                  this.statService.filtreEntreprise = []
                  this.statService.filtreEntreprise.push(this.selectedFiltre)
                  this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                  this.statService.filtreEntreprise.push(debut)
                  this.statService.filtreEntreprise.push(fin)
                  console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                  const variable = this.statService.getStatNombreTicketsPeriodeSaisieChoixEntreprise().subscribe((res) => {
                    // Récupération des données de la table StatNombreTickets
                    var statNbTickets = JSON.parse(JSON.stringify(res)).data
                    console.log(statNbTickets, 'statNbTickets')

                    //Chart Labels
                    this.lineChartLabels = []
                    categories = []
                    for(let row of statNbTickets){
                      if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                      if(!categories.includes(row.entreprise + ' - ' + row.base))  categories.push(row.entreprise + ' - ' + row.base)
                    }

                    // Insertion des categories
                    dataEtCategorie = []
                    for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                    // Alimentation data
                    for(let i=0; i<this.lineChartLabels.length; i++){
                      for(let item of dataEtCategorie){
                        item.data.push(0);
                        for(let row of statNbTickets){
                          let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                          let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                          if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && ese === row.entreprise && base === row.base)  item.data[item.data.length - 1] = row.quantite
                        }
                      }
                    }

                    // Paramétrage du graphe par type et du graphe global avec les données
                    this.lineChartReady = false;
                    // Graphe par type
                    this.lineChartData = [];
                    for(let item of dataEtCategorie){
                      color = this.getRandomColor();
                      this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                    }
                    this.lineChartReady = true;
                  });
                  this.listSubscription.push(variable);
                break;

                case "Temps de réponse": 
                  this.legende = "Moyenne du temps de réponse de la période saisie par base"
                  this.unite = '(en heure/jour)'
                  // Application du filtre
                  this.statService.filtreEntreprise = []
                  this.statService.filtreEntreprise.push(this.selectedFiltre)
                  this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                  this.statService.filtreEntreprise.push(debut)
                  this.statService.filtreEntreprise.push(fin)
                  console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                  const variable1 = this.statService.getStatTempsReponsePeriodeSaisieChoixEntreprise().subscribe((res) => {
                    var statTempsReponse = JSON.parse(JSON.stringify(res)).data
                    console.log(statTempsReponse, 'statTempsReponse')

                    //Chart Labels
                    this.lineChartLabels = []
                    categories = []
                    for(let row of statTempsReponse){
                      if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                      if(!categories.includes(row.entreprise + ' - ' + row.base))  categories.push(row.entreprise + ' - ' + row.base)
                    }

                    // Insertion des categories
                    dataEtCategorie = []
                    for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                    // Alimentation data
                    for(let i=0; i<this.lineChartLabels.length; i++){
                      for(let item of dataEtCategorie){
                        item.data.push(0);
                        for(let row of statTempsReponse){
                          let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                          let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                          if(this.lineChartLabels[i] === row.year && ese === row.entreprise && base === row.base)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2)
                        }
                      }
                    }

                    // Alimentation data
                    for(let i=0; i<this.lineChartLabels.length; i++){
                      for(let item of dataEtCategorie){
                        item.data.push(0);
                        for(let row of statTempsReponse){
                          let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                          let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                          if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && ese === row.entreprise && base === row.base)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2)
                        }
                      }
                    }

                    // Paramétrage du graphe par type et du graphe global avec les données
                    this.lineChartReady = false;
                    // Graphe par type
                    this.lineChartData = [];
                    for(let item of dataEtCategorie){
                      color = this.getRandomColor();
                      this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                    }
                    this.lineChartReady = true;
                  });
                  this.listSubscription.push(variable1);
                break;

                case "Temps de résolution": 
                  this.legende = "Moyenne du temps de résolution de la période saisie par base"
                  this.unite = '(en jour)'
                  // Application du filtre
                  this.statService.filtreEntreprise = []
                  this.statService.filtreEntreprise.push(this.selectedFiltre)
                  this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                  this.statService.filtreEntreprise.push(debut)
                  this.statService.filtreEntreprise.push(fin)
                  console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                  const variable2 = this.statService.getStatTempsResolutionPeriodeSaisieChoixEntreprise().subscribe((res) => {
                    var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                    console.log(statTempsResolution, 'statTempsResolution')

                    //Chart Labels
                    this.lineChartLabels = []
                    categories = []
                    for(let row of statTempsResolution){
                      if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                      if(!categories.includes(row.entreprise + ' - ' + row.base))  categories.push(row.entreprise + ' - ' + row.base)
                    }

                    // Insertion des categories
                    dataEtCategorie = []
                    for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                    // Alimentation data
                    for(let i=0; i<this.lineChartLabels.length; i++){
                      for(let item of dataEtCategorie){
                        item.data.push(0);
                        for(let row of statTempsResolution){
                          let ese = item.categorie.substr(0, item.categorie.indexOf(' -'))
                          let base: string = item.categorie.substr(item.categorie.indexOf('- ') + 2)
                          if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && ese === row.entreprise && base === row.base && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)   // moyenne
                        }
                      }
                    }

                    // Paramétrage du graphe par type et du graphe global avec les données
                    this.lineChartReady = false;
                    // Graphe par type
                    this.lineChartData = [];
                    for(let item of dataEtCategorie){
                      color = this.getRandomColor();
                      this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                    }
                    this.lineChartReady = true;

                  });
                  this.listSubscription.push(variable2);
                  break;
                }
            }
            else{
              // Par donnée
              switch(this.selectedCourbe){
                case "Nombre de tickets": 
                  this.legende = "Nombre de tickets ouverts durant la période saisie par entreprise"
                  this.unite = ''
                  // Application du filtre
                  this.statService.filtreEntreprise = []
                  this.statService.filtreEntreprise.push('Global')
                  this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                  this.statService.filtreEntreprise.push(debut)
                  this.statService.filtreEntreprise.push(fin)
                  console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                  const variable = this.statService.getStatNombreTicketsPeriodeSaisieChoixEntreprise().subscribe((res) => {
                    // Récupération des données de la table StatNombreTickets
                    var statNbTickets = JSON.parse(JSON.stringify(res)).data
                    console.log(statNbTickets, 'statNbTickets')

                    //Chart Labels
                    this.lineChartLabels = []
                    categories = []
                    for(let row of statNbTickets) {
                      if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                      if(!categories.includes(row.entreprise))  categories.push(row.entreprise)
                    }

                    // Insertion des categories
                    dataEtCategorie = []
                    for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                    // Alimentation data
                    for(let i=0; i<this.lineChartLabels.length; i++){
                      for(let item of dataEtCategorie){
                        item.data.push(0);
                        for(let row of statNbTickets){
                          if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.entreprise)  item.data[item.data.length - 1] += row.quantite
                        }
                      }
                    }

                    // Paramétrage du graphe par type et du graphe global avec les données
                    this.lineChartReady = false;
                    // Graphe par type
                    this.lineChartData = [];
                    for(let item of dataEtCategorie){
                      color = this.getRandomColor();
                      this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                    }
                    this.lineChartReady = true;
                  });
                  this.listSubscription.push(variable);
                break;

                case "Temps de réponse": 
                  this.legende = "Moyenne du temps de réponse de la période saisie par entreprise"
                  this.unite = '(en heure/jour)'
                  // Application du filtre
                  this.statService.filtreEntreprise = []
                  this.statService.filtreEntreprise.push('Global')
                  this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                  this.statService.filtreEntreprise.push(debut)
                  this.statService.filtreEntreprise.push(fin)
                  console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                  const variable1 = this.statService.getStatTempsReponsePeriodeSaisieChoixEntreprise().subscribe((res) => {
                    var statTempsReponse = JSON.parse(JSON.stringify(res)).data
                    console.log(statTempsReponse, 'statTempsReponse')

                    //Chart Labels
                    this.lineChartLabels = []
                    categories = []
                    for(let row of statTempsReponse){
                      if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                      if(!categories.includes(row.entreprise))  categories.push(row.entreprise)
                    }

                    // Insertion des categories
                    dataEtCategorie = []
                    for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                    // Alimentation data
                    for(let i=0; i<this.lineChartLabels.length; i++){
                      for(let item of dataEtCategorie){
                        item.data.push(0);
                        for(let row of statTempsReponse){
                          if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.entreprise)  item.data[item.data.length - 1] += (row.tempsReponse/row.nbTicketsConcernes).toFixed(2)   
                        }
                      }
                    }

                    // Paramétrage du graphe par type et du graphe global avec les données
                    this.lineChartReady = false;
                    // Graphe par type
                    this.lineChartData = [];
                    for(let item of dataEtCategorie){
                      color = this.getRandomColor();
                      this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                    }
                    this.lineChartReady = true;
                  });
                  this.listSubscription.push(variable1);
                break;

                case "Temps de résolution": 
                  this.legende = "Moyenne du temps de résolution de la période saisie par entreprise"
                  this.unite = '(en jour)'
                  // Application du filtre
                  this.statService.filtreEntreprise = []
                  this.statService.filtreEntreprise.push('Global')
                  this.statService.filtreEntreprise.push(this.listeEntrepriseBase)
                  this.statService.filtreEntreprise.push(debut)
                  this.statService.filtreEntreprise.push(fin)
                  console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
                  const variable2 = this.statService.getStatTempsResolutionPeriodeSaisieChoixEntreprise().subscribe((res) => {
                    var statTempsResolution = JSON.parse(JSON.stringify(res)).data
                    console.log(statTempsResolution, 'statTempsResolution')

                    //Chart Labels
                    this.lineChartLabels = []
                    categories = []
                    for(let row of statTempsResolution){
                      if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                      if(!categories.includes(row.entreprise))  categories.push(row.entreprise)                      
                    }

                    // Insertion des categories
                    dataEtCategorie = []
                    for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

                    // Alimentation data
                    for(let i=0; i<this.lineChartLabels.length; i++){
                      for(let item of dataEtCategorie){
                        item.data.push(0);
                        for(let row of statTempsResolution){
                          if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.entreprise && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] += (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)   // moyenne
                        }
                      }
                    }

                    // Paramétrage du graphe par type et du graphe global avec les données
                    this.lineChartReady = false;
                    // Graphe par type
                    this.lineChartData = [];
                    for(let item of dataEtCategorie){
                      color = this.getRandomColor();
                      this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
                    }
                    this.lineChartReady = true;

                  });
                  this.listSubscription.push(variable2);
                  break;
                }
              }
          }
          break;

      case "Responsable de dossier":
        // Par donnée
        switch(this.selectedCourbe){
          case "Nombre de tickets": 
            this.legende = "Nombre de tickets ouverts durant la période saisie filtré par responsable de dossier"
            this.unite = ''
            // Application du filtre
            this.statService.filtrePeriode = []
            this.statService.filtrePeriode.push('Responsable de dossier')
            this.statService.filtrePeriode.push(debut)
            this.statService.filtrePeriode.push(fin)
            const variable = this.statService.getStatNombreTicketsPeriodeSaisie().subscribe((res) => {
              // Récupération des données de la table StatTempsResolution
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              //Chart Labels
              categories = []
              for(let row of statNbTickets){
                if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                if(!categories.includes(row.categorie))  categories.push(row.categorie)
              }

              // Insertion des categories
              dataEtCategorie = []
              for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})

              // Alimentation data
              for(let i=0; i<this.lineChartLabels.length; i++){
                for(let item of dataEtCategorie){
                  item.data.push(0);
                  for(let row of statNbTickets){
                    if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie)  item.data[item.data.length - 1] = row.quantite
                  }
                }
              }

              // Paramétrage du graphe par type et du graphe global avec les données
              this.lineChartReady = false;
              // Graphe par type
              this.lineChartData = [];
              for(let item of dataEtCategorie){
                color = this.getRandomColor();
                this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
              }
              this.lineChartReady = true;

            });
            this.listSubscription.push(variable);
          break;

          case "Temps de réponse": 
            this.legende = "Moyenne du temps de réponse de la période saisie filtré par responsable de dossier"
            this.unite = '(en heure/jour)'
            // Application du filtre
            this.statService.filtrePeriode = []
            this.statService.filtrePeriode.push('Responsable de dossier')
            this.statService.filtrePeriode.push(debut)
            this.statService.filtrePeriode.push(fin)
            const variable1 = this.statService.getStatTempsReponsePeriodeSaisie().subscribe((res) => {
              // Récupération des données de la table statTempsReponse
              var statTempsReponse= JSON.parse(JSON.stringify(res)).data
              console.log(statTempsReponse, 'statTempsReponse')
              
               //Chart Labels
               categories = []
               for(let row of statTempsReponse){
                if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                 if(!categories.includes(row.categorie))  categories.push(row.categorie)
               }
 
               // Insertion des categories
               dataEtCategorie = []
               for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})
 
               // Alimentation data
               for(let i=0; i<this.lineChartLabels.length; i++){
                 for(let item of dataEtCategorie){
                   item.data.push(0);
                   for(let row of statTempsReponse){
                     if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie)  item.data[item.data.length - 1] = (row.tempsReponse/row.nbTicketsConcernes).toFixed(2)
                   }
                 }
               }
 
               // Paramétrage du graphe par type et du graphe global avec les données
               this.lineChartReady = false;
               // Graphe par type
               this.lineChartData = [];
               for(let item of dataEtCategorie){
                 color = this.getRandomColor();
                 this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
               }
               this.lineChartReady = true;

            });
            this.listSubscription.push(variable1)
          break;

          case "Temps de résolution": 
            this.legende = "Moyenne du temps de résolution de la période saisie filtré par responsable de dossier"
            this.unite = '(en jour)'
             // Application du filtre
             this.statService.filtrePeriode = []
             this.statService.filtrePeriode.push('Responsable de dossier')
             this.statService.filtrePeriode.push(debut)
             this.statService.filtrePeriode.push(fin)
             const variable2 = this.statService.getStatTempsResolutionPeriodeSaisie().subscribe((res) => {
               // Récupération des données de la table StatTempsResolution
               var statTempsResolution = JSON.parse(JSON.stringify(res)).data
               console.log(statTempsResolution, 'statTempsResolution')
 
               //Chart Labels
               categories = []
               for(let row of statTempsResolution){
                 if(!this.lineChartLabels.includes(row.week.substr(0, row.week.indexOf('T')))) this.lineChartLabels.push(row.week.substr(0, row.week.indexOf('T')))
                 if(!categories.includes(row.categorie))  categories.push(row.categorie)
               }
 
               // Insertion des categories
               dataEtCategorie = []
               for (let cat of categories) dataEtCategorie.push({data: [], categorie: cat})
 
               // Alimentation data
               for(let i=0; i<this.lineChartLabels.length; i++){
                 for(let item of dataEtCategorie){
                   item.data.push(0);
                   for(let row of statTempsResolution){
                     if(this.lineChartLabels[i] === row.week.substr(0, row.week.indexOf('T')) && item.categorie === row.categorie && row.nbTicketsConcernes !== 0)  item.data[item.data.length - 1] = (row.tempsResolution/row.nbTicketsConcernes).toFixed(2)
                   }
                 }
               }
 
               // Paramétrage du graphe par type et du graphe global avec les données
               this.lineChartReady = false;
               // Graphe par type
               this.lineChartData = [];
               for(let item of dataEtCategorie){
                 color = this.getRandomColor();
                 this.lineChartData.push({data: item.data, label: item.categorie, backgroundColor: [color]});
               }
               this.lineChartReady = true;
             });
             this.listSubscription.push(variable2)
          break;
        }
        break;
    }
  }

  // Affichage du graphe sur le dashboard
  checkCmpInDashboard(){
    let alreadyInDashboard = false;
    for(let cmp of this.dashboardComponents){
      // Vérification si le component est associé au user connecté et s'il s'agit du bon graphe
      if(cmp.userId == Number(this.currentUser.id) && cmp.titreComponent == "LineChartFiltreTicket"){
        if(cmp.donnees[0] == this.selectedCourbe && cmp.donnees[1] == this.selected && cmp.donnees[2] == this.periode)  alreadyInDashboard = true;
      }
    }
    return alreadyInDashboard;
  }

  addToDashboard(){
    this.dashboardService.dataToAdd = []
    this.dashboardService.dataToAdd.push({id: 0, userId: Number(this.currentUser.id), titreComponent: "LineChartFiltreTicket", titreDashboard: "Statistiques", donnees: ""});
    if (this.selected !== 'Choix Entreprise') this.dashboardService.dataToAdd[0].donnees = "/" + this.selectedCourbe + "*" + "/" + this.selected + "*" + "/" + this.periode + "*"
    else  {
      console.log(this.listeEntrepriseBase, 'listEntrepriseBase')
      this.dashboardService.dataToAdd[0].donnees = "/" + this.selectedCourbe + "*" + "/" + this.selected + "*" + "/" + this.periode + "*"
      this.dashboardService.dataToAdd[0].donnees += "/EntrepriseBase*"
      for (let row of this.listeEntrepriseBase) {
        this.dashboardService.dataToAdd[0].donnees += "/" + row.entreprise + ";" + row.url + "*"
      }
      this.dashboardService.dataToAdd[0].donnees += "/Filtre*"
      this.dashboardService.dataToAdd[0].donnees += "/" + this.selectedFiltre + "*"
      this.dashboardService.dataToAdd[0].donnees += "/Cumul*"
      this.dashboardService.dataToAdd[0].donnees += "/" + this.checkedGlobal + "*"
    }
    console.log(this.dashboardService.dataToAdd, 'dataToAdd')
    const variable = this.dashboardService.postAddDashboardComponentToServer().subscribe(
      () => {
      console.log('Component du dashboard sauvegardé !');
      },
      (error) => {
      console.log('Erreur ! : ' + error);
      }
    );
    this.listSubscription.push(variable);
  }

  removeFromDashboard(){
    for(let component of this.dashboardComponents){
      if(component.userId == Number(this.currentUser.id) && component.titreComponent == "LineChartFiltreTicket")  this.dashboardService.idOfDataToDelete = component.id;
    }
    const variable = this.dashboardService.postDeleteDashboardComponentFromServer().subscribe(
      () => {
        console.log('Component du dashboard supprimé !');
      },
      (error) => {
        console.log('Erreur ! : ' + error);
      }
    );
    this.listSubscription.push(variable);
  }

  // Quelques fonctions simples nécessaires
  getRandomColor() {
    var x = Math.floor(Math.random() * 256);
    var y = Math.floor(Math.random() * 256);
    var z = Math.floor(Math.random() * 256);
    var bgColor = "rgb(" + x + "," + y + "," + z + ", 0)";
    return bgColor;
  }


}
