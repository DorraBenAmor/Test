import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GrapheEvolutifFiltreComponent } from './graphe-evolutif-filtre.component';

describe('GrapheEvolutifFiltreComponent', () => {
  let component: GrapheEvolutifFiltreComponent;
  let fixture: ComponentFixture<GrapheEvolutifFiltreComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GrapheEvolutifFiltreComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GrapheEvolutifFiltreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
