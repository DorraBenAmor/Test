export class TypeObjetModel{
    id: number;
    typeObjet: string;
}