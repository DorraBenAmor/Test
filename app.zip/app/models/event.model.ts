import { CalendarEventAction } from 'angular-calendar';

export class EventModel{
    id: number;
    eventID: number;
    title: string;
    start: Date;
    end: Date;
    color: string;
    longEvent: boolean;
    recursif: boolean;
    quantite: number;
    jours: string;
    jourParMois: string;
    jourParAnnee: string;
    userID: number;
}