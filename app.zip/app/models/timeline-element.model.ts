export class TimelineElement{
    id: number;
    eventID: number;
    update_ID: number
    base_ID: number
    date: Date;
    heure: string;
    motif: string;
    userID: number;
    isUserConcerned: boolean;
}