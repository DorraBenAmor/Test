export class StatTempsResolutionModel{
    id: number;
    entreprise: string
    base: string
    filtre: string;
    categorie: string;
    jour: Date
    tempsResolution: number
    nbTicketsConcernes: number
}