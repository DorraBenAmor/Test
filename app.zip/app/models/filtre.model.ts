export class FiltreModel{
    id: number;
    userID: number;
    titre: string;
    filtre: any;
}