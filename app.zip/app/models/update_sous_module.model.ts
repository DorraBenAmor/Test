export class updatesousmodule{
    id:number;
    module:string;
    sous_module:string;
    date_prod:Date;
    date_preprod:Date;
    charge_dossier_ID:number;
    client_ID:number;





}