export class FicheMessageModel{
    numero_ticket: string; 
    date_ouverture: Date;
    libelle: string;
    respo_dossier_ID: number;
    usersID: string;
    accesVisuelPourUsers: string
    listUsers: string[];
    url: string;
    module: string;
    sous_module: string;
    ordre_priorite: string;
    type_objet: string;
    etat: string;
    impact: string;
    numTelephoneClient: string;
    archivé: number;
    ficheID: number;
    userID: number;
    userStatut: string
    invisibleAuClient: number
    date_envoie: Date;
    message: string;
    non_lu: number;
    envoyé: number;
    accesFicheRefuse: number
}