export class EtatModel{
    id: number;
    etat: string;
}