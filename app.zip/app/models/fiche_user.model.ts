export class FicheUserModel{
    id: number;
    ficheID: number;
    userID: number;
    non_lu: number;
    archive: number;
    accesFicheRefuse: number
}