export class Entreprise{
    id: number;
    nom: string;
    societe: string;
    codeAPE: number;
    siret: number;
    effectif: number;
    statut: string;
    logo: string;
    adresse: string;
    adresse2: string;
    codePostal: number;
    ville: string;
    pays: string;
    tel: number;
    fax: number;
}