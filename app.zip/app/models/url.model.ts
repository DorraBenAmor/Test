export class URLModel{
    id: number;
    url: string;
}