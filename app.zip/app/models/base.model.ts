export class base{
    Id: number; 
    coordonneesSociete:string;
    responsable:string;
    effectifs:number;
    utilisation:Date;
    urlBase:string;
    dateLivraison: Date;
    adresseMail: string;
    coordinateurProjet: string;
    chefProjet: string;
    typeBase:number;
    copieBase:number;
    autres:string;
    lieeGlobal:number;
    lieeGl:string;
    lieeCDF:number;
    lieeC:string;
    nettoyage:number;
    sitePro:number;
    siteP:string;
    siteCl:number;
    siteC:string;
    dateCreation: Date;
    statue: number; 
    nomDemandeur :string; 
    dateConfirmation:Date;
    codeConfirmation: string







}