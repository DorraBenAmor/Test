export class ModuleModel{
    id: number
    module: string;
    sous_module: string;
}