export class FicheModel{
    id: number;
    numero_ticket: string;
    date_ouverture: Date;
    libelle: string;
    respo_dossier_ID: number;
    usersID: string;
    accesVisuelPourUsers: string
    url: string;
    module: string;
    sous_module: string;
    ordre_priorite: string;
    type_objet: string;
    etat: string;
    impact: string;
    numTelephoneClient: string;
}