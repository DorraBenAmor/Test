export class DashboardComponentModel{
    id: number;
    userId: number;
    titreComponent: string;
    titreDashboard: string;
    donnees: string;
}