export class ImpactModel{
    id: number;
    impact: string;
}