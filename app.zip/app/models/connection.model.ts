export class Connection {
    id: string;
    online: boolean;
    nom: string;
    prenom: string;
    email: string;
    statut: string;
    image: string;
    tags: string;
    tel: string;
    entreprise: string;
    base: string
}