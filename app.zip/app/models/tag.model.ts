export class TagModel{
    id: number;
    tag: string;
}