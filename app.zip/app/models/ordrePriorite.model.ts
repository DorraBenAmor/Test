export class OrdrePrioriteModel{
    id: number;
    ordrePriorite: string;
}