export class faq{
    id:number;
    module:string;
    sous_module:string;
    question:string;
    reponse:string;
    is_prived: number;
    date:Date;
    responsable:string;
    nb_like:number;
    nb_dislike:number;
    reactions:string;
}