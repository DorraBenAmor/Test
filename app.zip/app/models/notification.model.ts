export class NotificationModel{
    id: number;
    userID: number;
    date: Date;
    notification: string;
}