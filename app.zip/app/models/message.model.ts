export class MessageModel{
    id: number;
    ficheID: number;
    userID: number;
    userStatut: string
    invisibleAuClient: number
    date_envoie: Date;
    message: string;
}