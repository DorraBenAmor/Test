export class StatTempsReponseModel{
    id: number;
    entreprise: string
    base: string
    filtre: string;
    categorie: string;
    jour: Date
    tempsReponse: string
    nbTicketsConcernes: number
}