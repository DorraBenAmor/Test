import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, AbstractControl } from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { BaseService } from 'src/app/services/base.service';
import { is } from 'date-fns/locale';
import { EntrepriseList } from 'src/app/services/entreprise-list.service';
import { Subscription } from 'rxjs';
import { InscriptionCheckService } from 'src/app/services/inscription-check.service';
import { UserList } from 'src/app/services/user-list.service';
import { Variable } from '@angular/compiler/src/render3/r3_ast';
import { TimelineData } from 'src/app/services/timeline-data.service';
import { ThrowStmt } from '@angular/compiler';
import { ConnexionService } from 'src/app/services/connexion.service';
import { CalendarAngularDateFormatter } from 'angular-calendar';
import { NgIf, DatePipe } from '@angular/common';

@Component({
  selector: 'app-base',
  templateUrl: './base.component.html',
  styleUrls: ['./base.component.css'],
  providers: [DatePipe]
})
export class BaseComponent implements OnInit {
 
  entreprises: any[] = [];
  users: any[] = [];
  bases: any[] = [];
  basesGlobal: any[] = [];
  basesCDF: any[] = [];
  timelines: any[] = [];
  personalversionsbases: any[] = [];
  clientversionsbases: any[] = [];
  formDisplayed: boolean = false;
  registerForm: FormGroup;
  registerForm2: FormGroup;
  submitted = false;
  submitted2=false;
  entrepriseSelectedID: number;
  userSelectedID: number;
  coordonneesSociete:string;
  responsable:string;
  effectifs:number;
  utilisation:Date;
  dateUtilisation:String;
  urlBase:string;
  dateLivraison: Date;
  adresseMail: string;
  coordinateurProjet: string;
  chefProjet: string;
  typeBase:number=0;
  copieBase:number=1;
  autres:string;
  lieeGlobal:number=1;
  lieeGl:string;
  lieeCDF:number=1;
  lieeC:string;
  nettoyage:number=1;
  sitePro:number=1;
  siteP:string;
  siteCl:number=1;
  siteC:string;
  dateCreation:Date;
  maxId:number;
  
  listSubscription1 = <Subscription[]>[];
  listSubscription2 = <Subscription[]>[];
  listSubscription3 = <Subscription[]>[];
  dataToAdd: any[] = []; 
  showModal:boolean=false;
  modified:boolean=false;
  valide:boolean=false;
  clicked:boolean=false;
  dateConfirmation : Date ; 
  modif:boolean;
  codeConfirmation:string;

  constructor(private titleService: Title, private userList: UserList, private entrepriseList: EntrepriseList,  private inscriptionCheckService: InscriptionCheckService, private baseService: BaseService, private formBuilder: FormBuilder,private timeline: TimelineData, private connexion: ConnexionService,  private router: Router, public datepipe: DatePipe) { }
  
  get f() { return this.registerForm.controls; }

  get f2() { return this.registerForm2.controls; }
 
  ngOnInit(): void {

    this.baseService.clear();
    this.modif=false;
    this.modif=this.baseService.forModif;
    this.baseService.forModif=false;
    // this.entreprises = this.entrepriseList.entrepriseSample;
    this.timelines=this.timeline.timelineSampple
    this.dateCreation=new Date();
    this.codeConfirmation=  Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);

    
    //METHODE GET: On récupère les entreprises enregistrées dans la BDD
    const variable = this.entrepriseList.getEntrepriseFromServer().subscribe((response:any) => {
        //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
      
          
        this.entreprises = response.data;
       
               
    });
    
  
    //Détruire la souscription
    this.listSubscription1.push(variable);
    const reg = '([\\da-zA-Z0-9.-]+)\\.([a-zA-Z0-9.]{2,6})[/\\w .-]*/?';
  this.titleService.setTitle('base');
  if(this.modif===false)
  {
  this.registerForm = this.formBuilder.group({
  coordonneesSociete: ['', [Validators.required]],
  responsable:['',[Validators.required]],
  effectifs:['', [Validators.required, Validators.minLength(1), Validators.maxLength(5), Validators.pattern("^[0-9]*$")]], 
  utilisation:['', Validators.required],
  urlBase:['',[Validators.required,Validators.pattern(reg)]],
  dateLivraison:['',[Validators.required]],
  adresseMail:['',[Validators.required,Validators.email]],
  coordinateurProjet:['',[Validators.required]],
  chefProjet:['',[Validators.required]],



        });

        this.registerForm2 = this.formBuilder.group({
          autres:['',[Validators.required]],
          lieeGl:['',[Validators.required]],
          lieeC:['',[Validators.required]],
          siteP:['',[Validators.required]],
          siteC:['',[Validators.required]],

        });
  }

else
{
  this.coordonneesSociete= this.baseService.coordonnees;
  const variable2 = this.userList.getUserFromServer().subscribe((response:any) => {
  //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template

this.users=response.data.filter(x=> x.entreprise===this.coordonneesSociete)
  //this.users=this.userList.userSample;
  // var j=0;
   console.log(this.users);
   console.log(response);
   /*
  console.log(this.coordonneesSociete);
  for(let i=0; i<(JSON.parse(JSON.stringify(response)).data).length;i++ )
  {
   if(JSON.parse(JSON.stringify(response)).data[i].entreprise == this.coordonneesSociete)
  { this.users[j] = JSON.parse(JSON.stringify(response)).data[i]; 
    j=j+1;
    console.log(j);
    console.log(JSON.parse(JSON.stringify(response)).data[i].nom);
  }
  
console.log(this.users);
  }*/

  
});
//Détruire la souscription
this.listSubscription2.push(variable2);



const variable3 = this.baseService.getBaseFromServerByCompany().subscribe((response) => {
  //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
    
   this.bases = JSON.parse(JSON.stringify(response)).data; 

 



  
});
//Détruire la souscription
this.listSubscription3.push(variable3);

const variable4 = this.baseService.getGlobalBaseFromServerByCompany().subscribe((response) => {
  //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template


   this.basesGlobal = JSON.parse(JSON.stringify(response)).data; 
 
   
 



  
});
//Détruire la souscription
this.listSubscription3.push(variable4);

//Détruire la souscription
//Détruire la souscription



const variable5 = this.baseService.getCDFBaseFromServerByCompany().subscribe((response) => {
  //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template


   this.basesCDF= JSON.parse(JSON.stringify(response)).data; 


  
});
//Détruire la souscription
this.listSubscription3.push(variable5);


const variable6 = this.baseService.getPersonalVersionFromServerByCompany().subscribe((response) => {
  //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template


    this.personalversionsbases= JSON.parse(JSON.stringify(response)).data; 
  


  
});
//Détruire la souscription
this.listSubscription3.push(variable6);


const variable7 = this.baseService.getClientVersionFromServerByCompany().subscribe((response) => {
  //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template

  
    this.clientversionsbases = JSON.parse(JSON.stringify(response)).data; 


  

  
});
//Détruire la souscription
this.listSubscription3.push(variable7);
console.log(this.userList.userSample);
this.users=this.userList.userSample;
console.log(this.users);
  this.responsable=this.baseService.responsable;
  this.coordinateurProjet=this.baseService.coordinateur;
  this.chefProjet= this.baseService.chef;
  this.autres=this.baseService.siAutres;
  this.copieBase=this.baseService.copiebase;
  this.lieeGl=this.baseService.siOui;
  this.lieeGlobal=this.baseService.lieeBase
  this.lieeC=this.baseService.siOuiCDF;
  this.lieeCDF=this.baseService.lieeCDF
  this.siteP=this.baseService.siOuiSiteP;
  this.sitePro=this.baseService.sitePro
  this.siteC=this.baseService.siOuiSiteC;
  this.siteCl=this.baseService.siteCl;
  this.effectifs=this.baseService.effectifs;
  this.utilisation=this.baseService.utilisationPrev;
  
  this.handleUtilisation(this.datepipe.transform(this.utilisation, 'yyyy-MM-dd'));
  this.nettoyage=this.baseService.nettoyage;
  this.urlBase=this.baseService.url;
  this.dateLivraison=this.baseService.dateLivraison;
  this.handleDateLivraison(this.datepipe.transform(this.dateLivraison, 'yyyy-MM-dd'));
  this.adresseMail=this.baseService.adresseMail;
   this.typeBase=this.baseService.type;
   this.copieBase= this.baseService.copiebase;
   this.dateCreation=this.baseService.dateCreation;


  this.registerForm = this.formBuilder.group({
    coordonneesSociete: [this.coordonneesSociete, [Validators.required]],
    responsable:[this.responsable,[Validators.required]],
    effectifs:[this.effectifs, [Validators.required, Validators.minLength(1), Validators.maxLength(5), Validators.pattern("^[0-9]*$")]], 
    utilisation:[this.utilisation, Validators.required],
    urlBase:[this.urlBase,[Validators.required,Validators.pattern(reg)]],
    dateLivraison:[this.dateLivraison,[Validators.required]],
    adresseMail:[this.adresseMail,[Validators.required,Validators.email]],
    coordinateurProjet:[this.coordinateurProjet,[Validators.required]],
    chefProjet:[this.chefProjet,[Validators.required]],
  
  
  
          });
  
          this.registerForm2 = this.formBuilder.group({
            autres:[this.autres,[Validators.required]],
            lieeGl:[this.lieeGl,[Validators.required]],
            lieeC:[this.lieeC,[Validators.required]],
            siteP:[this.siteP,[Validators.required]],
            siteC:[this.siteC,[Validators.required]],
  
          });

     
}
}
  ngOnDestroy(){
    this.listSubscription1.map((elem) => elem.unsubscribe());
    this.listSubscription2.map((elem) => elem.unsubscribe());
    this.listSubscription3.map((elem) => elem.unsubscribe());

}    

onDisplayForm(){
  this.formDisplayed = true;
}

  handleCoordonnees(value: number) {
   
    this.f.responsable.reset();
    this.f.coordinateurProjet.reset();
    this.f.chefProjet.reset();
    this.f2.lieeC.reset();
    this.f2.autres.reset();
    this.f2.lieeGl.reset();
    this.f2.siteP.reset();
    this.f2.siteC.reset();
    console.log(this.registerForm.invalid);
    this.entrepriseSelectedID = value;
    console.log("selected company ID: " + this.entrepriseSelectedID);
    for(let m=0;m<this.entreprises.length;m++)
  {
    if(this.entreprises[m].id==this.entrepriseSelectedID)
    {
      this.coordonneesSociete=this.entreprises[m].nom;
    }
  }
  this.baseService.coordonnees=this.coordonneesSociete;
  




//METHODE GET: On récupère les users enregistrées dans la BDD

const variable2 = this.userList.getUserFromServer().subscribe((response:any) => {
  //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template

this.users=response.data.filter(x=> x.entreprise===this.coordonneesSociete)
  //this.users=this.userList.userSample;
  // var j=0;
   console.log(this.users);
   console.log(response);
   /*
  console.log(this.coordonneesSociete);
  for(let i=0; i<(JSON.parse(JSON.stringify(response)).data).length;i++ )
  {
   if(JSON.parse(JSON.stringify(response)).data[i].entreprise == this.coordonneesSociete)
  { this.users[j] = JSON.parse(JSON.stringify(response)).data[i]; 
    j=j+1;
    console.log(j);
    console.log(JSON.parse(JSON.stringify(response)).data[i].nom);
  }
  
console.log(this.users);
  }*/

  
});
//Détruire la souscription
this.listSubscription2.push(variable2);



const variable3 = this.baseService.getBaseFromServerByCompany().subscribe((response) => {
  //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template
    
   this.bases = JSON.parse(JSON.stringify(response)).data; 

 



  
});
//Détruire la souscription
this.listSubscription3.push(variable3);

const variable4 = this.baseService.getGlobalBaseFromServerByCompany().subscribe((response) => {
  //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template


   this.basesGlobal = JSON.parse(JSON.stringify(response)).data; 
 
   
 



  
});
//Détruire la souscription
this.listSubscription3.push(variable4);

//Détruire la souscription
//Détruire la souscription



const variable5 = this.baseService.getCDFBaseFromServerByCompany().subscribe((response) => {
  //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template


   this.basesCDF= JSON.parse(JSON.stringify(response)).data; 


  
});
//Détruire la souscription
this.listSubscription3.push(variable5);


const variable6 = this.baseService.getPersonalVersionFromServerByCompany().subscribe((response) => {
  //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template


    this.personalversionsbases= JSON.parse(JSON.stringify(response)).data; 
  


  
});
//Détruire la souscription
this.listSubscription3.push(variable6);


const variable7 = this.baseService.getClientVersionFromServerByCompany().subscribe((response) => {
  //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template

  
    this.clientversionsbases = JSON.parse(JSON.stringify(response)).data; 


  

  
});
//Détruire la souscription
this.listSubscription3.push(variable7);
console.log(this.userList.userSample);
this.users=this.userList.userSample;
console.log(this.users);

  }
  handleResponsable(value: number) {
    console.log(value);
   
    if(isNaN(value))
    {
   this.f.responsable.reset();
  }
  else
  {
    this.userSelectedID = value;
   
    console.log("selected user ID: " + this.userSelectedID); 

    for(let m=0;m<this.users.length;m++)
    {
      if(this.users[m].id==this.userSelectedID)
      {
        this.responsable=this.users[m].nom+" "+this.users[m].prenom ;
      }
    }
  }
  }
  handleEffectifs(value: number) {
  this.effectifs = value;
  }
  handleUtilisation(value: any) {
  this.utilisation = value;
  console.log(this.utilisation);
  }

  handleUrlBase(value: string) {
    this.urlBase= value;
    }
  handleDateLivraison(value: any) {
    this.dateLivraison= value;
    }
  handleAdresseMail(value: string) {
    this.adresseMail= value;
    }
  handleCoordinateurProjet(value: number) {
    if(isNaN(value))
    {
   this.f.coordinateurProjet.reset();
  }
  else{ 
    this.userSelectedID=value;
    console.log("selected user ID: " + this.userSelectedID); 
  
    for(let m=0;m<this.users.length;m++)
    {
      if(this.users[m].id==this.userSelectedID)
      {
        this.coordinateurProjet=this.users[m].nom+" "+this.users[m].prenom ;
      }
    }
  }
    }
  handleChefProjet(value: number) {
    if(isNaN(value))
    {
   this.f.chefProjet.reset();
  }
  else{
    this.userSelectedID = value;
    console.log("selected user ID: " + this.userSelectedID); 

    for(let m=0;m<this.users.length;m++)
    {
      if(this.users[m].id==this.userSelectedID)
      {
        this.chefProjet=this.users[m].nom+" "+this.users[m].prenom ;
      }
    }
  }
    }

  handleAutres(value: string) {
 
    this.autres= value;
    
   
    
    
    }
  handleType(value: number) {
      this.typeBase= value;
    
    }

  handleLieeGl(value: string) {
   
    this.lieeGl= value;
    
 
    }
 
  handleLieeC(value: string) {
   
    this.lieeC= value;
  
 
    }

 
  handleSiteP(value: string) {
   
    this.siteP= value;
  
 
    }

  handlesiteC(value: string) {
    
    this.siteC= value;
   
 
   
    }

 
    remplirBase()
    {
      this.baseService.coordonnees=this.coordonneesSociete;
      this.baseService.responsable=this.responsable;
      this.baseService.effectifs=this.effectifs;
      this.baseService.utilisationPrev=this.utilisation;
      this.baseService.url=this.urlBase;
      this.baseService.dateLivraison=this.dateLivraison;
      this.baseService.adresseMail=this.adresseMail;
      this.baseService.coordinateur=this.coordinateurProjet;
      this.baseService.chef=this.chefProjet;
      this.baseService.type=this.typeBase;
      this.baseService.copiebase=this.copieBase;
      this.baseService.siAutres=this.autres;
      this.baseService.lieeBase=this.lieeGlobal;
      this.baseService.siOui=this.lieeGl;
      this.baseService.lieeCDF=this.lieeCDF;
      this.baseService.siOuiCDF=this.lieeC;
      this.baseService.nettoyage=this.nettoyage;
      this.baseService.sitePro=this.sitePro;
      this.baseService.siOuiSiteP=this.siteP;
      this.baseService.siteCl=this.siteCl;
      this.baseService.siOuiSiteC=this.siteC;
      this.baseService.dateCreation=this.dateCreation;
      this.baseService.statue=0;
      this.baseService.nomDemandeur=this.connexion.userNom+" "+this.connexion.userPrenom;
      this.baseService.dateConfirmation=this.dateConfirmation; 
      this.baseService.codeConfirmation=this.codeConfirmation;
      console.log(this.baseService);
      for (let user of this.users) {
        if(user.id == this.userSelectedID) {
            this.inscriptionCheckService.userEntreprise = user.name;
           
         
        }
    }
    for (let entreprise of this.entreprises) {
      if(entreprise.id == this.entrepriseSelectedID) {
          this.inscriptionCheckService.userEntreprise = entreprise.name;
        
       
      }
  }

  this.baseService.dataToAdd.push({Id: this.baseService.Id , coordonneesSociete: this.baseService.coordonnees, responsable: this.baseService.responsable, effectifs: this.baseService.effectifs, utilisation: this.baseService.utilisationPrev, urlBase: this.baseService.url, dateLivraison: this.baseService.dateLivraison, adresseMail: this.baseService.adresseMail, coordinateurProjet: this.baseService.coordinateur, chefProjet: this.baseService.chef, typeBase: this.baseService.type, copieBase: this.baseService.copiebase, autres: this.baseService.siAutres,  lieeGlobal: this.baseService.lieeBase,lieeGl:this.baseService.siOui, lieeCDF: this.baseService.lieeCDF, lieeC: this.baseService.siOuiCDF, nettoyage: this.baseService.nettoyage, sitePro: this.baseService.sitePro, siteP: this.baseService.siOuiSiteP, siteCl: this.baseService.siteCl, siteC: this.baseService.siOuiSiteC, dateCreation: this.baseService.dateCreation, statue: this.baseService.statue,
    nomDemandeur: this.baseService.nomDemandeur, dateConfirmation: null,codeConfirmation:this.baseService.codeConfirmation});
  console.log(this.baseService.dataToAdd);
  if(this.modif===false)
  {
    const variable  = this.baseService.postBaseToServer().subscribe(
    (response:any) => {
        console.log('Données sauvegardées !');
        console.log(response.data.Id);
    },
    (error) => {
        console.log('Erreur ! : ' + error);
    }
);
//Détruite la souscription
this.listSubscription3.push(variable);

const variable4 = this.baseService.getmaxid().subscribe((response:any) => {
  //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template


this.maxId=response.data[0].maxim;
 
   
 



  


this.dataToAdd = this.baseService.dataToAdd;
console.log(this.dataToAdd);
  //recevoir la taille de la table timeline

const variable8 = this.timeline.getEvtFromServer().subscribe((response) => {
  //On souhaite récupérer les données de la BDD dans une variable pour l'appeler ensuite dans le template

  
    this.timelines = JSON.parse(JSON.stringify(response)).data; 

});
//Détruire la souscription
this.listSubscription3.push(variable8);
 var dateObj =new Date();   
 if(dateObj.getHours()<10)
 {if(dateObj.getMinutes()<10)
   {var date="0"+dateObj.getHours()+":"+"0"+dateObj.getMinutes();}
   else{
    var date="0"+dateObj.getHours()+":"+dateObj.getMinutes();
   }
  
  
  }
else{
  if(dateObj.getMinutes()<10)
  {var date=dateObj.getHours()+":"+"0"+dateObj.getMinutes();}
  else{
   var date=dateObj.getHours()+":"+dateObj.getMinutes();
  }

}
   //alimentation de la timeline pour chaque concerné
   for(let i=0;i<this.users.length;i++)
{
    console.log(this.users[i].id);
    let identity=this.users[i].id;
    console.log(identity, "identity");
    this.timeline.dataToAdd=[];
    this.timeline.dataToAdd.push({id:0,eventID:this.timelines.length+1, update_ID: null, base_ID:this.maxId,date: new Date(), heure: date, motif:"Création de base en cours de Mr/Mme "+this.responsable , userID: identity, isUserConcerned:this.verifConcerned(identity) })
    console.log(identity);
    console.log(this.timeline.dataToAdd);

    var variable2  = this.timeline.postEvtToServer().subscribe(
      () => {
          console.log('Données sauvegardées !');
      },
      (error) => {
          console.log('Erreur ! : ' + error);
      }
  );
  this.listSubscription3.push(variable2);

    
    }
    console.log(this.baseService.type);
  });
  //Détruire la souscription
  this.listSubscription3.push(variable4);
  }
  else{

    const variable  = this.baseService.postupdateBaseToServer().subscribe(
      () => {
        console.log(this.baseService.Id)
          console.log('Données mises à jour !');
      },
      (error) => {
          console.log('Erreur ! : ' + error);
      }
  );
  //Détruite la souscription
  this.listSubscription3.push(variable);
  var dateObj =new Date();   
  if(dateObj.getHours()<10)
  {if(dateObj.getMinutes()<10)
    {var date="0"+dateObj.getHours()+":"+"0"+dateObj.getMinutes();}
    else{
     var date="0"+dateObj.getHours()+":"+dateObj.getMinutes();
    }
   
   
   }
 else{
   if(dateObj.getMinutes()<10)
   {var date=dateObj.getHours()+":"+"0"+dateObj.getMinutes();}
   else{
    var date=dateObj.getHours()+":"+dateObj.getMinutes();
   }
 
 }


 this.timeline.base_ID=this.baseService.Id;
 var variable5  = this.timeline.postDeleteBase().subscribe(
  () => {
      console.log('données supprimées ! !');
  },
  (error) => {
      console.log('Erreur ! : ' + error);
  }
);
this.listSubscription3.push(variable5);
    //alimentation de la timeline pour chaque concerné
    for(let i=0;i<this.users.length;i++)
 {
     console.log(this.users[i].id);
     let identity=this.users[i].id;
     console.log(this.users);
     console.log(identity, "identity");
     this.timeline.dataToAdd=[];
    console.log(this.baseService.responsable);
     this.timeline.dataToAdd.push({id:0,eventID:this.timelines.length+1, update_ID: null, base_ID:this.baseService.Id,date: new Date(), heure: date, motif:"Création de base en cours de Mr/Mme "+this.baseService.responsable, userID: identity, isUserConcerned:this.verifConcerned(identity) })
     console.log(identity);
     console.log(this.timeline.dataToAdd);
 
     var variable2  = this.timeline.postEvtToServer().subscribe(
       () => {
           console.log('donnée ajoutés ! !');
       },
       (error) => {
           console.log('Erreur ! : ' + error);
       }
   );
   this.listSubscription3.push(variable2);
 
     
     }






  }
  
  }

  verifConcerned(id:number)
  {
    var ConnectedName;
    for(let i=0; i<this.users.length;i++)
      {
        if(this.users[i].id==id)
        {

          ConnectedName=this.users[i].nom+" "+this.users[i].prenom;

        }
      }

      if(ConnectedName==this.responsable || ConnectedName==this.coordinateurProjet || ConnectedName== this.chefProjet)
      {

        return true;

      }
      else return false;



  }



  Verify()
  { var verif=false;
    var j=0;
    while(verif==false && j<5)
    
    {
      if(this.copieBase==0 && this.autres==null)
      { verif=true;}
      else{j++}
      if(this.lieeGlobal==0 && this.lieeGl==null)
      { verif=true;}
      else{j++}
      if(this.lieeCDF==0 && this.lieeC==null)
      { verif=true;}
      else{j++}
   
      if(this.sitePro==0 && this.siteP==null)
      { verif=true;}
      else{j++}
      if(this.sitePro==0 && this.siteP==null)
      { verif=true;}
      else{j++}
      




    }
    return verif;




  } 

  onCondition()
  {
    this.submitted = true;
    this.submitted2 = true;

    // stop here if form is invalid
   if(this.registerForm.invalid)

   { 
    console.log("Il y a une erreur de form");
    this.valide=false;
    return;
   }else {
     if(this.Verify())
     {
    
      console.log("Il y a une erreur de form");
      this.valide=false;

    return;
   


     }
     else{
     this.valide=true;
     


     }



   }

    
  }

  onSubmit() {
    this.submitted = true;
    this.submitted2 = true;

    // stop here if form is invalid
   if(this.registerForm.invalid)

   { 
    console.log("Il y a une erreur de form");
    return;
  
   }else {
     if(this.Verify())
     {
     
      console.log("Il y a une erreur de form");
    return;
   


     }
     else{
       console.log(this.baseService.dataToAdd);
      this.remplirBase();
     
      this.modified=true;
     


     }



   }

    
 
 
}




close()
{
  if(this.modified==true)
  {
    this.router.navigate(['baselist']);
  }

this.showModal=false;
this.modified=false;
this.clicked=false;


}
onClick1(nb:number)
{

this.copieBase=nb;

}
onClick2(nb:number)
{

 this.lieeGlobal=nb;

}
onClick3(nb:number)
{
this.lieeCDF=nb;


}
onClick4(nb:number)
{
  this.nettoyage=nb;
}

onClick7(nb:number)
{
  this.typeBase=nb;
  console.log(this.typeBase);
}
onClick5(nb:number)
{
this.sitePro=nb;


}
onClick6(nb:number)
{

this.siteCl=nb;

}




onReset() {
  this.submitted = false;
  this.registerForm.reset();
}


 

}

 