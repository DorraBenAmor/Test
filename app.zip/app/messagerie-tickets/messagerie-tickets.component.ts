import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { registerLocaleData } from '@angular/common';
import localeFr from '@angular/common/locales/fr';
import { Title } from '@angular/platform-browser';
import { MatCheckboxChange } from '@angular/material/checkbox';
import { FormControl } from '@angular/forms';
import { TooltipPosition } from '@angular/material/tooltip';
import { FicheModel } from '../models/fiche.model';
import { FicheUserModel } from '../models/fiche_user.model';
import { MessageModel } from '../models/message.model';
import { User } from '../models/user.model';
import { MessagerieTicketsService } from '../services/messagerie_tickets.service';
import { Subscription } from 'rxjs';
import { ConnexionService } from '../services/connexion.service';
import { Connection } from '../models/connection.model';
import { FicheMessageModel } from '../models/fiche_Message.model';
import { NotificationService } from '../services/notification.service';
import { FiltreModel } from '../models/filtre.model';
import { FAQService } from '../services/faq.service';
import { UserList } from '../services/user-list.service';
import { TypeObjetModel } from '../models/typeObjet.model';
import { EtatModel } from '../models/etat.model';
import { ModuleModel } from '../models/module.model';
import { OrdrePrioriteModel } from '../models/ordrePriorite.model';
import { URLModel } from '../models/url.model';
import { DataLoadingService } from '../services/dataLoading.service';
import { ImpactModel } from '../models/impact.model';
import { faq } from '../models/faq.model';
import { MatDialog } from '@angular/material/dialog';
import { DialogComponent } from '../dialog/dialog.component';

@Component({
  selector: 'app-messagerie-tickets',
  templateUrl: './messagerie-tickets.component.html',
  styleUrls: ['./messagerie-tickets.component.css']
})
export class MessagerieTicketsComponent implements OnInit, OnDestroy {

   // Loading Data
   private subscriptionLoadData: Subscription

  //Socket
  currentUser: Connection;
  private subscription: Subscription;
  
  currentConnection: any;
  private subscriptionCo: Subscription;
  

  newMessage: MessageModel[] = [];
  private subscriptionMsg: Subscription;
  updatedFicheUser: FicheUserModel;
  private subscriptionFicheUser: Subscription;
  newTicket: FicheMessageModel;
  private subscriptionFicheMsg: Subscription;

  //Autres
  registerForm: FormGroup;
  submitted = false;

  TypesObjet: TypeObjetModel[] = [];
  Etats: EtatModel[] = [];
  Modules: ModuleModel[] = [];
  OnlyModules: any[] = []
  OrdresPriorite: OrdrePrioriteModel[] = [];
  Urls: URLModel[] = [];
  Impacts: ImpactModel[] = []
  MyFiches: FicheModel[];
  MyFichesUser: FicheUserModel[] = [];
  MyFiltres: FiltreModel[] = [];
  MyMessagesOfMyFiches: MessageModel[] = [];
  Users: User[] = [];
  Faqs: faq[] = []
  myBase: string = ""

  user: User = null
  currentComponent: string = "Favoris";
  showBase = false;
  libelle: string;
  url: string;
  module: string;
  type_objet: string;
  ordre_priorite: string;
  etat: string;
  inputValue: string = "";
  fiches2: any = [];
  messagesToDisplay: any[] = [];
  newMessagesToDisplay: any[] = [];
  repertoiresMsg: any[] = [];
  repertoiresFiltres: any[] = [];
  dropdownMenuElt: string = "";
  msgFilteredDisplay: any[] = [];
  filtre: string = "";
  j = [-1];
  filtresFavoris: FiltreModel[] = [];
  filtreDate: any[] = [];
  designedSubCategory = ['Haute', 'Moyenne', 'Basse', 'Prise en compte', 'En attente', 'Demande envoyée', 'Demande terminée', 'Demande cloturée', 'Traitée'];
  subCategories: any[];
  subCategorySubscription: Subscription;
  erreurUserDifferent = false;
  erreurUserClientManquant = false;

  
  /*Multi select list pour FILTRE*/
  showMenuGauche = false;
  showLibelle = false;
  showUrl = false;
  showModule = false;
  showOrdrePriorite = false;
  showTypedObjet = false;
  showEtat = false;
  showDate = false;
  showStatut = false;
  erreurMsgLibelle = false;
  erreurMsgUrl = false;
  erreurMsgModule = false;
  erreurMsgOrdrePriorite = false;
  erreurMsgTypeObjet = false;
  erreurMsgEtat = false;
  erreurMsgDate = false;
  erreurMsgStatut = false;
  erreurMsgFiltre = false;
  selectedFilters: any[] = [];
  finaleSelectedFilters: any[] = [];
  countFiltres = 0;
  dropdownSettings: any = {};
  //Libelle
  libelles: any = [];
  selectedItemsLibelle: any = [];
  //URL
  urls: any = [];
  selectedItemsUrl: any = [];
  //Module
  modules: any = [];
  selectedItemsModule: any = [];
  //Ordre de priorité
  ordrePriorites: any = [];
  selectedItemsOrdrePriorite: any = [];
  //Type d'objet
  type_objets: any = [];
  selectedItemsTypeObjet: any = [];
  //Etat
  etats: any = [];
  selectedItemsEtat: any = [];
  //Date
  dates: any = [];
  selectedItemsDate: any = [];
  dropdownSettingsDate: any = {};
  //Statut
  statuts: any = [];
  selectedItemsStatut: any = [];

  /** Ajout Filtre aux favoris */
  nomRegroupement: string = "";
  erreurMsgAjouter = false;

  /**Menu de droite */
  showMenuDroite = "";
  //Header
  positionTop: TooltipPosition = 'above';
  position = new FormControl(this.positionTop);
  conversationData: any[] = [];
  dropdownTypeDemande: any = [];
  dropdownModule: any = [];
  dropdownURL: any = [];
  dropdownEtat: any = [];
  selectedTypeDemande = "";
  selectedModule = "";
  selectedSousModule = "";
  dataToTransfer = "";
  //Footer
  tinymceInit;
  source: string;
  erreurEditeurVide = false;

  /**Nouveau Message */
  //Header
  destinataires: any = [];
  selectedItemsDestinataire: any = [];
  dropdownSettingsDestinataires: any = {};
  responsables: any = [];
  respos: any[] = []
  selectedLibelle = "";
  selectedRespo: any = [];
  selectedNewTypeDemande = "";
  selectedNewModule = "";
  selectedNewSousModule = "";
  selectedURL = "";
  selectedEtat = "";
  selectedImpact = "";
  selectedTel = "";
  selectedPriorite = "";
  erreurDestinataire = false;
  erreurLibelle = false;
  erreurRespo = false;
  erreurModule = false;
  erreurSousModule = false;
  erreurTypeDemande = false;
  erreurURL = false;
  erreurEtat = false;
  erreurImpact = false;
  erreurTel = false;
  erreurPriorite = false;
  erreurBugTrackingTeamExist= false;
  erreurNewMessage = false;
  source2 = "";
  disabledEditor: boolean

  //Questions et réponses
  questions:any[];
  userid: number;
  selectedQuestion = "";

 
  listSubscription = <Subscription[]>[];

  constructor(private titleService: Title, public dialog: MatDialog, private dataLoadingService: DataLoadingService, private notificationService: NotificationService, private userService: UserList, private connexionService: ConnexionService, private messagerieTicketsSerivice: MessagerieTicketsService, private formBuilder: FormBuilder, private faq: FAQService) { }

  // getter for easy access to form fields
  get f() { return this.registerForm.controls; }

  ngOnInit(): void {
    // Initialisation
    this.titleService.setTitle('Gestion des tickets - Messagerie');
    this.disabledEditor = false
    registerLocaleData(localeFr, 'fr');
    // Mise à jour des components ouverts
    this.dataLoadingService.chartOpened.messagerieTicket = 1


    this.subscriptionCo = this.connexionService.currentConnection.subscribe(connection => {
      this.currentConnection = connection;
      console.log(this.currentConnection, "Connected User IN")
    });

    this.subscription = this.connexionService.connexionSubject.subscribe(datas => {
      this.currentUser = datas;
      this.selectedTel = this.currentUser.tel;
      this.myBase = this.currentUser.base
      console.log(datas, 'je récupère mon user connecté')
    })
    this.connexionService.emitConnection();

    // Sockets
    this.subCategorySubscription = this.messagerieTicketsSerivice.subCategorySubject.subscribe(
      (subCategories: any[]) => {
        this.subCategories = subCategories;
      }
    );
    this.messagerieTicketsSerivice.emitSubCategorySubject();

    this.subscriptionMsg = this.messagerieTicketsSerivice.newMessage.subscribe(msg => {
      console.log(msg, "Nouveau msg")
      this.newMessage.push(msg);
      for(let newMsg of this.newMessage){
        //Ajout nouveau message dans la conversation
        if(this.conversationData.length != 0) {
          if(this.conversationData[0].numeroDemande == newMsg.ficheID) {
            var msgAlreadyIn = false;
            for(let oldMsg of this.conversationData[0].messages){
              if(oldMsg.id == newMsg.id) msgAlreadyIn = true;
            }
            if(msgAlreadyIn == false) this.conversationData[0].messages.push({id: newMsg.id, date: new Date(newMsg.date_envoie), message: newMsg.message, userID: newMsg.userID, userStatut: newMsg.userStatut, invisibleAuClient: newMsg.invisibleAuClient});
          }
        }
        //Ajout nouveau message sur l'etiquette des tickets dans le menu de gauche
        if(this.messagesToDisplay.length != 0) {
          for(let msg of this.messagesToDisplay){
            if(msg.ficheID == newMsg.ficheID && msg.id != newMsg.id) {
              msg.msgID = newMsg.id;
              msg.date_envoie = new Date(newMsg.date_envoie);
              msg.message = newMsg.message;
              msg.userID = newMsg.userID;
              msg.userStatut = newMsg.userStatut
              msg.invisibleAuClient = newMsg.invisibleAuClient
            }
          }
        }
      }
      console.log(this.conversationData[0], "convData after msg added")
    });

    this.subscriptionFicheMsg = this.messagerieTicketsSerivice.newTicket.subscribe(ficheMsg => {
      this.newTicket = ficheMsg;
      console.log(this.newTicket, "My new ticket")
      if(this.filtre == "filtreSimple"){
        // ajout nouvelle fiche
        const variable5 = this.messagerieTicketsSerivice.getLastFicheFromServer().subscribe((res) => {
          let lastFiche = JSON.parse(JSON.stringify(res)).data;
          console.log(lastFiche, "last fiche")
          this.MyFiches.push(lastFiche[0])
          // this.dataLoadingService.myFiches.push(lastFiche[0])
          this.dataLoadingService.fiches.push(lastFiche[0])
          // ajout nouveau message
          const variable5 = this.messagerieTicketsSerivice.getLastMessageFromServer().subscribe((response) => {
              let lastMessage = JSON.parse(JSON.stringify(response)).data;
              console.log(lastMessage, "last message")
              this.MyMessagesOfMyFiches.push(lastMessage[0])
              this.dataLoadingService.messagesDeMesFiches.push(lastMessage[0])
              this.dataLoadingService.messages.push(lastMessage[0])
            // ajout nouvelles fichesUser
              this.messagerieTicketsSerivice.dataFicheId = lastFiche[0].id;
              const variable7 = this.messagerieTicketsSerivice.getFichesUserOfLastFicheFromServer().subscribe((response2) => {
                let lastFichesUser = JSON.parse(JSON.stringify(response2)).data;
                console.log(lastFichesUser, "lastFichesUser")
                for(let ficheUser of lastFichesUser) {
                  this.MyFichesUser.push(ficheUser)
                  this.dataLoadingService.myFichesUser.push(ficheUser)
                  this.dataLoadingService.fichesUser.push(ficheUser)
                }

                //On liste l'ensemble des users concernés par la fiche dans un tableau
                let listUsers = this.newTicket.usersID.split(/[/*]/);
                for(let i=0; i<listUsers.length; i++){
                  if(listUsers[i] == "") listUsers.splice(i, 1);
                }
                this.newMessagesToDisplay.push({msgID: lastMessage[lastMessage.length - 1].id, ficheID: lastFiche[lastFiche.length - 1].id, numero_ticket: lastFiche[lastFiche.length - 1].numero_ticket, userID: this.newTicket.userID, userStatut: this.newTicket.userStatut, invisibleAuClient: this.newTicket.invisibleAuClient, libelle: this.newTicket.libelle, date_envoie: new Date(this.newTicket.date_envoie), message: this.newTicket.message, non_lu: this.newTicket.non_lu, envoye: this.newTicket.envoyé, respo_dossier_ID: this.newTicket.respo_dossier_ID, usersID: this.newTicket.usersID, listUsers: listUsers, module: this.newTicket.module, sous_module: this.newTicket.sous_module, type_objet: this.newTicket.type_objet, ordre_priorite: this.newTicket.ordre_priorite, etat: this.newTicket.etat, impact: this.newTicket.impact, numTelephoneClient: this.newTicket.numTelephoneClient, archivé: this.newTicket.archivé})
                this.showConversation({msgID: lastMessage[lastMessage.length - 1].id, ficheID: lastFiche[lastFiche.length - 1].id, numero_ticket: lastFiche[lastFiche.length - 1].numero_ticket, userID: this.newTicket.userID, userStatut: this.newTicket.userStatut, invisibleAuClient: this.newTicket.invisibleAuClient, libelle: this.newTicket.libelle, date_envoie: new Date(this.newTicket.date_envoie), message: this.newTicket.message, non_lu: this.newTicket.non_lu, envoye: this.newTicket.envoyé, respo_dossier_ID: this.newTicket.respo_dossier_ID, usersID: this.newTicket.usersID, listUsers: listUsers, module: this.newTicket.module, sous_module: this.newTicket.sous_module, type_objet: this.newTicket.type_objet, ordre_priorite: this.newTicket.ordre_priorite, etat: this.newTicket.etat, impact: this.newTicket.impact, numTelephoneClient: this.newTicket.numTelephoneClient, archivé: this.newTicket.archivé})
                this.handleClick(this.dropdownMenuElt)

                // On vide tous les champs
                this.selectedLibelle = ""
                this.selectedRespo = ""
                this.selectedNewModule = ""
                this.selectedNewSousModule = ""
                this.selectedNewTypeDemande = ""
                this.selectedURL = ""
                this.selectedEtat = ""
                this.selectedImpact = ""
                this.selectedPriorite = ""
                this.source2 = ""
              });
              //Destruction de la souscription
              this.listSubscription.push(variable7);
          });
          //Détruire la souscription
          this.listSubscription.push(variable5);
        });
        //Détruire la souscription
        this.listSubscription.push(variable5);
      }
    })

    this.subscriptionFicheUser = this.messagerieTicketsSerivice.updatedFicheUser.subscribe(ficheUser => {
      this.updatedFicheUser = ficheUser;
      for(let fiche_user of this.MyFichesUser){
        if(this.updatedFicheUser.userID == Number(this.currentUser.id) && this.updatedFicheUser.ficheID == fiche_user.ficheID) {
          fiche_user.non_lu = this.updatedFicheUser.non_lu;
          fiche_user.archive = this.updatedFicheUser.archive;
        }
      }
      if(this.filtre == "filtreSimple") this.sortMsg(this.dropdownMenuElt);
    });

    //Ajout d'un regroupement
    this.registerForm = this.formBuilder.group({
      imbrication: ['', Validators.required],
      nom: ['', Validators.required]
    });
    
    // Chargement des fiches, fiches_user, messages
    // Mes Fiches
    this.messagerieTicketsSerivice.dataUserId = this.currentUser.id
    this.dataLoadingService.loadDataMyFiches()
    // Mes Fiches user
    this.dataLoadingService.loadDataMyFichesUser()
    // Mes messages
    this.dataLoadingService.loadDataMyMessages()
    //Chargement es données de la BDD
    this.chargementDonneesBDD()

    this.subscriptionLoadData = this.dataLoadingService.MessagerieTicketloadDataCalled.subscribe(() => {
      console.log('IN SUB')
      this.Users = this.dataLoadingService.users
      this.Urls = this.dataLoadingService.urls
      this.OrdresPriorite = this.dataLoadingService.ordresPriorite
      this.Modules = this.dataLoadingService.modules
      this.OnlyModules = this.dataLoadingService.onlyModules
      this.Impacts = this.dataLoadingService.impacts
      this.Etats = this.dataLoadingService.etats
      this.TypesObjet = this.dataLoadingService.typesObjet
      this.MyFiches = this.dataLoadingService.myFiches
      this.MyFichesUser = this.dataLoadingService.myFichesUser
      this.MyMessagesOfMyFiches = this.dataLoadingService.myMessagesOfMyFiches
      this.MyFiltres = this.dataLoadingService.myFiltres
      this.Faqs = this.dataLoadingService.faqs

      // Initialisation
      this.filtresFavoris = []
      for(let item of this.dataLoadingService.myFiltres){
        //seperate filtre string by *
        let values = item.filtre.split("*", item.filtre.split("*").length,); 
        let category = [values[0].substring(0, values[0].length - 1)];
        let sousCategory: any[] = [];
        let array: any = [];
        for(let i=1; i<values.length; i++){
          if(!values[i].includes("_")) array.push({item_text: values[i]});
          else{
            category.push(values[i].substring(0, values[i].length - 1));
            sousCategory.push({category: "", sous_category: array});
            array = [];
          }
          if(i == values.length - 1) sousCategory.push({category: "", sous_category: array});
        }
        console.log(category, "cat")
        console.log(sousCategory, "souscat")
        let i = 0;
        for(let item of sousCategory){
          item.category = category[i];
          i++;
        }
        console.log(sousCategory, "filtre")
        this.filtresFavoris.push({id: item.id, userID: item.userID, titre: item.titre, filtre: sousCategory})
        
      }
      
      console.log(this.filtresFavoris, "Filtres Favoris")

      // Initialisation
      this.initialisation()
      // Lancement
      this.handleClick('Récents')
    });

  }

  ngOnDestroy(){
    this.listSubscription.map((elem) => elem.unsubscribe());
    this.subscription.unsubscribe()
    this.subscriptionCo.unsubscribe()
    this.subscriptionMsg.unsubscribe()
    this.subscriptionFicheUser.unsubscribe()
    this.subscriptionFicheMsg.unsubscribe()
    this.subCategorySubscription.unsubscribe()
    this.subscriptionLoadData.unsubscribe()
  }

  convertStringToNumber(value: string){
    return Number(value);
  }

  convertNumberToString(value: number){
    return value.toString();
  }

  isDisabled(){
    if(this.currentUser.statut == "Externe")  return true;
    else return false;
  }

  isDisabledEditor(){
    return this.disabledEditor
  }

  chargementDonneesBDD(){
    
    // Chargement des données
    // Verfication chargement des données des types d'objet
    if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.typesObjet) == true) {
      if(this.dataLoadingService.loadingLaunched.typesObjet === 0)  this.dataLoadingService.loadDataTypesObjet()
      console.log('I am loading types objet data')
    }
    else this.TypesObjet = this.dataLoadingService.typesObjet

    // Verfication chargement des données des etats
    if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.etats) == true) {
      if(this.dataLoadingService.loadingLaunched.etats === 0)  this.dataLoadingService.loadDataEtats()
      console.log('I am loading etats data')
    }
    else this.Etats = this.dataLoadingService.etats

    // Verfication chargement des données des impacts
    if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.impacts) == true) {
      if(this.dataLoadingService.loadingLaunched.impacts === 0)  this.dataLoadingService.loadDataImpacts()
      console.log('I am loading impacts data')
    }
    else this.Impacts = this.dataLoadingService.impacts

    // Verfication chargement des données des modules
    if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.modules) == true) {
      if(this.dataLoadingService.loadingLaunched.modules === 0)  this.dataLoadingService.loadDataModules()
      console.log('I am loading modules data')
    }
    else {
      this.Modules = this.dataLoadingService.modules
      this.OnlyModules = this.dataLoadingService.onlyModules
    }

    // Verfication chargement des données des ordres de priorité
    if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.ordresPriorite) == true) {
      if(this.dataLoadingService.loadingLaunched.ordresPriorite === 0)  this.dataLoadingService.loadDataOrdresPriorite()
      console.log('I am loading ordres de priorité data')
    }
    else this.OrdresPriorite = this.dataLoadingService.ordresPriorite

    // Verfication chargement des données des urls
    if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.urls) == true) {
      if(this.dataLoadingService.loadingLaunched.urls === 0)  this.dataLoadingService.loadDataUrls()
      console.log('I am loading urls data')
    }
    else this.Urls = this.dataLoadingService.urls

    

    // Verfication chargement des données des fiches du user connecté
    if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.myFiches) == true) {
      this.messagerieTicketsSerivice.dataUserId = this.currentUser.id
      if(this.dataLoadingService.loadingLaunched.myFiches === 0)  this.dataLoadingService.loadDataMyFiches()
      console.log('I am loading fiches of connected user data')

      // Verfication chargement des données des messages des fiches du user connecté
      if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.myMessagesOfMyFiches) == true) {
        if(this.dataLoadingService.loadingLaunched.myMessages === 0)  this.dataLoadingService.loadDataMyMessages()
        console.log('I am loading messages of fiches of connected user data')

        // Verfication chargement des données des fichesUser du user connecté
        if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.myFichesUser) == true) {
          if(this.dataLoadingService.loadingLaunched.myFichesUser === 0)  this.dataLoadingService.loadDataMyFichesUser()
          console.log('I am loading fichesUser of connected user data')

          // Verfication chargement des données des users
          if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.users) == true) {
            if(this.dataLoadingService.loadingLaunched.users === 0)  this.dataLoadingService.loadDataUsers()
            console.log('I am loading users data')
          }
          else {
            this.Users = this.dataLoadingService.users

            // Initialisation
            this.initialisation()
            // Lancement
            this.handleClick('Récents')
          }
        }
        else {
          this.MyFichesUser = this.dataLoadingService.myFichesUser

          // Verfication chargement des données des users
          if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.users) == true) {
            if(this.dataLoadingService.loadingLaunched.users === 0)  this.dataLoadingService.loadDataUsers()
            console.log('I am loading users data')
          }
          else {
            this.Users = this.dataLoadingService.users

            // Initialisation
            this.initialisation()
            // Lancement
            this.handleClick('Récents')
          }
        }
      }
      else {
        this.MyMessagesOfMyFiches = this.dataLoadingService.myMessagesOfMyFiches

        // Verfication chargement des données des fichesUser du user connecté
        if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.myFichesUser) == true) {
          if(this.dataLoadingService.loadingLaunched.myFichesUser === 0)  this.dataLoadingService.loadDataMyFichesUser()
          console.log('I am loading fichesUser of connected user data')

          // Verfication chargement des données des users
          if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.users) == true) {
            if(this.dataLoadingService.loadingLaunched.users === 0)  this.dataLoadingService.loadDataUsers()
            console.log('I am loading users data')
          }
          else {
            this.Users = this.dataLoadingService.users

            // Initialisation
            this.initialisation()
            // Lancement
            this.handleClick('Récents')
          }
        }
        else {
          this.MyFichesUser = this.dataLoadingService.myFichesUser

          // Verfication chargement des données des users
          if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.users) == true) {
            if(this.dataLoadingService.loadingLaunched.users === 0)  this.dataLoadingService.loadDataUsers()
            console.log('I am loading users data')
          }
          else {
            this.Users = this.dataLoadingService.users

            // Initialisation
            this.initialisation()
            // Lancement
            this.handleClick('Récents')
          }
        }
      }
    }
    else {
      this.MyFiches = this.dataLoadingService.myFiches

      // Verfication chargement des données des messages des fiches du user connecté
      if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.myMessagesOfMyFiches) == true) {
        if(this.dataLoadingService.loadingLaunched.myMessages === 0)  this.dataLoadingService.loadDataMyMessages()
        console.log('I am loading messages of fiches of connected user data')

        // Verfication chargement des données des fichesUser du user connecté
        if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.myFichesUser) == true) {
          if(this.dataLoadingService.loadingLaunched.myFichesUser === 0)  this.dataLoadingService.loadDataMyFichesUser()
          console.log('I am loading fichesUser of connected user data')

          // Verfication chargement des données des users
          if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.users) == true) {
            if(this.dataLoadingService.loadingLaunched.users === 0)  this.dataLoadingService.loadDataUsers()
            console.log('I am loading users data')
          }
          else {
            this.Users = this.dataLoadingService.users

            // Initialisation
            this.initialisation()
            // Lancement
            this.handleClick('Récents')
          }
        }
        else {
          this.MyFichesUser = this.dataLoadingService.myFichesUser

          // Verfication chargement des données des users
          if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.users) == true) {
            if(this.dataLoadingService.loadingLaunched.users === 0)  this.dataLoadingService.loadDataUsers()
            console.log('I am loading users data')
          }
          else {
            this.Users = this.dataLoadingService.users

            // Initialisation
            this.initialisation()
            // Lancement
            this.handleClick('Récents')
          }
        }
      }
      else {
        this.MyMessagesOfMyFiches = this.dataLoadingService.myMessagesOfMyFiches

        // Verfication chargement des données des fichesUser du user connecté
        if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.myFichesUser) == true) {
          if(this.dataLoadingService.loadingLaunched.myFichesUser === 0)  this.dataLoadingService.loadDataMyFichesUser()
          console.log('I am loading fichesUser of connected user data')

          // Verfication chargement des données des users
          if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.users) == true) {
            if(this.dataLoadingService.loadingLaunched.users === 0)  this.dataLoadingService.loadDataUsers()
            console.log('I am loading users data')
          }
          else {
            this.Users = this.dataLoadingService.users

            // Initialisation
            this.initialisation()
            // Lancement
            this.handleClick('Récents')
          }
        }
        else {
          this.MyFichesUser = this.dataLoadingService.myFichesUser

          // Verfication chargement des données des users
          if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.users) == true) {
            if(this.dataLoadingService.loadingLaunched.users === 0)  this.dataLoadingService.loadDataUsers()
          }
          else {
            this.Users = this.dataLoadingService.users

            // Initialisation
            this.initialisation()
            // Lancement
            this.handleClick('Récents')
          }
        }
      }
    }

    // Verfication chargement des données des filtres
    if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.myFiltres) == true) {
      if(this.dataLoadingService.loadingLaunched.myFiltres === 0)  this.dataLoadingService.loadDataMyFiltres()
      console.log('I am loading filtres of connected user data')
    }
    else {
      this.MyFiltres = this.dataLoadingService.myFiltres

      // Initialisation
      for(let item of this.MyFiltres){
        //seperate filtre string by *
        let values = item.filtre.split("*", item.filtre.split("*").length,); 
        let category = [values[0].substring(0, values[0].length - 1)];
        let sousCategory: any[] = [];
        let array: any = [];
        for(let i=1; i<values.length; i++){
          if(!values[i].includes("_")) array.push({item_text: values[i]});
          else{
            category.push(values[i].substring(0, values[i].length - 1));
            sousCategory.push({category: "", sous_category: array});
            array = [];
          }
          if(i == values.length - 1) sousCategory.push({category: "", sous_category: array});
        }
        console.log(category, "cat")
        console.log(sousCategory, "souscat")
        let i = 0;
        for(let item of sousCategory){
          item.category = category[i];
          i++;
        }
        console.log(sousCategory, "filtre")
        this.filtresFavoris.push({id: item.id, userID: item.userID, titre: item.titre, filtre: sousCategory})
        
      }
      
      console.log(this.filtresFavoris, "Filtres Favoris")
    }

    // Verfication chargement des données des faqs
    if(this.dataLoadingService.verifyArrayEmpty(this.dataLoadingService.faqs) == true) {
      if(this.dataLoadingService.loadingLaunched.faqs === 0)  this.dataLoadingService.loadDataFaqs()
      console.log('I am loading faqs data')
    }
    else this.Faqs = this.dataLoadingService.faqs
    
  }

  initialisation(){
    // Paramétrage de l'espace d'écriture d'un message
    this.tinymceInit = {
      height: 300,
      menubar: false,
      images_upload_url: '/',
      automatic_uploads: false,
      image_advtab : true,
      //file_picker_types: 'file image media',
      file_picker_types: 'image',
      file_picker_callback: function (cb, value, meta) {
        let elem = this;
        var input = document.createElement('input');
        input.setAttribute('type', 'file');
        input.setAttribute('accept', 'image/*');
        input.onchange = function () {
          var file = input.files[0];
          var reader = new FileReader();
          reader.onload = function () {
            var id = 'blobid' + new Date().getTime();
            var blobCache = elem.editorUpload.blobCache;
            console.log(blobCache, reader)
            var base64 = reader.result.toString().split(',')[1];
            var blobInfo = blobCache.create(id, file, base64);
            blobCache.add(blobInfo);
            // // call the callback and populate the Title field with the file name
            cb(blobInfo.blobUri(), { title: file.name });
          };
          reader.readAsDataURL(file);
        };
          
        input.click();
      },
      plugins : [
        "advlist autolink lists link image code charmap print preview hr anchor pagebreak",
        "searchreplace wordcount visualblocks visualchars code fullscreen",
        "insertdatetime media nonbreaking save table contextmenu directionality",
        " template paste help wordcount textcolor colorpicker textpattern"
      ],
      toolbar : 'undo redo | link image code media |formatselect | bold italic underline forecolor backcolor |\
                 alignleft aligncenter alignright alignjustify  | bullist numlist outdent indent | removeformat | help',
      
    }

    

    // Paramétrage des options de filtres
    this.destinataires = [];
    this.selectedItemsDestinataire = [];
    this.destinataires = [
      ...this.destinataires,
      { item_id: this.destinataires.length + 1, item_text: "Bug Tracking Team", statut: "tag"},
    ];
    this.selectedItemsDestinataire = [
      ...this.selectedItemsDestinataire,
      { item_id: this.selectedItemsDestinataire.length + 1, item_text: "Bug Tracking Team", statut: "tag"},
    ];

    console.log(this.Users, 'Initialisation')
    //Initialisation
    this.responsables = []
    this.respos = []
    for(let item of this.Users){
      if(this.currentUser.statut == "Interne") {
        if(item.statut == "Externe") {
          this.destinataires = [
            ...this.destinataires,
            { item_id: this.destinataires.length + 1, item_text: item.prenom + " " + item.nom + "  <" + item.emailPro + ">", persoID: item.id, statut: "user"},
          ];
        }
      }
      if(this.currentUser.statut == "Externe") {
        if (item.tags != null) {
          if (item.tags.includes("hotline/")){
            this.responsables = [
              ...this.responsables,
              { item_id: this.destinataires.length + 1, item_text: item.prenom + " " + item.nom + "  <" + item.emailPro + ">", persoID: item.id},
            ];
            this.respos.push({id: item.id.toString(), nom: item.nom, prenom: item.prenom})
          }
        }
      }
    }

    if(this.currentComponent == "Ajout"){
      this.fiches2.push('Libelle')
      for(let fiche of this.dataLoadingService.myFiches){
        if(!this.fiches2.includes("Libelle/" + fiche.libelle)) this.fiches2.push("Libelle/" + fiche.libelle );
      }
      this.fiches2.push('URL')
      for(let fiche of this.dataLoadingService.myFiches){
        if(!this.fiches2.includes("URL/" + fiche.url)) this.fiches2.push("URL/" + fiche.url );
      }
      this.fiches2.push('Module')
      for(let fiche of this.dataLoadingService.myFiches){
        if(!this.fiches2.includes("Module/" + fiche.module)) this.fiches2.push("Module/" + fiche.module );
      }
      this.fiches2.push('Ordre de priorité')
      for(let fiche of this.dataLoadingService.myFiches){
        if(!this.fiches2.includes("Ordre de priorité/" + fiche.ordre_priorite)) this.fiches2.push("Ordre de priorité/" + fiche.ordre_priorite );
      }
      this.fiches2.push('Type d\'objet')
      for(let fiche of this.dataLoadingService.myFiches){
        if(!this.fiches2.includes("Type d'objet/" + fiche.type_objet)) this.fiches2.push("Type d'objet/" + fiche.type_objet );
      }
      this.fiches2.push('Etat')
      for(let fiche of this.dataLoadingService.myFiches){
        if(!this.fiches2.includes("Etat/" + fiche.etat)) this.fiches2.push("Etat/" + fiche.etat );
      }
    }

    console.log(this.MyFiches, "mes fiches avant recuperation des filtres")
    for(let fiche of this.dataLoadingService.myFiches){
      let valueLibelleExist = false;
      for(let libelle of this.libelles){
        if(libelle.item_text == fiche.libelle) valueLibelleExist = true;
      }
      if(valueLibelleExist == false){
        this.libelles = [
          ...this.libelles,
          { item_id: this.libelles.length + 1, item_text: fiche.libelle }
        ] 
      }

      let valueUrlExist = false;
      for(let url of this.urls){
        if(url.item_text == fiche.url) valueUrlExist = true;
      }
      if(valueUrlExist == false){
        this.urls = [
          ...this.urls,
          { item_id: this.urls.length + 1, item_text: fiche.url }
        ] 
      }

      let valueModuleExist = false;
      for(let module of this.modules){
        if(module.item_text == fiche.module) valueModuleExist = true;
      }
      if(valueModuleExist == false){
        this.modules = [
          ...this.modules,
          { item_id: this.modules.length + 1, item_text: fiche.module }
        ] 
      }
         
      let valueOrdrePrioriteExist = false;
      for(let ordrePriorite of this.ordrePriorites){
        if(ordrePriorite.item_text == fiche.ordre_priorite) valueOrdrePrioriteExist = true;
      }
      if(valueOrdrePrioriteExist == false){
        this.ordrePriorites = [
          ...this.ordrePriorites,
          { item_id: this.ordrePriorites.length + 1, item_text: fiche.ordre_priorite }
        ] 
      }

      let valueTypeObjetExist = false;
      for(let typeObjet of this.type_objets){
        if(typeObjet.item_text == fiche.type_objet) valueTypeObjetExist = true;
      }
      if(valueTypeObjetExist == false){
        this.type_objets = [
          ...this.type_objets,
          { item_id: this.type_objets.length + 1, item_text: fiche.type_objet }
        ] 
      }

      let valueEtatExist = false;
      for(let etat of this.etats){
        if(etat.item_text == fiche.etat) valueEtatExist = true;
      }
      if(valueEtatExist == false){
        this.etats = [
          ...this.etats,
          { item_id: this.etats.length + 1, item_text: fiche.etat }
        ]
      }
    }

    this.dates = []
    this.dates = [
      ...this.dates,
      { item_id: 1, item_text: "Heure"},
      { item_id: 2, item_text: "Jour"},
      { item_id: 3, item_text: "Mois"},
      { item_id: 4, item_text: "Année"}
    ];

    // this.statuts = [
    //   ...this.statuts,
    //   { item_id: 1, item_text: "Non lus"},
    //   { item_id: 2, item_text: "Lus"},
    //   { item_id: 3, item_text: "Envoyés"},
    //   { item_id: 4, item_text: "Archivés"}
    // ];

      this.dropdownSettings = {
        singleSelection: false,
        idField: 'item_id',
        textField: 'item_text',
        selectAllText: 'Select All',
        unSelectAllText: 'UnSelect All',
        itemsShowLimit: 1,
        allowSearchFilter: true
      };

      this.dropdownSettingsDate = {
        singleSelection: false,
        idField: 'item_id',
        textField: 'item_text',
        selectAllText: 'Select All',
        unSelectAllText: 'UnSelect All',
        itemsShowLimit: 1,
        allowSearchFilter: true,
        limitSelection: 1
      };
      

      this.dropdownSettingsDestinataires = {
        singleSelection: false,
        idField: 'item_id',
        textField: 'item_text',
        selectAllText: 'Select All',
        unSelectAllText: 'UnSelect All',
        itemsShowLimit: 2,
        allowSearchFilter: true
      };

  }

  handleClick(selectedElt: string) {

    this.filtre = "filtreSimple"
    switch (selectedElt) {
      case 'Récents':
        this.dropdownMenuElt = "Récents";
        this.sortMsg('Récents');
        break;
      case 'Non lu':
        this.dropdownMenuElt = "Non lu";
        this.sortMsg('Non lu');
        break;
      case 'Envoyés':
        this.dropdownMenuElt = "Envoyés";
        this.sortMsg('Envoyés');
        break;
      case 'Archivés':
        this.dropdownMenuElt = "Archivés";
        this.sortMsg('Archivés');
        break;
      default:
        this.dropdownMenuElt = "";  
      }
  }

  sortMsg(sortBy: string){

    //on parcourt les fiches
    let ficheDates = [];
    this.messagesToDisplay = [];
    console.log(this.newMessagesToDisplay, "new msgs")
    for(let newTicket of this.newMessagesToDisplay){
      let listAccesUsers
      if(newTicket.accesVisuelPourUsers !== null && newTicket.accesVisuelPourUsers !== undefined) {
        listAccesUsers = newTicket.accesVisuelPourUsers.split(/[/*]/);
        for(let i=0; i<listAccesUsers.length; i++){
          if(listAccesUsers[i] == "") listAccesUsers.splice(i, 1);
        }
      }
      else listAccesUsers = []
      if(this.currentUser.statut == 'Interne'){
        if(newTicket.usersID.includes("/" + this.currentUser.id.toString() + "*") || newTicket.accesVisuelPourUsers	.includes("/" + this.currentUser.id.toString() + "*")){ 
          let usersList = newTicket.usersID;
          for(let user of this.dataLoadingService.users){
            if(user.statut == 'Interne' && usersList.includes("/" + user.id + "*")) usersList = usersList.replace("/" + user.id + "*", '');
          }
          this.messagesToDisplay.push({msgID: newTicket.msgID, ficheID: newTicket.ficheID, numero_ticket: newTicket.numero_ticket, userID: newTicket.userID, accesVisuelPourUsers: newTicket.accesVisuelPourUsers, libelle: newTicket.libelle, date_envoie: new Date(newTicket.date_envoie), message: newTicket.message, senderId: newTicket.userID, non_lu: newTicket.non_lu, envoye: newTicket.envoye, respo_dossier_ID: newTicket.respo_dossier_ID, usersID: usersList, listUsers: newTicket.listUsers, listAccesUsers: listAccesUsers, module: newTicket.module, sous_module: newTicket.sous_module, type_objet: newTicket.type_objet, ordre_priorite: newTicket.ordre_priorite, etat: newTicket.etat, impact: this.newTicket.impact, numTelephoneClient: this.newTicket.numTelephoneClient, archivé: newTicket.archivé})
        }
      }
      if(this.currentUser.statut == 'Externe'){
        if(newTicket.usersID.includes("/" + this.currentUser.id.toString() + "*")){ 
          let usersList = "/" + this.currentUser.id.toString() + "*";
          if(newTicket.userStatut !== 'Assistance') this.messagesToDisplay.push({msgID: newTicket.msgID, ficheID: newTicket.ficheID, numero_ticket: newTicket.numero_ticket, userID: newTicket.userID, accesVisuelPourUsers: newTicket.accesVisuelPourUsers, libelle: newTicket.libelle, date_envoie: new Date(newTicket.date_envoie), message: newTicket.message, senderId: newTicket.userID, non_lu: newTicket.non_lu, envoye: newTicket.envoye, respo_dossier_ID: newTicket.respo_dossier_ID, usersID: usersList, listUsers: newTicket.listUsers, listAccesUsers: listAccesUsers, module: newTicket.module, sous_module: newTicket.sous_module, type_objet: newTicket.type_objet, ordre_priorite: newTicket.ordre_priorite, etat: newTicket.etat, impact: this.newTicket.impact, numTelephoneClient: this.newTicket.numTelephoneClient, archivé: newTicket.archivé})
        }
      }
    }
    // const variable2 = this.messagerieTicketsSerivice.getFichesFromServer().subscribe((response) => {
      ficheDates = []
      console.log( this.dataLoadingService.myFiches, "sortMsg: mesFiches")
      console.log(this.dataLoadingService.myFichesUser, 'myfichesuser')
      console.log(this.dataLoadingService.myMessagesOfMyFiches, 'myMessages')
      // fiches
      for(let fiche of this.dataLoadingService.myFiches){
        ficheDates = []
        for(let msg of this.dataLoadingService.myMessagesOfMyFiches){
          if(this.currentUser.statut == 'Interne'){
            if(fiche.id == msg.ficheID && (fiche.usersID.includes("/" + this.currentUser.id.toString() + "*") || fiche.accesVisuelPourUsers.includes("/" + this.currentUser.id.toString() + "*"))){ 
              console.log('YES')
              let usersList = fiche.usersID;
              for(let user of this.dataLoadingService.users){
                if(user.statut == 'Interne' && usersList.includes("/" + user.id + "*")) usersList = usersList.replace("/" + user.id + "*", '');
              }
              //On liste l'ensemble des users concernés par la fiche dans un tableau
              let listUsers = fiche.usersID.split(/[/*]/);
              for(let i=0; i<listUsers.length; i++){
                if(listUsers[i] == "") listUsers.splice(i, 1);
              }
              //On liste l'ensemble des users ayant un accès visuel à la fiche dans un tableau
              let listAccesUsers
              if(fiche.accesVisuelPourUsers !== null && fiche.accesVisuelPourUsers !== undefined) {
                listAccesUsers = fiche.accesVisuelPourUsers.split(/[/*]/);
                for(let i=0; i<listAccesUsers.length; i++){
                  if(listAccesUsers[i] == "") listAccesUsers.splice(i, 1);
                }
              }
              else listAccesUsers = []
              
              for(let fiche_user of this.dataLoadingService.myFichesUser){
                let msgEnvoyé = 0;
                if(msg.userID === Number(this.currentUser.id)) msgEnvoyé = 1;
                if(fiche_user.ficheID === fiche.id && fiche_user.userID == Number(this.currentUser.id)) ficheDates.push({id: msg.id, userID: msg.userID, userStatut: msg.userStatut, invisibleAuClient: msg.invisibleAuClient, libelle: fiche.libelle, date: new Date(msg.date_envoie), msg: msg.message, senderId: msg.userID, non_lu: fiche_user.non_lu, envoyé: msgEnvoyé, respo_dossier_ID: fiche.respo_dossier_ID, usersID: usersList, listUsers: listUsers, listAccesUsers: listAccesUsers, module: fiche.module, sous_module: fiche.sous_module, type_objet: fiche.type_objet, etat: fiche.etat, impact: fiche.impact, numTelephoneClient: fiche.numTelephoneClient, archivé: fiche_user.archive, accesFicheRefuse: fiche_user.accesFicheRefuse});
              }
            }
          }
          if(this.currentUser.statut == 'Externe'){
            if(fiche.id == msg.ficheID && fiche.usersID.includes("/" + this.currentUser.id + "*")){ 
              let usersList = "/" + this.currentUser.id + "*";
              //On liste l'ensemble des users concernés par la fiche dans un tableau
              let listUsers = fiche.usersID.split(/[/*]/)
              for(let i=0; i<listUsers.length; i++){
                if(listUsers[i] == "") listUsers.splice(i, 1);
              }
              //On met à vide la liste de l'ensemble des users ayant un accès visuel à la fiche dans un tableau (pour ne pas avoir d'erreur lors de l'affichage)
              let listAccesUsers = []
              for(let fiche_user of this.dataLoadingService.myFichesUser){
                let msgEnvoyé = 0;
                if(msg.userID == Number(this.currentUser.id)) msgEnvoyé = 1;
                if(fiche_user.ficheID == fiche.id && fiche_user.userID == Number(this.currentUser.id) && msg.userStatut !== 'Assistance') ficheDates.push({id: msg.id, userID: msg.userID, userStatut: msg.userStatut, invisibleAuClient: msg.invisibleAuClient, libelle: fiche.libelle, date: new Date(msg.date_envoie), msg: msg.message, senderId: msg.userID, non_lu: fiche_user.non_lu, envoyé: msgEnvoyé, respo_dossier_ID: fiche.respo_dossier_ID, usersID: usersList, listUsers: listUsers, listAccesUsers: listAccesUsers, module: fiche.module, sous_module: fiche.sous_module, type_objet: fiche.type_objet, etat: fiche.etat, impact: fiche.impact, numTelephoneClient: fiche.numTelephoneClient, archivé: fiche_user.archive, accesFicheRefuse: fiche_user.accesFicheRefuse});
              }
            }
          }
        }
        ficheDates.sort((a, b) => b.date - a.date)
        
        if(ficheDates.length != 0){
          switch(sortBy){
            case 'Récents':
              if(ficheDates[0].archivé == 0)   this.messagesToDisplay.push({msgID: ficheDates[0].id, ficheID: fiche.id, userStatut: ficheDates[0].userStatut, invisibleAuClient: ficheDates[0].invisibleAuClient, numero_ticket: fiche.numero_ticket, userID: ficheDates[0].userID, libelle: ficheDates[0].libelle, date_envoie: ficheDates[0].date, message: ficheDates[0].msg, senderId: ficheDates[ficheDates.length -1].senderId, non_lu: ficheDates[0].non_lu, envoye: ficheDates[0].envoyé, respo_dossier_ID: ficheDates[0].respo_dossier_ID, usersID: ficheDates[0].usersID, listUsers: ficheDates[0].listUsers, listAccesUsers: ficheDates[0].listAccesUsers, module: ficheDates[0].module, sous_module: ficheDates[0].sous_module, type_objet: ficheDates[0].type_objet, ordre_priorite: fiche.ordre_priorite, etat: ficheDates[0].etat, impact: fiche.impact, numTelephoneClient: fiche.numTelephoneClient, archivé: ficheDates[0].archivé, accesFicheRefuse: ficheDates[0].accesFicheRefuse});
              break;

            case 'Non lu':
              if(ficheDates[0].non_lu == 1)   this.messagesToDisplay.push({msgID: ficheDates[0].id, ficheID: fiche.id, userStatut: ficheDates[0].userStatut, invisibleAuClient: ficheDates[0].invisibleAuClient,  numero_ticket: fiche.numero_ticket, userID: ficheDates[0].userID, libelle: ficheDates[0].libelle, date_envoie: ficheDates[0].date, message: ficheDates[0].msg, senderId: ficheDates[ficheDates.length -1].senderId, non_lu: ficheDates[0].non_lu, envoye: ficheDates[0].envoyé, respo_dossier_ID: ficheDates[0].respo_dossier_ID, usersID: ficheDates[0].usersID, listUsers: ficheDates[0].listUsers, listAccesUsers: ficheDates[0].listAccesUsers, module: ficheDates[0].module, sous_module: ficheDates[0].sous_module, type_objet: ficheDates[0].type_objet, ordre_priorite: fiche.ordre_priorite, etat: ficheDates[0].etat, impact: fiche.impact, numTelephoneClient: fiche.numTelephoneClient, archivé: ficheDates[0].archivé, accesFicheRefuse: ficheDates[0].accesFicheRefuse});
              break;

            case 'Envoyés':
              if(ficheDates[0].envoyé == 1)   this.messagesToDisplay.push({msgID: ficheDates[0].id, ficheID: fiche.id, userStatut: ficheDates[0].userStatut, invisibleAuClient: ficheDates[0].invisibleAuClient, numero_ticket: fiche.numero_ticket, userID: ficheDates[0].userID, libelle: ficheDates[0].libelle, date_envoie: ficheDates[0].date, message: ficheDates[0].msg, senderId: ficheDates[ficheDates.length -1].senderId, non_lu: ficheDates[0].non_lu, envoye: ficheDates[0].envoyé, respo_dossier_ID: ficheDates[0].respo_dossier_ID, usersID: ficheDates[0].usersID, listUsers: ficheDates[0].listUsers, listAccesUsers: ficheDates[0].listAccesUsers, module: ficheDates[0].module, sous_module: ficheDates[0].sous_module, type_objet: ficheDates[0].type_objet, ordre_priorite: fiche.ordre_priorite, etat: ficheDates[0].etat, impact: fiche.impact, numTelephoneClient: fiche.numTelephoneClient, archivé: ficheDates[0].archivé, accesFicheRefuse: ficheDates[0].accesFicheRefuse});
              break;

            case 'Archivés':
              if(ficheDates[0].archivé == 1)   this.messagesToDisplay.push({msgID: ficheDates[0].id, ficheID: fiche.id, userStatut: ficheDates[0].userStatut, invisibleAuClient: ficheDates[0].invisibleAuClient, numero_ticket: fiche.numero_ticket, userID: ficheDates[0].userID, libelle: ficheDates[0].libelle, date_envoie: ficheDates[0].date, message: ficheDates[0].msg, senderId: ficheDates[ficheDates.length -1].senderId, non_lu: ficheDates[0].non_lu, envoye: ficheDates[0].envoyé, respo_dossier_ID: ficheDates[0].respo_dossier_ID, usersID: ficheDates[0].usersID, listUsers: ficheDates[0].listUsers, listAccesUsers: ficheDates[0].listAccesUsers, module: ficheDates[0].module, sous_module: ficheDates[0].sous_module, type_objet: ficheDates[0].type_objet, ordre_priorite: fiche.ordre_priorite, etat: ficheDates[0].etat, impact: fiche.impact, numTelephoneClient: fiche.numTelephoneClient, archivé: ficheDates[0].archivé, accesFicheRefuse: ficheDates[0].accesFicheRefuse});
              break;

            default:
              break;
          }
        }
      }

      this.messagesToDisplay.sort((a, b) => b.date_envoie - a.date_envoie);
      console.log(this.messagesToDisplay, "message to display");
      console.log(this.MyFiches, "HERE")
    // });
    // //Détruire la souscription
    // this.listSubscription.push(variable2);
  }

  displayDate(msgDate: Date){
    //si la date est la même qu'aujourd'hui, on affichera seulement l'heure sur la liste de messgaes dans le template
    if(new Date().getTime() == msgDate.getTime())  return true;
    //sinon, on affichera la date
    else return false;
  }
  checkCurrentYear(msgDate: Date) {
    //si la date correspond à cette année
    if(new Date().toString().substring(10, 15) == msgDate.toString().substring(10, 15)) return true;
    else  return false;
  }

  handleNomInput(value: string) {
    this.nomRegroupement = value;
  }

  onCheckedFiltre(event: MatCheckboxChange, value: string): void {
    switch(value){
      case 'Libelle':
        if(event.checked == true) this.showLibelle = true;
        else {
          for(let i=0; i<this.selectedFilters.length; i++ ){
            if(this.selectedFilters[i].category == 'Libelle') this.selectedFilters.splice(i, 1);
          }
          this.selectedItemsLibelle = [];
          this.showLibelle = false; 
        }
        break;
      case 'Url':
        if(event.checked == true) this.showUrl = true;
        else {
          for(let i=0; i<this.selectedFilters.length; i++ ){
            if(this.selectedFilters[i].category == 'Url') this.selectedFilters.splice(i, 1);
          }
          this.selectedItemsUrl = [];
          this.showUrl = false; 
        }
        break;
      case 'Module':
        if(event.checked == true) this.showModule = true;
        else {
          for(let i=0; i<this.selectedFilters.length; i++ ){
            if(this.selectedFilters[i].category == 'Module') this.selectedFilters.splice(i, 1);
          }
          this.selectedItemsModule = [];
          this.showModule = false; 
        }
        break;
      case 'Ordre de priorite':
        if(event.checked == true) this.showOrdrePriorite = true;
        else {
          for(let i=0; i<this.selectedFilters.length; i++ ){
            if(this.selectedFilters[i].category == 'Ordre de priorite') this.selectedFilters.splice(i, 1);
          }
          this.selectedItemsOrdrePriorite = [];
          this.showOrdrePriorite = false; 
        }
        break;
      case 'Type dObjet':
        if(event.checked == true) this.showTypedObjet = true;
        else {
          for(let i=0; i<this.selectedFilters.length; i++ ){
            if(this.selectedFilters[i].category == 'Type dObjet') this.selectedFilters.splice(i, 1);
          }
          this.selectedItemsTypeObjet = [];
          this.showTypedObjet = false; 
        }
        break;
      case 'Etat':
          if(event.checked == true) this.showEtat = true;
          else {
            for(let i=0; i<this.selectedFilters.length; i++ ){
              if(this.selectedFilters[i].category == 'Etat') this.selectedFilters.splice(i, 1);
            }
            this.selectedItemsEtat = [];
            this.showEtat = false; 
          }
          break;
        case 'Date':
          if(event.checked == true) this.showDate = true;
          else {
            for(let i=0; i<this.selectedFilters.length; i++ ){
              if(this.selectedFilters[i].category == 'Date') this.selectedFilters.splice(i, 1);
            }
            this.selectedItemsDate = [];
            this.showDate = false; 
          }
          break;
        case 'Statut':
          if(event.checked == true) this.showStatut = true;
          else {
            for(let i=0; i<this.selectedFilters.length; i++ ){
              if(this.selectedFilters[i].category == 'Statut') this.selectedFilters.splice(i, 1);
            }
            this.selectedItemsStatut = [];
            this.showStatut = false; 
          }
          break;
      default:
        break;
    }
  }

  addFilter(category: string){
    switch(category){
      case 'Libelle':
        for(let i=0; i<this.selectedFilters.length; i++ ){
          if(this.selectedFilters[i].category == 'Libelle') {
            this.selectedFilters.splice(i, 1);
            this.countFiltres--;
          }
        }
        if(this.selectedItemsLibelle.length == 0) this.erreurMsgLibelle = true;
        else {
          this.erreurMsgLibelle = false;
          this.selectedFilters.push({category: 'Libelle', sous_category: this.selectedItemsLibelle});
          this.countFiltres++;       
        }
        
        break;
      case 'Url':
        for(let i=0; i<this.selectedFilters.length; i++ ){
          if(this.selectedFilters[i].category == 'Url'){ 
            this.selectedFilters.splice(i, 1);
            this.countFiltres--;
          }
        }
        if(this.selectedItemsUrl.length == 0) this.erreurMsgUrl = true;
        else {
          this.erreurMsgUrl = false;
          this.selectedFilters.push({category: 'Url', sous_category: this.selectedItemsUrl});
          this.countFiltres++;       
        }
        break;
      case 'Module':
        for(let i=0; i<this.selectedFilters.length; i++ ){
          if(this.selectedFilters[i].category == 'Module') {
            this.selectedFilters.splice(i, 1);
            this.countFiltres--;
          }
        }
        if(this.selectedItemsModule.length == 0) this.erreurMsgModule = true;
        else {
          this.erreurMsgModule = false;
          this.selectedFilters.push({category: 'Module', sous_category: this.selectedItemsModule});
          this.countFiltres++;       
        }
        break;
      case 'Ordre de priorite':
        for(let i=0; i<this.selectedFilters.length; i++ ){
          if(this.selectedFilters[i].category == 'Ordre de priorite'){ 
            this.selectedFilters.splice(i, 1);
            this.countFiltres--;
          }
        }
        if(this.selectedItemsOrdrePriorite.length == 0) this.erreurMsgOrdrePriorite = true;
        else {
          this.erreurMsgOrdrePriorite = false;
          this.selectedFilters.push({category: 'Ordre de priorite', sous_category: this.selectedItemsOrdrePriorite});
          this.countFiltres++;       
        }
        break;
      case 'Type dObjet':
        for(let i=0; i<this.selectedFilters.length; i++ ){
          if(this.selectedFilters[i].category == 'Type dObjet') this.selectedFilters.splice(i, 1);
        }
        if(this.selectedItemsTypeObjet.length == 0) {
          this.erreurMsgTypeObjet = true;
          this.countFiltres--;
        }
        else {
          this.erreurMsgTypeObjet = false;
          this.selectedFilters.push({category: 'Type dObjet', sous_category: this.selectedItemsTypeObjet});    
          this.countFiltres++;           
        }
        break;
      case 'Etat':
        for(let i=0; i<this.selectedFilters.length; i++ ){
          if(this.selectedFilters[i].category == 'Etat'){ 
            this.selectedFilters.splice(i, 1);
            this.countFiltres--;
          }
        }
        if(this.selectedItemsEtat.length == 0) this.erreurMsgEtat = true;
        else {
          this.erreurMsgEtat = false;
          this.selectedFilters.push({category: 'Etat', sous_category: this.selectedItemsEtat});
          this.countFiltres++;       
        }
        break;
      case 'Date':
        for(let i=0; i<this.selectedFilters.length; i++ ){
          if(this.selectedFilters[i].category == 'Date'){ 
            this.selectedFilters.splice(i, 1);
            this.countFiltres--;
          }
        }
        if(this.selectedItemsDate.length == 0) this.erreurMsgDate = true;
        else {
          this.erreurMsgDate = false;
          this.selectedFilters.push({category: 'Date', sous_category: this.selectedItemsDate});
          this.countFiltres++;       
        }
        break;
      case 'Statut':
          for(let i=0; i<this.selectedFilters.length; i++ ){
            if(this.selectedFilters[i].category == 'Statut'){ 
              this.selectedFilters.splice(i, 1);
              this.countFiltres--;
            }
          }
          if(this.selectedItemsStatut.length == 0) this.erreurMsgStatut = true;
          else {
            this.erreurMsgStatut = false;
            this.selectedFilters.push({category: 'Statut', sous_category: this.selectedItemsStatut});
            this.countFiltres++;       
          }
          break;
    }
    console.log(this.selectedFilters);
  }

  Filtrer(filters: any[]){
    this.finaleSelectedFilters = [];
    this.finaleSelectedFilters = filters;
    if(this.finaleSelectedFilters.length == 0) this.erreurMsgFiltre = true;
    else{
      //on filtre les messages
      this.msgFilteredDisplay = [];
      console.log(this.finaleSelectedFilters, "selected filters")
      this.erreurMsgFiltre = false;
      this.filtre = "filtreImbrique";
      //pour récupérer le dernier message
      let ficheDates;
      let nbImbrication = 0;
      // const variable2 = this.messagerieTicketsSerivice.getFichesFromServer().subscribe((response) => {
        //On récupère les dates d'ouverture de chaque ticket en amont dans une variable
        let triMsg;
        let tableauDateOuverture = [];
        for(let f of this.dataLoadingService.myFiches){
          triMsg = [];
          for(let m of this.MyMessagesOfMyFiches){
            if(f.id == m.ficheID){
              triMsg.push({ficheID: f.id, date: new Date(m.date_envoie)})
            }
          }
          triMsg.sort((a, b) => a.date - b.date);
          tableauDateOuverture.push(triMsg[0]);
        }
        console.log(tableauDateOuverture, "testing")
        //On remet à jour les sous-catégories de la catégorie Date
        let choixFiltre;
        for(let value of this.finaleSelectedFilters){
          if(value.category == "Date"){
            choixFiltre = value.sous_category;
            value.sous_category = [];
            for(let i=0; i<choixFiltre.length; i++){

              //Par Année
              if(choixFiltre[i].item_text == "Année"){
                let years = [];
                let exist;
                console.log(tableauDateOuverture, "test")
                for(let ligne of tableauDateOuverture){
                  exist = false;
                  for(let year of years){
                    let date = new Date(ligne.date)
                    if(year.year == date.getFullYear()) exist = true;
                  }
                  if(exist == false) years.push({year: ligne.date.getFullYear(), date: ligne.date});
                }
                years.sort((a, b) => b.year - a.year);
                for(let item of years){
                  value.sous_category.push({item_text: item.year});
                }
              }

              //Par Mois
              if(choixFiltre[i].item_text == "Mois"){
                let years = [];
                let exist;
                for(let ligne of tableauDateOuverture){
                  exist = false;
                  for(let year of years){
                    let date1 = new Date(year.date)
                    let date2 = new Date(ligne.date)
                    if(year.date == date2.getFullYear()) exist = true;
                  }
                  if(exist == false) years.push({date: ligne.date.getFullYear()});
                }
                years.sort((a, b) => b.date - a.date);
                let mois = [];
                let existMois;
                for(let ligne of tableauDateOuverture){
                  existMois = false;
                  for(let m of mois){
                    if(m.month == ligne.date.getMonth() + 1 && m.year == ligne.date.getFullYear()) existMois = true;
                  }
                  if(existMois == false) mois.push({month: ligne.date.getMonth() + 1, year: ligne.date.getFullYear()});
                }
                mois.sort((a, b) => a.month - b.month);
                mois.sort((a, b) => b.year - a.year);
                for(let y of years){
                  for(let m of mois){
                    if(m.year == y.date){
                      value.sous_category.push({item_text: m.month + "/" + m.year});
                    }
                  }
                }
              }

              //Par Jour
              if(choixFiltre[i].item_text == "Jour"){
                let years = [];
                let exist;
                for(let ligne of tableauDateOuverture){
                  exist = false;
                  for(let year of years){
                    if(year.date == ligne.date.getFullYear()) exist = true;
                  }
                  if(exist == false) years.push({date: ligne.date.getFullYear()});
                }
                years.sort((a, b) => b.date - a.date);

                let mois = [];
                let existMois;
                for(let ligne of tableauDateOuverture){
                  existMois = false;
                  for(let m of mois){
                    if(m.month == ligne.date.getMonth() + 1 && m.year == ligne.date.getFullYear()) existMois = true;
                  }
                  if(existMois == false) mois.push({month: ligne.date.getMonth() + 1, year: ligne.date.getFullYear()});
                }
                mois.sort((a, b) => a.month - b.month);
                mois.sort((a, b) => b.year - a.year);

                let jour = [];
                let existJour;
                for(let ligne of tableauDateOuverture){
                  existJour = false;
                  for(let j of jour){
                    if(j.day == ligne.date.getDate() && j.month == ligne.date.getMonth() + 1 && j.year == ligne.date.getFullYear()) existJour = true;
                  }
                  if(existJour == false) jour.push({day: ligne.date.getDate(), month: ligne.date.getMonth() + 1, year: ligne.date.getFullYear()});
                }
                jour.sort((a, b) => a.day - b.day);
                jour.sort((a, b) => a.month - b.month);
                jour.sort((a, b) => b.year - a.year);

                for(let y of years){
                  for(let m of mois){
                    for(let j of jour){
                      if(j.year == y.date && j.month == m.month && j.year == m.year){
                        value.sous_category.push({item_text:  j.day + "/" + j.month + "/" + j.year});
                      }
                    }
                  }
                }
              }

              //Par Heure
              if(choixFiltre[i].item_text == "Heure"){
                let years = [];
                let exist;
                for(let ligne of tableauDateOuverture){
                  exist = false;
                  for(let year of years){
                    if(year.date == ligne.date.getFullYear()) exist = true;
                  }
                  if(exist == false) years.push({date: ligne.date.getFullYear()});
                }
                years.sort((a, b) => b.date - a.date);

                let mois = [];
                let existMois;
                for(let ligne of tableauDateOuverture){
                  existMois = false;
                  for(let m of mois){
                    if(m.month == ligne.date.getMonth() + 1 && m.year == ligne.date.getFullYear()) existMois = true;
                  }
                  if(existMois == false) mois.push({month: ligne.date.getMonth() + 1, year: ligne.date.getFullYear()});
                }
                mois.sort((a, b) => a.month - b.month);
                mois.sort((a, b) => b.year - a.year);

                let jour = [];
                let existJour;
                for(let ligne of tableauDateOuverture){
                  existJour = false;
                  for(let j of jour){
                    if(j.day == ligne.date.getDate() && j.month == ligne.date.getMonth() + 1 && j.year == ligne.date.getFullYear()) existJour = true;
                  }
                  if(existJour == false) jour.push({day: ligne.date.getDate(), month: ligne.date.getMonth() + 1, year: ligne.date.getFullYear()});
                }
                jour.sort((a, b) => a.day - b.day);
                jour.sort((a, b) => a.month - b.month);
                jour.sort((a, b) => b.year - a.year);

                let heure = [];
                let existHeure;
                for(let ligne of tableauDateOuverture){
                  existHeure = false;
                  for(let h of heure){
                    if(h.time == ligne.date.getHours() && h.day == ligne.date.getDate() && h.month == ligne.date.getMonth() + 1 && h.year == ligne.date.getFullYear()) existHeure = true;
                  }
                  if(existHeure == false) heure.push({hour: ligne.date.getHours(), day: ligne.date.getDate(), month: ligne.date.getMonth() + 1, year: ligne.date.getFullYear()});
                }
                heure.sort((a, b) => a.hour - b.hour);
                heure.sort((a, b) => a.day - b.day);
                heure.sort((a, b) => a.month - b.month);
                heure.sort((a, b) => b.year - a.year);
                console.log(tableauDateOuverture, "Tab date Ouverture")
                console.log(heure, "Heure")

                //let tabMois = ["Janvier", "Févier", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre";]
                for(let y of years){
                  for(let m of mois){
                    for(let j of jour){
                      if(j.year == y.date && j.month == m.month && j.year == m.year){
                        for(let h of heure){
                          if(h.day == j.day && h.month == j.month && h.year == j.year){
                            value.sous_category.push({item_text: j.day + "/" + j.month + "/" + j.year + " " + h.hour + ":00"});
                          }
                        }
                      }
                    }
                  }
                }
              }

            }
          }
        }

        //On commence le filtrage
        let k;
        for(let value of this.finaleSelectedFilters){
          for(let i=0; i<value.sous_category.length; i++){
            for(let fiche of this.dataLoadingService.myFiches){
              ficheDates = [];
              k = 0;
              for(let msg of this.MyMessagesOfMyFiches){
                if(fiche.id == msg.ficheID){
                  
                  let usersList = "";
                  let listUsers;
                  let listAccesUsers
                  if(this.connexionService.userStatut == 'Interne'){
                    if(fiche.usersID.includes("/" + this.currentUser.id.toString() + "*") || fiche.accesVisuelPourUsers	.includes("/" + this.currentUser.id.toString() + "*")){ 
                      usersList = fiche.usersID;
                      for(let user of this.Users){
                        if(user.statut == 'Interne' && usersList.includes("/" + user.id + "*")) usersList = usersList.replace("/" + user.id + "*", '');
                      }
                      //On liste l'ensemble des users concernés par la fiche dans un tableau
                      listUsers = fiche.usersID.split(/[/*]/);
                      for(let i=0; i<listUsers.length; i++){
                        if(listUsers[i] == "") listUsers.splice(i, 1);
                      }
                      //On liste l'ensemble des users ayant un accès visuel à la fiche dans un tableau
                      if(fiche.accesVisuelPourUsers !== null) {
                        listAccesUsers = fiche.accesVisuelPourUsers.split(/[/*]/);
                        for(let i=0; i<listAccesUsers.length; i++){
                          if(listAccesUsers[i] == "") listAccesUsers.splice(i, 1);
                        }
                      }
                      else listAccesUsers = []
                    }
                  }
                  if(this.currentUser.statut == 'Externe'){
                    if(fiche.usersID.includes("/" + this.connexionService.userID.toString() + "*")){ 
                      usersList = "/" + this.connexionService.userID.toString() + "*";
                      //On liste l'ensemble des users concernés par la fiche dans un tableau
                      listUsers = fiche.usersID.split(/[/*]/);
                      for(let i=0; i<listUsers.length; i++){
                        if(listUsers[i] == "") listUsers.splice(i, 1);
                      }
                      //On met à vide la liste de l'ensemble des users ayant un accès visuel à la fiche dans un tableau (pour ne pas avoir d'erreur lors de l'affichage)
                      listAccesUsers = []
                    }
                  }

                  switch(value.category){
                    case 'Libelle':
                      if(fiche.libelle == value.sous_category[i].item_text) {
                        for(let fiche_user of this.dataLoadingService.myFichesUser){
                          let msgEnvoyé = 0;
                          if(msg.userID == Number(this.currentUser.id)) msgEnvoyé = 1;
                          if(fiche_user.ficheID == fiche.id && fiche_user.userID == Number(this.currentUser.id)) ficheDates.push({id: msg.id, date: new Date(msg.date_envoie), msg: msg.message, non_lu: fiche_user.non_lu, envoyé: msgEnvoyé, respo_dossier_ID: fiche.respo_dossier_ID, usersID: usersList, listUsers: listUsers, listAccesUsers: listAccesUsers, module: fiche.module, type_objet: fiche.type_objet, etat: fiche.etat, archivé: fiche_user.archive});
                        }
                      }
                      break;
                    case 'Url':
                      if(fiche.url == value.sous_category[i].item_text) {
                        for(let fiche_user of this.dataLoadingService.myFichesUser){
                          let msgEnvoyé = 0;
                          if(msg.userID == Number(this.currentUser.id)) msgEnvoyé = 1;
                          if(fiche_user.ficheID == fiche.id && fiche_user.userID == Number(this.currentUser.id)) ficheDates.push({id: msg.id, date: new Date(msg.date_envoie), msg: msg.message, non_lu: fiche_user.non_lu, envoyé: msgEnvoyé, respo_dossier_ID: fiche.respo_dossier_ID, usersID: usersList, listUsers: listUsers, listAccesUsers: listAccesUsers, module: fiche.module, type_objet: fiche.type_objet, etat: fiche.etat, archivé: fiche_user.archive});
                        }
                      }
                      break;
                    case 'Module':
                      if(fiche.module == value.sous_category[i].item_text) {
                        for(let fiche_user of this.dataLoadingService.myFichesUser){
                          let msgEnvoyé = 0;
                          if(msg.userID == Number(this.currentUser.id)) msgEnvoyé = 1;
                          if(fiche_user.ficheID == fiche.id && fiche_user.userID == Number(this.currentUser.id)) ficheDates.push({id: msg.id, date: new Date(msg.date_envoie), msg: msg.message, non_lu: fiche_user.non_lu, envoyé: msgEnvoyé, respo_dossier_ID: fiche.respo_dossier_ID, usersID: usersList, listUsers: listUsers, listAccesUsers: listAccesUsers, module: fiche.module, type_objet: fiche.type_objet, etat: fiche.etat, archivé: fiche_user.archive});
                        }
                      }
                      break;
                    case 'Ordre de priorite':
                      if(fiche.ordre_priorite == value.sous_category[i].item_text) {
                        for(let fiche_user of this.dataLoadingService.myFichesUser){
                          let msgEnvoyé = 0;
                          if(msg.userID == Number(this.currentUser.id)) msgEnvoyé = 1;
                          if(fiche_user.ficheID == fiche.id && fiche_user.userID == Number(this.currentUser.id)) ficheDates.push({id: msg.id, date: new Date(msg.date_envoie), msg: msg.message, non_lu: fiche_user.non_lu, envoyé: msgEnvoyé, respo_dossier_ID: fiche.respo_dossier_ID, usersID: usersList, listUsers: listUsers, listAccesUsers: listAccesUsers, module: fiche.module, type_objet: fiche.type_objet, etat: fiche.etat, archivé: fiche_user.archive});
                        }
                      }
                      break;
                    case 'Type dObjet':
                      if(fiche.type_objet == value.sous_category[i].item_text) {
                        for(let fiche_user of this.dataLoadingService.myFichesUser){
                          let msgEnvoyé = 0;
                          if(msg.userID == Number(this.currentUser.id)) msgEnvoyé = 1;
                          if(fiche_user.ficheID == fiche.id && fiche_user.userID == Number(this.currentUser.id)) ficheDates.push({id: msg.id, date: new Date(msg.date_envoie), msg: msg.message, non_lu: fiche_user.non_lu, envoyé: msgEnvoyé, respo_dossier_ID: fiche.respo_dossier_ID, usersID: usersList, listUsers: listUsers, listAccesUsers: listAccesUsers, module: fiche.module, type_objet: fiche.type_objet, etat: fiche.etat, archivé: fiche_user.archive});
                        }
                      }
                      break;
                    case 'Etat':
                      if(fiche.etat == value.sous_category[i].item_text) {
                        for(let fiche_user of this.dataLoadingService.myFichesUser){
                          let msgEnvoyé = 0;
                          if(msg.userID == Number(this.currentUser.id)) msgEnvoyé = 1;
                          if(fiche_user.ficheID == fiche.id && fiche_user.userID == Number(this.currentUser.id)) ficheDates.push({id: msg.id, date: new Date(msg.date_envoie), msg: msg.message, non_lu: fiche_user.non_lu, envoyé: msgEnvoyé, respo_dossier_ID: fiche.respo_dossier_ID, usersID: usersList, listUsers: listUsers, listAccesUsers: listAccesUsers, module: fiche.module, type_objet: fiche.type_objet, etat: fiche.etat, archivé: fiche_user.archive});
                        }
                      }
                      break;
                    case 'Date':
                      let ligne = "";
                      for(let row of tableauDateOuverture){

                        if(choixFiltre[0].item_text == "Année"){
                          if(fiche.id == row.ficheID && row.date.getFullYear() == value.sous_category[i].item_text){
                            for(let fiche_user of this.dataLoadingService.myFichesUser){
                              let msgEnvoyé = 0;
                              if(msg.userID == Number(this.currentUser.id)) msgEnvoyé = 1;
                              if(fiche_user.ficheID == fiche.id && fiche_user.userID == Number(this.currentUser.id)) ficheDates.push({id: msg.id, date: new Date(msg.date_envoie), msg: msg.message, non_lu: fiche_user.non_lu, envoyé: msgEnvoyé, respo_dossier_ID: fiche.respo_dossier_ID, usersID: usersList, listUsers: listUsers, listAccesUsers: listAccesUsers, module: fiche.module, type_objet: fiche.type_objet, etat: fiche.etat, archivé: fiche_user.archive});
                            }                            
                            k++;
                          }
                        }

                        if(choixFiltre[0].item_text == "Mois"){
                          ligne = (row.date.getMonth() + 1) + "/" + row.date.getFullYear();
                          if(fiche.id == row.ficheID && ligne == value.sous_category[i].item_text){
                            for(let fiche_user of this.dataLoadingService.myFichesUser){
                              let msgEnvoyé = 0;
                              if(msg.userID == Number(this.currentUser.id)) msgEnvoyé = 1;
                              if(fiche_user.ficheID == fiche.id && fiche_user.userID == Number(this.currentUser.id)) ficheDates.push({id: msg.id, date: new Date(msg.date_envoie), msg: msg.message, non_lu: fiche_user.non_lu, envoyé: msgEnvoyé, respo_dossier_ID: fiche.respo_dossier_ID, usersID: usersList, listUsers: listUsers, listAccesUsers: listAccesUsers, module: fiche.module, type_objet: fiche.type_objet, etat: fiche.etat, archivé: fiche_user.archive});
                            }                            
                            k++;
                          }
                        }

                        if(choixFiltre[0].item_text == "Jour"){
                          ligne = row.date.getDate() + "/" + (row.date.getMonth() + 1) + "/" + row.date.getFullYear();
                          if(fiche.id == row.ficheID && ligne == value.sous_category[i].item_text){
                            for(let fiche_user of this.dataLoadingService.myFichesUser){
                              let msgEnvoyé = 0;
                              if(msg.userID == Number(this.currentUser.id)) msgEnvoyé = 1;
                              if(fiche_user.ficheID == fiche.id && fiche_user.userID == Number(this.currentUser.id)) ficheDates.push({id: msg.id, date: new Date(msg.date_envoie), msg: msg.message, non_lu: fiche_user.non_lu, envoyé: msgEnvoyé, respo_dossier_ID: fiche.respo_dossier_ID, usersID: usersList, listUsers: listUsers, listAccesUsers: listAccesUsers, module: fiche.module, type_objet: fiche.type_objet, etat: fiche.etat, archivé: fiche_user.archive});
                            }                            
                            k++;
                          }
                        }

                        if(choixFiltre[0].item_text == "Heure"){
                          ligne = row.date.getDate() + "/" + (row.date.getMonth() + 1) + "/" + row.date.getFullYear()  + " " + row.date.getHours() + ":00";
                          if(fiche.id == row.ficheID && ligne == value.sous_category[i].item_text){
                            for(let fiche_user of this.dataLoadingService.myFichesUser){
                              let msgEnvoyé = 0;
                              if(msg.userID == Number(this.currentUser.id)) msgEnvoyé = 1;
                              if(fiche_user.ficheID == fiche.id && fiche_user.userID == Number(this.currentUser.id)) ficheDates.push({id: msg.id, date: new Date(msg.date_envoie), msg: msg.message, non_lu: fiche_user.non_lu, envoyé: msgEnvoyé, respo_dossier_ID: fiche.respo_dossier_ID, usersID: usersList, listUsers: listUsers, listAccesUsers: listAccesUsers, module: fiche.module, type_objet: fiche.type_objet, etat: fiche.etat, archivé: fiche_user.archive});
                            }                            
                            k++;
                          }
                        }
                      }
                      break;
                    case 'Statut':
                      for(let fiche_user of this.dataLoadingService.myFichesUser){
                        let msgEnvoyé = 0;
                        if(msg.userID == Number(this.currentUser.id)) msgEnvoyé = 1;
                        if(fiche_user.ficheID == fiche.id && fiche_user.userID == Number(this.currentUser.id)){
                          
                          switch(value.sous_category[i].item_text){
                            case "Non lus":
                              if(fiche_user.non_lu == 1)  ficheDates.push({id: msg.id, date: new Date(msg.date_envoie), msg: msg.message, non_lu: fiche_user.non_lu, envoyé: msgEnvoyé, respo_dossier_ID: fiche.respo_dossier_ID, usersID: usersList, listUsers: listUsers, listAccesUsers: listAccesUsers, module: fiche.module, type_objet: fiche.type_objet, etat: fiche.etat, archivé: fiche_user.archive});
                              break;
                            case "Lus":
                              if(fiche_user.non_lu == 0)  ficheDates.push({id: msg.id, date: new Date(msg.date_envoie), msg: msg.message, non_lu: fiche_user.non_lu, envoyé: msgEnvoyé, respo_dossier_ID: fiche.respo_dossier_ID, usersID: usersList, listUsers: listUsers, listAccesUsers: listAccesUsers, module: fiche.module, type_objet: fiche.type_objet, etat: fiche.etat, archivé: fiche_user.archive});
                              break;
                            case "Envoyés":
                              if(msgEnvoyé == 1)  ficheDates.push({id: msg.id, date: new Date(msg.date_envoie), msg: msg.message, non_lu: fiche_user.non_lu, envoyé: msgEnvoyé, respo_dossier_ID: fiche.respo_dossier_ID, usersID: usersList, listUsers: listUsers, listAccesUsers: listAccesUsers, module: fiche.module, type_objet: fiche.type_objet, etat: fiche.etat, archivé: fiche_user.archive});
                              break;
                            case "Archivés":
                              if(fiche_user.archive == 1)  ficheDates.push({id: msg.id, date: new Date(msg.date_envoie), msg: msg.message, non_lu: fiche_user.non_lu, envoyé: msgEnvoyé, respo_dossier_ID: fiche.respo_dossier_ID, usersID: usersList, listUsers: listUsers, listAccesUsers: listAccesUsers, module: fiche.module, type_objet: fiche.type_objet, etat: fiche.etat, archivé: fiche_user.archive});
                              break;
                          }
                        }
                      }
                      break;
                  }
                }
              }
              if(ficheDates.length != 0){
                ficheDates.sort((a, b) => b.date - a.date);
                if(nbImbrication == 0)  this.msgFilteredDisplay.push({category: [value.category], sous_category: [value.sous_category[i].item_text], msgID: ficheDates[0].id, ficheID: fiche.id, numero_ticket: fiche.numero_ticket, libelle: fiche.libelle, date_envoie: ficheDates[0].date, message: ficheDates[0].msg, non_lu: ficheDates[0].non_lu, envoye: ficheDates[0].envoyé, respo_dossier_ID: ficheDates[0].respo_dossier_ID, usersID: ficheDates[0].usersID, listUsers: ficheDates[0].listUsers, listAccesUsers: ficheDates[0].listAccesUsers, module: ficheDates[0].module, type_objet: ficheDates[0].type_objet, etat: ficheDates[0].etat, archivé: ficheDates[0].archivé});
                else{
                  for(let item of this.msgFilteredDisplay){
                    if(item.ficheID == fiche.id)  {
                      item.category.push(value.category);
                      item.sous_category.push(value.sous_category[i].item_text);
                    }
                  }
                }
              }
            }
          }
          nbImbrication++;
        }
        let indexArray = [];
        for(let i=0; i<this.msgFilteredDisplay.length; i++){
          if(this.msgFilteredDisplay[i].category.length != nbImbrication){
            indexArray.push(i);
          }   
        }
        for(let i of indexArray)  this.msgFilteredDisplay.splice(this.msgFilteredDisplay.indexOf(this.msgFilteredDisplay[i]), 1);
        console.log(this.msgFilteredDisplay, "Filtered")

        this.repertoiresFiltres.push(this.finaleSelectedFilters)
        this.repertoiresMsg.push(this.msgFilteredDisplay)
        for(let sub of this.repertoiresFiltres[0][0].sous_category) console.log(sub.item_text, "sous_category")
        console.log(this.repertoiresFiltres, "Rep Filtres")
        console.log(this.repertoiresMsg, "Rep Messages")
      // });
      // //Détruire la souscription
      // this.listSubscription.push(variable2)

      this.showMenuGauche = false;
    }
  }

  DeleteFiltre(id: number){
    this.messagerieTicketsSerivice.dataToDelete = id;
    const variable  = this.messagerieTicketsSerivice.postDeleteFiltretInServer().subscribe(
      () => {
      console.log('Filtre supprimé !');
      },
      (error) => {
      console.log('Erreur ! : ' + error);
      }
    );
    //Destruction de la souscription
    this.listSubscription.push(variable);
    for (let i = 0; i < this.filtresFavoris.length; i++) {
      if (this.filtresFavoris[i].id === id)  this.filtresFavoris.splice(i, 1)
    }
  }

  AjouterFavoris(){
    if(this.nomRegroupement != "" && this.selectedFilters.length != 0){
      this.erreurMsgAjouter = false;
      this.erreurMsgFiltre = false;
      let filtre = "";
      for(let item of this.selectedFilters){
        filtre = filtre + item.category + "_" ;
        for(let subItem of item.sous_category){
          filtre = filtre + "*" + subItem.item_text;
        }
      }
      console.log(this.selectedFilters, "Filtre à ajouter")
      //Ajout Filtre dans la BDD
      this.messagerieTicketsSerivice.dataToAdd = [];
      this.messagerieTicketsSerivice.dataToAdd.push({id: 0, userID: Number(this.currentUser.id), titre: this.nomRegroupement, filtre: filtre});
      const variable  = this.messagerieTicketsSerivice.postAddFiltreToServer().subscribe(
        () => {
          console.log('Filtre sauvegardé !')
        },
        (error) => {
        console.log('Erreur ! : ' + error);
        }
      );
      //Destruction de la souscription
      this.listSubscription.push(variable);

      this.dataLoadingService.loadDataMyFiltres()
    }
    else{
      if(this.nomRegroupement == "") this.erreurMsgAjouter = true;
      if(this.selectedFilters.length == 0) this.erreurMsgFiltre = true;
    }
  }

  checkMsgInCategory(niveau: number, sub_category1: string, sub_category2: string, sub_category3: string, sub_category4: string, sub_category5: string, sub_category6: string){
    for(let repertoireMsg of this.repertoiresMsg){
      for(let fiche of repertoireMsg){
        for (let user of this.Users){
          switch(niveau){
            case 1:
              if(fiche.usersID.includes('/' + user.id + '*') && fiche.sous_category.includes(sub_category1)) return true;
              break;
            case 2: 
              if(fiche.usersID.includes('/' + user.id + '*') && fiche.sous_category.includes(sub_category1) && fiche.sous_category.includes(sub_category2)) return true;
              break;
            case 3: 
              if(fiche.usersID.includes('/' + user.id + '*') && fiche.sous_category.includes(sub_category1) && fiche.sous_category.includes(sub_category2) && fiche.sous_category.includes(sub_category3)) return true;
              break;
            case 4: 
              if(fiche.usersID.includes('/' + user.id + '*') && fiche.sous_category.includes(sub_category1) && fiche.sous_category.includes(sub_category2) && fiche.sous_category.includes(sub_category3) && fiche.sous_category.includes(sub_category4)) return true;
              break;
            case 5: 
              if(fiche.usersID.includes('/' + user.id + '*') && fiche.sous_category.includes(sub_category1) && fiche.sous_category.includes(sub_category2) && fiche.sous_category.includes(sub_category3) && fiche.sous_category.includes(sub_category4) && fiche.sous_category.includes(sub_category5)) return true;
              break;
            case 6: 
              if(fiche.usersID.includes('/' + user.id + '*') && fiche.sous_category.includes(sub_category1) && fiche.sous_category.includes(sub_category2) && fiche.sous_category.includes(sub_category3) && fiche.sous_category.includes(sub_category4) && fiche.sous_category.includes(sub_category5) && fiche.sous_category.includes(sub_category6)) return true;
              break;
            default:
              break;
          }
        }
      }
    }
    return false;
  }

  addSubCategory(value: string) {
    if(!(this.subCategories.includes(value))) {
      this.messagerieTicketsSerivice.addSubCategory(value);
      return true
    }
    else return false;
  }

  onReset() {
    this.nomRegroupement = "";
    this.selectedFilters = [];
    this.repertoiresMsg = [];
    this.repertoiresFiltres = [];
    this.countFiltres = 0;
    this.filtre = "filtreSimple";
    this.handleClick('Récents');
  }
  

  /** Mise en relation avec Menu de droite (Conversation) **/
  handleClickOption(selectedElt: string, value: string) {
    let currentfiche;
    for(let fiche of this.dataLoadingService.myFiches){
      if(fiche.id = this.conversationData[0].numeroDemande) currentfiche = fiche; 
    }
      switch (selectedElt) {
        case 'Type de demande':
          this.messagerieTicketsSerivice.dataFicheToAdd = [];
          this.messagerieTicketsSerivice.dataFicheToAdd.push({id: currentfiche.id, numero_ticket: currentfiche.numero_ticket, libelle: "", date_ouverture: currentfiche.date_ouverture, respo_dossier_ID: 0, usersID: "", accesVisuelPourUsers: "", url: "", module: currentfiche.module, sous_module: currentfiche.sous_module, ordre_priorite: currentfiche.ordre_priorite, type_objet: value, etat: currentfiche.etat, impact: currentfiche.impact, numTelephoneClient: currentfiche.numTelephoneClient});
          const variable  = this.messagerieTicketsSerivice.postUpdateFicheToServer().subscribe(
            (res) => {
            console.log('Fiche mise à jour !');
            },
            (error) => {
            console.log('Erreur ! : ' + error);
            }
          );
          //Destruction de la souscription
          this.listSubscription.push(variable); 
          this.conversationData[0].typeDemande = value;
          for(let fiche of this.dataLoadingService.myFiches){
            if(fiche.id = this.conversationData[0].numeroDemande)  fiche.type_objet = value; 
          }
          for(let fiche of this.messagesToDisplay){
            if(fiche.ficheID == this.conversationData[0].numeroDemande) fiche.type_objet = value;
          }
          break;
        case 'Module':
          this.messagerieTicketsSerivice.dataFicheToAdd = [];
          this.messagerieTicketsSerivice.dataFicheToAdd.push({id: currentfiche.id, numero_ticket: currentfiche.numero_ticket, date_ouverture: currentfiche.date_ouverture, libelle: "", respo_dossier_ID: 0, usersID: "", accesVisuelPourUsers: "", url: "", module: value, sous_module: currentfiche.sous_module, ordre_priorite: currentfiche.ordre_priorite, type_objet: currentfiche.type_objet, etat: currentfiche.etat, impact: currentfiche.impact, numTelephoneClient: currentfiche.numTelephoneClient});
          console.log(this.messagerieTicketsSerivice.dataFicheToAdd, "Module récuperé")
          const variable2  = this.messagerieTicketsSerivice.postUpdateFicheToServer().subscribe(
            (res) => {
            console.log('Fiche mise à jour !');
            },
            (error) => {
            console.log('Erreur ! : ' + error);
            }
          );
          //Destruction de la souscription
          this.listSubscription.push(variable2); 
          this.conversationData[0].module = value;
          for(let fiche of this.dataLoadingService.myFiches){
            if(fiche.id = this.conversationData[0].numeroDemande)  fiche.module = value; 
          }
          for(let fiche of this.messagesToDisplay){
            if(fiche.ficheID == this.conversationData[0].numeroDemande) fiche.module = value;
          }
          let coherentSousModule = false;
          for(let item of this.Modules){
            if(item.module == this.selectedModule && item.sous_module == this.selectedSousModule) coherentSousModule = true;
          }
          if(coherentSousModule == false){
            this.selectedSousModule = "";
            this.messagerieTicketsSerivice.dataFicheToAdd = [];
            this.messagerieTicketsSerivice.dataFicheToAdd.push({id: currentfiche.id, numero_ticket: currentfiche.numero_ticket, date_ouverture: currentfiche.date_ouverture, libelle: "", respo_dossier_ID: 0, usersID: "", accesVisuelPourUsers: "", url: "", module: value, sous_module: "", ordre_priorite: currentfiche.ordre_priorite, type_objet: currentfiche.type_objet, etat: currentfiche.etat, impact: currentfiche.impact, numTelephoneClient: currentfiche.numTelephoneClient});
            const variable6  = this.messagerieTicketsSerivice.postUpdateFicheToServer().subscribe(
              (res) => {
              console.log('Fiche mise à jour !');
              },
              (error) => {
              console.log('Erreur ! : ' + error);
              }
            );
            //Destruction de la souscription
            this.listSubscription.push(variable6);
            this.conversationData[0].sous_module = "";
            for(let fiche of this.dataLoadingService.myFiches){
              if(fiche.id = this.conversationData[0].numeroDemande)  fiche.sous_module = value; 
            }
            for(let fiche of this.messagesToDisplay){
              if(fiche.ficheID == this.conversationData[0].numeroDemande) fiche.sous_module = "";
            }
          } 
          break;
        case 'Sous_Module':
          // Q & A
          this.questions=[];
          this.faq.sous_module=value;
          this.questions=this.faq.faqSample;
          // const variable7 = this.faq.getQuestionBySousModule().subscribe((response) => {
            if(this.currentUser.statut == "Interne") this.questions = this.Faqs;
            else {
              this.questions=[];
              var j=0;
              for(let i=0;i<this.Faqs.length;i++)
              {
                console.log(this.Faqs.length);
                if(this.Faqs[i].is_prived==0)
                {
                  this.questions[j]=this.Faqs[i];
                  j++;
                }
              }
            }
            console.log(this.Faqs);
            console.log(this.questions, "Q");
          // });
          // this.listSubscription.push(variable7);
          this.faq.clear();

          // Choix du sous_module
          this.messagerieTicketsSerivice.dataFicheToAdd = [];
          this.messagerieTicketsSerivice.dataFicheToAdd.push({id: currentfiche.id, numero_ticket: currentfiche.numero_ticket, date_ouverture: currentfiche.date_ouverture, libelle: "", respo_dossier_ID: 0, usersID: "", accesVisuelPourUsers: "", url: "", module: currentfiche.module, sous_module: value, ordre_priorite: currentfiche.ordre_priorite, type_objet: currentfiche.type_objet, etat: currentfiche.etat, impact: currentfiche.impact, numTelephoneClient: currentfiche.numTelephoneClient});
          const variable6  = this.messagerieTicketsSerivice.postUpdateFicheToServer().subscribe(
            (res) => {
            console.log('Fiche mise à jour !');
            },
            (error) => {
            console.log('Erreur ! : ' + error);
            }
          );
          //Destruction de la souscription
          this.listSubscription.push(variable6); 
          this.conversationData[0].sous_module = value;
          for(let fiche of this.dataLoadingService.myFiches){
            if(fiche.id = this.conversationData[0].numeroDemande)  fiche.sous_module = value; 
          }
          for(let fiche of this.messagesToDisplay){
            if(fiche.ficheID == this.conversationData[0].numeroDemande) fiche.sous_module = value;
          }
          break;
        case 'Priorité':
          this.messagerieTicketsSerivice.dataFicheToAdd = [];
          this.messagerieTicketsSerivice.dataFicheToAdd.push({id: currentfiche.id, numero_ticket: currentfiche.numero_ticket, date_ouverture: currentfiche.date_ouverture, libelle: "", respo_dossier_ID: 0, usersID: "", accesVisuelPourUsers: "", url: "", module: currentfiche.module, sous_module: currentfiche.sous_module, ordre_priorite: value, type_objet: currentfiche.type_objet, etat: currentfiche.etat, impact: currentfiche.impact, numTelephoneClient: currentfiche.numTelephoneClient});
          const variable4  = this.messagerieTicketsSerivice.postUpdateFicheToServer().subscribe(
            (res) => {
            console.log('Fiche mise à jour !');
            },
            (error) => {
            console.log('Erreur ! : ' + error);
            }
          );
          //Destruction de la souscription
          this.listSubscription.push(variable4); 
          this.conversationData[0].ordre_priorite = value;
          for(let fiche of this.dataLoadingService.myFiches){
            if(fiche.id = this.conversationData[0].numeroDemande)  fiche.ordre_priorite = value; 
          }
          for(let fiche of this.messagesToDisplay){
            if(fiche.ficheID == this.conversationData[0].numeroDemande) fiche.ordre_priorite = value;
          }
          break;
        case 'Responsable de dossier':
          this.messagerieTicketsSerivice.dataToUpdate = []
          this.messagerieTicketsSerivice.dataToUpdate.push(Number(value))
          this.messagerieTicketsSerivice.dataToUpdate.push(this.conversationData[0].numeroDemande)
          const variable7  = this.messagerieTicketsSerivice.updateTicketRespo().subscribe(
            (res) => {
            console.log('Fiche mise à jour !');
            },
            (error) => {
            console.log('Erreur ! : ' + error);
            }
          );
          //Destruction de la souscription
          this.listSubscription.push(variable7); 
          for (let respo of this.respos) {
            if (respo.id === value) this.conversationData[0].respoDossier = respo.prenom + " " + respo.nom;
          }
          for(let fiche of this.dataLoadingService.myFiches){
            if(fiche.id = this.conversationData[0].numeroDemande)  fiche.respo_dossier_ID = Number(value)
          }
          for(let fiche of this.messagesToDisplay){
            if(fiche.ficheID == this.conversationData[0].numeroDemande) fiche.respo_dossier_ID = value
          }
          break;
        case 'Etat':
          this.messagerieTicketsSerivice.dataFicheToAdd = [];
          this.messagerieTicketsSerivice.dataFicheToAdd.push({id: currentfiche.id, numero_ticket: currentfiche.numero_ticket, date_ouverture: currentfiche.date_ouverture, libelle: "", respo_dossier_ID: 0, usersID: "", accesVisuelPourUsers: "", url: "", module: currentfiche.module, sous_module: currentfiche.sous_module, ordre_priorite: currentfiche.ordre_priorite, type_objet: currentfiche.type_objet, etat: value, impact: currentfiche.impact, numTelephoneClient: currentfiche.numTelephoneClient});
          const variable5  = this.messagerieTicketsSerivice.postUpdateFicheToServer().subscribe(
            (res) => {
            console.log('Fiche mise à jour !');
            },
            (error) => {
            console.log('Erreur ! : ' + error);
            }
          );
          //Destruction de la souscription
          this.listSubscription.push(variable5); 
          this.conversationData[0].etatDossier = value;
          for(let fiche of this.dataLoadingService.myFiches){
            if(fiche.id = this.conversationData[0].numeroDemande)  fiche.etat = value; 
          }
          for(let fiche of this.messagesToDisplay){
            if(fiche.ficheID == this.conversationData[0].numeroDemande) fiche.etat = value;
          }
          break;
        case 'Transférer Ticket existant':
          this.dataToTransfer = "<p>Fiche n°" + this.conversationData[0].numeroDemande + " transférée " +
                                "datant du " + this.conversationData[0].dateDemande.getDate() + '/' + ((this.conversationData[0].dateDemande.getMonth() + 1)) + '/' + this.conversationData[0].dateDemande.getFullYear() + "</p>" +
                                "\n\n<p>Type de demande: " + this.conversationData[0].typeDemande + "</p>" +
                                "\n<p>Module: " + this.conversationData[0].module + "</p>" +
                                "\n<p>Module: " + this.conversationData[0].sous_module + "</p>" +
                                "\n<p>Objet: " + this.conversationData[0].libelle + "</p>" +
                                "\n\n __________________________________________________________________________________________________";
          for(let data of this.conversationData[0].messages){
            for(let user of this.Users){
              if(data.userID == user.id){
                this.dataToTransfer = this.dataToTransfer + "<p><b>" + user.prenom + " " + user.nom + "</b></p>\n<p>" + data.message + "<p>\n\n";
              }
            }
          }
          this.dataToTransfer = this.dataToTransfer + "\n\n __________________________________________________________________________________________________";
          console.log(this.dataToTransfer, "data to transfer")
          //On envoie le message en l'inserrant dans la BDD
          this.messagerieTicketsSerivice.dataMsgToAdd = [];
          var date = new Date();
          var newMsg = 0;
          this.messagerieTicketsSerivice.dataMsgToAdd.push({id: 0, ficheID: Number(value), userID: Number(this.currentUser.id), userStatut: this.currentUser.statut, invisibleAuClient: 0, date_envoie: date, message: this.dataToTransfer});
          const variable3  = this.messagerieTicketsSerivice.postAddMessageToServer().subscribe(
            (response) => {
            console.log(response, 'message recu')
            newMsg = JSON.parse(JSON.stringify(response)).data;
            console.log('Message sauvegardé !');

            //Messaging Socket
            //On liste l'ensemble des users concernés par la fiche dans un tableau
            let listUsers = this.dataLoadingService.myFiches[Number(value)].usersID.split(/[/*]/);
            for(let i=0; i<listUsers.length; i++){
              if(listUsers[i] == "") listUsers.splice(i, 1);
            }
            this.messagerieTicketsSerivice.addMessage(newMsg[0].id, Number(value), Number(this.currentUser.id), this.currentUser.id, 0, date, this.dataToTransfer, 0, 1, listUsers, this.conversationData[0].listAccesUsers);
            //this.conversationData[0].messages.push({date: date, message: this.source, userID: this.connexionService.userID, envoye: 1});
            console.log(this.conversationData, "added msg in Conversation Data")

            //Une fois le message enregistré et envoyé, on peut vider l'éditeur de message
            this.dataToTransfer = "";  
            },
            (error) => {
            console.log('Erreur ! : ' + error);
            }
          );
          //Destruction de la souscription
          this.listSubscription.push(variable3);
          break;
        case "Marquer comme non lu":
          for(let fiche_user of this.dataLoadingService.myFichesUser){
            if(fiche_user.userID == Number(this.currentUser.id)){
              if(fiche_user.ficheID == Number(value)){
                this.messagerieTicketsSerivice.dataFicheUserToAdd = [];
                this.messagerieTicketsSerivice.dataFicheUserToAdd.push({id: 0, ficheID: fiche_user.ficheID, userID: Number(this.currentUser.id), non_lu: 1, archive: fiche_user.archive, accesFicheRefuse: fiche_user.accesFicheRefuse})
                const variable = this.messagerieTicketsSerivice.postUpdateFicheUserToServer().subscribe(
                  (response) => {
                    console.log('Fiche_user mise à jour !');
                  },
                  (error) => {
                    console.log('Erreur ! : ' + error);
                  }
                );
                //Destruction de la souscription
                this.listSubscription.push(variable);
                
                //On modifie en temps réel à l'aide de socket
                // this.messagerieTicketsSerivice.updateFicheUser(fiche_user.id, fiche_user.ficheID, fiche_user.userID, 1, fiche_user.archive, fiche_user.accesFicheRefuse);
                this.conversationData[0].non_lu = 1;
                for(let fiche of this.dataLoadingService.myFichesUser){
                  if(fiche.id = this.conversationData[0].numeroDemande)  fiche.non_lu = 1; 
                }
                for(let fiche of this.messagesToDisplay){
                  if(fiche.ficheID == this.conversationData[0].numeroDemande) fiche.non_lu = 1;
                }
              }
            }
          }
          break;
        case "Archiver":
          for(let fiche_user of this.dataLoadingService.myFichesUser){
            if(fiche_user.userID == Number(this.currentUser.id)){
              if(fiche_user.ficheID == Number(value)){

                //On modifie dans la BDD
                this.messagerieTicketsSerivice.dataFicheUserToAdd = [];
                this.messagerieTicketsSerivice.dataFicheUserToAdd.push({id: 0, ficheID: fiche_user.ficheID, userID: Number(this.currentUser.id), non_lu: fiche_user.non_lu, archive: 1, accesFicheRefuse: fiche_user.accesFicheRefuse})
                const variable = this.messagerieTicketsSerivice.postUpdateFicheUserToServer().subscribe(
                  (response) => {
                    console.log('Fiche_user mise à jour !');
                  },
                  (error) => {
                    console.log('Erreur ! : ' + error);
                  }
                );
                //Destruction de la souscription
                this.listSubscription.push(variable);

                //On modifie en temps réel à l'aide de socket
                // this.messagerieTicketsSerivice.updateFicheUser(fiche_user.id, fiche_user.ficheID, fiche_user.userID, fiche_user.non_lu, 1, fiche_user.accesFicheRefuse);
                this.conversationData[0].archive = 1;
                fiche_user.archive = 1
              }
            }
          }
          for(let fiche of this.messagesToDisplay){
            if(fiche.ficheID == Number(value)) fiche.archive = 1;
          }
          break;
        case "Retirer des archives":
          for(let fiche_user of this.dataLoadingService.myFichesUser){
            if(fiche_user.userID == Number(this.currentUser.id)){
              if(fiche_user.ficheID == Number(value)){

                //On modifie dans la BDD
                this.messagerieTicketsSerivice.dataFicheUserToAdd = [];
                this.messagerieTicketsSerivice.dataFicheUserToAdd.push({id: 0, ficheID: fiche_user.ficheID, userID: Number(this.currentUser.id), non_lu: fiche_user.non_lu, archive: 0, accesFicheRefuse: fiche_user.accesFicheRefuse})
                const variable = this.messagerieTicketsSerivice.postUpdateFicheUserToServer().subscribe(
                  (response) => {
                    console.log('Fiche_user mise à jour !');
                  },
                  (error) => {
                    console.log('Erreur ! : ' + error);
                  }
                );
                //Destruction de la souscription
                this.listSubscription.push(variable);

                //On modifie en temps réel à l'aide de socket
                // this.messagerieTicketsSerivice.updateFicheUser(fiche_user.id, fiche_user.ficheID, fiche_user.userID, fiche_user.non_lu, 0, fiche_user.accesFicheRefuse);
                this.conversationData[0].archive = 0;
                fiche_user.archive = 0;
              }
            }
          }
          for(let fiche of this.messagesToDisplay){
            if(fiche.ficheID == this.conversationData[0].numeroDemande) fiche.archive = 0;
          }
          break;
        default:
          break;
      }
  }

  // afficher la conversation (sur la droite)
  showConversation(fiche: any){
    console.log(fiche, "Fiche")
    this.showMenuDroite = "conversation";

    if (fiche.accesFicheRefuse === 1) this.disabledEditor = true

    //Si le message n'avait pas été lu, on le marque comme lu
    if(fiche.non_lu == 1){
      this.messagerieTicketsSerivice.dataFicheUserToAdd = [];
      this.messagerieTicketsSerivice.dataFicheUserToAdd.push({id: 0, ficheID: fiche.ficheID, userID: Number(this.currentUser.id), non_lu: 0, archive: fiche.archivé, accesFicheRefuse: fiche.accesFicheRefuse})
      const variable = this.messagerieTicketsSerivice.postUpdateFicheUserToServer().subscribe(
        (response) => {
          console.log('Fiche_user mise à jour !');
        },
        (error) => {
          console.log('Erreur ! : ' + error);
        }
      );
      //Destruction de la souscription
      this.listSubscription.push(variable);
      
      //On modifie en temps réel à l'aide de socket
      // this.messagerieTicketsSerivice.updateFicheUser(fiche.id, fiche.ficheID, Number(this.currentUser.id), 0, fiche.archivé, fiche.accesFicheRefuse);
      this.conversationData[0].non_lu = 0;
      for(let ficheValue of this.dataLoadingService.myFichesUser){
        if(ficheValue.id = this.conversationData[0].numeroDemande)  ficheValue.non_lu = 0; 
      }
      for(let ficheValue of this.messagesToDisplay){
        if(ficheValue.ficheID === this.conversationData[0].numeroDemande) {
          ficheValue.non_lu = 0
        }
      }
      fiche.non_lu = 0
    }

    //on réinitialise la variable
    this.conversationData = [];

    

    //On récupère les données nécessaires dans la table users
    let respoDossier = "", nameDestinataireTest = "", nameDestinataire = "", telDestinataire = "";
    if(this.currentUser.statut == "Interne"){
      console.time("starting")
      for(let user of this.Users){
        if(user.id == fiche.respo_dossier_ID) respoDossier = user.prenom + " " + user.nom;
        if(fiche.listUsers.includes(user.id.toString()) && user.statut == 'Externe'){
          nameDestinataireTest = nameDestinataireTest + " " + user.prenom + " " + user.nom + ", ";
        }
      }
      console.timeEnd("ending")
      if(nameDestinataireTest != "") nameDestinataire = nameDestinataireTest.slice(0, -2);
    }
    if(this.currentUser.statut == "Externe"){
      for(let user of this.Users){
        if(user.id == fiche.respo_dossier_ID) respoDossier = user.prenom + " " + user.nom;
      }
      nameDestinataire = "Bug Tracking Team";
    }
    
    //On récupère tous les messages liés à cette fiche
    let ficheDates = []
    for(let message of this.MyMessagesOfMyFiches){
      if(message.ficheID == fiche.ficheID)  ficheDates.push({id: message.id, date: new Date(message.date_envoie), message: message.message, userID: message.userID, userStatut: message.userStatut, invisibleAuClient: message.invisibleAuClient});
    }
    //On rajoute les messages ajoutés par d'autres utilisateurs via les sockets
    for(let newMsg of this.newMessage){
      if(fiche.ficheID == newMsg.ficheID) {
        if(!(ficheDates.includes(newMsg))){
          ficheDates.push({id: newMsg.id, date: new Date(newMsg.date_envoie), message: newMsg.message, userID: newMsg.userID, userStatut: newMsg.userStatut, invisibleAuClient: newMsg.invisibleAuClient});
        }
      }
    }
    //on trie pour récupérer la date la plus ancienne ayant créée la fiche dans la table messages
    ficheDates.sort((a, b) => a.date - b.date);

    //on entre 2 données qui seront afficher
    this.selectedTypeDemande = fiche.type_objet;
    this.selectedModule = fiche.module;
    this.selectedSousModule = fiche.sous_module;

    //On entre tous les données dans une varible pour les afficher sur le template
    this.conversationData.push({numeroDemande: fiche.ficheID, numero_ticket: fiche.numero_ticket, nameDestinataire: nameDestinataire, libelle: fiche.libelle, dateDemande: ficheDates[0].date, typeDemande: fiche.type_objet, module: fiche.module, sous_module: fiche.sous_module, tel: fiche.numTelephoneClient, respoDossier: respoDossier, ordre_priorite: fiche.ordre_priorite, etatDossier: fiche.etat, impact: fiche.impact, messages: ficheDates, listUsers: fiche.listUsers, listAccesUsers: fiche.listAccesUsers, accesFicheRefuse: fiche.accesFicheRefuse});
    console.log(this.conversationData, "conversation Data")
    console.log(this.MyFiches, "mes fiches")

    // Si tout est bon, on charge les questions liés au module et sous-module en question
    this.initialisationQuestions();
  }

  removeMessageTags(msg: string){
    if(msg.includes("<")){
      let message = "";
      let values = msg.split(">", msg.split("<").length); 
      for(let element of values){
        element = element.substring(0, element.indexOf('<')); 
        message = message + element;
      }
      return message;
    }
    else return msg;
    
  }

  //Non utilisé pour le moment
  splitMessage(msg: string){
    var limit = 70;
    let message = "";
    let values = msg.split(" ", msg.split(" ").length,); 
    for(let element of values){
      //si le substring (sans espace) a une taille supérieur à 80, on ajoute un break (pour afficher sans dépasser de la fenêtre)
      if(element.length > 80){
        for (var i = 0; i < element.length; i++) {
          if (i % (limit + 1) === 0 && i > 0) {
            element = [element.slice(0, i), '\n', element.slice(i)].join('');
          }
        }
      }
      message = message + " " + element; 
    }
    
    return message;
  }

  sendMessage(){
    if(!this.source) this.erreurEditeurVide = true;
    else this.erreurEditeurVide = false;

    if(this.erreurEditeurVide == false){

      // Si l'utilisateur connecté fait partie de la conversation
      if(this.conversationData[0].listUsers.includes(this.currentUser.id)) {
        //Ajout du message dans la BDD
        this.messagerieTicketsSerivice.dataMsgToAdd = [];
        var date = new Date();
        var newMsg = 0;
        this.messagerieTicketsSerivice.dataMsgToAdd.push({id: 0, ficheID: this.conversationData[0].numeroDemande, userID: Number(this.currentUser.id), userStatut: this.currentUser.statut, invisibleAuClient: 0, date_envoie: date, message: this.source});
        console.log(this.currentUser.statut, 'statut')
        console.log(  this.messagerieTicketsSerivice.dataMsgToAdd, 'dataToAdd')
        const variable  = this.messagerieTicketsSerivice.postAddMessageToServer().subscribe(
          (response) => {
          console.log(response, 'message recu')
          newMsg = JSON.parse(JSON.stringify(response)).data;
          console.log('Message sauvegardé !');

          //Socket
          this.messagerieTicketsSerivice.addMessage(newMsg[0].id, this.conversationData[0].numeroDemande,  Number(this.currentUser.id), this.currentUser.statut, 0, date, this.source, 0, 1, this.conversationData[0].listUsers, this.conversationData[0].listAccesUsers);
          console.log(this.conversationData, "added msg in Conversation Data")

          //Une fois le message enregistré et envoyé, on peut vider l'éditeur de message
          this.source = "";  

          //On envoie une notification pour la reception d'un nouveau message
          for(let userID of this.conversationData[0].listUsers){
            if(userID != Number(this.currentUser.id)){
              for(let user of this.Users){
                if(userID == user.id && user.statut != this.currentUser.statut){
                  this.notificationService.dataToAdd = [];
                  this.notificationService.dataToAdd.push({id: 0, userID: userID, date: new Date(), notification: "Vous avez un nouveau message."})
                  const variable2 = this.notificationService.postAddNotifToServer().subscribe(
                  (res) => {
                    console.log('Notification sauvegardé !');
                    },
                    (error) => {
                    console.log('Erreur ! : ' + error);
                    }
                  );
                  //Destruction de la souscription
                  this.listSubscription.push(variable2); 
                }
              }
              

              //Ajout Socket
              //On envoie aux clients
              if(this.currentUser.statut == "Interne")  this.notificationService.addNotification("Externe", 0, userID, new Date(), "Vous avez un nouveau message.");
              //On envoie aux hotliners
              if(this.currentUser.statut == "Externe")  this.notificationService.addNotification("Interne", 0, userID, new Date(), "Vous avez un nouveau message.");
            }
          }

          
          },
          (error) => {
          console.log('Erreur ! : ' + error);
          }
        );
        //Destruction de la souscription
        this.listSubscription.push(variable);
      }

      // Si l'utilisateur connecté ne fait pas partie de la conversation mais son aide est sollicité par le hotliner
      if(this.conversationData[0].listAccesUsers.includes(this.currentUser.id)) {
        let reponse: string = 'Réponse de l\'agent: ' + this.source
        //Ajout du message dans la BDD
        this.messagerieTicketsSerivice.dataMsgToAdd = [];
        var date = new Date();
        var newMsg = 0;
        this.messagerieTicketsSerivice.dataMsgToAdd.push({id: 0, ficheID: this.conversationData[0].numeroDemande, userID: Number(this.currentUser.id), userStatut: "Assistance", invisibleAuClient: 1, date_envoie: date, message: reponse});
        console.log(this.currentUser.statut, 'statut')
        console.log(  this.messagerieTicketsSerivice.dataMsgToAdd, 'dataToAdd')
        const variable  = this.messagerieTicketsSerivice.postAddMessageToServer().subscribe(
          (response) => {
            console.log(response, 'message recu')
            newMsg = JSON.parse(JSON.stringify(response)).data;
            console.log('Message sauvegardé !');

            //Socket
            this.messagerieTicketsSerivice.addMessage(newMsg[0].id, this.conversationData[0].numeroDemande, Number(this.currentUser.id), "Assistance", 1, date, reponse, 0, 1, this.conversationData[0].listUsers, this.conversationData[0].listAccesUsers);

            //On envoie une notification pour la reception d'un nouveau message
            for(let userID of this.conversationData[0].listUsers){
              if(userID != Number(this.currentUser.id)){
                for(let user of this.Users){
                  if(userID == user.id && user.statut != this.currentUser.statut){
                    this.notificationService.dataToAdd = [];
                    this.notificationService.dataToAdd.push({id: 0, userID: userID, date: new Date(), notification: "Vous avez un nouveau message."})
                    const variable2 = this.notificationService.postAddNotifToServer().subscribe(
                    (res) => {
                      console.log('Notification sauvegardé !');
                      },
                      (error) => {
                      console.log('Erreur ! : ' + error);
                      }
                    );
                    //Destruction de la souscription
                    this.listSubscription.push(variable2); 
                  }
                }
                

                //Ajout Socket
                //On envoie aux hotliners
                if(this.currentUser.statut == "Interne")  this.notificationService.addNotification("Interne", 0, userID, new Date(), "Vous avez un nouveau message.");
              }
            }

            // Une fois la réponse de l'utilisateur envoyée pour aider le hotliner, il n'aura plus la possibilité d'envoyer un message à nouveau mais pourra visualiser la conversation
            // donc on lui restreint l'accès à la fiche
            for(let fiche_user of this.dataLoadingService.myFichesUser){
              if(fiche_user.userID == Number(this.currentUser.id) && fiche_user.ficheID == this.conversationData[0].numeroDemande){
                this.messagerieTicketsSerivice.dataFicheUserToAdd = [];
                this.messagerieTicketsSerivice.dataFicheUserToAdd.push({id: 0, ficheID: fiche_user.ficheID, userID: Number(this.currentUser.id), non_lu: fiche_user.non_lu, archive: fiche_user.archive, accesFicheRefuse: 1})
                const variable = this.messagerieTicketsSerivice.postUpdateFicheUserToServer().subscribe(
                  (response) => {
                    console.log('Fiche_user mise à jour !');
                    this.conversationData[0].accesFicheRefuse = 1
                    this.disabledEditor = true
                  },
                  (error) => {
                    console.log('Erreur ! : ' + error);
                  }
                );
                //Destruction de la souscription
                this.listSubscription.push(variable);
                
                //On modifie en temps réel à l'aide de socket
                this.messagerieTicketsSerivice.updateFicheUser(fiche_user.id, fiche_user.ficheID, fiche_user.userID, fiche_user.non_lu, fiche_user.archive, 1);
              }
            }

            // on ajoute affiche le nouveau message en temps réel
            // this.newMessage.push({ id: newMsg[0].id, ficheID: this.conversationData[0].numeroDemande, userID: Number(this.currentUser.id), userStatut: "Assistance", invisibleAuClient: 1, date_envoie: date, message: reponse});
            this.conversationData[0].messages.push({id: newMsg[0].id, date: date, message: 'Réponse de l\'agent: ' + this.source, userID: Number(this.currentUser.id), userStatut: "Assistance", invisibleAuClient: 1});
            //Ajout nouveau message sur l'etiquette des tickets dans le menu de gauche
            // if(this.messagesToDisplay.length != 0) {
            //   for(let msg of this.messagesToDisplay){
            //     if(msg.ficheID == this.conversationData[0].numeroDemande) {
            //       msg.msgID = newMsg[0].id;
            //       msg.date_envoie = new Date(date);
            //       msg.message = response
            //       msg.userID = Number(this.currentUser.id);
            //       msg.userStatut = "Assistance"
            //       msg.invisibleAuClient = 1
            //     }
            //   }
            // }
            console.log(reponse, 'reponse')
            console.log(this.conversationData[0], 'convData updated')

            //Une fois le message enregistré et envoyé, on peut vider l'éditeur de message
            this.source = "";  
          
          },
          (error) => {
          console.log('Erreur ! : ' + error);
          }
        );
        //Destruction de la souscription
        this.listSubscription.push(variable);
      }
      
    }
  }

  // Q & A
  initialisationQuestions(){
    this.questions=[];
    this.faq.sous_module = this.conversationData[0].sous_module
    this.faq.module = this.conversationData[0].module
    this.questions = this.faq.faqSample;
    const variable7 = this.faq.getQuestionBySousModule().subscribe((response) => {
      this.Faqs = JSON.parse(JSON.stringify(response)).data
      if(this.currentUser.statut === "Externe") this.questions = this.Faqs;
      else {
        this.questions=[];
        var j=0;
        for(let i=0;i<this.Faqs.length;i++)
        {
          console.log(this.Faqs.length);
          if(this.Faqs[i].is_prived==0)
          {
            this.questions[j]=this.Faqs[i];
            j++;
          }
        }
      }
      console.log(this.Faqs);
      console.log(this.questions, "Q");
    });
    this.listSubscription.push(variable7);
    this.faq.clear();
  }

  handleQuestion(value: string, value2: string){
    this.selectedQuestion = value;
    this.source="";
    this.messagerieTicketsSerivice.dataMsgToAdd = [];
    var date = new Date();
    var newMsg = 0;
    console.log(value);
    
    //Ajout du message dans la BDD
    this.messagerieTicketsSerivice.dataMsgToAdd = [];
    var date = new Date();
    var newMsg = 0;
    this.messagerieTicketsSerivice.dataMsgToAdd.push({id: 0, ficheID: this.conversationData[0].numeroDemande, userID: Number(this.currentUser.id), userStatut: this.currentUser.statut, invisibleAuClient: 0, date_envoie: date, message: value});
    const variable  = this.messagerieTicketsSerivice.postAddMessageToServer().subscribe((response) => {
      console.log(response, 'message recu')
      newMsg = JSON.parse(JSON.stringify(response)).data;
      console.log('Message sauvegardé !');

      //Socket
      this.messagerieTicketsSerivice.addMessage(newMsg[0].id, this.conversationData[0].numeroDemande, this.connexionService.userID, this.currentUser.statut, 0, date,value, 0, 1, this.conversationData[0].listUsers, this.conversationData[0].data);
      console.log(this.conversationData, "added msg in Conversation Data")

      let sent: boolean = false
      //Une fois le message enregistré et envoyé, on peut vider l'éditeur de message
      //On envoie une notification pour la reception d'un nouveau message
      for(let userID of this.conversationData[0].listUsers){
        if(userID != Number(this.currentUser.id)){
          this.userService.dataUserId = Number(userID)
          const variable2 = this.userService.getUserWithHisIdFromServer().subscribe((res) => {
            let utilisateur = JSON.parse(JSON.stringify(response)).data
            if(utilisateur.statut != this.currentUser.statut){
              
              // this.notificationService.dataToAdd = [];
              // this.notificationService.dataToAdd.push({id: 0, userID: userID, date: new Date(), notification: "Vous avez un nouveau message."})
              // const variable2 = this.notificationService.postAddNotifToServer().subscribe((res) => {
              //   console.log('Notification sauvegardé !');
              //   date = new Date();
              //   newMsg = 0;
              //   console.log(value);
              //   console.log(value2);
              if(sent !== true) {
                this.messagerieTicketsSerivice.dataMsgToAdd=[];
                this.messagerieTicketsSerivice.dataMsgToAdd.push({id: 0, ficheID: this.conversationData[0].numeroDemande, userID: Number(userID),  userStatut: utilisateur.statut, invisibleAuClient: 0, date_envoie: date, message: value2});
                console.log(this.messagerieTicketsSerivice.dataMsgToAdd);
                const variable3  = this.messagerieTicketsSerivice.postAddMessageToServer().subscribe((response) => {
                  console.log(response, 'message recu')
                  newMsg = JSON.parse(JSON.stringify(response)).data;
                  console.log('Message sauvegardé !');
                  this.messagerieTicketsSerivice.addMessage(newMsg[0].id, this.conversationData[0].numeroDemande, Number(userID), utilisateur.statut, 0, date, value2, 0, 1, this.conversationData[0].listUsers, this.conversationData[0].listAccesUsers);
                  console.log(this.conversationData, "added msg in Conversation Data")
                  this.source = "";  
                    

                  // this.notificationService.dataToAdd = [];
                  // this.notificationService.dataToAdd.push({id: 0, userID: userID, date: new Date(), notification: "Vous avez un nouveau message."})
                  // const variable4 = this.notificationService.postAddNotifToServer().subscribe((res) => {
                  //   console.log('Notification sauvegardé !');
                  // },
                  // (error) => {
                  //   console.log('Erreur ! : ' + error);
                  //   });
                  //   this.listSubscription.push(variable4); 
                });
                this.listSubscription.push(variable3); 
                //     },
                //   (error) => {
                //     console.log('Erreur ! : ' + error);
                // });
                // //Destruction de la souscription
                // this.listSubscription.push(variable2);
              }
            
              //   //Ajout Socket
              //   //On envoie aux clients
              //   if(this.currentUser.statut == "Interne")  this.notificationService.addNotification("Externe", 0, userID, new Date(), "Vous avez un nouveau message.");
              //   //On envoie aux hotliners
              //   if(this.currentUser.statut == "Externe")  this.notificationService.addNotification("Interne", 0, userID, new Date(), "Vous avez un nouveau message.");
              sent = true
            }
          });
          //Destruction de la souscription
          this.listSubscription.push(variable2);
        }
      }
    });
    //Destruction de la souscription
    this.listSubscription.push(variable);
  }

  /**Nouveau message */
  createNewTicket(){

    var respoID;
    var usersID = "";
    this.selectedEtat = 'En attente'

    console.log(this.destinataires, "destinataires")
    console.log(this.selectedItemsDestinataire, "selected destinataires")

    if(this.selectedItemsDestinataire.length == 0) this.erreurDestinataire = true;
    else this.erreurDestinataire = false;
    if(this.selectedLibelle == "") this.erreurLibelle = true;
    else this.erreurLibelle = false;
    if(this.currentUser.statut == "Interne"){
      if(this.selectedRespo == "") this.erreurRespo = true;
      else this.erreurRespo = false;
    }
    if(this.selectedNewModule == "") this.erreurModule = true;
    else this.erreurModule = false;
    if(this.selectedNewSousModule == "") this.erreurSousModule = true;
    else this.erreurSousModule = false;
    if(this.selectedNewTypeDemande == "") this.erreurTypeDemande = true;
    else this.erreurTypeDemande = false;
    if(this.selectedURL == "") this.erreurURL = true;
    else this.erreurURL = false;
    if(this.selectedEtat == "") this.erreurEtat = true;
    else this.erreurEtat = false;
    if(this.selectedImpact == "") this.erreurImpact = true;
    else this.erreurImpact = false;
    if(this.selectedTel == "") this.erreurTel = true;
    else this.erreurTel = false;
    if(this.selectedPriorite == "") this.erreurPriorite = true;
    else this.erreurPriorite = false;
    if(this.source2 == "") this.erreurNewMessage = true;
    else this.erreurNewMessage = false;
    this.erreurBugTrackingTeamExist = true;
    for(let destinataire of this.selectedItemsDestinataire){
      if(destinataire.item_text == "Bug Tracking Team") this.erreurBugTrackingTeamExist = false;
    }


    

    if(this.erreurNewMessage == false && this.erreurDestinataire == false && this.erreurLibelle == false && this.erreurRespo == false && this.erreurModule == false && this.erreurSousModule == false && this.erreurTypeDemande == false && this.erreurURL == false && this.erreurEtat == false && this.erreurImpact == false && this.erreurTel == false && this.erreurPriorite == false && this.erreurBugTrackingTeamExist == false){
      
      console.log("SAVE DATA")

      for(let user of this.Users){
        if(this.currentUser.statut == "Externe"){
          if(user.emailPro == this.selectedRespo.substring(this.selectedRespo.lastIndexOf("<") + 1, this.selectedRespo.lastIndexOf(">"))){
            respoID = user.id;
          }
        }
        else respoID = 0;
      }

      console.log(this.destinataires, "destinataires")
      console.log(this.selectedItemsDestinataire, "selected destinataires")
      for(let user of this.Users){
        for(let destinataire of this.selectedItemsDestinataire){
          for(let dest of this.destinataires){
            if(destinataire.item_id == dest.item_id){
              // console.log(dest, "destii")
            
              if(dest.statut == "user"){
                if(user.id == dest.persoID){
                  if(!(usersID.includes("/" + user.id + "*"))){
                    usersID = usersID + "/" + user.id + "*";
                    console.log(usersID, "usersID")
                  }
                }
              }
              if(dest.statut == "tag"){
                if(destinataire.item_text == "Bug Tracking Team"){
                  if(user.tags != null){
                    if(user.tags.includes("hotline/")){
                      if(!(usersID.includes("/" + user.id + "*"))){
                        usersID = usersID + "/" + user.id + "*";
                        console.log(usersID, "usersID")
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }

      // On rajoute à la conversation tous les utilisateurs clients qui font partie de la même entreprise et base
      this.userService.dataUsersOfEntrepriseBase = []
      this.userService.dataUsersOfEntrepriseBase.push(this.currentUser.entreprise)
      this.userService.dataUsersOfEntrepriseBase.push(this.currentUser.base)
      const variable4 = this.userService.getUsersOfEntrepriseBase().subscribe((res) => {
        
        let clientUsers = JSON.parse(JSON.stringify(res)).data
        console.log(clientUsers, 'clientUsers')
        for (let clientUser of clientUsers) {
          if(!(usersID.includes("/" + clientUser.id + "*"))){
            usersID = usersID + "/" + clientUser.id + "*";
          }
        }

        // On va générer le numéro dossier 
        // On liste l'ensemble des users concernés par la fiche dans un tableau
        let listUsers = usersID.split(/[/*]/);
        for(let i=0; i<listUsers.length; i++){
          if(listUsers[i] == "") listUsers.splice(i, 1);
        }
        console.log(listUsers, "ListeUsers")
        let entreprises = [];
        for(let user of this.Users){
          for(let userlistID of listUsers){
            if(user.id == Number(userlistID)){
              if(user.statut == "Externe"){
                entreprises.push(user.entreprise);
              }
            }
          }
        }
        //si l'utilisateur a choisi des destinataires "client" d'entreprises différentes
        this.erreurUserDifferent = false;
        this.erreurUserClientManquant = false;
        if(entreprises.length != 0){
          for(let ese of entreprises){
            if(ese != entreprises[0])  this.erreurUserDifferent = true;
          }
        }
        //si aucun user client n'a été choisi
        else{
          if(this.currentUser.statut == "Interne")  this.erreurUserClientManquant = true;
        } 

        if(this.erreurUserDifferent == false && this.erreurUserClientManquant == false){
          //Génération numéro de ticket unique
          let numTicket = "";
          console.log(entreprises[0], 'entreprise cliente')
          numTicket = "_" + entreprises[0] ;
          console.log(numTicket, "numero ticket en production")

          let listNumTicket = [];
          let listNumTicketFinal = []
          if(this.dataLoadingService.fiches.length != 0){
            for(let fiche of this.dataLoadingService.fiches){
              if(fiche.numero_ticket.includes(numTicket)) listNumTicket.push({numero_ticket: fiche.numero_ticket});
            }
            for (let value of listNumTicket) {
              let number = value.numero_ticket
              for(let i=0; i<number.length; i++){
                if(number[i] == "_") listNumTicketFinal.push(number.substring(0, i))
              }
            }
            listNumTicketFinal.sort(function(a, b) {
              return b - a;
            });
            console.log(listNumTicketFinal, 'listNumTicket')
          
            if(listNumTicketFinal.length != 0){
              let number = listNumTicketFinal[0];
              numTicket = (Number(number) + 1).toString() + numTicket;
            }
            else  numTicket = "1" + numTicket;
            
            console.log(numTicket, "FINAL TICKET")

            this.messagerieTicketsSerivice.addNewTicket(numTicket, this.selectedLibelle, respoID, usersID, "", this.selectedURL, this.selectedNewModule, this.selectedNewSousModule, this.selectedPriorite, this.selectedNewTypeDemande, 'En attente', this.selectedImpact, this.selectedTel, 0, 0, Number(this.currentUser.id), this.currentUser.statut, 0, new Date(), this.source2, 0, 1);
            
            //Ajout du ticket dans la BDD
            this.messagerieTicketsSerivice.dataFicheMsgToAdd = [];
            this.messagerieTicketsSerivice.dataFicheMsgToAdd.push({numero_ticket: numTicket, date_ouverture: new Date(), libelle: this.selectedLibelle, respo_dossier_ID: respoID, usersID: usersID, accesVisuelPourUsers: "", listUsers: listUsers, url: this.selectedURL, module: this.selectedNewModule, sous_module: this.selectedNewSousModule, ordre_priorite: this.selectedPriorite, type_objet: this.selectedNewTypeDemande, etat: 'En attente', impact: this.selectedImpact, numTelephoneClient: this.selectedTel, archivé: 0, ficheID: 0, userID: Number(this.currentUser.id), userStatut: this.currentUser.statut, invisibleAuClient: 0, date_envoie: new Date(), message: this.source2, non_lu: 0, envoyé: 1, accesFicheRefuse: 0});
            console.log(this.messagerieTicketsSerivice.dataFicheMsgToAdd, "datato ADD")
            const variable = this.messagerieTicketsSerivice.postAddFicheMessageToServer().subscribe(
              (res) => {
              console.log('Fiche et message sauvegardé !');
              },
              (error) => {
              console.log('Erreur ! : ' + error);
              }
            );
            //Destruction de la souscription
            this.listSubscription.push(variable)

          }
          else{
            const variable2 = this.messagerieTicketsSerivice.getFichesFromServer().subscribe((response) => {
              console.log(JSON.parse(JSON.stringify(response)).data, "fiches chargées")
              for(let fiche of JSON.parse(JSON.stringify(response)).data){
                if(fiche.numero_ticket.includes(numTicket)) listNumTicket.push({numero_ticket: fiche.numero_ticket});
              }
              for (let value of listNumTicket) {
                let number = value.numero_ticket
                for(let i=0; i<number.length; i++){
                  if(number[i] == "_") listNumTicketFinal.push(number.substring(0, i))
                }
              }
              listNumTicketFinal.sort(function(a, b) {
                return b - a;
              });
              console.log(listNumTicketFinal, 'listNumTicket')
            
              if(listNumTicketFinal.length != 0){
                let number = listNumTicketFinal[0];
                numTicket = (Number(number) + 1).toString() + numTicket;
              }
              else  numTicket = "1" + numTicket;
              
              console.log(numTicket, "FINAL TICKET")
      
              this.messagerieTicketsSerivice.addNewTicket(numTicket, this.selectedLibelle, respoID, usersID, "", this.selectedURL, this.selectedNewModule, this.selectedNewSousModule, this.selectedPriorite, this.selectedNewTypeDemande, 'En attente', this.selectedImpact, this.selectedTel, 0, 0, Number(this.currentUser.id), this.currentUser.statut, 0, new Date(), this.source2, 0, 1);

              //Ajout du ticket dans la BDD
              this.messagerieTicketsSerivice.dataFicheMsgToAdd = [];
              this.messagerieTicketsSerivice.dataFicheMsgToAdd.push({numero_ticket: numTicket, date_ouverture: new Date(), libelle: this.selectedLibelle, respo_dossier_ID: respoID, usersID: usersID, accesVisuelPourUsers: "", listUsers: listUsers, url: this.selectedURL, module: this.selectedNewModule, sous_module: this.selectedNewSousModule, ordre_priorite: this.selectedPriorite, type_objet: this.selectedNewTypeDemande, etat: 'En attente', impact: this.selectedImpact, numTelephoneClient: this.selectedTel, archivé: 0, ficheID: 0, userID: Number(this.currentUser.id), userStatut: this.currentUser.statut, invisibleAuClient: 0, date_envoie: new Date(), message: this.source2, non_lu: 0, envoyé: 1, accesFicheRefuse: 0});
              console.log(this.messagerieTicketsSerivice.dataFicheMsgToAdd, "datato ADD")
              const variable  = this.messagerieTicketsSerivice.postAddFicheMessageToServer().subscribe(
                (res) => {
                console.log('Fiche et message sauvegardé !');
                },
                (error) => {
                console.log('Erreur ! : ' + error);
                }
              );
              //Destruction de la souscription
              this.listSubscription.push(variable)
            })
            this.listSubscription.push(variable2); 
          }

        }
      });
      this.listSubscription.push(variable4); 
    }    
    else console.log("ERROR")
  }

  getUserWithUserId(userId: number){
    this.user = null
    for (let user of this.Users){
      if(user.id === userId) {
        this.user = user
        return true
      }
    }
    return false
  }

  checkFicheUsersIDIncludesUserId(ficheUsersID: string){
    this.user = null
    for (let user of this.Users){
      if(ficheUsersID.substr(0, 4).includes('/' + user.id + '*')) {
        this.user = user
        return true
      }
    }
    return false
  }

  openDialog() {
    const dialogRef = this.dialog.open(DialogComponent);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
      if (result === true)  {
        console.log(this.messagerieTicketsSerivice.selectedInterneTransfert, 'selectedInterneTransfert')
        console.log(this.messagerieTicketsSerivice.commentaireTransfert, 'commentaireTransfert')
        let selectedInterneTransfert = this.messagerieTicketsSerivice.selectedInterneTransfert
        let comment = "Commentaire de l'expéditeur: " + this.messagerieTicketsSerivice.commentaireTransfert

        var date = new Date()
        var newMsg

        // ajout d'un message informatif dans la BDD
        this.messagerieTicketsSerivice.dataMsgToAdd = [];
        this.messagerieTicketsSerivice.dataMsgToAdd.push({id: 0, ficheID: this.conversationData[0].numeroDemande, userID: 0,  userStatut: "Assistance", invisibleAuClient: 1, date_envoie: new Date(), message: "En attente de la réponse d’un agent de GTP"});
        console.log(this.messagerieTicketsSerivice.dataMsgToAdd);
        const variable3  = this.messagerieTicketsSerivice.postAddMessageToServer().subscribe(
          (response) => {
            console.log(response, 'message recu info')
            newMsg = JSON.parse(JSON.stringify(response)).data;
            console.log('Message sauvegardé !')
    
            // ajout du message informatif dans la conversation
            //Socket
            //On met à jour la liste de l'ensemble des users ayant un accès visuel à la fiche
            if (this.checkDestinataireAlreadyIn(this.conversationData[0].listAccesUsers, selectedInterneTransfert) === false) this.conversationData[0].listAccesUsers.push(selectedInterneTransfert) 
            this.messagerieTicketsSerivice.addMessage(newMsg[0].id, this.conversationData[0].numeroDemande, 0, "Assistance", 1, date, "En attente de la réponse d’un agent de GTP", 1, 0, this.conversationData[0].listUsers, this.conversationData[0].listAccesUsers)
    
            //On envoie une notification pour la reception du nouveau message
            for(let userID of this.conversationData[0].listUsers){
              if(userID != Number(this.currentUser.id)){
                for(let user of this.Users){
                  if(userID == user.id && user.statut != this.currentUser.statut){
                    this.notificationService.dataToAdd = [];
                    this.notificationService.dataToAdd.push({id: 0, userID: userID, date: new Date(), notification: "Vous avez un nouveau message."})
                    const variable2 = this.notificationService.postAddNotifToServer().subscribe(
                    (res) => {
                      console.log('Notification sauvegardé !');
                      },
                      (error) => {
                      console.log('Erreur ! : ' + error);
                      }
                    );
                    //Destruction de la souscription
                    this.listSubscription.push(variable2); 
                  }
                }
                
    
                //Ajout Socket
                //On envoie aux hotliners
                if(this.currentUser.statut == "Interne")  this.notificationService.addNotification("Interne", 0, userID, new Date(), "Vous avez un nouveau message.");
              }
            }

            if (this.conversationData[0].listAccesUsers.length === 0 || this.checkDestinataireAlreadyIn(this.conversationData[0].listAccesUsers, selectedInterneTransfert) === false) {
              console.log('i went inside')
              let accessUsers = ''
              if (this.conversationData[0].listAccesUsers !== null) {
                for (let userID of this.conversationData[0].listAccesUsers) {
                  accessUsers += "/" + userID + "*"
                }
              }
  
              // On note dans la base de données que la fiche est accessible par tel user visuellement
              this.messagerieTicketsSerivice.dataToUpdate = []
              this.messagerieTicketsSerivice.dataToUpdate.push(accessUsers)
              this.messagerieTicketsSerivice.dataToUpdate.push(this.conversationData[0].numeroDemande)
              const variable7 = this.messagerieTicketsSerivice.updateAccesVisuelUser().subscribe(
                (res) => {
                console.log('Fiche mise à jour !')
  
                },
                (error) => {
                console.log('Erreur ! : ' + error)
                }
              );
              //Destruction de la souscription
              this.listSubscription.push(variable7);

              //Création d'une fiche user pour le destinataire
              this.messagerieTicketsSerivice.dataFicheUserToAdd = [];
              this.messagerieTicketsSerivice.dataFicheUserToAdd.push({id: 0, ficheID: this.conversationData[0].numeroDemande, userID: Number(selectedInterneTransfert), non_lu: 1, archive: 0, 	accesFicheRefuse: 0});
              const variable3  = this.messagerieTicketsSerivice.postAddFicheUserToServer().subscribe(
                (res) => {
                console.log('Fiche_user sauvegardé !');
                },
                (error) => {
                console.log('Erreur ! : ' + error);
                }
              );
              //Destruction de la souscription
              this.listSubscription.push(variable3); 
            }
            else {
              console.log('i am outside')
              //On met à jour la fiche user pour le destinataire de sorte qu'il ait accès à la fiche
              this.messagerieTicketsSerivice.dataFicheUserToAdd = [];
              this.messagerieTicketsSerivice.dataFicheUserToAdd.push({id: 0, ficheID: this.conversationData[0].numeroDemande, userID: Number(selectedInterneTransfert), non_lu: 1, archive: 0, 	accesFicheRefuse: 0});
              const variable3  = this.messagerieTicketsSerivice.postUpdateFicheUserToServer().subscribe(
                (res) => {
                console.log('Fiche_user mise à jour !');
                },
                (error) => {
                console.log('Erreur ! : ' + error);
                }
              );
              //Destruction de la souscription
              this.listSubscription.push(variable3); 
            }
          },
          (error) => {
            console.log('Erreur ! : ' + error);
          }
        );
        //Destruction de la souscription
        this.listSubscription.push(variable3)

        if (this.messagerieTicketsSerivice.commentaireTransfert !== null || this.messagerieTicketsSerivice.commentaireTransfert !== '') {
          
          // ajout du commentaire en message informatif dans la BDD
          this.messagerieTicketsSerivice.dataMsgToAdd=[];
          this.messagerieTicketsSerivice.dataMsgToAdd.push({id: 0, ficheID: this.conversationData[0].numeroDemande, userID: Number(this.currentUser.id),  userStatut: "Assistance", invisibleAuClient: 1, date_envoie: new Date(), message: comment});
          console.log(this.messagerieTicketsSerivice.dataMsgToAdd);
          const variable3  = this.messagerieTicketsSerivice.postAddMessageToServer().subscribe(
            (response) => {
              console.log(response, 'message recu info')
              newMsg = JSON.parse(JSON.stringify(response)).data;
              console.log('Message sauvegardé !');
      
              // ajout du message informatif dans la conversation
              //Socket
              this.messagerieTicketsSerivice.addMessage(newMsg[0].id, this.conversationData[0].numeroDemande, Number(this.currentUser.id), "Assistance", 1, date, comment, 1, 0, this.conversationData[0].listUsers, this.conversationData[0].listAccesUsers);
      
              //On envoie une notification pour la reception du nouveau message
              for(let userID of this.conversationData[0].listUsers){
                if(userID != Number(this.currentUser.id)){
                  for(let user of this.Users){
                    if(userID == user.id && user.statut != this.currentUser.statut){
                      this.notificationService.dataToAdd = [];
                      this.notificationService.dataToAdd.push({id: 0, userID: userID, date: new Date(), notification: "Vous avez un nouveau message."})
                      const variable2 = this.notificationService.postAddNotifToServer().subscribe(
                      (res) => {
                        console.log('Notification sauvegardé !');
                        },
                        (error) => {
                        console.log('Erreur ! : ' + error);
                        }
                      );
                      //Destruction de la souscription
                      this.listSubscription.push(variable2); 
                    }
                  }
                  
      
                  //Ajout Socket
                  //On envoie aux hotliners
                  if(this.currentUser.statut == "Interne")  this.notificationService.addNotification("Interne", 0, userID, new Date(), "Vous avez un nouveau message.");
                }
              }
            },
            (error) => {
              console.log('Erreur ! : ' + error);
            }
          );
          //Destruction de la souscription
          this.listSubscription.push(variable3)
        }

        // On vide la variable dédiée au destinataire
        this.messagerieTicketsSerivice.selectedInterneTransfert = ''
        this.messagerieTicketsSerivice.commentaireTransfert = ''
      }
    });
  }

  checkDestinataireAlreadyIn(listAccesUsers: any[], selectedInterneTransfert: string) {
    let exist = false
    for (let value of listAccesUsers) {
      if (value === selectedInterneTransfert.toString()) exist = true
    }
    return exist
  }

}
