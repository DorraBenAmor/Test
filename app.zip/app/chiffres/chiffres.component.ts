import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { MessagerieTicketsService } from '../services/messagerie_tickets.service';
import { UserList } from '../services/user-list.service';

@Component({
  selector: 'app-chiffres',
  templateUrl: './chiffres.component.html',
  styleUrls: ['./chiffres.component.css']
})
export class ChiffresComponent implements OnInit, OnDestroy {

  // DECLARATION DES VARIABLES

  // 4 données à afficher
  nbTicketsOuverts: number;
  nbTicketsFermes: number;
  nbUsersInternes: number;
  nbUsersExternes: number;

  listSubscription = <Subscription[]>[];

  constructor(private userService: UserList, private messagerieTicketsSerivice: MessagerieTicketsService) { }

  ngOnInit(): void {
    // Initialisation des variables
    this.nbTicketsOuverts = 0;
    this.nbTicketsFermes = 0;
    this.nbUsersInternes = 0;
    this.nbUsersExternes = 0;

    const variable1 = this.messagerieTicketsSerivice.getNbTicketsFermes().subscribe((response) => {
      this.nbTicketsFermes = JSON.parse(JSON.stringify(response)).data[0].nb
    });
    //Détruire la souscription
    this.listSubscription.push(variable1)

    const variable2 = this.messagerieTicketsSerivice.getNbTicketsOuverts().subscribe((response) => {
      this.nbTicketsOuverts = JSON.parse(JSON.stringify(response)).data[0].nb
    });
    //Détruire la souscription
    this.listSubscription.push(variable2);

    const variable3 = this.userService.getNbInternes().subscribe((response) => {
      this.nbUsersInternes = JSON.parse(JSON.stringify(response)).data[0].nb
    });
    //Détruire la souscription
    this.listSubscription.push(variable1)

    const variable4 = this.userService.getNbExternes().subscribe((response) => {
      this.nbUsersExternes = JSON.parse(JSON.stringify(response)).data[0].nb
    });
    //Détruire la souscription
    this.listSubscription.push(variable2);
    
  }

  ngOnDestroy(): void {
    this.listSubscription.map((elem) => elem.unsubscribe());
  }

}
