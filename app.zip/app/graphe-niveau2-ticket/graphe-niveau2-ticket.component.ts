import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { FicheModel } from '../models/fiche.model';
import { DashboardService } from '../services/dashboard.service';
import { Connection } from '../models/connection.model';
import { ConnexionService } from '../services/connexion.service'
import { StatService } from '../services/statistique.service';

interface dataLabel{
  data: any[];
  label: string;   
}
@Component({
  selector: 'app-graphe-niveau2-ticket',
  templateUrl: './graphe-niveau2-ticket.component.html',
  styleUrls: ['./graphe-niveau2-ticket.component.css']
})
export class GrapheNiveau2TicketComponent implements OnInit, OnDestroy {

  /**Déclaration des variables**/

  // Données du user connecté
  currentUser: Connection;
  private subscription: Subscription;

  //Données de la BDD
  dashboardComponents: any[] = [];
  listeEntreprises: any[] = []
  listeEntreprisesBases: any[] = []
  
  //Paramètres Groupement niveau 2 BarChart
  //Selection menu
  selectedGroup1: string;
  selectedGroup2: string;
  selectedOptionTicket: string;
  erreurGroupeManquant: boolean = false;
  erreurGroupesIdentiques: boolean = false;
  //Chart
  barChartReady: boolean = false;
  barChartOptions;
  public barChartLabels: any[] = [];
  public barChartType: string;
  public barChartLegend: boolean;
  public barChartData: any[] = [];
  legende: string
  //Data
  fichesFiltered: FicheModel[] = [];
  dataSet: any[] = [];
  // Choix de menu
  selectedEntreprises1 = new FormControl()
  selectedEntreprises2 = new FormControl()
  selectedBases1 = new FormControl()
  selectedBases2 = new FormControl()
  //Choix de periode
  periode: string = "";
  fichesPeriode: FicheModel[] = [];
  //Saisie période
  debut: Date;
  fin: Date;
  erreurPeriodeManquante: boolean = false;
  erreurPeriodeIncorrect: boolean = false;
  //Legende
  barChartLegende: string = "";

  //Chemin de la page
  href: string;
  
  listSubscription = <Subscription[]>[];


  constructor(private statService: StatService, private router: Router, private connexionService: ConnexionService, private dashboardService: DashboardService) { }

  ngOnInit(): void {
    // Initialisation des variables
    this.href = this.router.url
    this.selectedGroup1 = "Etat"
    this.selectedGroup2 = "Type d\'objet"
    this.selectedOptionTicket = "Nombre"
    this.periode = "Tout"
    //Paramétrage BarChart
    this.barChartOptions = {
      scaleShowVerticalLines: false,
      responsive: true,
      legend: {position: 'right',
      /*
        // Barrer toutes les légendes sauf celui qu'on clique
        onClick: function(e, legendItem) {
          var index = legendItem.datasetIndex;
          var ci = this.chart;
          var alreadyHidden = (ci.getDatasetMeta(index).hidden === null) ? false : ci.getDatasetMeta(index).hidden;

          ci.data.datasets.forEach(function(e, i) {
            var meta = ci.getDatasetMeta(i);

            if (i !== index) {
              if (!alreadyHidden) {
                meta.hidden = meta.hidden === null ? !meta.hidden : null;
              } else if (meta.hidden === null) {
                meta.hidden = true;
              }
            } else if (i === index) {
              meta.hidden = null;
            }
          });

          ci.update();
        }*/
      }
    };
    this.barChartLegend = true;
    this.barChartType = 'bar';

    // Récupération des données du user connecté
    this.subscription = this.connexionService.connexionSubject.subscribe(datas => {
      this.currentUser = datas
      if (this.currentUser.statut === 'Externe') {
        this.selectedGroup1 = "Entreprise - Base"
        this.selectedGroup2 = "Type d\'objet"
      }
    })
    this.connexionService.emitConnection()

    const variable = this.statService.getEntreprisesFromFiches().subscribe((res) => {
      this.listeEntreprises = JSON.parse(JSON.stringify(res)).data
    });
    this.listSubscription.push(variable)

    const variable2 = this.statService.getEntreprisesBasesFromFiches().subscribe((res) => {
      this.listeEntreprisesBases = JSON.parse(JSON.stringify(res)).data
    });
    this.listSubscription.push(variable2)

    // Lancement
    this.chargementBarChart();
  }

  ngOnDestroy(): void {
    this.listSubscription.map((elem) => elem.unsubscribe());
    this.subscription.unsubscribe();
  }

  activeLegend() {
    this.barChartLegend = !this.barChartLegend
  }

  handleDebutInput(value: Date) {
    this.debut = value;
    console.log(this.debut, "Debut");
  }
  handleFinInput(value: Date) {
    this.fin = value;
    console.log(this.fin, "Fin");
  }

  /** Bar Chart methods */

  handleClickPeriode(periode: string){
    this.periode = periode
    if (this.periode !== 'Periode') this.chargementBarChart()
    else  this.chargementPeriode()
  }

  chargementPeriode(){
    this.erreurPeriodeManquante = false
    this.erreurPeriodeIncorrect = false
    if(this.debut == undefined || this.fin == undefined){
      this.erreurPeriodeManquante = true
    }
    if(this.debut > this.fin){
      this.erreurPeriodeIncorrect = true
    }
    if(this.debut <= this.fin && this.debut != undefined && this.fin != undefined){
      this.chargementBarChart()
    }
  }


  chargementBarChart(){

    this.erreurGroupeManquant = false;
    this.erreurGroupesIdentiques = false;
    if(this.selectedGroup1 == undefined || this.selectedGroup2 == undefined)  this.erreurGroupeManquant = true;
    if(this.selectedGroup1 == this.selectedGroup2 && this.selectedGroup1 != undefined && this.selectedGroup2 != undefined)  this.erreurGroupesIdentiques = true;
    
    if(this.erreurGroupeManquant == false && this.erreurGroupesIdentiques == false){
      console.log('before canLaunch')
      let canLaunch = true
      if (this.selectedGroup1 === 'Entreprise - Base' && (this.selectedEntreprises1.value === null || this.selectedBases1.value === null || this.selectedEntreprises1.value.length === 0 || this.selectedBases1.value.length === 0)) canLaunch = false
      if (this.selectedGroup2 === 'Entreprise - Base' && (this.selectedEntreprises2.value === null || this.selectedBases2.value === null || this.selectedEntreprises2.value.length === 0 || this.selectedBases2.value.length === 0)) canLaunch = false
      if (this.selectedGroup1 === 'Entreprise' && (this.selectedEntreprises1.value === null || this.selectedEntreprises1.value.length === 0)) canLaunch = false
      if (this.selectedGroup2 === 'Entreprise' && (this.selectedEntreprises2.value === null || this.selectedEntreprises2.value.length === 0)) canLaunch = false
      if (this.selectedGroup1 === 'Base' && (this.selectedBases1.value === null || this.selectedBases1.value.length === 0)) canLaunch = false
      if (this.selectedGroup2 === 'Base' && (this.selectedBases2.value === null || this.selectedBases2.value.length === 0)) canLaunch = false
      console.log(canLaunch, 'canLaunch')
      if (canLaunch === true) this.chargementDonnees()
    }
  }

  chargementDonnees() {
    let dateDebut
    let dateFin
    if (this.periode === 'Periode') {
      dateDebut = new Date(this.debut)
      dateFin = new Date(this.fin)
    }

    let listeEntrepriseBase = []

    // Pour la récupération de la bonne donnée dans la BDD
    if(this.selectedGroup1 === 'Entreprise - Base' && this.selectedEntreprises1.value !== null && this.selectedBases1.value !== null)  listeEntrepriseBase = this.getListEntrepriseBaseSelected(this.selectedEntreprises1.value, this.selectedBases1.value)
    if(this.selectedGroup1 === 'Entreprise' && this.selectedGroup2 !== 'Base' && this.selectedEntreprises1.value !== null)  listeEntrepriseBase = this.selectedEntreprises1.value
    if(this.selectedGroup1 === 'Entreprise' && this.selectedGroup2 === 'Base' && this.selectedEntreprises1.value !== null && this.selectedBases2.value !== null)  listeEntrepriseBase = this.getListEntrepriseBaseSelected(this.selectedEntreprises1.value, this.selectedBases2.value)

    if(this.selectedGroup2 === 'Entreprise - Base' && this.selectedEntreprises2.value !== null && this.selectedBases2.value !== null)  listeEntrepriseBase = this.getListEntrepriseBaseSelected(this.selectedEntreprises2.value, this.selectedBases2.value)
    if(this.selectedGroup2 === 'Entreprise' && this.selectedGroup1 !== 'Base' && this.selectedEntreprises2.value !== null)  listeEntrepriseBase = this.selectedEntreprises2.value
    if(this.selectedGroup2 === 'Entreprise' && this.selectedGroup1 === 'Base' && this.selectedEntreprises2.value !== null && this.selectedBases1.value !== null)  listeEntrepriseBase = this.getListEntrepriseBaseSelected(this.selectedEntreprises2.value, this.selectedBases1.value)

    
    let legendes = []
    this.barChartLabels = []
    let dataLabel: dataLabel[] = []
    let labels = []

    switch(this.periode) {
      case "Tout":
        // 1er grouppement
        if(this.selectedGroup1 === "Entreprise - Base") {
          this.legende = 'Nombre total de tickets ouverts par base filtré par ' + this.selectedGroup2.toLowerCase()
          // 2nd grouppement
          // Application du filtre
          this.statService.filtreEntreprise = []
          this.statService.filtreEntreprise.push(this.selectedGroup2)
          this.statService.filtreEntreprise.push(listeEntrepriseBase)
          console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
          const variable = this.statService.getStatNbTicketsToutEntrepriseBaseFiltre().subscribe((res) => {
            // Récupération des données de la table StatNombreTickets
            var statNbTickets = JSON.parse(JSON.stringify(res)).data
            console.log(statNbTickets, 'statNbTickets')

            // Alimentation légende
            for(let row of statNbTickets) {
              if(!legendes.includes(row.entreprise + " - " + row.base)) legendes.push(row.entreprise + " - " + row.base)
              if(!this.barChartLabels.includes(row.categorie)) this.barChartLabels.push(row.categorie);
            }

            // Alimentation des données
            this.barChartReady = false
            this.barChartData = [];

            for (let legende of legendes){
              this.barChartData.push({data: [], label: legende, stack: 'a'});
              for (let label of this.barChartLabels){
                this.barChartData[this.barChartData.length - 1].data.push(0)
                for (let row of statNbTickets)
                if (legende === row.entreprise + " - " + row.base && label === row.categorie) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
              }
            }

            this.barChartReady = true;
          })
          this.listSubscription.push(variable);
        }

        // 1er grouppement
        if(this.selectedGroup1 === "Entreprise") {
          // 2nd grouppement
          if(this.selectedGroup2 === 'Etat' || this.selectedGroup2 === 'Impact' || this.selectedGroup2 === 'Type d\'objet' || this.selectedGroup2 === 'Module' || this.selectedGroup2 === 'Ordre de priorité' || this.selectedGroup2 === 'Responsable de dossier') {
            this.legende = 'Nombre total de tickets ouverts par entreprise filtré par ' + this.selectedGroup2.toLowerCase()
            // Application du filtre
            this.statService.filtreEntreprise = []
            this.statService.filtreEntreprise.push(this.selectedGroup2)
            this.statService.filtreEntreprise.push(listeEntrepriseBase)
            console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
            const variable = this.statService.getStatNbTicketsToutEntrepriseFiltre().subscribe((res) => {
              // Récupération des données de la table StatNombreTickets
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              // Alimentation légende
              for(let row of statNbTickets) {
                if(!legendes.includes(row.entreprise)) legendes.push(row.entreprise)
                if(!this.barChartLabels.includes(row.categorie)) this.barChartLabels.push(row.categorie);
              }

              // Alimentation des données
              this.barChartReady = false
              this.barChartData = [];

              for (let legende of legendes){
                this.barChartData.push({data: [], label: legende, stack: 'a'});
                for (let label of this.barChartLabels){
                  this.barChartData[this.barChartData.length - 1].data.push(0)
                  for (let row of statNbTickets)
                  if (legende === row.entreprise && label === row.categorie) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                }
              }

              this.barChartReady = true;
            })
            this.listSubscription.push(variable);
          }
          
          // 1er grouppement
          if(this.selectedGroup2 === 'Base') {
            this.legende = 'Nombre total de tickets ouverts par entreprise filtré par ' + this.selectedGroup2.toLowerCase()
            // Application du filtre
            this.statService.filtreEntreprise = []
            this.statService.filtreEntreprise.push(listeEntrepriseBase)
            console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
            const variable = this.statService.getStatNbTicketsToutEntrepriseBase().subscribe((res) => {
              // Récupération des données de la table StatNombreTickets
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              // Alimentation légende
              labels = []
              for(let row of statNbTickets) {
                if(!legendes.includes(row.entreprise)) legendes.push(row.entreprise)
                if(!this.barChartLabels.includes(row.base)) this.barChartLabels.push(row.base)
              }

              // Alimentation des données
              this.barChartReady = false
              this.barChartData = [];

              for (let legende of legendes){
                this.barChartData.push({data: [], label: legende, stack: 'a'});
                for (let label of this.barChartLabels){
                  this.barChartData[this.barChartData.length - 1].data.push(0)
                  for (let row of statNbTickets)
                  if (legende === row.entreprise && label === row.base) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                }
              }

              this.barChartReady = true;
            })
            this.listSubscription.push(variable);
          }
        }

        // 1er grouppement
        if (this.selectedGroup1 === 'Base') {
          // 2nd grouppement
          switch(this.selectedGroup2){
            case "Entreprise":
              this.legende = 'Nombre total de tickets ouverts par base filtré par ' + this.selectedGroup2.toLowerCase()
              // Application du filtre
              this.statService.filtreEntreprise = []
              this.statService.filtreEntreprise.push(listeEntrepriseBase)
              console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
              const variable = this.statService.getStatNbTicketsToutEntrepriseBase().subscribe((res) => {
                // Récupération des données de la table StatNombreTickets
                var statNbTickets = JSON.parse(JSON.stringify(res)).data
                console.log(statNbTickets, 'statNbTickets')

                // Alimentation légende
                labels = []
                for(let row of statNbTickets) {
                  if(!legendes.includes(row.base)) legendes.push(row.base)
                  if(!this.barChartLabels.includes(row.entreprise)) this.barChartLabels.push(row.entreprise)
                }

                // Alimentation des données
                this.barChartReady = false
                this.barChartData = [];

                for (let legende of legendes){
                  this.barChartData.push({data: [], label: legende, stack: 'a'});
                  for (let label of this.barChartLabels){
                    this.barChartData[this.barChartData.length - 1].data.push(0)
                    for (let row of statNbTickets)
                    if (legende === row.base && label === row.entreprise) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                  }
                }

                this.barChartReady = true;
              })
              this.listSubscription.push(variable);
              break;
          }
        }

        // 1er grouppement
        if (this.selectedGroup1 === 'Etat' || this.selectedGroup1 === 'Impact' || this.selectedGroup1 === 'Type d\'objet' || this.selectedGroup1 === 'Module' || this.selectedGroup1 === 'Ordre de priorité' || this.selectedGroup1 === 'Responsable de dossier') {
          console.log('1er')
          // 2nd grouppement
          if (this.selectedGroup2 === 'Entreprise') {
            this.legende = 'Nombre total de tickets ouverts par '+ this.selectedGroup1.toLowerCase() + ' filtré par ' + this.selectedGroup2.toLowerCase()
            // Application du filtre
            this.statService.filtreEntreprise = []
            this.statService.filtreEntreprise.push(this.selectedGroup1)
            this.statService.filtreEntreprise.push(listeEntrepriseBase)
            console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
            const variable = this.statService.getStatNbTicketsToutEntrepriseFiltre().subscribe((res) => {
              // Récupération des données de la table StatNombreTickets
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              // Alimentation légende
              for(let row of statNbTickets) {
                if(!legendes.includes(row.categorie)) legendes.push(row.categorie)
                if(!this.barChartLabels.includes(row.entreprise)) this.barChartLabels.push(row.entreprise);
              }

              // Alimentation des données
              this.barChartReady = false
              this.barChartData = [];

              for (let legende of legendes){
                this.barChartData.push({data: [], label: legende, stack: 'a'});
                for (let label of this.barChartLabels){
                  this.barChartData[this.barChartData.length - 1].data.push(0)
                  for (let row of statNbTickets)
                  if (legende === row.categorie && label === row.entreprise)  this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                }
              }

              this.barChartReady = true;
            })
            this.listSubscription.push(variable);
          }

          // 2nd grouppement
          if (this.selectedGroup2 === 'Entreprise - Base') {
             this.legende = 'Nombre total de tickets ouverts par '+ this.selectedGroup1.toLowerCase() + ' filtré par base'
            // Application du filtre
            this.statService.filtreEntreprise = []
            this.statService.filtreEntreprise.push(this.selectedGroup1)
            this.statService.filtreEntreprise.push(listeEntrepriseBase)
            console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
            const variable = this.statService.getStatNbTicketsToutEntrepriseBaseFiltre().subscribe((res) => {
              // Récupération des données de la table StatNombreTickets
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              // Alimentation légende
              for(let row of statNbTickets) {
                if(!legendes.includes(row.categorie)) legendes.push(row.categorie)
                if(!this.barChartLabels.includes(row.entreprise + " - " + row.base)) this.barChartLabels.push(row.entreprise + " - " + row.base);
              }

              // Alimentation des données
              this.barChartReady = false
              this.barChartData = [];

              for (let legende of legendes){
                this.barChartData.push({data: [], label: legende, stack: 'a'});
                for (let label of this.barChartLabels){
                  this.barChartData[this.barChartData.length - 1].data.push(0)
                  for (let row of statNbTickets)
                  if (legende === row.categorie && label === row.entreprise + " - " + row.base) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                }
              }

              this.barChartReady = true
            })
            this.listSubscription.push(variable);
          }
          
          // 2nd grouppement
          if (this.selectedGroup2 !== this.selectedGroup1 && (this.selectedGroup2 === 'Etat' || this.selectedGroup2 === 'Impact' || this.selectedGroup2 === 'Type d\'objet' || this.selectedGroup2 === 'Module' || this.selectedGroup2 === 'Ordre de priorité' || this.selectedGroup2 === 'Responsable de dossier')) {
             this.legende = 'Nombre total de tickets ouverts par '+ this.selectedGroup1.toLowerCase() + ' filtré par ' + this.selectedGroup2.toLowerCase()
            // Application du filtre
            this.statService.filtreEntreprise = []
            this.statService.filtreEntreprise.push(this.selectedGroup1)
            this.statService.filtreEntreprise.push(this.selectedGroup2)
            console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
            const variable = this.statService.getStatNbTicketsToutDoubleFiltre().subscribe((res) => {
              // Récupération des données de la table StatNombreTickets
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              // Alimentation légende
              for(let row of statNbTickets) {
                if(this.selectedGroup1 === row.filtre) {
                  if(!legendes.includes(row.categorie)) legendes.push(row.categorie)
                  if(!this.barChartLabels.includes(row.categorie2)) this.barChartLabels.push(row.categorie2);
                }
                else {
                  if(!legendes.includes(row.categorie2)) legendes.push(row.categorie2)
                  if(!this.barChartLabels.includes(row.categorie)) this.barChartLabels.push(row.categorie);
                }
              }

              // Alimentation des données
              this.barChartReady = false
              this.barChartData = []

              for (let legende of legendes){
                this.barChartData.push({data: [], label: legende, stack: 'a'});
                for (let label of this.barChartLabels){
                  this.barChartData[this.barChartData.length - 1].data.push(0)
                  for (let row of statNbTickets)
                  if(this.selectedGroup1 === row.filtre) {
                    if (legende === row.categorie && label === row.categorie2) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                  }
                  else {
                    if (legende === row.categorie2 && label === row.categorie) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                  } 
                }
              }

              this.barChartReady = true;
            })
            this.listSubscription.push(variable);
          }
        }
        break

      case "Année":
        // 1er grouppement
        if(this.selectedGroup1 === "Entreprise - Base") {
          this.legende = 'Nombre total de tickets ouverts cette année par base et filtré par ' + this.selectedGroup2.toLowerCase()
          // 2nd grouppement
          // Application du filtre
          this.statService.filtreEntreprise = []
          this.statService.filtreEntreprise.push(this.selectedGroup2)
          this.statService.filtreEntreprise.push(listeEntrepriseBase)
          console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
          const variable = this.statService.getStatNbTicketsAnneeEntrepriseBaseFiltre().subscribe((res) => {
            // Récupération des données de la table StatNombreTickets
            var statNbTickets = JSON.parse(JSON.stringify(res)).data
            console.log(statNbTickets, 'statNbTickets')

            // Alimentation légende
            for(let row of statNbTickets) {
              if(!legendes.includes(row.entreprise + " - " + row.base)) legendes.push(row.entreprise + " - " + row.base)
              if(!this.barChartLabels.includes(row.categorie)) this.barChartLabels.push(row.categorie);
            }

            // Alimentation des données
            this.barChartReady = false
            this.barChartData = [];

            for (let legende of legendes){
              this.barChartData.push({data: [], label: legende, stack: 'a'});
              for (let label of this.barChartLabels){
                this.barChartData[this.barChartData.length - 1].data.push(0)
                for (let row of statNbTickets)
                if (legende === row.entreprise + " - " + row.base && label === row.categorie) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
              }
            }

            this.barChartReady = true;
          })
          this.listSubscription.push(variable);
        }

        // 1er grouppement
        if(this.selectedGroup1 === "Entreprise") {
          console.log('here0')
          // 2nd grouppement
          if(this.selectedGroup2 === 'Etat' || this.selectedGroup2 === 'Impact' || this.selectedGroup2 === 'Type d\'objet' || this.selectedGroup2 === 'Module' || this.selectedGroup2 === 'Ordre de priorité' || this.selectedGroup2 === 'Responsable de dossier') {
            this.legende = 'Nombre total de tickets ouverts cette année par enteprise et filtré par ' + this.selectedGroup2.toLowerCase()
            // Application du filtre
            this.statService.filtreEntreprise = []
            this.statService.filtreEntreprise.push(this.selectedGroup2)
            this.statService.filtreEntreprise.push(listeEntrepriseBase)
            console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
            const variable = this.statService.getStatNbTicketsAnneeEntrepriseFiltre().subscribe((res) => {
              // Récupération des données de la table StatNombreTickets
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              // Alimentation légende
              for(let row of statNbTickets) {
                if(!legendes.includes(row.entreprise)) legendes.push(row.entreprise)
                if(!this.barChartLabels.includes(row.categorie)) this.barChartLabels.push(row.categorie);
              }

              // Alimentation des données
              this.barChartReady = false
              this.barChartData = [];

              for (let legende of legendes){
                this.barChartData.push({data: [], label: legende, stack: 'a'});
                for (let label of this.barChartLabels){
                  this.barChartData[this.barChartData.length - 1].data.push(0)
                  for (let row of statNbTickets)
                  if (legende === row.entreprise && label === row.categorie) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                }
              }

              this.barChartReady = true;
            })
            this.listSubscription.push(variable);
          }
          
          // 1er grouppement
          if(this.selectedGroup2 === 'Base') {
            this.legende = 'Nombre total de tickets ouverts cette année par entreprise et filtré par ' + this.selectedGroup2.toLowerCase()
            // Application du filtre
            this.statService.filtreEntreprise = []
            this.statService.filtreEntreprise.push(listeEntrepriseBase)
            console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
            const variable = this.statService.getStatNbTicketsAnneeEntrepriseBase().subscribe((res) => {
              // Récupération des données de la table StatNombreTickets
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              // Alimentation légende
              this.barChartReady = false
              labels = []
              for(let row of statNbTickets) {
                if(!legendes.includes(row.entreprise)) legendes.push(row.entreprise)
                if(!this.barChartLabels.includes(row.base)) this.barChartLabels.push(row.base)
              }

              // Alimentation des données
              this.barChartData = [];

              for (let legende of legendes){
                this.barChartData.push({data: [], label: legende, stack: 'a'});
                for (let label of this.barChartLabels){
                  this.barChartData[this.barChartData.length - 1].data.push(0)
                  for (let row of statNbTickets)
                  if (legende === row.entreprise && label === row.base) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                }
              }

              this.barChartReady = true;
            })
            this.listSubscription.push(variable);
          }
        }

        // 1er grouppement
        if (this.selectedGroup1 === 'Base') {
          // 2nd grouppement
          switch(this.selectedGroup2){
            case "Entreprise":
            this.legende = 'Nombre total de tickets ouverts cette année par base et filtré par ' + this.selectedGroup2.toLowerCase()
              // Application du filtre
              this.statService.filtreEntreprise = []
              this.statService.filtreEntreprise.push(listeEntrepriseBase)
              console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
              const variable = this.statService.getStatNbTicketsAnneeEntrepriseBase().subscribe((res) => {
                // Récupération des données de la table StatNombreTickets
                var statNbTickets = JSON.parse(JSON.stringify(res)).data
                console.log(statNbTickets, 'statNbTickets')

                // Alimentation légende
                labels = []
                for(let row of statNbTickets) {
                  if(!legendes.includes(row.base)) legendes.push(row.base)
                  if(!this.barChartLabels.includes(row.entreprise)) this.barChartLabels.push(row.entreprise)
                }

                // Alimentation des données
                this.barChartReady = false
                this.barChartData = [];

                for (let legende of legendes){
                  this.barChartData.push({data: [], label: legende, stack: 'a'});
                  for (let label of this.barChartLabels){
                    this.barChartData[this.barChartData.length - 1].data.push(0)
                    for (let row of statNbTickets)
                    if (legende === row.base && label === row.entreprise) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                  }
                }

                this.barChartReady = true;
              })
              this.listSubscription.push(variable);
              break;
          }
        }

        // 1er grouppement
        if (this.selectedGroup1 === 'Etat' || this.selectedGroup1 === 'Impact' || this.selectedGroup1 === 'Type d\'objet' || this.selectedGroup1 === 'Module' || this.selectedGroup1 === 'Ordre de priorité' || this.selectedGroup1 === 'Responsable de dossier') {
          console.log('1er')
          // 2nd grouppement
          if (this.selectedGroup2 === 'Entreprise') {
            this.legende = 'Nombre total de tickets ouverts cette année par ' + this.selectedGroup1.toLowerCase() + ' et filtré par ' + this.selectedGroup2.toLowerCase()
            // Application du filtre
            this.statService.filtreEntreprise = []
            this.statService.filtreEntreprise.push(this.selectedGroup1)
            this.statService.filtreEntreprise.push(listeEntrepriseBase)
            console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
            const variable = this.statService.getStatNbTicketsAnneeEntrepriseFiltre().subscribe((res) => {
              // Récupération des données de la table StatNombreTickets
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              // Alimentation légende
              for(let row of statNbTickets) {
                if(!legendes.includes(row.categorie)) legendes.push(row.categorie)
                if(!this.barChartLabels.includes(row.entreprise)) this.barChartLabels.push(row.entreprise);
              }

              // Alimentation des données
              this.barChartReady = false
              this.barChartData = [];

              for (let legende of legendes){
                this.barChartData.push({data: [], label: legende, stack: 'a'});
                for (let label of this.barChartLabels){
                  this.barChartData[this.barChartData.length - 1].data.push(0)
                  for (let row of statNbTickets)
                  if (legende === row.categorie && label === row.entreprise)  this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                }
              }

              this.barChartReady = true;
            })
            this.listSubscription.push(variable);
          }

          // 2nd grouppement
          if (this.selectedGroup2 === 'Entreprise - Base') {
            this.legende = 'Nombre total de tickets ouverts cette année par ' + this.selectedGroup1.toLowerCase() + ' et filtré par base'
            // Application du filtre
            this.statService.filtreEntreprise = []
            this.statService.filtreEntreprise.push(this.selectedGroup1)
            this.statService.filtreEntreprise.push(listeEntrepriseBase)
            console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
            const variable = this.statService.getStatNbTicketsAnneeEntrepriseBaseFiltre().subscribe((res) => {
              // Récupération des données de la table StatNombreTickets
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              // Alimentation légende
              for(let row of statNbTickets) {
                if(!legendes.includes(row.categorie)) legendes.push(row.categorie)
                if(!this.barChartLabels.includes(row.entreprise + " - " + row.base)) this.barChartLabels.push(row.entreprise + " - " + row.base);
              }

              // Alimentation des données
              this.barChartReady = false
              this.barChartData = [];

              for (let legende of legendes){
                this.barChartData.push({data: [], label: legende, stack: 'a'});
                for (let label of this.barChartLabels){
                  this.barChartData[this.barChartData.length - 1].data.push(0)
                  for (let row of statNbTickets)
                  if (legende === row.categorie && label === row.entreprise + " - " + row.base) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                }
              }

              this.barChartReady = true
            })
            this.listSubscription.push(variable);
          }
          
          // 2nd grouppement
          if (this.selectedGroup2 !== this.selectedGroup1 && (this.selectedGroup2 === 'Etat' || this.selectedGroup2 === 'Impact' || this.selectedGroup2 === 'Type d\'objet' || this.selectedGroup2 === 'Module' || this.selectedGroup2 === 'Ordre de priorité' || this.selectedGroup2 === 'Responsable de dossier')) {
            this.legende = 'Nombre total de tickets ouverts cette année par ' + this.selectedGroup1.toLowerCase() + ' et filtré par ' + this.selectedGroup2.toLowerCase()
            // Application du filtre
            this.statService.filtreEntreprise = []
            this.statService.filtreEntreprise.push(this.selectedGroup1)
            this.statService.filtreEntreprise.push(this.selectedGroup2)
            console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
            const variable = this.statService.getStatNbTicketsAnneeDoubleFiltre().subscribe((res) => {
              // Récupération des données de la table StatNombreTickets
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              // Alimentation légende
              for(let row of statNbTickets) {
                if(this.selectedGroup1 === row.filtre) {
                  if(!legendes.includes(row.categorie)) legendes.push(row.categorie)
                  if(!this.barChartLabels.includes(row.categorie2)) this.barChartLabels.push(row.categorie2);
                }
                else {
                  if(!legendes.includes(row.categorie2)) legendes.push(row.categorie2)
                  if(!this.barChartLabels.includes(row.categorie)) this.barChartLabels.push(row.categorie);
                }
              }

              // Alimentation des données
              this.barChartReady = false
              this.barChartData = []

              for (let legende of legendes){
                this.barChartData.push({data: [], label: legende, stack: 'a'});
                for (let label of this.barChartLabels){
                  this.barChartData[this.barChartData.length - 1].data.push(0)
                  for (let row of statNbTickets)
                  if(this.selectedGroup1 === row.filtre) {
                    if (legende === row.categorie && label === row.categorie2) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                  }
                  else {
                    if (legende === row.categorie2 && label === row.categorie) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                  } 
                }
              }

              this.barChartReady = true;
            })
            this.listSubscription.push(variable);
          }
        }
        break

      case "Mois":
        // 1er grouppement
        if(this.selectedGroup1 === "Entreprise - Base") {
          // 2nd grouppement
          this.legende = 'Nombre total de tickets ouverts ce mois-ci par base et filtré par ' + this.selectedGroup2.toLowerCase()
          // Application du filtre
          this.statService.filtreEntreprise = []
          this.statService.filtreEntreprise.push(this.selectedGroup2)
          this.statService.filtreEntreprise.push(listeEntrepriseBase)
          console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
          const variable = this.statService.getStatNbTicketsMoisEntrepriseBaseFiltre().subscribe((res) => {
            // Récupération des données de la table StatNombreTickets
            var statNbTickets = JSON.parse(JSON.stringify(res)).data
            console.log(statNbTickets, 'statNbTickets')

            // Alimentation légende
            for(let row of statNbTickets) {
              if(!legendes.includes(row.entreprise + " - " + row.base)) legendes.push(row.entreprise + " - " + row.base)
              if(!this.barChartLabels.includes(row.categorie)) this.barChartLabels.push(row.categorie);
            }

            // Alimentation des données
            this.barChartReady = false
            this.barChartData = [];

            for (let legende of legendes){
              this.barChartData.push({data: [], label: legende, stack: 'a'});
              for (let label of this.barChartLabels){
                this.barChartData[this.barChartData.length - 1].data.push(0)
                for (let row of statNbTickets)
                if (legende === row.entreprise + " - " + row.base && label === row.categorie) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
              }
            }

            this.barChartReady = true;
          })
          this.listSubscription.push(variable);
        }

        // 1er grouppement
        if(this.selectedGroup1 === "Entreprise") {
          console.log('here0')
          // 2nd grouppement
          if(this.selectedGroup2 === 'Etat' || this.selectedGroup2 === 'Impact' || this.selectedGroup2 === 'Type d\'objet' || this.selectedGroup2 === 'Module' || this.selectedGroup2 === 'Ordre de priorité' || this.selectedGroup2 === 'Responsable de dossier') {
            this.legende = 'Nombre total de tickets ouverts ce mois-ci par entreprise et filtré par ' + this.selectedGroup2.toLowerCase()
            // Application du filtre
            this.statService.filtreEntreprise = []
            this.statService.filtreEntreprise.push(this.selectedGroup2)
            this.statService.filtreEntreprise.push(listeEntrepriseBase)
            console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
            const variable = this.statService.getStatNbTicketsMoisEntrepriseFiltre().subscribe((res) => {
              // Récupération des données de la table StatNombreTickets
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              // Alimentation légende
              for(let row of statNbTickets) {
                if(!legendes.includes(row.entreprise)) legendes.push(row.entreprise)
                if(!this.barChartLabels.includes(row.categorie)) this.barChartLabels.push(row.categorie);
              }

              // Alimentation des données
              this.barChartReady = false
              this.barChartData = [];

              for (let legende of legendes){
                this.barChartData.push({data: [], label: legende, stack: 'a'});
                for (let label of this.barChartLabels){
                  this.barChartData[this.barChartData.length - 1].data.push(0)
                  for (let row of statNbTickets)
                  if (legende === row.entreprise && label === row.categorie) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                }
              }

              this.barChartReady = true;
            })
            this.listSubscription.push(variable);
          }
          
          // 1er grouppement
          if(this.selectedGroup2 === 'Base') {
            this.legende = 'Nombre total de tickets ouverts ce mois-ci par entreprise et filtré par ' + this.selectedGroup2.toLowerCase()
            // Application du filtre
            this.statService.filtreEntreprise = []
            this.statService.filtreEntreprise.push(listeEntrepriseBase)
            console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
            const variable = this.statService.getStatNbTicketsMoisEntrepriseBase().subscribe((res) => {
              // Récupération des données de la table StatNombreTickets
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              // Alimentation légende
              labels = []
              for(let row of statNbTickets) {
                if(!legendes.includes(row.entreprise)) legendes.push(row.entreprise)
                if(!this.barChartLabels.includes(row.base)) this.barChartLabels.push(row.base)
              }

              // Alimentation des données
              this.barChartReady = false
              this.barChartData = [];

              for (let legende of legendes){
                this.barChartData.push({data: [], label: legende, stack: 'a'});
                for (let label of this.barChartLabels){
                  this.barChartData[this.barChartData.length - 1].data.push(0)
                  for (let row of statNbTickets)
                  if (legende === row.entreprise && label === row.base) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                }
              }

              this.barChartReady = true;
            })
            this.listSubscription.push(variable);
          }
        }

        // 1er grouppement
        if (this.selectedGroup1 === 'Base') {
          // 2nd grouppement
          switch(this.selectedGroup2){
            case "Entreprise":
              this.legende = 'Nombre total de tickets ouverts ce mois-ci par base et filtré par ' + this.selectedGroup2.toLowerCase()
              // Application du filtre
              this.statService.filtreEntreprise = []
              this.statService.filtreEntreprise.push(listeEntrepriseBase)
              console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
              const variable = this.statService.getStatNbTicketsMoisEntrepriseBase().subscribe((res) => {
                // Récupération des données de la table StatNombreTickets
                var statNbTickets = JSON.parse(JSON.stringify(res)).data
                console.log(statNbTickets, 'statNbTickets')

                // Alimentation légende
                labels = []
                for(let row of statNbTickets) {
                  if(!legendes.includes(row.base)) legendes.push(row.base)
                  if(!this.barChartLabels.includes(row.entreprise)) this.barChartLabels.push(row.entreprise)
                }

                // Alimentation des données
                this.barChartReady = false
                this.barChartData = [];

                for (let legende of legendes){
                  this.barChartData.push({data: [], label: legende, stack: 'a'});
                  for (let label of this.barChartLabels){
                    this.barChartData[this.barChartData.length - 1].data.push(0)
                    for (let row of statNbTickets)
                    if (legende === row.base && label === row.entreprise) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                  }
                }

                this.barChartReady = true;
              })
              this.listSubscription.push(variable);
              break;
          }
        }

        // 1er grouppement
        if (this.selectedGroup1 === 'Etat' || this.selectedGroup1 === 'Impact' || this.selectedGroup1 === 'Type d\'objet' || this.selectedGroup1 === 'Module' || this.selectedGroup1 === 'Ordre de priorité' || this.selectedGroup1 === 'Responsable de dossier') {
          console.log('1er')
          // 2nd grouppement
          if (this.selectedGroup2 === 'Entreprise') {
            this.legende = 'Nombre total de tickets ouverts ce mois-ci par ' + this.selectedGroup1.toLowerCase() + ' et filtré par ' + this.selectedGroup2.toLowerCase()
            // Application du filtre
            this.statService.filtreEntreprise = []
            this.statService.filtreEntreprise.push(this.selectedGroup1)
            this.statService.filtreEntreprise.push(listeEntrepriseBase)
            console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
            const variable = this.statService.getStatNbTicketsMoisEntrepriseFiltre().subscribe((res) => {
              // Récupération des données de la table StatNombreTickets
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              // Alimentation légende
              for(let row of statNbTickets) {
                if(!legendes.includes(row.categorie)) legendes.push(row.categorie)
                if(!this.barChartLabels.includes(row.entreprise)) this.barChartLabels.push(row.entreprise);
              }

              // Alimentation des données
              this.barChartReady = false
              this.barChartData = [];

              for (let legende of legendes){
                this.barChartData.push({data: [], label: legende, stack: 'a'});
                for (let label of this.barChartLabels){
                  this.barChartData[this.barChartData.length - 1].data.push(0)
                  for (let row of statNbTickets)
                  if (legende === row.categorie && label === row.entreprise)  this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                }
              }

              this.barChartReady = true;
            })
            this.listSubscription.push(variable);
          }

          // 2nd grouppement
          if (this.selectedGroup2 === 'Entreprise - Base') {
            this.legende = 'Nombre total de tickets ouverts ce mois-ci par ' + this.selectedGroup1.toLowerCase() + ' et filtré par base'
            // Application du filtre
            this.statService.filtreEntreprise = []
            this.statService.filtreEntreprise.push(this.selectedGroup1)
            this.statService.filtreEntreprise.push(listeEntrepriseBase)
            console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
            const variable = this.statService.getStatNbTicketsMoisEntrepriseBaseFiltre().subscribe((res) => {
              // Récupération des données de la table StatNombreTickets
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              // Alimentation légende
              for(let row of statNbTickets) {
                if(!legendes.includes(row.categorie)) legendes.push(row.categorie)
                if(!this.barChartLabels.includes(row.entreprise + " - " + row.base)) this.barChartLabels.push(row.entreprise + " - " + row.base);
              }

              // Alimentation des données
              this.barChartReady = false
              this.barChartData = [];

              for (let legende of legendes){
                this.barChartData.push({data: [], label: legende, stack: 'a'});
                for (let label of this.barChartLabels){
                  this.barChartData[this.barChartData.length - 1].data.push(0)
                  for (let row of statNbTickets)
                  if (legende === row.categorie && label === row.entreprise + " - " + row.base) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                }
              }

              this.barChartReady = true
            })
            this.listSubscription.push(variable);
          }
          
          // 2nd grouppement
          if (this.selectedGroup2 !== this.selectedGroup1 && (this.selectedGroup2 === 'Etat' || this.selectedGroup2 === 'Impact' || this.selectedGroup2 === 'Type d\'objet' || this.selectedGroup2 === 'Module' || this.selectedGroup2 === 'Ordre de priorité' || this.selectedGroup2 === 'Responsable de dossier')) {
            this.legende = 'Nombre total de tickets ouverts ce mois-ci par ' + this.selectedGroup1.toLowerCase() + ' et filtré par ' + this.selectedGroup2.toLowerCase()
            // Application du filtre
            this.statService.filtreEntreprise = []
            this.statService.filtreEntreprise.push(this.selectedGroup1)
            this.statService.filtreEntreprise.push(this.selectedGroup2)
            console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
            const variable = this.statService.getStatNbTicketsMoisDoubleFiltre().subscribe((res) => {
              // Récupération des données de la table StatNombreTickets
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              // Alimentation légende
              for(let row of statNbTickets) {
                if(this.selectedGroup1 === row.filtre) {
                  if(!legendes.includes(row.categorie)) legendes.push(row.categorie)
                  if(!this.barChartLabels.includes(row.categorie2)) this.barChartLabels.push(row.categorie2);
                }
                else {
                  if(!legendes.includes(row.categorie2)) legendes.push(row.categorie2)
                  if(!this.barChartLabels.includes(row.categorie)) this.barChartLabels.push(row.categorie);
                }
              }

              // Alimentation des données
              this.barChartReady = false
              this.barChartData = []

              for (let legende of legendes){
                this.barChartData.push({data: [], label: legende, stack: 'a'});
                for (let label of this.barChartLabels){
                  this.barChartData[this.barChartData.length - 1].data.push(0)
                  for (let row of statNbTickets)
                  if(this.selectedGroup1 === row.filtre) {
                    if (legende === row.categorie && label === row.categorie2) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                  }
                  else {
                    if (legende === row.categorie2 && label === row.categorie) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                  } 
                }
              }

              this.barChartReady = true;
            })
            this.listSubscription.push(variable);
          }
        }
        break

      case "Semaine":
        // 1er grouppement
        if(this.selectedGroup1 === "Entreprise - Base") {
          // 2nd grouppement
          this.legende = 'Nombre total de tickets ouverts cette semaine par base et filtré par ' + this.selectedGroup2.toLowerCase()
          // Application du filtre
          this.statService.filtreEntreprise = []
          this.statService.filtreEntreprise.push(this.selectedGroup2)
          this.statService.filtreEntreprise.push(listeEntrepriseBase)
          console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
          const variable = this.statService.getStatNbTicketsSemaineEntrepriseBaseFiltre().subscribe((res) => {
            // Récupération des données de la table StatNombreTickets
            var statNbTickets = JSON.parse(JSON.stringify(res)).data
            console.log(statNbTickets, 'statNbTickets')

            // Alimentation légende
            for(let row of statNbTickets) {
              if(!legendes.includes(row.entreprise + " - " + row.base)) legendes.push(row.entreprise + " - " + row.base)
              if(!this.barChartLabels.includes(row.categorie)) this.barChartLabels.push(row.categorie);
            }

            // Alimentation des données
            this.barChartReady = false
            this.barChartData = [];

            for (let legende of legendes){
              this.barChartData.push({data: [], label: legende, stack: 'a'});
              for (let label of this.barChartLabels){
                this.barChartData[this.barChartData.length - 1].data.push(0)
                for (let row of statNbTickets)
                if (legende === row.entreprise + " - " + row.base && label === row.categorie) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
              }
            }

            this.barChartReady = true;
          })
          this.listSubscription.push(variable);
        }

        // 1er grouppement
        if(this.selectedGroup1 === "Entreprise") {
          // 2nd grouppement
          if(this.selectedGroup2 === 'Etat' || this.selectedGroup2 === 'Impact' || this.selectedGroup2 === 'Type d\'objet' || this.selectedGroup2 === 'Module' || this.selectedGroup2 === 'Ordre de priorité' || this.selectedGroup2 === 'Responsable de dossier') {
            this.legende = 'Nombre total de tickets ouverts cette semaine par entreprise et filtré par ' + this.selectedGroup2.toLowerCase()
            // Application du filtre
            this.statService.filtreEntreprise = []
            this.statService.filtreEntreprise.push(this.selectedGroup2)
            this.statService.filtreEntreprise.push(listeEntrepriseBase)
            console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
            const variable = this.statService.getStatNbTicketsSemaineEntrepriseFiltre().subscribe((res) => {
              // Récupération des données de la table StatNombreTickets
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              // Alimentation légende
              for(let row of statNbTickets) {
                if(!legendes.includes(row.entreprise)) legendes.push(row.entreprise)
                if(!this.barChartLabels.includes(row.categorie)) this.barChartLabels.push(row.categorie);
              }

              // Alimentation des données
              this.barChartReady = false
              this.barChartData = [];

              for (let legende of legendes){
                this.barChartData.push({data: [], label: legende, stack: 'a'});
                for (let label of this.barChartLabels){
                  this.barChartData[this.barChartData.length - 1].data.push(0)
                  for (let row of statNbTickets)
                  if (legende === row.entreprise && label === row.categorie) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                }
              }

              this.barChartReady = true;
            })
            this.listSubscription.push(variable);
          }
          
          // 1er grouppement
          if(this.selectedGroup2 === 'Base') {
            this.legende = 'Nombre total de tickets ouverts cette semaine par entreprise et filtré par ' + this.selectedGroup2.toLowerCase()
            // Application du filtre
            this.statService.filtreEntreprise = []
            this.statService.filtreEntreprise.push(listeEntrepriseBase)
            console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
            const variable = this.statService.getStatNbTicketsSemaineEntrepriseBase().subscribe((res) => {
              // Récupération des données de la table StatNombreTickets
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              // Alimentation légende
              labels = []
              for(let row of statNbTickets) {
                if(!legendes.includes(row.entreprise)) legendes.push(row.entreprise)
                if(!this.barChartLabels.includes(row.base)) this.barChartLabels.push(row.base)
              }

              // Alimentation des données
              this.barChartReady = false
              this.barChartData = [];

              for (let legende of legendes){
                this.barChartData.push({data: [], label: legende, stack: 'a'});
                for (let label of this.barChartLabels){
                  this.barChartData[this.barChartData.length - 1].data.push(0)
                  for (let row of statNbTickets)
                  if (legende === row.entreprise && label === row.base) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                }
              }

              this.barChartReady = true;
            })
            this.listSubscription.push(variable);
          }
        }

        // 1er grouppement
        if (this.selectedGroup1 === 'Base') {
          // 2nd grouppement
          switch(this.selectedGroup2){
            case "Entreprise":
            this.legende = 'Nombre total de tickets ouverts cette semaine par base et filtré par ' + this.selectedGroup2.toLowerCase()
              // Application du filtre
              this.statService.filtreEntreprise = []
              this.statService.filtreEntreprise.push(listeEntrepriseBase)
              console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
              const variable = this.statService.getStatNbTicketsSemaineEntrepriseBase().subscribe((res) => {
                // Récupération des données de la table StatNombreTickets
                var statNbTickets = JSON.parse(JSON.stringify(res)).data
                console.log(statNbTickets, 'statNbTickets')

                // Alimentation légende
                labels = []
                for(let row of statNbTickets) {
                  if(!legendes.includes(row.base)) legendes.push(row.base)
                  if(!this.barChartLabels.includes(row.entreprise)) this.barChartLabels.push(row.entreprise)
                }

                // Alimentation des données
                this.barChartReady = false
                this.barChartData = [];

                for (let legende of legendes){
                  this.barChartData.push({data: [], label: legende, stack: 'a'});
                  for (let label of this.barChartLabels){
                    this.barChartData[this.barChartData.length - 1].data.push(0)
                    for (let row of statNbTickets)
                    if (legende === row.base && label === row.entreprise) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                  }
                }

                this.barChartReady = true;
              })
              this.listSubscription.push(variable);
              break;
          }
        }

        // 1er grouppement
        if (this.selectedGroup1 === 'Etat' || this.selectedGroup1 === 'Impact' || this.selectedGroup1 === 'Type d\'objet' || this.selectedGroup1 === 'Module' || this.selectedGroup1 === 'Ordre de priorité' || this.selectedGroup1 === 'Responsable de dossier') {
          console.log('1er')
          // 2nd grouppement
          if (this.selectedGroup2 === 'Entreprise') {
            this.legende = 'Nombre total de tickets ouverts cette semaine par ' + this.selectedGroup1.toLowerCase() + ' et filtré par ' + this.selectedGroup2.toLowerCase()
            // Application du filtre
            this.statService.filtreEntreprise = []
            this.statService.filtreEntreprise.push(this.selectedGroup1)
            this.statService.filtreEntreprise.push(listeEntrepriseBase)
            console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
            const variable = this.statService.getStatNbTicketsSemaineEntrepriseFiltre().subscribe((res) => {
              // Récupération des données de la table StatNombreTickets
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              // Alimentation légende
              for(let row of statNbTickets) {
                if(!legendes.includes(row.categorie)) legendes.push(row.categorie)
                if(!this.barChartLabels.includes(row.entreprise)) this.barChartLabels.push(row.entreprise);
              }

              // Alimentation des données
              this.barChartReady = false
              this.barChartData = [];

              for (let legende of legendes){
                this.barChartData.push({data: [], label: legende, stack: 'a'});
                for (let label of this.barChartLabels){
                  this.barChartData[this.barChartData.length - 1].data.push(0)
                  for (let row of statNbTickets)
                  if (legende === row.categorie && label === row.entreprise)  this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                }
              }

              this.barChartReady = true;
            })
            this.listSubscription.push(variable);
          }

          // 2nd grouppement
          if (this.selectedGroup2 === 'Entreprise - Base') {
            this.legende = 'Nombre total de tickets ouverts cette semaine par ' + this.selectedGroup1.toLowerCase() + ' et filtré par base'
            // Application du filtre
            this.statService.filtreEntreprise = []
            this.statService.filtreEntreprise.push(this.selectedGroup1)
            this.statService.filtreEntreprise.push(listeEntrepriseBase)
            console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
            const variable = this.statService.getStatNbTicketsSemaineEntrepriseBaseFiltre().subscribe((res) => {
              // Récupération des données de la table StatNombreTickets
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              // Alimentation légende
              for(let row of statNbTickets) {
                if(!legendes.includes(row.categorie)) legendes.push(row.categorie)
                if(!this.barChartLabels.includes(row.entreprise + " - " + row.base)) this.barChartLabels.push(row.entreprise + " - " + row.base);
              }

              // Alimentation des données
              this.barChartReady = false
              this.barChartData = [];

              for (let legende of legendes){
                this.barChartData.push({data: [], label: legende, stack: 'a'});
                for (let label of this.barChartLabels){
                  this.barChartData[this.barChartData.length - 1].data.push(0)
                  for (let row of statNbTickets)
                  if (legende === row.categorie && label === row.entreprise + " - " + row.base) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                }
              }

              this.barChartReady = true
            })
            this.listSubscription.push(variable);
          }
          
          // 2nd grouppement
          if (this.selectedGroup2 !== this.selectedGroup1 && (this.selectedGroup2 === 'Etat' || this.selectedGroup2 === 'Impact' || this.selectedGroup2 === 'Type d\'objet' || this.selectedGroup2 === 'Module' || this.selectedGroup2 === 'Ordre de priorité' || this.selectedGroup2 === 'Responsable de dossier')) {
            this.legende = 'Nombre total de tickets ouverts cette semaine par ' + this.selectedGroup1.toLowerCase() + ' et filtré par ' + this.selectedGroup2.toLowerCase()
            // Application du filtre
            this.statService.filtreEntreprise = []
            this.statService.filtreEntreprise.push(this.selectedGroup1)
            this.statService.filtreEntreprise.push(this.selectedGroup2)
            console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
            const variable = this.statService.getStatNbTicketsSemaineDoubleFiltre().subscribe((res) => {
              // Récupération des données de la table StatNombreTickets
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              // Alimentation légende
              for(let row of statNbTickets) {
                if(this.selectedGroup1 === row.filtre) {
                  if(!legendes.includes(row.categorie)) legendes.push(row.categorie)
                  if(!this.barChartLabels.includes(row.categorie2)) this.barChartLabels.push(row.categorie2);
                }
                else {
                  if(!legendes.includes(row.categorie2)) legendes.push(row.categorie2)
                  if(!this.barChartLabels.includes(row.categorie)) this.barChartLabels.push(row.categorie);
                }
              }

              // Alimentation des données
              this.barChartReady = false
              this.barChartData = []

              for (let legende of legendes){
                this.barChartData.push({data: [], label: legende, stack: 'a'});
                for (let label of this.barChartLabels){
                  this.barChartData[this.barChartData.length - 1].data.push(0)
                  for (let row of statNbTickets)
                  if(this.selectedGroup1 === row.filtre) {
                    if (legende === row.categorie && label === row.categorie2) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                  }
                  else {
                    if (legende === row.categorie2 && label === row.categorie) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                  } 
                }
              }

              this.barChartReady = true;
            })
            this.listSubscription.push(variable);
          }
        }
        break

      case "Periode":
        // 1er grouppement
        if(this.selectedGroup1 === "Entreprise - Base") {
          // 2nd grouppement
          this.legende = 'Nombre total de tickets ouverts durant la période saisie filtré par base et par ' + this.selectedGroup2.toLowerCase()
          // Application du filtre
          this.statService.filtreEntreprise = []
          this.statService.filtreEntreprise.push(this.selectedGroup2)
          this.statService.filtreEntreprise.push(listeEntrepriseBase)
          this.statService.filtreEntreprise.push(dateDebut)
          this.statService.filtreEntreprise.push(dateFin)
          console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
          const variable = this.statService.getStatNbTicketsPeriodeSaisieEntrepriseBaseFiltre().subscribe((res) => {
            // Récupération des données de la table StatNombreTickets
            var statNbTickets = JSON.parse(JSON.stringify(res)).data
            console.log(statNbTickets, 'statNbTickets')

            // Alimentation légende
            for(let row of statNbTickets) {
              if(!legendes.includes(row.entreprise + " - " + row.base)) legendes.push(row.entreprise + " - " + row.base)
              if(!this.barChartLabels.includes(row.categorie)) this.barChartLabels.push(row.categorie);
            }

            // Alimentation des données
            this.barChartReady = false
            this.barChartData = [];

            for (let legende of legendes){
              this.barChartData.push({data: [], label: legende, stack: 'a'});
              for (let label of this.barChartLabels){
                this.barChartData[this.barChartData.length - 1].data.push(0)
                for (let row of statNbTickets)
                if (legende === row.entreprise + " - " + row.base && label === row.categorie) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
              }
            }

            this.barChartReady = true;
          })
          this.listSubscription.push(variable);
        }

        // 1er grouppement
        if(this.selectedGroup1 === "Entreprise") {
          console.log('here0')
          // 2nd grouppement
          if(this.selectedGroup2 === 'Etat' || this.selectedGroup2 === 'Impact' || this.selectedGroup2 === 'Type d\'objet' || this.selectedGroup2 === 'Module' || this.selectedGroup2 === 'Ordre de priorité' || this.selectedGroup2 === 'Responsable de dossier') {
            this.legende = 'Nombre total de tickets ouverts durant la période saisie filtré par entreprise et par ' + this.selectedGroup2.toLowerCase()
            // Application du filtre
            this.statService.filtreEntreprise = []
            this.statService.filtreEntreprise.push(this.selectedGroup2)
            this.statService.filtreEntreprise.push(listeEntrepriseBase)
            this.statService.filtreEntreprise.push(dateDebut)
            this.statService.filtreEntreprise.push(dateFin)
            console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
            const variable = this.statService.getStatNbTicketsPeriodeSaisieEntrepriseFiltre().subscribe((res) => {
              // Récupération des données de la table StatNombreTickets
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              // Alimentation légende
              for(let row of statNbTickets) {
                if(!legendes.includes(row.entreprise)) legendes.push(row.entreprise)
                if(!this.barChartLabels.includes(row.categorie)) this.barChartLabels.push(row.categorie);
              }

              // Alimentation des données
              this.barChartReady = false
              this.barChartData = [];

              for (let legende of legendes){
                this.barChartData.push({data: [], label: legende, stack: 'a'});
                for (let label of this.barChartLabels){
                  this.barChartData[this.barChartData.length - 1].data.push(0)
                  for (let row of statNbTickets)
                  if (legende === row.entreprise && label === row.categorie) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                }
              }

              this.barChartReady = true;
            })
            this.listSubscription.push(variable);
          }
          
          // 1er grouppement
          if(this.selectedGroup2 === 'Base') {
            this.legende = 'Nombre total de tickets ouverts durant la période saisie filtré par base et par ' + this.selectedGroup2.toLowerCase()
            // Application du filtre
            this.statService.filtreEntreprise = []
            this.statService.filtreEntreprise.push(listeEntrepriseBase)
            this.statService.filtreEntreprise.push(dateDebut)
            this.statService.filtreEntreprise.push(dateFin)
            console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
            const variable = this.statService.getStatNbTicketsPeriodeSaisieEntrepriseBase().subscribe((res) => {
              // Récupération des données de la table StatNombreTickets
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              // Alimentation légende
              labels = []
              for(let row of statNbTickets) {
                if(!legendes.includes(row.entreprise)) legendes.push(row.entreprise)
                if(!this.barChartLabels.includes(row.base)) this.barChartLabels.push(row.base)
              }

              // Alimentation des données
              this.barChartReady = false
              this.barChartData = [];

              for (let legende of legendes){
                this.barChartData.push({data: [], label: legende, stack: 'a'});
                for (let label of this.barChartLabels){
                  this.barChartData[this.barChartData.length - 1].data.push(0)
                  for (let row of statNbTickets)
                  if (legende === row.entreprise && label === row.base) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                }
              }

              this.barChartReady = true;
            })
            this.listSubscription.push(variable);
          }
        }

        // 1er grouppement
        if (this.selectedGroup1 === 'Base') {
          // 2nd grouppement
          switch(this.selectedGroup2){
            case "Entreprise":
              this.legende = 'Nombre total de tickets ouverts durant la période saisie filtré par base et par ' + this.selectedGroup2.toLowerCase()
              // Application du filtre
              this.statService.filtreEntreprise = []
              this.statService.filtreEntreprise.push(listeEntrepriseBase)
              this.statService.filtreEntreprise.push(dateDebut)
              this.statService.filtreEntreprise.push(dateFin)
              console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
              const variable = this.statService.getStatNbTicketsPeriodeSaisieEntrepriseBase().subscribe((res) => {
                // Récupération des données de la table StatNombreTickets
                var statNbTickets = JSON.parse(JSON.stringify(res)).data
                console.log(statNbTickets, 'statNbTickets')

                // Alimentation légende
                labels = []
                for(let row of statNbTickets) {
                  if(!legendes.includes(row.base)) legendes.push(row.base)
                  if(!this.barChartLabels.includes(row.entreprise)) this.barChartLabels.push(row.entreprise)
                }

                // Alimentation des données
                this.barChartReady = false
                this.barChartData = [];

                for (let legende of legendes){
                  this.barChartData.push({data: [], label: legende, stack: 'a'});
                  for (let label of this.barChartLabels){
                    this.barChartData[this.barChartData.length - 1].data.push(0)
                    for (let row of statNbTickets)
                    if (legende === row.base && label === row.entreprise) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                  }
                }

                this.barChartReady = true;
              })
              this.listSubscription.push(variable);
              break;
          }
        }

        // 1er grouppement
        if (this.selectedGroup1 === 'Etat' || this.selectedGroup1 === 'Impact' || this.selectedGroup1 === 'Type d\'objet' || this.selectedGroup1 === 'Module' || this.selectedGroup1 === 'Ordre de priorité' || this.selectedGroup1 === 'Responsable de dossier') {
          console.log('1er')
          // 2nd grouppement
          if (this.selectedGroup2 === 'Entreprise') {
            this.legende = 'Nombre total de tickets ouverts durant la période saisie filtré par ' + this.selectedGroup1.toLowerCase() + ' et par ' + this.selectedGroup2.toLowerCase()
            // Application du filtre
            this.statService.filtreEntreprise = []
            this.statService.filtreEntreprise.push(this.selectedGroup1)
            this.statService.filtreEntreprise.push(listeEntrepriseBase)
            this.statService.filtreEntreprise.push(dateDebut)
            this.statService.filtreEntreprise.push(dateFin)
            console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
            const variable = this.statService.getStatNbTicketsPeriodeSaisieEntrepriseFiltre().subscribe((res) => {
              // Récupération des données de la table StatNombreTickets
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              // Alimentation légende
              for(let row of statNbTickets) {
                if(!legendes.includes(row.categorie)) legendes.push(row.categorie)
                if(!this.barChartLabels.includes(row.entreprise)) this.barChartLabels.push(row.entreprise);
              }

              // Alimentation des données
              this.barChartReady = false
              this.barChartData = [];

              for (let legende of legendes){
                this.barChartData.push({data: [], label: legende, stack: 'a'});
                for (let label of this.barChartLabels){
                  this.barChartData[this.barChartData.length - 1].data.push(0)
                  for (let row of statNbTickets)
                  if (legende === row.categorie && label === row.entreprise)  this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                }
              }

              this.barChartReady = true;
            })
            this.listSubscription.push(variable);
          }

          // 2nd grouppement
          if (this.selectedGroup2 === 'Entreprise - Base') {
            this.legende = 'Nombre total de tickets ouverts durant la période saisie filtré par ' + this.selectedGroup1.toLowerCase() + ' et par base'
            // Application du filtre
            this.statService.filtreEntreprise = []
            this.statService.filtreEntreprise.push(this.selectedGroup1)
            this.statService.filtreEntreprise.push(listeEntrepriseBase)
            this.statService.filtreEntreprise.push(dateDebut)
            this.statService.filtreEntreprise.push(dateFin)
            console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
            const variable = this.statService.getStatNbTicketsPeriodeSaisieEntrepriseBaseFiltre().subscribe((res) => {
              // Récupération des données de la table StatNombreTickets
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              // Alimentation légende
              for(let row of statNbTickets) {
                if(!legendes.includes(row.categorie)) legendes.push(row.categorie)
                if(!this.barChartLabels.includes(row.entreprise + " - " + row.base)) this.barChartLabels.push(row.entreprise + " - " + row.base);
              }

              // Alimentation des données
              this.barChartReady = false
              this.barChartData = [];

              for (let legende of legendes){
                this.barChartData.push({data: [], label: legende, stack: 'a'});
                for (let label of this.barChartLabels){
                  this.barChartData[this.barChartData.length - 1].data.push(0)
                  for (let row of statNbTickets)
                  if (legende === row.categorie && label === row.entreprise + " - " + row.base) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                }
              }

              this.barChartReady = true
            })
            this.listSubscription.push(variable);
          }
          
          // 2nd grouppement
          if (this.selectedGroup2 !== this.selectedGroup1 && (this.selectedGroup2 === 'Etat' || this.selectedGroup2 === 'Impact' || this.selectedGroup2 === 'Type d\'objet' || this.selectedGroup2 === 'Module' || this.selectedGroup2 === 'Ordre de priorité' || this.selectedGroup2 === 'Responsable de dossier')) {
            this.legende = 'Nombre total de tickets ouverts durant la période saisie filtré par ' + this.selectedGroup1.toLowerCase() + ' et par ' + this.selectedGroup2.toLowerCase()
            // Application du filtre
            this.statService.filtreEntreprise = []
            this.statService.filtreEntreprise.push(this.selectedGroup1)
            this.statService.filtreEntreprise.push(this.selectedGroup2)
            this.statService.filtreEntreprise.push(dateDebut)
            this.statService.filtreEntreprise.push(dateFin)
            console.log(this.statService.filtreEntreprise, 'filtreEntreprise')
            const variable = this.statService.getStatNbTicketsPeriodeSaisieDoubleFiltre().subscribe((res) => {
              // Récupération des données de la table StatNombreTickets
              var statNbTickets = JSON.parse(JSON.stringify(res)).data
              console.log(statNbTickets, 'statNbTickets')

              // Alimentation légende
              for(let row of statNbTickets) {
                if(this.selectedGroup1 === row.filtre) {
                  if(!legendes.includes(row.categorie)) legendes.push(row.categorie)
                  if(!this.barChartLabels.includes(row.categorie2)) this.barChartLabels.push(row.categorie2);
                }
                else {
                  if(!legendes.includes(row.categorie2)) legendes.push(row.categorie2)
                  if(!this.barChartLabels.includes(row.categorie)) this.barChartLabels.push(row.categorie);
                }
              }

              // Alimentation des données
              this.barChartReady = false
              this.barChartData = []

              for (let legende of legendes){
                this.barChartData.push({data: [], label: legende, stack: 'a'});
                for (let label of this.barChartLabels){
                  this.barChartData[this.barChartData.length - 1].data.push(0)
                  for (let row of statNbTickets)
                  if(this.selectedGroup1 === row.filtre) {
                    if (legende === row.categorie && label === row.categorie2) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                  }
                  else {
                    if (legende === row.categorie2 && label === row.categorie) this.barChartData[this.barChartData.length - 1].data[this.barChartData[this.barChartData.length - 1].data.length - 1] = row.quantite
                  } 
                }
              }

              this.barChartReady = true;
            })
            this.listSubscription.push(variable);
          }
        }
        break
    }
    
  }

  // Affichage du graphe sur le dashboard
  checkCmpInDashboard(){
    let alreadyInDashboard = false;
    for(let cmp of this.dashboardComponents){
      // Vérification si le component est associé au user connecté et s'il s'agit du bon graphe
      if(cmp.userId == Number(this.currentUser.id) && cmp.titreComponent == "BartChartNiveau2") alreadyInDashboard = true;
    }
    return alreadyInDashboard;
  }

  addToDashboard(){
    this.dashboardService.dataToAdd = []
    this.dashboardService.dataToAdd.push({id: 0, userId: Number(this.currentUser.id), titreComponent: "BartChartNiveau2", titreDashboard: "Statistiques", donnees: ""});
    const variable = this.dashboardService.postAddDashboardComponentToServer().subscribe(
      () => {
      console.log('Component du dashboard sauvegardé !');
      },
      (error) => {
      console.log('Erreur ! : ' + error);
      }
    );
    this.listSubscription.push(variable);
  }

  removeFromDashboard(){
    for(let component of this.dashboardComponents){
      if(component.userId == Number(this.currentUser.id) && component.titreComponent == "BartChartNiveau2")  this.dashboardService.idOfDataToDelete = component.id;
    }
    const variable = this.dashboardService.postDeleteDashboardComponentFromServer().subscribe(
      () => {
        console.log('Component du dashboard supprimé !');
      },
      (error) => {
        console.log('Erreur ! : ' + error);
      }
    );
    this.listSubscription.push(variable);
  }
  /* FIN Affichage du graphe sur le dashboard */

  /** FIN Bar Chart methods */
  getUserEntreprise() {
    for (let item of this.listeEntreprises) {
      if (item.entreprise === this.currentUser.entreprise)  return item.entreprise
    }
  }

  getBaseOfEntreprise(entreprise: string) {
    let listBases = []
    for(let item of this.listeEntreprisesBases) {
      if (entreprise === item.entreprise)  listBases.push(item.url)
    }
    return listBases
  }

  getBaseOfEntrepriseUser(entreprise: string) {
    let listBases = []
    for(let item of this.listeEntreprisesBases) {
      if (entreprise === item.entreprise && this.currentUser.base === item.url)  listBases.push(item.url)
    }
    return listBases
  }

  getListEntrepriseBaseSelected(selectedEntreprises: any[],  selectedBases: any[]) {
    let listEB = []
    for(let item of this.listeEntreprisesBases) {
      for(let ese of selectedEntreprises) {
        for(let base of selectedBases) {
          if(item.entreprise === ese && item.url === base)  listEB.push(item)
        }
      }
    }
    return listEB
  }

  getWeek(date: Date ) { 

    // Create a copy of this date object  
    var target  = new Date(date.valueOf());  
    
    // ISO week date weeks start on monday so correct the day number  
    var dayNr   = (date.getDay() + 6) % 7;  

    // Set the target to the thursday of this week so the target date is in the right year  
    target.setDate(target.getDate() - dayNr + 3);  

    // ISO 8601 states that week 1 is the week with january 4th in it  
    var jan4    = new Date(target.getFullYear(), 0, 4);  

    // Number of days between target date and january 4th  
    var diff = Math.abs(target.getTime() - jan4.getTime());
    var dayDiff = Math.ceil(diff / (1000 * 3600 * 24)); 


    // Calculate week number: Week 1 (january 4th) plus the number of weeks between target date and january 4th    
    var weekNr = 1 + Math.ceil(dayDiff / 7);    

    return weekNr;    

  }

}
