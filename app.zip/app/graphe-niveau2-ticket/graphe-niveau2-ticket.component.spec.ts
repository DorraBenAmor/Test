import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GrapheNiveau2TicketComponent } from './graphe-niveau2-ticket.component';

describe('GrapheNiveau2TicketComponent', () => {
  let component: GrapheNiveau2TicketComponent;
  let fixture: ComponentFixture<GrapheNiveau2TicketComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GrapheNiveau2TicketComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GrapheNiveau2TicketComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
