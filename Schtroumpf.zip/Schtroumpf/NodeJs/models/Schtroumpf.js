const mongoose = require('mongoose');

var Schtroumpf = mongoose.model('Schtroumpf', {
    
    login: { type: String },
    pw: { type: String },
    name: { type: String },
    age: { type: String },
    family: { type: String },
    race: { type: String },
    food: { type: String }
});

module.exports = { Schtroumpf };
