import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Schtroumpf } from '../shared/schtroumpf.model';
import { SchtroumpfService } from '../shared/schtroumpf.service';



@Component({
  selector: 'app-schtroumpf',
  templateUrl: './schtroumpf.component.html',
  styleUrls: ['./schtroumpf.component.scss'],
  providers: [SchtroumpfService],
})

export class SchtroumpfComponent implements OnInit {

  constructor(public SchtroumpfService: SchtroumpfService, private route: Router) { }

  submitted:boolean= false ;
  
  resetForm(form?: NgForm) {
    if (form)
      form.reset();
    this.SchtroumpfService.selectedSchtroumpf = {
      _id: "",
      login:"",
      pw:"",
      name: "",
      age: "",
      family: "",
      race:"",
      food:""
    
    }
  }
  ngOnInit() {
   this.resetForm();
  this.refreshSchtroumpfList();
  }

 

  onSubmit(form: NgForm) {

    if (form.value._id == "") {
      this.submitted=true;
      console.log("try1");
      this.SchtroumpfService.postSchtroumpf(form.value).subscribe((res) => {
        this.resetForm(form);
        console.log("done1");
        this.refreshSchtroumpfList();
        this.route.navigate(['connexion']);
     
     
      });
    }
    else {
      console.log("try2");
      this.SchtroumpfService.putSchtroumpf(form.value).subscribe((res) => {
        this.resetForm(form);
        console.log("done2");
        this.refreshSchtroumpfList();
      
      });
    }
  }

  refreshSchtroumpfList() {
    this.SchtroumpfService.getSchtroumpfList().subscribe((res) => {
      this.SchtroumpfService.Schtroumpfs = res as Schtroumpf[];
    });
  }

  onEdit(emp: Schtroumpf) {
    this.SchtroumpfService.selectedSchtroumpf = emp;
    this.submitted=false;
  }

  onDelete(_id: string, form: NgForm) {
    if (confirm('Are you sure to delete this record ?') == true) {
      this.SchtroumpfService.deleteSchtroumpf(_id).subscribe((res) => {
        this.refreshSchtroumpfList();
        this.resetForm(form);

      });
    }
  }

}



