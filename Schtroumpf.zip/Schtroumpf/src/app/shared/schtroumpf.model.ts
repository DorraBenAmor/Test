export class Schtroumpf {
    _id: string="";
    login: string="" ;
    pw: string="";
    name:  string ="" ;
    age:   string ="" ;
    family: string ="";
    race: string="";
    food: string ="" ;
}
