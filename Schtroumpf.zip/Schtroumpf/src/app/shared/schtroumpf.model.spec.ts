import { Schtroumpf } from './schtroumpf.model';

describe('Schtroumpf', () => {
  it('should create an instance', () => {
    expect(new Schtroumpf()).toBeTruthy();
  });
});
