import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SchtroumpfComponent } from './schtroumpf/schtroumpf.component';
import { SchtroumpfService } from './shared/schtroumpf.service';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ConnexionComponent } from './connexion/connexion.component';



const appRoutes: Routes = [
     { path: 'Inscription', component: SchtroumpfComponent},
     {path: 'connexion', component: ConnexionComponent
    }
     
];
@NgModule({
  declarations: [
    AppComponent,
    SchtroumpfComponent,
    ConnexionComponent
  ],
  imports: [
    RouterModule.forRoot(appRoutes),
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule,
    HttpClientModule
  ],
  providers: [
    SchtroumpfService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
