import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Schtroumpf } from '../shared/schtroumpf.model';
import { SchtroumpfService } from '../shared/schtroumpf.service';

@Component({
  selector: 'app-connexion',
  templateUrl: './connexion.component.html',
  styleUrls: ['./connexion.component.scss'],
  providers:[SchtroumpfService]
})
export class ConnexionComponent implements OnInit {

  constructor(public SchtroumpfService: SchtroumpfService, private route: Router) { }

  login: string="";
  pw:string="";
  submitted2=true;
  ngOnInit(): void {
  }

  
 verifConnexion() {
   
  var test=false;
    this.SchtroumpfService.getSchtroumpfList().subscribe((res:any) => {
    var i=0

 
     while (i<res.length && test===false) 
      {i++;
        if(res[i].login===this.login && res[i].pw===this.pw)
        {
          test=true;
          console.log(test);
          return test;
         

        }
        console.log(res[i]);
        console.log(test);

      }

    
    });
    return test;
  }

  handleLogin(value: string)
  {
this.login=value;
console.log(this.login);
  }
  handlepw(value: string)
  {
    this.pw=value;
    console.log(this.pw);
    this.verifConnexion();
  }


  onSubmit()
  {
    
    if(this.verifConnexion()===true)
    {this.submitted2=true;}
    else
    {
      
      this.submitted2=false;
      this.route.navigate(['inscription']);
    


  }
}
}

